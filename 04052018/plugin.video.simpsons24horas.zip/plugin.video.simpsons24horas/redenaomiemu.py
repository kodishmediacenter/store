import re
import requests
#import xbmc
import BeautifulSoup
from BeautifulSoup import BeautifulSoup
from urlparse import unquote



def naomi_eat(link):
    pagina_do_site = requests.get(link)
    soup = BeautifulSoup(pagina_do_site.text, "html.parser")
    i = 0
    for item2 in soup.find_all('script', attrs={'type':'text/javascript'}):
        i = i + 1
        vitem2 = str(item2)
        tamc = len(vitem2)
        resolvaurl =""+vitem2+""
        if i == 2:
            link = str(re.findall("file:(.*).mp4",resolvaurl))
            nlink = link[4:tamc].replace("/videos/']","").replace("/ondemand/']","")
            return nlink
        
        #print(resolvaurl)
       
    



