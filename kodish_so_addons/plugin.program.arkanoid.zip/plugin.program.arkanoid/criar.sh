cp -r dosbox-0.74.conf "/home/kodi/.dosbox/"
