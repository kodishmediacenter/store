
# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.CorujinhaSP'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')





def addDir(title,url,icons):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} ) 
    liz.setArt({'thumb':icons,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':
    YOUTUBE_CHANNEL_ID1 = "channel/UCvtEdUH19LmhMLRAAy8JQWw/playlists"
    icon1 = "https://yt3.ggpht.com/a/AATXAJy5QvaOQwhQKWBYFL6saN6iMcXwlUYLMAn0kA=s256-c-k-c0xffffffff-no-rj-mo"
    
    YOUTUBE_CHANNEL_ID2 = "channel/UCH3p_wPirx69UZX5EhFRlyg/playlists"
    icon2 = "https://yt3.ggpht.com/a/AATXAJydHRGM9xCNah1V8taPLZRQljTjt-yFxXlzzA=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID3 = "channel/UCUUEpvwJfOktmiwhc2DIOeA/playlists"
    icon3 = "https://yt3.ggpht.com/a/AATXAJz4yYz-jezGQ7KjFn9r6TN4nZArFY2HeBj8ww=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID4 = "channel/UCk_RcE3XYJZ0tt3BYslHuRw/playlists"
    icon4 = "https://yt3.ggpht.com/a/AATXAJy9_FTaUc96Sg76WPKIwM5K-5cUuFT8EgkY6g=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID5 = "channel/UCGoTOxSdG6WxSXWWjFF1OTQ/playlists"
    icon5 = "https://yt3.ggpht.com/a/AATXAJwuwUgNnTvWAlSybKB8GozAMKf-fXftLpWNcA=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID6 = "channel/UCnAxhqL43T3XjagjZpYoQAA/playlists"
    icon6 = "https://yt3.ggpht.com/a/AATXAJxfnmb9WkptGgsAL_QI4D2qH85JWZeVl9Kacw=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID7 = "channel/UCRhKhbPbQvBf3RgWcxNpZZA/playlists"
    icon7 = "https://yt3.ggpht.com/a/AATXAJzYohCC0_N0xo82CQm6x21aUmB1WUWV2UBSyw=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID8 = "channel/UCBEVOzstEvR_wIncmnG7gPg/playlists"
    icon8 = "https://yt3.ggpht.com/a/AATXAJzkTwH734MUnFTEyE2SsyMOVkXFf8IozTl9ag=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID9 = "channel/UCDcQT0hAplpsUOAmUaB81BQ/playlists"
    icon9 = "https://yt3.ggpht.com/a/AATXAJzaN8G2CkmRisVeLMNGqdl63ieKF8jElmm2FQ=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID10 = "channel/UCt2_DSCq7omH3cdFYqA7g7Q/playlists"
    icon10 = "https://yt3.ggpht.com/a/AATXAJzO6NpTflqRGoqlxgNI0UOZgdeGnfS42AcD_A=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID11 = "channel/UCkObaGgM8jacXZhoBtzOtDQ/playlists"
    icon11 = "https://yt3.ggpht.com/a/AATXAJwvxyZmMeeHov_Z83qACQsllC4sL94wrTZz=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID12 = "channel/UCM62zdmQ2R3VOR6v6Va70aw/playlists"
    icon12 = "https://yt3.ggpht.com/a/AATXAJxCewWODEM1n8_6zvikmgRO3GBoLbsccWLjFQ=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID13 = "channel/UCJF8dn7OAkMgnHeRxj-yRNA/playlists"
    icon13 = "https://yt3.ggpht.com/a/AATXAJz1OxDQFd0dHxOv3Q1hunlI7iI4mIiFfGaO6g=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID14 = "channel/UC-8VgK8z0FQP9irloXmrtzg/playlists"
    icon14 = "https://yt3.ggpht.com/a/AATXAJx4lCO2_LdwdnuJuPp5RdA9ZFllx5rhKoEc=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID15 = "channel/UCBL2tfrwhEhX52Dze_aO3zA/live"
    icon15 = "https://yt3.ggpht.com/a/AATXAJw1i2IhUf_0WqzJCaXOK9-3BDwU6FB2EavxOw=s256-c-k-c0xffffffff-no-rj-mo"

    #YOUTUBE_CHANNEL_ID16 = ""
    #icon16 = ""

   
    

    addDir(title="Creche",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",icons=icon1)
    addDir(title="1o ano EF - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",icons=icon2)
    addDir(title="2o ano EF - CMSP             ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",icons=icon3)
    addDir(title="3o ano EF - CMSP              ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",icons=icon4)
    addDir(title="4o ano EF - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",icons=icon5)
    addDir(title="5o ano EF - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",icons=icon6)
    addDir(title="6o ano EF - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID7+"/",icons=icon7)
    addDir(title="7o ano EF - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID8+"/",icons=icon8)
    addDir(title="8o ano EF - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID9+"/",icons=icon9)
    addDir(title="9o ano EF - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID10+"/",icons=icon10)
    addDir(title="1o ano EM - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID11+"/",icons=icon11)
    addDir(title="2o ano EM - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID12+"/",icons=icon12)
    addDir(title="3o ano EM - CMSP               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID13+"/",icons=icon13)
    addDir(title="CMSP - EJA                     ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID14+"/",icons=icon14)
   # addDir(title="Ao Vivo Univesp                ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID15+"/",icons=icon15)
   # addDir(title="Ao Vivo TV Educação                     ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID16+"/",icons=icon16)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
