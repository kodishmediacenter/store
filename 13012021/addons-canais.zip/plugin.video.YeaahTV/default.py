# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv3.zcast.com.br/yeeaah/yeeaah/chunklist.m3u8"


xbmc.Player().play(url)