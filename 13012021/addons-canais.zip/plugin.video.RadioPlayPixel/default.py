# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "http://stream.zeno.fm/8g81y3e51k8uv.m3u"


xbmc.Player().play(url)