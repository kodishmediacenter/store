# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://5c483b9d1019c.streamlock.net/8078/8078/chunklist_w1660411812.m3u8"


xbmc.Player().play(url)