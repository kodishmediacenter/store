# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://59f1cbe63db89.streamlock.net:1443/canal/_definst_/canal/chunklist_w196292492.m3u8"


xbmc.Player().play(url)