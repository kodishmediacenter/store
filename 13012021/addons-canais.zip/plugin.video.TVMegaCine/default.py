# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/reconsatcine/reconsatcine/chunklist_w1246757685.m3u8"


xbmc.Player().play(url)