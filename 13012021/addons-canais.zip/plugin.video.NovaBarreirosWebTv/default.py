# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://5d82644094cc0.streamlock.net/8026/8026/chunklist_w1879209005.m3u8"


xbmc.Player().play(url)