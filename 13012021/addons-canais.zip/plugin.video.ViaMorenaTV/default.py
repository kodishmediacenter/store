# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://59f1cbe63db89.streamlock.net:1443/cleuzaviamorena/_definst_/cleuzaviamorena/chunklist_w1790442423.m3u8"


xbmc.Player().play(url)