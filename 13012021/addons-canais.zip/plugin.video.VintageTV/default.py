# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvstm.com/rogerio4248/rogerio4248/chunklist_w465794776.m3u8"


xbmc.Player().play(url)