# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv3.samcast.com.br/marcosroberto5912/marcosroberto5912/chunklist_w749717003.m3u8"


xbmc.Player().play(url)