# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://studio.genialltv.com/live/Stream1_360p/chunklist_w883469436.m3u8"


xbmc.Player().play(url)