# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/animetv/animetv/chunklist_w1327383665.m3u8"


xbmc.Player().play(url)