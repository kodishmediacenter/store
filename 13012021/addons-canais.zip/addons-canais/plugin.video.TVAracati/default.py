# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://5e36c064a2f6a.streamlock.net:1936/8554/8554/playlist.m3u8"


xbmc.Player().play(url)
