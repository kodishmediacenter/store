# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv2.zcast.com.br/oney7654/oney7654/chunklist_w117317781.m3u8"


xbmc.Player().play(url)