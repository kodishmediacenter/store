# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url =  "https://centurylink.br.cdn.booyah.live/hls/1000027/34850987_1080.m3u8"
url2 = "https://aws-br.cdn.booyah.live/hls/1000027/34850987_1080.m3u8"

dialog = xbmcgui.Dialog()
link = dialog.select('Loading', ['Rota 1','Rota 2'])

if link == "0":
    xbmc.Player().play(url)

if link == "1":
    xbmc.Player().play(url2)