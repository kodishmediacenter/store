# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/manchetebahia/manchetebahia/chunklist_w1967542387.m3u8"


xbmc.Player().play(url)