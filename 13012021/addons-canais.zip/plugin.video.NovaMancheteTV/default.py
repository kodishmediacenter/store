# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv5.zcast.com.br/tvmanchete/tvmanchete/chunklist_w967550760.m3u8"


xbmc.Player().play(url)