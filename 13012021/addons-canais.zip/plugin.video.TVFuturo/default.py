# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://streaming03.zas.media/tvfuturo/tvfuturo/chunklist_w605692760.m3u8"


xbmc.Player().play(url)