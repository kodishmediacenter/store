# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvstm.com/tvserie3/tvserie3/chunklist_w1062191621.m3u8"


xbmc.Player().play(url)