# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://centurylink.br.cdn.booyah.live/hls/1000026/34850987_1080.m3u8"


xbmc.Player().play(url)