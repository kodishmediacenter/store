# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint
import base64

tunel = "UmVmZXJlcj1odHRwOi8vd3d3LnJlZGVjYW5haXMuY29tLmJyLw=="
ftunel = base64.b64decode(tunel)


addonID = 'plugin.video.thewalkingdead'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,107)
ieps = 107 - eps

eng2sp = {1:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT01EP01.mp4|"+ftunel+"",
2:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT01EP02.mp4|"+ftunel+"",
3:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT01EP03.mp4|"+ftunel+"",
4:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT01EP04.mp4|"+ftunel+"",
5:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT01EP05.mp4|"+ftunel+"",
6:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT01EP06.mp4|"+ftunel+"",
7:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP01.mp4|"+ftunel+"",
8:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP02.mp4|"+ftunel+"",
9:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP03.mp4|"+ftunel+"",
10:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP04.mp4|"+ftunel+"",
11:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP05.mp4|"+ftunel+"",
12:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP06.mp4|"+ftunel+"",
13:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP07.mp4|"+ftunel+"",
14:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP08.mp4|"+ftunel+"",
15:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP09.mp4|"+ftunel+"",
16:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP10.mp4|"+ftunel+"",
17:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP11.mp4|"+ftunel+"",
18:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP12.mp4|"+ftunel+"",
19:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TWDT02EP13.mp4|"+ftunel+"",
20:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP01.mp4|"+ftunel+"",
21:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP02.mp4|"+ftunel+"",
22:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP03.mp4|"+ftunel+"",
23:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP04.mp4|"+ftunel+"",
24:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP05.mp4|"+ftunel+"",
25:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP06.mp4|"+ftunel+"",
26:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP07.mp4|"+ftunel+"",
27:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP08.mp4|"+ftunel+"",
28:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP09.mp4|"+ftunel+"",
29:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP10.mp4|"+ftunel+"",
30:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP11.mp4|"+ftunel+"",
31:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP12.mp4|"+ftunel+"",
32:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP13.mp4|"+ftunel+"",
33:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP14.mp4|"+ftunel+"",
34:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP15.mp4|"+ftunel+"",
35:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer04/ondemand/TWDT03EP16.mp4|"+ftunel+"",
36:"http://v5.ec.cx/RedeCanais/RCServer05/ondemand/TWDT04EP01.mp4|"+ftunel+"",
37:"http://v5.ec.cx/RedeCanais/RCServer05/ondemand/TWDT04EP02.mp4|"+ftunel+"",
38:"http://v5.ec.cx/RedeCanais/RCServer05/ondemand/TWDT04EP03.mp4|"+ftunel+"",
39:"http://v5.ec.cx/RedeCanais/RCServer05/ondemand/TWDT04EP04.mp4|"+ftunel+"",
40:"http://v5.ec.cx/RedeCanais/RCServer05/ondemand/TWDT04EP05.mp4|"+ftunel+"",
41:"http://v5.ec.cx/RedeCanais/RCServer05/ondemand/TWDT04EP06.mp4|"+ftunel+"",
42:"http://v5.ec.cx/RedeCanais/RCServer05/ondemand/TWDT04EP07.mp4|"+ftunel+"",
43:"http://v5.ec.cx/RedeCanais/RCServer05/ondemand/TWDT04EP08.mp4|"+ftunel+"",
44:"http://v1.ec.cx/RedeCanais/RedeCanais/RCServer06/ondemand/TWDT04EP09.mp4|"+ftunel+"",
45:"http://v1.ec.cx/RedeCanais/RedeCanais/RCServer06/ondemand/TWDT04EP10.mp4|"+ftunel+"",
46:"http://v1.ec.cx/RedeCanais/RedeCanais/RCServer06/ondemand/TWDT04EP11.mp4|"+ftunel+"",
47:"http://v1.ec.cx/RedeCanais/RedeCanais/RCServer06/ondemand/TWDT04EP12.mp4|"+ftunel+"",
48:"http://v1.ec.cx/RedeCanais/RedeCanais/RCServer06/ondemand/TWDT04EP13.mp4|"+ftunel+"",
49:"http://v1.ec.cx/RedeCanais/RedeCanais/RCServer06/ondemand/TWDT04EP14.mp4|"+ftunel+"",
50:"http://v1.ec.cx/RedeCanais/RedeCanais/RCServer06/ondemand/TWDT04EP15.mp4|"+ftunel+"",
51:"http://v1.ec.cx/RedeCanais/RedeCanais/RCServer07/ondemand/TWDT04EP16.mp4|"+ftunel+"",          
52:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP01.mp4|"+ftunel+"",
53:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP02.mp4|"+ftunel+"",
54:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP03.mp4|"+ftunel+"",
55:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP04.mp4|"+ftunel+"",
56:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP05.mp4|"+ftunel+"",
57:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP06.mp4|"+ftunel+"",
58:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP07.mp4|"+ftunel+"",
59:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP08.mp4|"+ftunel+"",
60:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP09.mp4|"+ftunel+"",
61:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP10.mp4|"+ftunel+"",
62:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP11.mp4|"+ftunel+"",
63:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP12.mp4|"+ftunel+"",
64:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP13.mp4|"+ftunel+"",
65:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP14.mp4|"+ftunel+"",
66:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP15.mp4|"+ftunel+"",
67:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT05EP16.mp4|"+ftunel+"",
68:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT06EP01.mp4|"+ftunel+"",
69:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT06EP02.mp4|"+ftunel+"",
70:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer09/ondemand/TWDT06EP03.mp4|"+ftunel+"",
71:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP04.mp4|"+ftunel+"",
72:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP05.mp4|"+ftunel+"",
73:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP06.mp4|"+ftunel+"",
74:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP07.mp4|"+ftunel+"",
75:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP08.mp4|"+ftunel+"",
76:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP09.mp4|"+ftunel+"",
77:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP10-.mp4|"+ftunel+"",
78:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP11.mp4|"+ftunel+"",
79:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP12.mp4|"+ftunel+"",
80:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP13.mp4|"+ftunel+"",
81:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP14.mp4|"+ftunel+"",
82:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP15.mp4|"+ftunel+"",
83:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer10/ondemand/TWDT06EP16.mp4|"+ftunel+"",
84:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP01.mp4|"+ftunel+"",
85:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP02.mp4|"+ftunel+"",
86:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP03.mp4|"+ftunel+"",
87:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP04-up.mp4|"+ftunel+"",
88:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP05.mp4|"+ftunel+"",
89:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP06.mp4|"+ftunel+"",
90:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP07.mp4|"+ftunel+"",
91:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP08.mp4|"+ftunel+"",
92:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP09.mp4|"+ftunel+"",
93:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP10.mp4|"+ftunel+"",
94:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP11.mp4|"+ftunel+"",
95:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP12.mp4|"+ftunel+"",
96:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP13.mp4|"+ftunel+"",
97:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP14.mp4|"+ftunel+"",
98:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP15.mp4|"+ftunel+"",
99:"http://v4.ec.cx/RedeCanais/RedeCanais/RCServer11/ondemand/TWDT07EP16.mp4|"+ftunel+"",
100:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer13/ondemand/TWDT08EP01.mp4|"+ftunel+"",
101:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer13/ondemand/TWDT08EP02.mp4|"+ftunel+"",
102:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer13/ondemand/TWDT08EP03.mp4|"+ftunel+"",
103:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer13/ondemand/TWDT08EP04.mp4|"+ftunel+"",
104:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer13/ondemand/TWDT08EP05.mp4|"+ftunel+"",
105:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer13/ondemand/TWDT08EP06.mp4|"+ftunel+"",
106:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer13/ondemand/TWDT08EP07.mp4|"+ftunel+"",
107:"http://v7.ec.cx/RedeCanais/RedeCanais/RCServer13/ondemand/TWDT08EP08.mp4|"+ftunel+"",
}

        
for j in range(ieps,(ieps+30)):
        
        file = open(""+m3u+"","a")
        file.write(eng2sp[j])
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

