# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint
import base64

tunel = "UmVmZXJlcj1odHRwOi8vd3d3LnJlZGVjYW5haXMuY29tLmJyLw=="
ftunel = base64.b64decode(tunel)


addonID = 'plugin.video.chaves24horas'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,170)
ieps = 170 - eps

eng2sp = {1:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/19302ca6.mp4|"+ftunel+"",
2:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/fd63d6a3.mp4|"+ftunel+"",
3:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4efbbddc.mp4|"+ftunel+"",                            
4:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/385bae20.mp4|"+ftunel+"",
5:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/95e7a1e7.mp4|"+ftunel+"",
6:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/468978c5.mp4|"+ftunel+"",
7:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a56f0d96.mp4|"+ftunel+"",
8:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3f727aa7.mp4|"+ftunel+"",
9:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/23e730b5.mp4|"+ftunel+"",
10:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0f500990.mp4|"+ftunel+"",
11:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/98ceaf00.mp4|"+ftunel+"",
12:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c3f335cc.mp4|"+ftunel+"",
13:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b8e84ed6.mp4|"+ftunel+"",
14:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a38cd93a.mp4|"+ftunel+"",
15:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6412cd6d.mp4|"+ftunel+"",
16:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/abb59149.mp4|"+ftunel+"",
17:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1f08eb61.mp4|"+ftunel+"",
18:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7eef4b16.mp4|"+ftunel+"",
19:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1699e490.mp4|"+ftunel+"",
20:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/14bda406.mp4|"+ftunel+"",
21:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/72e293ba.mp4|"+ftunel+"",
22:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2d6f88f3.mp4|"+ftunel+"",
23:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8544a079.mp4|"+ftunel+"",
24:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5152a234.mp4|"+ftunel+"",
25:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/fa8c76cc.mp4|"+ftunel+"",
26:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b0a02715.mp4|"+ftunel+"",
27:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/850ef314.mp4|"+ftunel+"",
28:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d09de6f6.mp4|"+ftunel+"",
29:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a56311d9.mp4|"+ftunel+"",
30:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/76ac45c0.mp4|"+ftunel+"",
31:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9a96118e.mp4|"+ftunel+"",
32:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3b2374c1.mp4|"+ftunel+"",
33:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/808c0163.mp4|"+ftunel+"",
34:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/17f360dd.mp4|"+ftunel+"",
35:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/cc826836.mp4|"+ftunel+"",
36:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/64749e66.mp4|"+ftunel+"",
37:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9854af7a.mp4|"+ftunel+"",
38:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/da546d5c.mp4|"+ftunel+"",
39:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6642ce7d.mp4|"+ftunel+"",
40:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3e2722f7.mp4|"+ftunel+"",
41:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b68186ae.mp4|"+ftunel+"",
42:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0b58dbe7.mp4|"+ftunel+"",
43:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/26afb3ce.mp4|"+ftunel+"",
44:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ee23b315.mp4|"+ftunel+"",
45:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d0fba958.mp4|"+ftunel+"",
46:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/453ab3d6.mp4|"+ftunel+"",
47:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/495a46cd.mp4|"+ftunel+"",
48:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b0e2df45.mp4|"+ftunel+"",
49:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d4ad7838.mp4|"+ftunel+"",
50:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1ce618b4.mp4|"+ftunel+"",
51:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3ed85ee2.mp4|"+ftunel+"",
52:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6d73cb17.mp4|"+ftunel+"",
53:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2cb8f2cf.mp4|"+ftunel+"",
54:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5e4971fe.mp4|"+ftunel+"",
55:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3cefff35.mp4|"+ftunel+"",
56:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/90a98a72.mp4|"+ftunel+"",
57:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8dd3b7ba.mp4|"+ftunel+"",
58:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8820ee38.mp4|"+ftunel+"",
59:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/bd280f31.mp4|"+ftunel+"",
60:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/33efc051.mp4|"+ftunel+"",
61:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b90c45b0.mp4|"+ftunel+"",
62:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/52e9e0e3.mp4|"+ftunel+"",
63:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0908825a.mp4|"+ftunel+"",
64:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8ff1b195.mp4|"+ftunel+"",
65:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/54ae6a0c.mp4|"+ftunel+"",
66:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/983bc014.mp4|"+ftunel+"",
67:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/60154eb3.mp4|"+ftunel+"",
68:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1ba68fce.mp4|"+ftunel+"",
69:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/256e8cb7.mp4|"+ftunel+"",
70:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ea02ebb6.mp4|"+ftunel+"",
71:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0e802e03.mp4|"+ftunel+"",
72:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/22e7f2cf.mp4|"+ftunel+"",
73:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/56cd67c8.mp4|"+ftunel+"",
74:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/cc5c7c61.mp4|"+ftunel+"",
75:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b5c9ced0.mp4|"+ftunel+"",
76:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9a4e0146.mp4|"+ftunel+"",
77:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/566d6fcf.mp4|"+ftunel+"",
78:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5200f700.mp4|"+ftunel+"",
79:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/75153908.mp4|"+ftunel+"",
80:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a65d243e.mp4|"+ftunel+"",
81:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2ad8e80b.mp4|"+ftunel+"",
82:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7e9c0021.mp4|"+ftunel+"",
83:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5b9d59ce.mp4|"+ftunel+"",
84:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2bfb3126.mp4|"+ftunel+"",
85:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/62975a34.mp4|"+ftunel+"",
86:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0fb9a2f3.mp4|"+ftunel+"",
87:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/92e851c6.mp4|"+ftunel+"",
88:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4178bc37.mp4|"+ftunel+"",
89:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ba4686f9.mp4|"+ftunel+"",
90:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2e5702c2.mp4|"+ftunel+"",
91:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/726db9f2.mp4|"+ftunel+"",
92:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d12de135.mp4|"+ftunel+"",
93:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b842991a.mp4|"+ftunel+"",
94:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0e63e384.mp4|"+ftunel+"",
95:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ccba9742.mp4|"+ftunel+"",
96:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/309398ba.mp4|"+ftunel+"",
97:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4d2a52ad.mp4|"+ftunel+"",
98:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f9759dff.mp4|"+ftunel+"",
99:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ebe696c3.mp4|"+ftunel+"",
100:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/dc561706.mp4|"+ftunel+"",
101:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d7828de2.mp4|"+ftunel+"",
102:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b1f7b5ae.mp4|"+ftunel+"",
103:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/452badda.mp4|"+ftunel+"",
104:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/53311bee.mp4|"+ftunel+"",
105:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b1f7b5ae.mp4|"+ftunel+"",
106:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3867b694.mp4|"+ftunel+"",
107:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/30a0d926.mp4|"+ftunel+"",
108:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/01a9b0ce.mp4|"+ftunel+"",
109:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/413c9ed6.mp4|"+ftunel+"",
110:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1cce2d4d.mp4|"+ftunel+"",
111:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/57a61f99.mp4|"+ftunel+"",
112:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/420f22af.mp4|"+ftunel+"",
113:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/475deb16.mp4|"+ftunel+"",
114:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a8126c11.mp4|"+ftunel+"",
115:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f1eb1170.mp4|"+ftunel+"",
116:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/bb354e7d.mp4|"+ftunel+"",
117:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2fd7c153.mp4|"+ftunel+"",
118:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1ceee9d2.mp4|"+ftunel+"",
119:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3da3529c.mp4|"+ftunel+"",
120:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a5799a37.mp4|"+ftunel+"",
121:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b67ab490.mp4|"+ftunel+"",
122:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a05d3d80.mp4|"+ftunel+"",
123:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/af04c956.mp4|"+ftunel+"",
124:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/af1c2783.mp4|"+ftunel+"",
125:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c351e732.mp4|"+ftunel+"",
126:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a5b3d8e6.mp4|"+ftunel+"",
127:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c0901170.mp4|"+ftunel+"",
128:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0ec14f1c.mp4|"+ftunel+"",
129:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f52fb5b5.mp4|"+ftunel+"",
130:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/42ee0387.mp4|"+ftunel+"",
131:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/76d0d92c.mp4|"+ftunel+"",
132:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/fa357d10.mp4|"+ftunel+"",
133:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a1db2c27.mp4|"+ftunel+"",
134:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d8e1f094.mp4|"+ftunel+"",
135:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9e72a823.mp4|"+ftunel+"",
136:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c75d5bd7.mp4|"+ftunel+"",
137:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/dd30eed0.mp4|"+ftunel+"",
138:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d48b5929.mp4|"+ftunel+"",
139:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2eea57eb.mp4|"+ftunel+"",
140:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/52ee7471.mp4|"+ftunel+"",
141:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3516535a.mp4|"+ftunel+"",
142:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e02eeb6e.mp4|"+ftunel+"",
143:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/130e4742.mp4|"+ftunel+"",
144:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/fefa3ed5.mp4|"+ftunel+"",
145:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a16824c9.mp4|"+ftunel+"",
146:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b7e8891d.mp4|"+ftunel+"",
147:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a58f8c9e.mp4|"+ftunel+"",
148:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/76ffb021.mp4|"+ftunel+"",
149:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b05a00ee.mp4|"+ftunel+"",
150:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/06d8464c.mp4|"+ftunel+"",
151:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9a4307fc.mp4|"+ftunel+"",
152:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7db6e3ec.mp4|"+ftunel+"",
153:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/61efe8b4.mp4|"+ftunel+"",
154:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/fbc65ca5.mp4|"+ftunel+"",
155:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/683e7d62.mp4|"+ftunel+"",
156:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d36aa766.mp4|"+ftunel+"",
157:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b1366d48.mp4|"+ftunel+"",
158:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/27edf991.mp4|"+ftunel+"",
159:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f83aa3f9.mp4|"+ftunel+"",
160:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/965f721f.mp4|"+ftunel+"",
161:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1d392059.mp4|"+ftunel+"",
162:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8bc03f51.mp4|"+ftunel+"",
163:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/966a26f9.mp4|"+ftunel+"",
164:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8cbc9c05.mp4|"+ftunel+"",
165:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/bfff7b26.mp4|"+ftunel+"",
166:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a0da6ca7.mp4|"+ftunel+"",
167:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/fceb5c1e.mp4|"+ftunel+"",
168:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7270a1b4.mp4|"+ftunel+"",
169:"http://v2.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f11f72e6.mp4|"+ftunel+"",
}

        
for j in range(ieps,(ieps+30)):
        
        file = open(""+m3u+"","a")
        file.write(eng2sp[j])
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

