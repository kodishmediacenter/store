# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint
import base64

addonID = 'plugin.video.picapau24horas'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'

tunel = "UmVmZXJlcj1odHRwOi8vd3d3LnJlZGVjYW5haXMuY29tLmJyLw=="
ftunel = base64.b64decode(tunel)


addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,193)
eng2sp = {1:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0569af54.mp4|"+ftunel+"|"+ftunel+"",
2:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/52dee7b0.mp4|"+ftunel+"",
3:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/49603cf0.mp4|"+ftunel+"",
4:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/15f2abb6.mp4|"+ftunel+"",
5:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a5fa4a86.mp4|"+ftunel+"",
6:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5e67a3eb.mp4|"+ftunel+"",
7:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ef29e24f.mp4|"+ftunel+"",
8:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/337a13e1.mp4|"+ftunel+"",
9:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7b3d7702.mp4|"+ftunel+"",
10:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0cf08560.mp4|"+ftunel+"",
11:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f0595f94.mp4|"+ftunel+"",
12:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2b3e0823.mp4|"+ftunel+"",
13:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5e888720.mp4|"+ftunel+"",
14:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a74f2b13.mp4|"+ftunel+"",
15:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7a39fd4f.mp4|"+ftunel+"",
16:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5502ace9.mp4|"+ftunel+"",
17:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2b881c24.mp4|"+ftunel+"",
18:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/76aab751.mp4|"+ftunel+"",
19:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/57efdbac.mp4|"+ftunel+"",
20:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ca95b690.mp4|"+ftunel+"",
21:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/cf52586b.mp4|"+ftunel+"",
22:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/42e49909.mp4|"+ftunel+"",
23:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9bfb6c23.mp4|"+ftunel+"",
24:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/452663cf.mp4|"+ftunel+"",
25:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/30b5f0f7.mp4|"+ftunel+"",
26:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/44b1bf4e.mp4|"+ftunel+"",
27:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a8f5c48a.mp4|"+ftunel+"",
28:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/095c4ba2.mp4|"+ftunel+"",
29:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/075b9bb3.mp4|"+ftunel+"",
30:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/97b838ae.mp4|"+ftunel+"",
31:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a12cea5b.mp4|"+ftunel+"",
32:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6abf282f.mp4|"+ftunel+"",
33:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6a3c97c7.mp4|"+ftunel+"",
34:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a09a60fb.mp4|"+ftunel+"",
35:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f1a11064.mp4|"+ftunel+"",
36:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e658b4fa.mp4|"+ftunel+"",
37:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d3f159e1.mp4|"+ftunel+"",
38:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/126114e0.mp4|"+ftunel+"",
39:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/eee33f39.mp4|"+ftunel+"",
40:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4af38d3e.mp4|"+ftunel+"",
41:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a7e9e5ca.mp4|"+ftunel+"",
42:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7027d525.mp4|"+ftunel+"",
43:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/83343bca.mp4|"+ftunel+"",
44:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/480a0382.mp4|"+ftunel+"",
45:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/89a55dbf.mp4|"+ftunel+"",
46:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2bb2a14b.mp4|"+ftunel+"",
47:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/31486f25.mp4|"+ftunel+"",
48:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/dd19bea7.mp4|"+ftunel+"",
49:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8020add1.mp4|"+ftunel+"",
50:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/fb35e386.mp4|"+ftunel+"",
51:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1b8a90ea.mp4|"+ftunel+"",
52:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8cd9e078.mp4|"+ftunel+"",
53:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4dbf51d3.mp4|"+ftunel+"",
54:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7e873c09.mp4|"+ftunel+"",
55:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/de64f4c4.mp4|"+ftunel+"",
56:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b35e3398.mp4|"+ftunel+"",
57:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/eedd81fa.mp4|"+ftunel+"",
58:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6402222a.mp4|"+ftunel+"",
59:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8c4b5bd2.mp4|"+ftunel+"",
60:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/dc6e6dd2.mp4|"+ftunel+"",
61:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/38345f73.mp4|"+ftunel+"",
62:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5b19bcbd.mp4|"+ftunel+"",
63:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d0577e8b.mp4|"+ftunel+"",
64:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ddd2b824.mp4|"+ftunel+"",
65:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6c412be1.mp4|"+ftunel+"",
66:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6fd17f75.mp4|"+ftunel+"",
67:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/bcabf144.mp4|"+ftunel+"",
68:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5e5389bf.mp4|"+ftunel+"",
69:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/78e54422.mp4|"+ftunel+"",
70:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9fb8fca6.mp4|"+ftunel+"",
71:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8da5eff1.mp4|"+ftunel+"",
72:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2fe1edc8.mp4|"+ftunel+"",
73:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e110bc78.mp4|"+ftunel+"",
74:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/487e0579.mp4|"+ftunel+"",
75:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5fc7bce2.mp4|"+ftunel+"",
76:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/670ec278.mp4|"+ftunel+"",
77:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6923855f.mp4|"+ftunel+"",
78:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0fb4d932.mp4|"+ftunel+"",
79:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f7f25cea.mp4|"+ftunel+"",
80:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/69e4c1c7.mp4|"+ftunel+"",
81:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b356b2a9.mp4|"+ftunel+"",
82:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a86b6f6b.mp4|"+ftunel+"",
83:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b2403a8c.mp4|"+ftunel+"",
84:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8de83397.mp4|"+ftunel+"",
85:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/36a2a4d3.mp4|"+ftunel+"",
86:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1019bbd4.mp4|"+ftunel+"",
87:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/276e4a31.mp4|"+ftunel+"",
88:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/de972047.mp4|"+ftunel+"",
89:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/cce6dc25.mp4|"+ftunel+"",
90:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/16adef5f.mp4|"+ftunel+"",
91:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/aff4f629.mp4|"+ftunel+"",
92:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0bcc07cf.mp4|"+ftunel+"",
93:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/894b5d87.mp4|"+ftunel+"",
94:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7ab1fea3.mp4|"+ftunel+"",
95:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7824fc9e.mp4|"+ftunel+"",
96:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/823197b3.mp4|"+ftunel+"",
97:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ad71af37.mp4|"+ftunel+"",
98:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/11f46a69.mp4|"+ftunel+"",
99:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a7c1ed42.mp4|"+ftunel+"",
100:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a37d169a.mp4|"+ftunel+"",
101:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2991481c.mp4|"+ftunel+"",
102:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c529cdc2.mp4|"+ftunel+"",
103:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/31811b41.mp4|"+ftunel+"",
104:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2f2f123f.mp4|"+ftunel+"",
105:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/143048c6.mp4|"+ftunel+"",
106:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/efcdbff6.mp4|"+ftunel+"",
107:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7edd69fc.mp4|"+ftunel+"",
108:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/68262d6e.mp4|"+ftunel+"",
109:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9e9e84dc.mp4|"+ftunel+"",
110:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5195d008.mp4|"+ftunel+"",
111:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/46c0671f.mp4|"+ftunel+"",
112:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9c89ed74.mp4|"+ftunel+"",
113:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/57094235.mp4|"+ftunel+"",
114:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/55ecb4a7.mp4|"+ftunel+"",
115:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3c5db68c.mp4|"+ftunel+"",
116:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/900c406b.mp4|"+ftunel+"",
117:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9f989238.mp4|"+ftunel+"",
118:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5d9ed135.mp4|"+ftunel+"",
119:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b4ff4c91.mp4|"+ftunel+"",
120:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e14f616e.mp4|"+ftunel+"",
121:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6a18e3fa.mp4|"+ftunel+"",
122:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5f7e4654.mp4|"+ftunel+"",
123:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/61dd1622.mp4|"+ftunel+"",
124:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/98ef8773.mp4|"+ftunel+"",
125:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/431f5b95.mp4|"+ftunel+"",
126:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/16c447df.mp4|"+ftunel+"",
127:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9f996ba7.mp4|"+ftunel+"",
128:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/289a68d9.mp4|"+ftunel+"",
129:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/07220d18.mp4|"+ftunel+"",
130:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ec5b8b51.mp4|"+ftunel+"",
131:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/86104cf2.mp4|"+ftunel+"",
132:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b45be4bb.mp4|"+ftunel+"",
133:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1ca4827b.mp4|"+ftunel+"",
134:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f7ad2f3b.mp4|"+ftunel+"",
135:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/19a20735.mp4|"+ftunel+"",
136:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/318d8291.mp4|"+ftunel+"",
137:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a91778ae.mp4|"+ftunel+"",
138:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d0a65d2d.mp4|"+ftunel+"",
139:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/60545aed.mp4|"+ftunel+"",
140:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/09479465.mp4|"+ftunel+"",
141:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0d41d4f2.mp4|"+ftunel+"",
142:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/97ad6e2b.mp4|"+ftunel+"",
143:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d34f838f.mp4|"+ftunel+"",
144:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/de5bdeeb.mp4|"+ftunel+"",
145:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e213cb59.mp4|"+ftunel+"",
146:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/136440fb.mp4|"+ftunel+"",
147:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d7d778a0.mp4|"+ftunel+"",
148:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ea2901d9.mp4|"+ftunel+"",
149:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f2b7095b.mp4|"+ftunel+"",
150:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4aaf2e7e.mp4|"+ftunel+"",
151:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/afe103e3.mp4|"+ftunel+"",
152:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b49c79a2.mp4|"+ftunel+"",
153:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/59e23a63.mp4|"+ftunel+"",
154:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/00f46257.mp4|"+ftunel+"",
155:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/42418494.mp4|"+ftunel+"",
156:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/169dd912.mp4|"+ftunel+"",
157:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9295da01.mp4|"+ftunel+"",
158:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/df5674f9.mp4|"+ftunel+"",
159:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/45e5517d.mp4|"+ftunel+"",
160:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/107b504a.mp4|"+ftunel+"",
161:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f9c3ced3.mp4|"+ftunel+"",
162:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e4b8238f.mp4|"+ftunel+"",
163:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/96796d9c.mp4|"+ftunel+"",
164:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/bfc017c2.mp4|"+ftunel+"",
165:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/84c8ed09.mp4|"+ftunel+"",
166:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/51231f94.mp4|"+ftunel+"",
167:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1a472aa0.mp4|"+ftunel+"",
168:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/85160fcf.mp4|"+ftunel+"",
169:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ed737d2f.mp4|"+ftunel+"",
170:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0a0d0ab6.mp4|"+ftunel+"",
171:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6c146c45.mp4|"+ftunel+"",
172:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2d1bee7a.mp4|"+ftunel+"",
173:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/659efc9a.mp4|"+ftunel+"",
174:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ecc6e0cd.mp4|"+ftunel+"",
175:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a177b83d.mp4|"+ftunel+"",
176:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/41161300.mp4|"+ftunel+"",
177:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/366c93c5.mp4|"+ftunel+"",
178:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6fe3dd75.mp4|"+ftunel+"",
179:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9d6ac4c6.mp4|"+ftunel+"",
180:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d1399387.mp4|"+ftunel+"",
181:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a9597bd6.mp4|"+ftunel+"",
182:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a8771390.mp4|"+ftunel+"",
183:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e3d904d3.mp4|"+ftunel+"",
184:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a6552d42.mp4|"+ftunel+"",
185:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/dd37e823.mp4|"+ftunel+"",
186:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a484da6a.mp4|"+ftunel+"",
187:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b5d59e11.mp4|"+ftunel+"",
188:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/bc6f857e.mp4|"+ftunel+"",
189:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6172928e.mp4|"+ftunel+"",
190:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2c346f0c.mp4|"+ftunel+"",
191:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c8d35ba3.mp4|"+ftunel+"",
192:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9d24fd98.mp4|"+ftunel+"",
193:"http://d3eryu5vlst7sb.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7cae8922.mp4|"+ftunel+"",
}

        
for j in range(eps,(eps+30)):
        
        file = open(""+m3u+"","a")
        file.write(eng2sp[j])
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

