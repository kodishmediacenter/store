# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint
import base64

addonID = 'plugin.video.jiraia'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'

tunel = "UmVmZXJlcj1odHRwOi8vd3d3LnJlZGVjYW5haXMuY29tLmJyLw=="
ftunel = base64.b64decode(tunel)

addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,277)
ieps = 145 - eps

eng2sp = {01:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP01.mp4|"+ftunel+"",
02:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP02.mp4|"+ftunel+"",
03:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP03.mp4|"+ftunel+"",
04:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP04.mp4|"+ftunel+"",
05:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP05.mp4|"+ftunel+"",
06:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP06.mp4|"+ftunel+"",
07:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP07.mp4|"+ftunel+"",
08:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP08.mp4|"+ftunel+"",
09:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP09.mp4|"+ftunel+"",
10:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP10.mp4|"+ftunel+"",
11:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP11.mp4|"+ftunel+"",
12:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP12.mp4|"+ftunel+"",
13:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP13.mp4|"+ftunel+"",
14:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP14.mp4|"+ftunel+"",
15:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP15.mp4|"+ftunel+"",
16:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP16.mp4|"+ftunel+"",
17:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP17.mp4|"+ftunel+"",
18:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP18.mp4|"+ftunel+"",
19:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP19.mp4|"+ftunel+"",
20:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP20.mp4|"+ftunel+"",
21:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP21.mp4|"+ftunel+"",
22:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP22.mp4|"+ftunel+"",
23:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP23.mp4|"+ftunel+"",
24:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP24.mp4|"+ftunel+"",
25:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP25.mp4|"+ftunel+"",
26:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP26.mp4|"+ftunel+"",
27:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP27.mp4|"+ftunel+"",
28:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP28.mp4|"+ftunel+"",
29:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP29.mp4|"+ftunel+"",
30:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP30.mp4|"+ftunel+"",
31:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP31.mp4|"+ftunel+"",
32:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP32.mp4|"+ftunel+"",
33:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP33.mp4|"+ftunel+"",
34:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP34.mp4|"+ftunel+"",
35:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP35.mp4|"+ftunel+"",
36:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP36.mp4|"+ftunel+"",
37:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP37.mp4|"+ftunel+"",
38:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP38.mp4|"+ftunel+"",
39:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP39.mp4|"+ftunel+"",
40:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP40.mp4|"+ftunel+"",
41:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP41.mp4|"+ftunel+"",
42:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP42.mp4|"+ftunel+"",
43:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP43.mp4|"+ftunel+"",
44:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP44.mp4|"+ftunel+"",
45:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP45.mp4|"+ftunel+"",
46:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP46.mp4|"+ftunel+"",
47:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP47.mp4|"+ftunel+"",
48:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP48.mp4|"+ftunel+"",
49:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP49.mp4|"+ftunel+"",
50:"http://d3nmi1vru110g2.ec.cx/RedeCanais/RedeCanais/RCServer02/ondemand/JOINJEP50.mp4|"+ftunel+"",
}

        
for j in range(eps,(eps+25)):
        
        file = open(""+m3u+"","a")
        file.write(eng2sp[j])
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

