import xbmcgui
import xbmc
import default

def menuinstalleasy(): 
       dialog = xbmcgui.Dialog()
       ret = dialog.select('[COLOR yellow]Bem Vindo a[/COLOR][COLOR red]o Instala Facil [/COLOR]', ['Instalar Build','Limpar o Kodi','Usar Vikings Wizard','Instalar as Builds Disponiveis (online)'])
       if ret == 0: 
        xbmc.executebuiltin("PlayMedia(plugin://plugin.program.NordicCatsRevolts/?mode=restorezip)")
       if ret == 1: 
        xbmc.executebuiltin("PlayMedia(plugin://plugin.program.NordicCatsRevolts/?mode=freshstart)")
       if ret == 2: 
        xbmc.executebuiltin("PlayMedia(plugin://plugin.program.NordicCatsRevolts)")
       if ret == 3:
        xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.NordicCatsRevolts/?mode=builds)")
		
menuinstalleasy()
