# -*- coding: utf-8 -*-
import urllib , urlparse , sys , xbmcplugin , xbmcgui , xbmcaddon , xbmc , os , json , hashlib , re , urllib2 , htmlentitydefs
import shutil
import xbmc
import webbrowser
if 64 - 64: i11iIiiIii
OO0o = "1.7.6"
if 81 - 81: Iii1I1 + OO0O0O % iiiii % ii1I - ooO0OO000o
ii11i = 'plugin.video.MMmaroto'
oOooOoO0Oo0O = xbmcaddon . Addon ( ii11i )
iI1 = oOooOoO0Oo0O . getAddonInfo ( "name" )
i1I11i = oOooOoO0Oo0O . getAddonInfo ( 'icon' )
if 73 - 73: III - oo00oOOo * Oooo000o % OOo . OOO
IiI1ii1 = oOooOoO0Oo0O . getAddonInfo ( 'path' ) . decode ( "utf-8" )
oooOOooo = os . path . join ( IiI1ii1 , "resources" , "images" )
if 64 - 64: o0oo * O00ooOO
I1iII1iiII = os . path . join ( IiI1ii1 , 'resources' , 'lib' )
sys . path . insert ( 0 , I1iII1iiII )
import common
if 28 - 28: Ii11111i * iiI1i1
i1I1ii1II1iII = xbmc . translatePath ( oOooOoO0Oo0O . getAddonInfo ( "profile" ) ) . decode ( "utf-8" )
oooO0oo0oOOOO = os . path . join ( i1I1ii1II1iII , "cache" )
if not os . path . exists ( oooO0oo0oOOOO ) :
 os . makedirs ( oooO0oo0oOOOO )
 if 53 - 53: o0oo0o / Oo + OOo00O0Oo0oO / iIi * ooO00oOoo - o0oo0o
oOOoo00O0O = oOooOoO0Oo0O . getSetting ( "cadulto" )
i1111 = oOooOoO0Oo0O . getSetting ( "cPage" )
i11 = oOooOoO0Oo0O . getSetting ( "cPageleg" )
I11 = oOooOoO0Oo0O . getSetting ( "cPagenac" )
Oo0o0000o0o0 = oOooOoO0Oo0O . getSetting ( "cPagelan" )
oOo0oooo00o = oOooOoO0Oo0O . getSetting ( "cPageser" )
oO0o0o0ooO0oO = oOooOoO0Oo0O . getSetting ( "cPageani" )
oo0o0O00 = oOooOoO0Oo0O . getSetting ( "cPagedes" )
oO = oOooOoO0Oo0O . getSetting ( "cPagefo1" )
i1iiIIiiI111 = oOooOoO0Oo0O . getSetting ( "i1iiIIiiI111" )
oooOOOOO = oOooOoO0Oo0O . getSetting ( "cPageGOf" )
if 22 - 22: o0oo0o * Iii1I1 / OOO
o00ooooO0oO = oOooOoO0Oo0O . getSetting ( "cEPG" )
oOoOo00oOo = "date" if oOooOoO0Oo0O . getSetting ( "cOrdFO" ) == "0" else "title"
Ooo00O00O0O0O = "date" if oOooOoO0Oo0O . getSetting ( "cOrdRCF" ) == "0" else "title"
OooO0OO = "date" if oOooOoO0Oo0O . getSetting ( "cOrdRCS" ) == "0" else "title"
iiiIi = oOooOoO0Oo0O . getSetting ( "cOrdNCF" )
IiIIIiI1I1 = oOooOoO0Oo0O . getSetting ( "cOrdNCS" )
if 86 - 86: i11iIiiIii + o0oo0o + ooO00oOoo * iiI1i1 + OOO
oOoO = oOooOoO0Oo0O . getSetting ( "Cat" )
oOo = oOooOoO0Oo0O . getSetting ( "Catfo" )
oOoOoO = oOooOoO0Oo0O . getSetting ( "CatMM" )
ii1IOooO0 = oOooOoO0Oo0O . getSetting ( "CatGO" )
if 35 - 35: Ii11111i % iIi % i11iIiiIii / iiiii
Ii11iI1i = [ "todos" , "acao" , "animacao" , "aventura" , "comedia" , "drama" , "fantasia" , "ficcao-cientifica" , "romance" , "suspense" , "terror" ]
Ooo = [ "Sem filtro (Mostrar Todos)" , "Acao" , "Animacao" , "Aventura" , "Comedia" , "Drama" , "Fantasia" , "Ficcao-Cientifica" , "Romance" , "Suspense" , "Terror" ]
O0o0Oo = [ "Sem filtro (Mostrar Todos)" , "Ação" , "Animação" , "Aventura" , "Comédia" , "Drama" , "Fantasia" , "Ficção-Científica" , "Romance" , "Suspense" , "Terror" ]
Oo00OOOOO = [ "0" , "48" , "3" , "7" , "8" , "5" , "4" , "14" , "16" , "15" , "11" ]
O0O = [ "Sem filtro (Mostrar Todos)" , "Lançamentos" , "Ação" , "Animação" , "Aventura" , "Comédia" , "Drama" , "Ficção-Científica" , "Romance" , "Suspense" , "Terror" ]
O00o0OO = [ "lancamentos" , "acao" , "animacao" , "aventura" , "comedia" , "drama" , "fantasia" , "ficcao-cientifica" , "guerra" , "policial" , "romance" , "suspense" , "terror" ]
I11i1 = [ "Lançamentos" , "Ação" , "Animação" , "Aventura" , "Comédia" , "Drama" , "Fantasia" , "F. Científica" , "Guerra" , "Policial" , "Romance" , "Suspense" , "Terror" ]
iIi1ii1I1 = [ "all" , "lancamentos" , "acao" , "animacao" , "aventura" , "comedia" , "drama" , "ficcao-cientifica" , "guerra" , "policial" , "romance" , "suspense" , "terror" ]
o0 = [ "Sem filtro (Mostrar Todos)" , "Lançamentos" , "Ação" , "Animação" , "Aventura" , "Comédia" , "Drama" , "Ficção-Científica" , "Guerra" , "Policial" , "Romance" , "Suspense" , "Terror" ]
if 9 - 9: o0oo0o + O00ooOO % o0oo0o + ii1I . Ii11111i
def III1i1i ( ) :
 xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'tvshows' )
def iiI1 ( ) :
 xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
 if 19 - 19: iiI1i1 + ooO00oOoo
ooo = os . path . join ( i1I1ii1II1iII , 'favoritesf.txt' )
ii1I1i1I = os . path . join ( i1I1ii1II1iII , 'favoritess.txt' )
OOoo0O0 = os . path . join ( i1I1ii1II1iII , 'historic.txt' )
if 41 - 41: O00ooOO
if 6 - 6: o0oo
I1I = "true"
oOO00oOO = "https://site260719.wixsite.com/centraldedownloads"
if 75 - 75: ii1I / iiiii - Iii1I1 / OOo . ooO0OO000o - ii1I
O000OO0 = oOO00oOO + "nc/"
I11iii1Ii = oOO00oOO + "fo/"
if 13 - 13: iIi % OOo - i11iIiiIii . III + ooO0OO000o
def II111ii1II1i ( id ) :
 return oOooOoO0Oo0O . getLocalizedString ( id ) . encode ( 'utf-8' )
 if 59 - 59: Iii1I1 + III + OOo00O0Oo0oO % III
def o0OOoo0OO0OOO ( msg ) :
 if 19 - 19: O00ooOO % ii1I % OOO
 #oo0OooOOo0 ( "[B] VOCE ACHA MESMO QUE EU NÃO CONSEGUIRIA SEU CUZÃO DE MERDA...KKK [/B]" , "" , - 0 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/novoicone.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = False , info = "[B][COLOR white]|[/COLOR][COLOR crimson]|[/COLOR][COLOR white]|[/COLOR] [B]CENTRO DE ENTRETENIMENTOS![/B][B] [COLOR white]|[/COLOR][COLOR crimson]|[/COLOR][COLOR white]|[/COLOR][/B]\nSUPORTE OFICIAL Team TWTUTORIAIS [COLOR orange]|[/COLOR] FILMES [COLOR orange]|[/COLOR] SERIES [COLOR orange]|[/COLOR] DESENHOS [COLOR orange]|[/COLOR] ANIMES [COLOR orange]|[/COLOR] MELHORES LANÇAMENTOS DUBLADOS E LEGENDADOS! [COLOR orange]|[/COLOR]" )
 #oo0OooOOo0 ( "[B]AJUDAR O QUE SEU MERCENARIO DE BOSTA, BANDIDO VAGABUNDO, VAI PROCURAR UM SERVIÇO DE HOMEM, VAI PASSAR NUM CONCURSO IGUAL EU PASSEI SEU LIXO[COLOR crimson]|[/COLOR] PROJETO...KKK PEGA TUDO  SITE E AINDA QUER DINHEIRO VAGABUNDO.[/COLOR] [COLOR white]|[/COLOR][COLOR crimson]|[/COLOR][COLOR white]|[/COLOR][/B]" , "config" , 46 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/novoicone.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = True , info = "by TWTUTORIAIS ... CHUPA CUZÃO DE NOVO...KKK" )
 #oo0OooOOo0 ( "[B][COLOR white]|[/COLOR][COLOR blue]|[/COLOR][COLOR white]|[/COLOR][COLOR white] SUPORTE É O NEGÂO QUE ENQUANTO VC FICA COMETENDO CRIME NA INTERNET ELE TA SENTANDO A - P I R O C O N A  NA OXIGENADA..KKKKKKK [/COLOR][COLOR white]|[/COLOR][COLOR blue]|[/COLOR][COLOR white]|[/COLOR][/B]" , "config" , 44 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/novoicone.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = True , info = "by TWTUTORIAIS ... CHUPA CUZÃO DE NOVO...KKK" )
 oo0OooOOo0 ( "[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR][/B] [COLOR white][B]Pesquisar[/B][/COLOR]" , "" , 160 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/busca.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , info = "[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B] [B][COLOR white]PESQUISA DE FILMES & SÉRIES[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B]\n[B][COLOR yellow]|[/COLOR][/B] [COLOR white]Para Toda Sua Família[/COLOR] [B][COLOR yellow]|[/COLOR][/B]\n[B][COLOR yellow]|[/COLOR][/B] Team TWTUTORIAIS [B][COLOR yellow]|[/COLOR][/B]" )
 oo0OooOOo0 ( "[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR][/B] [COLOR white][B]Filmes[/COLOR][/B]" , "" , - 2 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FILMES.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = True , info = "[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B] [B][COLOR white]FILMES[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B]\nComédia, Ação, Dramas, Entrevistas, Viagens...\nAqui você encontra o que há de melhor entre os melhores Lançamentos de  Filmes e Séries da TV.\n[B][COLOR yellow]|[/COLOR][/B] Team TWTUTORIAIS [B][COLOR yellow]|[/COLOR][/B]" )
 oo0OooOOo0 ( "[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR][/B] [COLOR white][B]Séries[/B][/COLOR]" , "config" , 190 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/SERIES2.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = True , info = "[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B] [B][COLOR white]SÉRIES[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B]\nComédia, Ação, Dramas, Entrevistas, Viagens...\nAqui você encontra o que há de melhor entre os melhores Lançamentos de  Filmes e Séries da TV.\n[B][COLOR yellow]|[/COLOR][/B] Team TWTUTORIAIS [B][COLOR yellow]|[/COLOR][/B]" )
 oo0OooOOo0 ( "[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR][/B] [COLOR white][B]Filmes Favoritos[/B][/COLOR]" , "" , 301 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FILMES.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , info = "[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B] [COLOR white][B]Filmes Favoritos[/B][/COLOR] [B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B]\nOs Melhores Filmes da TV.\n[B][COLOR yellow]|[/COLOR][/B] Team TWTUTORIAIS [B][COLOR yellow]|[/COLOR][/B]" )
 oo0OooOOo0 ( "[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR][/B] [COLOR white][B]Séries Favoritas [/B][/COLOR]" , "" , 302 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/SERIES2.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , info = "[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B] [COLOR white][B]Séries Favoritas[/B][/COLOR] [B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B]\nAs Melhore Séries da TV.\n[B][COLOR yellow]|[/COLOR][/B] Team TWTUTORIAIS [B][COLOR yellow]|[/COLOR][/B]" )
 oo0OooOOo0 ( "[B][COLOR white]Limpar Histórico & Checar Atualização[/COLOR][/B]" , "" , 54 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/UPDATE.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = False , info = "[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B] [B]Limpar e Checar![/B] [B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR][/B]\n[B][COLOR yellow]|[/COLOR][/B] Limpar Hitóricos Favoritos [B][COLOR yellow]|[/COLOR][/B]\r\n[B][COLOR yellow]|[/COLOR][/B] Versão atual: [B][COLOR yellow]|[/COLOR][/B]" + OO0o )
 if 92 - 92: Oo . iiI1i1 + OOO
 if 28 - 28: ii1I * oo00oOOo - OOO * OOo00O0Oo0oO * o0oo0o / Oooo000o
 if 94 - 94: ooO0OO000o % o0oo / OOo * OO0O0O
 if 54 - 54: OOO - III + iiiii
 if 70 - 70: o0oo0o / iiI1i1 . Oo % oo00oOOo
 if 67 - 67: OOo * OOO . OOo00O0Oo0oO - Oooo000o * OOO
def IIiI1I ( ) :
 O00Oo000ooO0 = common . OpenURL ( "https://pastebin.com/raw/" )
 OoO0O00 = re . compile ( '(.+);(.+)' ) . findall ( O00Oo000ooO0 )
 for IIiII , o0ooOooo000oOO in OoO0O00 :
  oo0OooOOo0 ( "[COLOR while][B][" + IIiII + "][/COLOR][/B]" , o0ooOooo000oOO , 102 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/novoicone.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/novoicone.png" )
 iiI1 ( )
def Oo0oOOo ( ) :
 if 58 - 58: ooO0OO000o * Ii11111i * o0oo / Ii11111i
 if 75 - 75: O00ooOO
 if 50 - 50: o0oo0o / oo00oOOo - O00ooOO - iiI1i1 % Oo - O00ooOO
 if 91 - 91: Oooo000o / iiI1i1 - ooO0OO000o . iiI1i1
 if 18 - 18: OOO
 oo0OooOOo0 ( "[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto: [/COLOR][COLOR white]Últimos Adicionados[/COLOR][/B]" , "config" , 184 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FILMES.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = True )
 oo0OooOOo0 ( "[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto: [/COLOR][COLOR white]Filmes por Categorias[/COLOR][/B]" , "config" , 180 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FILMES.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = True )
 if 98 - 98: Oo * Oo / Oo + iiI1i1
 iiI1 ( )
 if 34 - 34: ooO00oOoo
def I1111I1iII11 ( ) :
 if 59 - 59: OO0O0O * i11iIiiIii / o0oo * ii1I * Iii1I1
 if 83 - 83: Oooo000o / iIi . OOo / OOo00O0Oo0oO . OOo . Ii11111i
 if 75 - 75: iiI1i1 + Oooo000o . OOo . ooO00oOoo + oo00oOOo . Oooo000o
 if 96 - 96: Ii11111i . ooO00oOoo - oo00oOOo + OO0O0O / OOo * Ii11111i
 if 65 - 65: o0oo0o . OO0O0O / Iii1I1 - o0oo0o
 oo0OooOOo0 ( "[B][COLOR white]Séries MMFilmes.tv[/COLOR][/B]" , "config" , 190 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/SERIES2.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = True )
 iiI1 ( )
 if 21 - 21: III * OO0O0O
 if 91 - 91: OOo00O0Oo0oO
 if 15 - 15: ooO0OO000o
 if 18 - 18: i11iIiiIii . ii1I % iiiii / Iii1I1
def OO0OoO0o00 ( msg ) :
 import burn
 burn.byebyeBoaNoite()
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 O00Oo000ooO0 = ooOO0O0ooOooO . select ( '[B][COLOR white]BEM-VINDO[/COLOR] [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[COLOR white] Team TWTUTORIAIS[/COLOR][/B]' , [ '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] Site Oficial[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] Ajude o Add-on[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] [I][COLOR blue]TESTE AQUI O MELHOR P2P [COLOR lime]B[/COLOR][COLOR yellow]R[/COLOR][/COLOR][/I][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] Facebook[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] Youtube[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] Telegram[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR lime] ENTRE AQUI[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR red] SAIR[/COLOR][/B]' ] )
 if 55 - 55: OOO * OOo
 if O00Oo000ooO0 == 0 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://site260719.wixsite.com/centraldedownloads/' ) )
  else :
   o0O00oOoOO = webbrowser . open ( 'https://site260719.wixsite.com/centraldedownloads/' )
   if 42 - 42: Oooo000o
 if O00Oo000ooO0 == 1 :
  o0o ( True )
  if 84 - 84: Iii1I1
 if O00Oo000ooO0 == 2 :
  OOOooOO0 ( True )
  if 87 - 87: O00ooOO * o0oo + Ii11111i / OO0O0O / Oo
 if O00Oo000ooO0 == 3 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.facebook.com/BuildTonyWarlley/' ) )
  else :
   o0O00oOoOO = webbrowser . open ( 'https://www.facebook.com/BuildTonyWarlley/' )
   if 37 - 37: Oo - ooO00oOoo * O00ooOO % i11iIiiIii - iIi
 if O00Oo000ooO0 == 4 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   o0O00oOoOO = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://bit.ly/MEGATONY-SE-INSCREVA' ) )
  else :
   webbrowser . open ( 'http://bit.ly/MEGATONY-SE-INSCREVA' )
   if 83 - 83: iiI1i1 / III
 if O00Oo000ooO0 == 5 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   o0O00oOoOO = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://t.me/' ) )
  else :
   o0O00oOoOO = webbrowser . open ( 'https://t.me/' )
   if 34 - 34: OOo00O0Oo0oO
 if O00Oo000ooO0 == 6 :
  o0OOoo0OO0OOO ( True )
  iiI1 ( )
  if 57 - 57: O00ooOO . iiI1i1 . ii1I
 if O00Oo000ooO0 == 7 :
  xbmc . executebuiltin ( "XBMC.Container.Refresh('close()')" )
  xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
  if 42 - 42: iiI1i1 + o0oo % Iii1I1
  if 6 - 6: O00ooOO
  if 68 - 68: OOo - Oooo000o
def IIi ( msg ) :
 addDir ( title_menu2 , '' , 44 , VIP , fanart_vip , url_title_descricao2 , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 if 68 - 68: i11iIiiIii % o0oo + i11iIiiIii
def OOOooOO0 ( msg ) :
 xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO[/COLOR][/B]' , '[B][COLOR blue]||| [/COLOR][/B] OLÁ! SEJA BEM-VINDO AO SUPORTE EXCLUSIVO P2P [B] [COLOR blue] ||| [/COLOR][/B]  [B][COLOR blue] ||| [/COLOR][/B]PEÇA UM TESTE AGORA E COMPROVE A QUALIDADE [B][COLOR blue] ||| [/COLOR][/B]' )
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 O00Oo000ooO0 = ooOO0O0ooOooO . select ( '[B][COLOR white]Suporte:[COLOR lime][/COLOR] [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[COLOR white] Team TWTUTORIAIS[/COLOR][/B]' , [ '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] TESTE [/COLOR]' , '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] DETALHES [/COLOR]' , '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] APLICATIVO P2P ANDROID[/COLOR]' , '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR lime] CONTINUAR NO ADDON[/COLOR]' , '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR red] SAIR [/COLOR]' ] )
 if 31 - 31: ooO0OO000o . III
 if O00Oo000ooO0 == 0 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://bit.ly/MELHOR-P2PBR' ) )
  else :
   o0O00oOoOO = webbrowser . open ( 'http://bit.ly/MELHOR-P2PBR' )
   if 1 - 1: oo00oOOo / OOO % Oo * OOo00O0Oo0oO . i11iIiiIii
 if O00Oo000ooO0 == 1 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   o0O00oOoOO = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://bit.ly/MELHOR-P2PBR' ) )
  else :
   webbrowser . open ( 'http://bit.ly/MELHOR-P2PBR' )
   if 2 - 2: o0oo * iiI1i1 - OO0O0O + III . O00ooOO % Oo
 if O00Oo000ooO0 == 2 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   o0O00oOoOO = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://is.gd/p2ptop' ) )
  else :
   webbrowser . open ( 'https://is.gd/p2ptop' )
   if 92 - 92: Oo
 if O00Oo000ooO0 == 4 :
  xbmc . executebuiltin ( "XBMC.Container.Refresh('close()')" )
  xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
  if 25 - 25: oo00oOOo - III / iiiii / OOO
def II111iiiI1Ii ( msg ) :
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 O00Oo000ooO0 = ooOO0O0ooOooO . select ( '[B][COLOR white]SUPORTE[/COLOR] [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[COLOR white] OFICIAL[/COLOR][/B]' , [ '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] SITE[/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] FACEBOOK[/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] YOUTUBE[/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] VOLTAR[/B]' ] )
 if 78 - 78: o0oo0o % iIi + o0oo
 if O00Oo000ooO0 == 0 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://site260719.wixsite.com/centraldedownloads/' ) )
  else :
   o0O00oOoOO = webbrowser . open ( 'https://site260719.wixsite.com/centraldedownloads/' )
   if 64 - 64: O00ooOO * Iii1I1 . III + ooO0OO000o
 if O00Oo000ooO0 == 1 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.facebook.com/BuildTonyWarlley/' ) )
  else :
   o0O00oOoOO = webbrowser . open ( 'https://www.facebook.com/BuildTonyWarlley/' )
   if 6 - 6: OOo / Oo . OOo00O0Oo0oO . OOo00O0Oo0oO
 if O00Oo000ooO0 == 2 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   o0O00oOoOO = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://bit.ly/MEGATONY-SE-INSCREVA' ) )
  else :
   webbrowser . open ( 'http://bit.ly/MEGATONY-SE-INSCREVA' )
   if 62 - 62: o0oo + OOo00O0Oo0oO % Oo + Ii11111i
def o0o ( msg ) :
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 O00Oo000ooO0 = ooOO0O0ooOooO . select ( '[B][COLOR white]AJUDAR[/COLOR] [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[COLOR white] Team TWTUTORIAIS[/COLOR][/B]' , [ '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] [COLOR white]DOAÇÃO[/COLOR] [COLOR blue]PAY[/COLOR][COLOR white]PAL[/COLOR] [COLOR lime]$ Qualque Valor[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] [COLOR white]DOAÇÃO MP[/COLOR] [COLOR lime]R$ 10,00[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] [COLOR lightgreen]DOAÇÃO PICPAY[/COLOR] [COLOR lime]$ Qualque Valor[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR white] [COLOR lightgreen]DOAÇÃO CONVITE PICPAY[/COLOR] [COLOR lime]R$ 10,00[/COLOR][/B]' , '[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR] [COLOR red] VOLTAR[/COLOR][/B]' ] )
 if 33 - 33: Iii1I1 . OOo00O0Oo0oO . III
 if O00Oo000ooO0 == 0 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO![/COLOR][/B]' , '[B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B][COLOR white] ESTA DOAÇÃO É PARA AQUELES QUE ADMIRA MEU TRABALHO TWTUTORIAIS, POR FAVOR NÃO SE CINTA NA OBRIGAÇÃO DE DOAR, DOE SOMENTE SE QUISER INCENTIVAR. AGRADEÇO DE CORAÇÃO E FIQUEM COM DEUS. [/COLOR][B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B]' )
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.picpay.com/convite?!31ZJYL' ) )
  else :
   xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO![/COLOR][/B]' , '[B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B][COLOR white] ESTA DOAÇÃO É PARA AQUELES QUE ADMIRA MEU TRABALHO TWTUTORIAIS, POR FAVOR NÃO SE CINTA NA OBRIGAÇÃO DE DOAR, DOE SOMENTE SE QUISER INCENTIVAR. AGRADEÇO DE CORAÇÃO E FIQUEM COM DEUS. [/COLOR][B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B]' )
   o0O00oOoOO = webbrowser . open ( 'https://www.picpay.com/convite?!31ZJYL' )
   if 72 - 72: ii1I / Oooo000o + iiiii - oo00oOOo
 if O00Oo000ooO0 == 1 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO![/COLOR][/B]' , '[B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B][COLOR white] ESTA DOAÇÃO É PARA AQUELES QUE ADMIRA MEU TRABALHO TWTUTORIAIS, POR FAVOR NÃO SE CINTA NA OBRIGAÇÃO DE DOAR, DOE SOMENTE SE QUISER INCENTIVAR. AGRADEÇO DE CORAÇÃO E FIQUEM COM DEUS. [/COLOR][B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B]' )
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://bit.ly/MP-10-TWTUTORIAIS' ) )
  else :
   xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO![/COLOR][/B]' , '[B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B][COLOR white] ESTA DOAÇÃO É PARA AQUELES QUE ADMIRA MEU TRABALHO TWTUTORIAIS, POR FAVOR NÃO SE CINTA NA OBRIGAÇÃO DE DOAR, DOE SOMENTE SE QUISER INCENTIVAR. AGRADEÇO DE CORAÇÃO E FIQUEM COM DEUS. [/COLOR][B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B]' )
   o0O00oOoOO = webbrowser . open ( 'http://bit.ly/MP-10-TWTUTORIAIS' )
   if 29 - 29: o0oo + O00ooOO % Iii1I1
 if O00Oo000ooO0 == 2 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO![/COLOR][/B]' , '[B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B][COLOR white] ESTA DOAÇÃO É PARA AQUELES QUE ADMIRA MEU TRABALHO TWTUTORIAIS, POR FAVOR NÃO SE CINTA NA OBRIGAÇÃO DE DOAR, DOE SOMENTE SE QUISER INCENTIVAR. AGRADEÇO DE CORAÇÃO E FIQUEM COM DEUS. [/COLOR][B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B]' )
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://app.picpay.com/user/twtutoriais/' ) )
  else :
   xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO![/COLOR][/B]' , '[B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B][COLOR white] ESTA DOAÇÃO É PARA AQUELES QUE ADMIRA MEU TRABALHO TWTUTORIAIS, POR FAVOR NÃO SE CINTA NA OBRIGAÇÃO DE DOAR, DOE SOMENTE SE QUISER INCENTIVAR. AGRADEÇO DE CORAÇÃO E FIQUEM COM DEUS. [/COLOR][B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B]' )
   o0O00oOoOO = webbrowser . open ( 'https://app.picpay.com/user/twtutoriais/' )
   if 10 - 10: iiI1i1 / iIi - III * OO0O0O - III
 if O00Oo000ooO0 == 3 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO![/COLOR][/B]' , '[B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B][COLOR white] ESTA DOAÇÃO É PARA AQUELES QUE ADMIRA MEU TRABALHO TWTUTORIAIS, POR FAVOR NÃO SE CINTA NA OBRIGAÇÃO DE DOAR, DOE SOMENTE SE QUISER INCENTIVAR. AGRADEÇO DE CORAÇÃO E FIQUEM COM DEUS. [/COLOR][B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B]' )
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.picpay.com/convite?!31ZJYL' ) )
  else :
   xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO![/COLOR][/B]' , '[B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B][COLOR white] ESTA DOAÇÃO É PARA AQUELES QUE ADMIRA MEU TRABALHO TWTUTORIAIS, POR FAVOR NÃO SE CINTA NA OBRIGAÇÃO DE DOAR, DOE SOMENTE SE QUISER INCENTIVAR. AGRADEÇO DE CORAÇÃO E FIQUEM COM DEUS. [/COLOR][B][COLOR yellow]|[/COLOR][/B][B][COLOR yellow]|[/COLOR][/B]' )
   o0O00oOoOO = webbrowser . open ( 'https://www.picpay.com/convite?!31ZJYL' )
   if 97 - 97: o0oo + III * o0oo0o + Ii11111i % Oo
   if 74 - 74: O00ooOO - oo00oOOo + iiiii + iIi / OOo
   if 23 - 23: Iii1I1
def o00oO0oOo00 ( msg ) :
 try :
  oO0oOo0 = urllib2 . urlopen ( "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/plugin.video.MMmaroto/version.txt" ) . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  oO0oOo0 = re . compile ( '[a-zA-Z\.\d]+' ) . findall ( oO0oOo0 ) [ 0 ]
  if 45 - 45: Oo / Oo + iIi + ooO00oOoo
  if oO0oOo0 != OO0o :
   iI111i ( )
   xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
  elif msg == True :
   if 26 - 26: o0oo * Oo . ooO0OO000o * o0oo0o
   if 28 - 28: Oooo000o . ii1I * III + Iii1I1 . ii1I - ooO00oOoo
   OO0OoO0o00 ( True )
 except urllib2 . URLError , i1I1ii11i1Iii :
  if msg == True :
   xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , "Não foi possível checar" )
   if 26 - 26: iiI1i1 - OO0O0O - III / Oooo000o . OOo % OO0O0O
def OO ( msg ) :
 try :
  oO0oOo0 = urllib2 . urlopen ( "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/plugin.video.MMmaroto/version.txt" ) . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  oO0oOo0 = re . compile ( '[a-zA-Z\.\d]+' ) . findall ( oO0oOo0 ) [ 0 ]
  if 25 - 25: Oooo000o
  if oO0oOo0 != OO0o :
   iI111i ( )
   xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
  elif msg == True :
   xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , "O ADDON Já Esta na Última Versão: " + OO0o + "\nAs Atualizações Normalmente São Automáticas. Se Caso não Atualizar, Atualize em\nhttp://bit.ly/DOWNLOADSTWTUTORIAIS/\nUse Esse Recurso Caso Não Esteja Recebendo Automaticamente" )
   xbmcaddon . Addon ( ) . openSettings ( )
   if 62 - 62: Ii11111i + Iii1I1
 except urllib2 . URLError , i1I1ii11i1Iii :
  if msg == True :
   xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , "Não foi possível checar" )
def iI111i ( ) :
 oO0OOOO0 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 try :
  iI1I11iiI1i = urllib2 . urlopen ( "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/plugin.video.MMmaroto/default.py" ) . read ( ) . replace ( '' , '' )
  oO0o0Ooooo = re . compile ( 'Team TWTUTORIAIS' ) . findall ( iI1I11iiI1i )
  if oO0o0Ooooo :
   OOo0oO00ooO00 = os . path . join ( oO0OOOO0 , "default.py" )
   file = open ( OOo0oO00ooO00 , "w" )
   file . write ( iI1I11iiI1i )
   file . close ( )
  iI1I11iiI1i = urllib2 . urlopen ( "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/plugin.video.MMmaroto/resources/settings.xml" ) . read ( ) . replace ( '' , '' )
  oO0o0Ooooo = re . compile ( '</settings>' ) . findall ( iI1I11iiI1i )
  if oO0o0Ooooo :
   OOo0oO00ooO00 = os . path . join ( oO0OOOO0 , "resources/settings.xml" )
   file = open ( OOo0oO00ooO00 , "w" )
   file . write ( iI1I11iiI1i )
   file . close ( )
  iI1I11iiI1i = urllib2 . urlopen ( "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/plugin.video.MMmaroto/addon.xml" ) . read ( ) . replace ( '' , '' )
  oO0o0Ooooo = re . compile ( '</addon>' ) . findall ( iI1I11iiI1i )
  if oO0o0Ooooo :
   OOo0oO00ooO00 = os . path . join ( oO0OOOO0 , "addon.xml" )
   file = open ( OOo0oO00ooO00 , "w" )
   file . write ( iI1I11iiI1i )
   file . close ( )
  xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , "OBS: Add-on desatualizaldo! Não se preocupe estamos atualizando o addon. Aguarde um momento! Caso ocorrer erro, por favor Atualize o Add-on no nosso Site Oficial http://bit.ly/DOWNLOADSTWTUTORIAIS" ) . xbmc . executebuiltin
 except :
  xbmc . executebuiltin ( "Notification({0}, {1}, 9000, {2})" . format ( __addonname__ , "[B][COLOR whithe]Atualizando o addon. Por favor aguarde 5 segundos e entre novamente![/COLOR][/B]" , __icon__ ) )
 xbmc . executebuiltin ( "XBMC.Container.Refresh(%s?mode=None,replace)" % sys . argv [ 0 ] )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 90 - 90: OOo * iIi + OOO
OO ( False )
if 81 - 81: O00ooOO . OOO % Iii1I1 / III - O00ooOO
def Ii1I1i ( ) :
 OOI1iI1ii1II = {
 "Accept-Language" : "en-US,en;q=0.5" ,
 "Accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
 "Referer" : "ADD-ON [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR] v1.0  >>TEAM Team TWTUTORIAIS<< " ,
 "Connection" : "keep-alive"
 }
 O0O0OOOOoo = urllib2 . Request ( "https://whos.amung.us/pingjs/?k=4w80f35j2b" , headers = OOI1iI1ii1II )
 oOooO0 = urllib2 . urlopen ( O0O0OOOOoo ) . read ( )
 if 29 - 29: OO0O0O + OOo * Oooo000o * Ii11111i . III * III
 if 7 - 7: OOo00O0Oo0oO * iIi % o0oo0o - OOO
Ii1I1i ( )
if 13 - 13: o0oo0o . i11iIiiIii
def oOOoo00O00o ( ) :
 O00Oo000ooO0 = common . OpenURL ( "https://pastebin.com/raw/" )
 O0O00Oo = O00Oo000ooO0 . split ( "\n" )
 for oooooo0O000o in O0O00Oo :
  try :
   OoO = eval ( oooooo0O000o )
   oo0OooOOo0 ( OoO [ 'title' ] + " [COLOR yellow](" + str ( OoO [ 'year' ] ) + ")[/COLOR] " + " [COLOR blue][" + str ( OoO [ 'rating' ] ) + "][/COLOR]" , OoO [ 'mp4' ] + "?play" , 229 , isFolder = False , IsPlayable = True , metah = OoO )
  except :
   pass
 iiI1 ( )
def ooO0O0O0ooOOO ( ) :
 O00Oo000ooO0 = common . OpenURL ( "https://pastebin.com/raw/pha8JaFf" )
 O0O00Oo = O00Oo000ooO0 . split ( "\n" )
 oOOo0O00o = common . OpenURL ( "https://pastebin.com/" )
 iIiIi11 = 1
 for oooooo0O000o in O0O00Oo :
  try :
   OoO = eval ( oooooo0O000o )
   file = OoO [ 'mp4' ] . split ( "$" )
   OOOiiiiI = "(.+)\$" + file [ 1 ]
   O0O00Oo = re . compile ( OOOiiiiI , re . IGNORECASE ) . findall ( oOOo0O00o )
   o0ooOooo000oOO = O0O00Oo [ 0 ]
   oo0OooOOo0 ( OoO [ 'title' ] + " [COLOR yellow](" + str ( OoO [ 'year' ] ) + ")[/COLOR] " + " [COLOR blue][" + str ( OoO [ 'rating' ] ) + "][/COLOR]" , o0ooOooo000oOO + file [ 0 ] + "?play|Referer=http://redecanais.link/" , 229 , isFolder = False , IsPlayable = True , metah = OoO )
  except :
   pass
 iiI1 ( )
def oooOo0OOOoo0 ( ) :
 OOoO ( OO0O000 , iiIiI1i1 , oO0O00oOOoooO , IiIi11iI , "" , Oo0O00O000 )
 if 3 - 3: o0oo0o * o0oo % iiI1i1
 if 59 - 59: O00ooOO - Oo
def I1 ( x ) :
 ii1I1 = oOooOoO0Oo0O . getSetting ( eval ( "x" ) )
 IIiII = "Data" if ii1I1 == "0" else "Titulo"
 oo0OooOOo0 ( "[COLOR white][B]Organizado por:[/B] " + IIiII + " (Clique para alterar)[/COLOR]" , x , 81 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/System-icon.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = False )
def OooooOOoo0 ( url ) :
 ii1I1 = oOooOoO0Oo0O . getSetting ( url )
 oooooo0O000o = "0" if ii1I1 == "1" else "1"
 if 35 - 35: iiI1i1 % Ii11111i - O00ooOO
 oOooOoO0Oo0O . setSetting ( url , oooooo0O000o )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
def ii1iii1i ( ) :
 try :
  I1 ( "cOrdNCS" )
  O00Oo000ooO0 = common . OpenURL ( "http://netcine.us/tvshows/page/1/" ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  Iii1I1111ii = re . compile ( "box_movies(.+)" ) . findall ( O00Oo000ooO0 )
  O00Oo000ooO0 = common . OpenURL ( "http://netcine.us/tvshows/page/2/" ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  ooOoO00 = re . compile ( "box_movies(.+)" ) . findall ( O00Oo000ooO0 )
  Ii1IIiI1i = re . compile ( "img src\=\"([^\"]+).+?alt\=\"([^\"]+).+?f\=\"([^\"]+)" ) . findall ( Iii1I1111ii [ 0 ] + ooOoO00 [ 0 ] )
  if IiIIIiI1I1 == "1" :
   Ii1IIiI1i = sorted ( Ii1IIiI1i , key = lambda Ii1IIiI1i : Ii1IIiI1i [ 1 ] )
  for o0O00Oo0 , IIiII , o0ooOooo000oOO in Ii1IIiI1i :
   if IIiII != "Close" :
    IIiII = IIiII . replace ( "&#8211;" , "-" ) . replace ( "&#038;" , "&" ) . replace ( "&#8217;" , "\'" )
    o0O00Oo0 = re . sub ( '-120x170.(jpg|png)' , r'.\1' , o0O00Oo0 )
    oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 61 , o0O00Oo0 , o0O00Oo0 , isFolder = True )
 except :
  oo0OooOOo0 ( "Server NETCINE offline, tente novamente em alguns minutos" , "" , 0 , isFolder = False )
def IiII111i1i11 ( x ) :
 try :
  O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 ) . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<div class="soci">' , "class='has-sub'" ) . replace ( '\t' , "" )
  O0O00Oo = re . compile ( "(.emporada \w+)(.+?class\=\'has-sub\')" ) . findall ( O00Oo000ooO0 )
  i111iIi1i1II1 = re . compile ( "<h2>Synopsis<\/h2>+.+?[div|p].{0,15}?.+?(.+?)<\/" ) . findall ( O00Oo000ooO0 )
  i111iIi1i1II1 = re . sub ( 'style\=.+?\>' , '' , i111iIi1i1II1 [ 0 ] ) if i111iIi1i1II1 else " "
  iIiIi11 = 0
  if "None" in oooO :
   for i1I1i111Ii , oooi1i1iI1iiiI in O0O00Oo :
    oo0OooOOo0 ( "[B][COLOR red] " + i1I1i111Ii + "[/COLOR][/B]" , iiIiI1i1 , 61 , oO0O00oOOoooO , oO0O00oOOoooO , isFolder = True , background = iIiIi11 , info = i111iIi1i1II1 )
    iIiIi11 += 1
  else :
   Ooo0oOooo0 = re . compile ( "href\=\"([^\"]+).+?(\d+) - (\d+)" ) . findall ( O0O00Oo [ int ( x ) ] [ 1 ] )
   oOOOoo00 = re . compile ( "icon-chevron-right\W+\w\W+([^\<]+)" ) . findall ( O0O00Oo [ int ( x ) ] [ 1 ] )
   for o0ooOooo000oOO , iiIiIIIiiI , iiI1IIIi in Ooo0oOooo0 :
    oo0OooOOo0 ( "S" + iiIiIIIiiI + "E" + iiI1IIIi + " - " + oOOOoo00 [ iIiIi11 ] , o0ooOooo000oOO , 62 , oO0O00oOOoooO , oO0O00oOOoooO , isFolder = False , IsPlayable = True , info = IiIi11iI )
    iIiIi11 += 1
 except :
  oo0OooOOo0 ( "Server NETCINE offline, tente novamente em alguns minutos" , "" , 0 , isFolder = False )
def II11IiIi11 ( ) :
 try :
  O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  O0O00Oo = re . compile ( "\"play-.\".+?src=\"([^\"]+)" ) . findall ( O00Oo000ooO0 )
  II = re . compile ( "\#play-...(\w*)" ) . findall ( O00Oo000ooO0 )
  iIiIi11 = 0
  OOO0O00O0OOOO = [ ]
  I1iiii1I = [ ]
  for o0ooOooo000oOO in O0O00Oo :
   OOo0 = common . OpenURL ( o0ooOooo000oOO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
   oOOOoo00 = re . compile ( "(campanha\d?).php?([^\"]+)" ) . findall ( OOo0 )
   for oO00ooooO0o in oOOOoo00 :
    if oO00ooooO0o [ 0 ] == "campanha" :
     oo0o = "desktop22"
    elif oO00ooooO0o [ 0 ] == "campanha2" :
     oo0o = "desktop20"
    else :
     oo0o = "desktopnovo"
    o0oO0oooOoo = common . OpenURL ( "http://www.micetop.us/" + oo0o + ".php" + oO00ooooO0o [ 1 ] )
    I1III1111iIi = re . compile ( "http.+?mp4[^\"]+" ) . findall ( o0oO0oooOoo )
    I1III1111iIi = list ( reversed ( I1III1111iIi ) )
    for I1i111I in I1III1111iIi :
     I1iiii1I . append ( I1i111I )
     OooOo0oo0O0o00O = "[COLOR lime]HD[/COLOR][/B]" if "ALTO" in I1i111I else "[COLOR white]SD[/COLOR][/B]"
     OOO0O00O0OOOO . append ( "[B][COLOR green]" + II [ iIiIi11 ] + "[/COLOR] " + OooOo0oo0O0o00O )
   iIiIi11 += 1
  I1i11 = xbmcgui . Dialog ( ) . select ( "Escolha a resolução:" , OOO0O00O0OOOO )
  if I1i11 != - 1 :
   OOoO ( OO0O000 , I1iiii1I [ I1i11 ] , oO0O00oOOoooO , IiIi11iI )
 except :
  xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Erro, tente novamente em alguns minutos' )
  if 12 - 12: ii1I + ii1I - o0oo * oo00oOOo % oo00oOOo - ooO0OO000o
def o0O ( ) :
 oo0OooOOo0 ( "[COLOR lime][B]Genero dos Filmes:[/B] " + Ooo [ int ( oOoO ) ] + "[/COLOR]" , "url" , 80 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/System-icon.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = False )
 I1 ( "cOrdNCF" )
 try :
  if oOoO == "0" :
   O00Oo000ooO0 = common . OpenURL ( "http://netcine.us/page/1/?mt" ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
   Iii1I1111ii = re . compile ( "box_movies(.+)" ) . findall ( O00Oo000ooO0 )
   O00Oo000ooO0 = common . OpenURL ( "http://netcine.us/page/2/?mt" ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
   ooOoO00 = re . compile ( "box_movies(.+)" ) . findall ( O00Oo000ooO0 )
   Ii1IIiI1i = re . compile ( "img src\=\"([^\"]+).+?alt\=\"([^\"]+).+?f\=\"([^\"]+)" ) . findall ( Iii1I1111ii [ 0 ] + ooOoO00 [ 0 ] )
  else :
   O00Oo000ooO0 = common . OpenURL ( "http://netcine.us/category/" + Ii11iI1i [ int ( oOoO ) ] ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
   Iii1I1111ii = re . compile ( "box_movies(.+)" ) . findall ( O00Oo000ooO0 )
   Ii1IIiI1i = re . compile ( "img src\=\"([^\"]+).+?alt\=\"([^\"]+).+?f\=\"([^\"]+)" ) . findall ( Iii1I1111ii [ 0 ] )
  if iiiIi == "1" :
   Ii1IIiI1i = sorted ( Ii1IIiI1i , key = lambda Ii1IIiI1i : Ii1IIiI1i [ 1 ] )
  for o0O00Oo0 , IIiII , o0ooOooo000oOO in Ii1IIiI1i :
   if IIiII != "Close" :
    IIiII = IIiII . replace ( "&#8211;" , "-" ) . replace ( "&#038;" , "&" ) . replace ( "&#8217;" , "\'" )
    o0O00Oo0 = re . sub ( '-120x170.(jpg|png)' , r'.\1' , o0O00Oo0 )
    oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 78 , o0O00Oo0 , o0O00Oo0 , isFolder = True )
 except urllib2 . URLError , i1I1ii11i1Iii :
  oo0OooOOo0 ( "Server NETCINE offline, tente novamente em alguns minutos" , "" , 0 , isFolder = False )
def OOOooo ( ) :
 try :
  O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  O0O00Oo = re . compile ( "\"play-.\".+?src=\"([^\"]+)" ) . findall ( O00Oo000ooO0 )
  Ooo0oOooo0 = re . compile ( "\#play-...(\w*)" ) . findall ( O00Oo000ooO0 )
  i111iIi1i1II1 = re . compile ( "<h2>Synopsis<\/h2>+.+?[div|p].{0,15}?.+?(.+?)<\/" ) . findall ( O00Oo000ooO0 )
  i111iIi1i1II1 = re . sub ( 'style\=.+?\>' , '' , i111iIi1i1II1 [ 0 ] ) if i111iIi1i1II1 else ""
  iIiIi11 = 0
  for IIiII in Ooo0oOooo0 :
   oo0OooOOo0 ( OO0O000 + " [COLOR lime](" + IIiII + ")[/COLOR]" , O0O00Oo [ iIiIi11 ] , 79 , oO0O00oOOoooO , oO0O00oOOoooO , isFolder = False , IsPlayable = True , info = i111iIi1i1II1 , background = iiIiI1i1 )
   iIiIi11 += 1
 except urllib2 . URLError , i1I1ii11i1Iii :
  oo0OooOOo0 ( "Server error, tente novamente em alguns minutos" , "" , 0 , isFolder = False )
def OooO0OOo0OOo0o0O0O ( ) :
 try :
  O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 )
  O0O00Oo = re . compile ( "(campanha\d?).php?([^\"]+)" ) . findall ( O00Oo000ooO0 )
  if O0O00Oo [ 0 ] [ 0 ] == "campanha" :
   oo0o = "desktop22"
  elif O0O00Oo [ 0 ] [ 0 ] == "campanha2" :
   oo0o = "desktop20"
  else :
   oo0o = "desktopnovo"
  oOOo0O00o = common . OpenURL ( "http://www.micetop.us/" + oo0o + ".php" + O0O00Oo [ 0 ] [ 1 ] )
  Ooo0oOooo0 = re . compile ( "http.+?mp4[^\"]+" ) . findall ( oOOo0O00o )
  if Ooo0oOooo0 :
   Ooo0oOooo0 = list ( reversed ( Ooo0oOooo0 ) )
   Ii1IIiI1i = [ ]
   for o0ooOooo000oOO in Ooo0oOooo0 :
    Ii1IIiI1i . append ( "[B][COLOR lime]HD[/COLOR][/B]" if "ALTO" in o0ooOooo000oOO else "[B][COLOR white]SD[/COLOR][/B]" )
   I1i11 = xbmcgui . Dialog ( ) . select ( "Escolha a resolução:" , Ii1IIiI1i )
   if I1i11 != - 1 :
    global oooO
    oooO = oooO + ";;;" + OO0O000 + ";;;NC"
    OOoO ( OO0O000 , Ooo0oOooo0 [ I1i11 ] , oO0O00oOOoooO , IiIi11iI )
 except urllib2 . URLError , i1I1ii11i1Iii :
  xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Erro, tente novamente em alguns minutos' )
def o0OO0o0oOOO0O ( ) :
 I1i11 = xbmcgui . Dialog ( ) . select ( "Escolha o Genero" , O0o0Oo )
 if I1i11 != - 1 :
  global oOoO
  oOooOoO0Oo0O . setSetting ( "Cat" , str ( I1i11 ) )
  oOoO = I1i11
  oOooOoO0Oo0O . setSetting ( "cPage" , "0" )
  oOooOoO0Oo0O . setSetting ( "cPageleg" , "0" )
  xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
  if 49 - 49: o0oo . OOO . ooO0OO000o
  if 98 - 98: Oo
def OooooO0oOOOO ( ) :
 oo0OooOOo0 ( "[COLOR yellow][B][Genero dos Filmes]:[/B] " + Ooo [ int ( oOoO ) ] + "[/COLOR]" , "url" , 80 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/System-icon.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = False )
 I1 ( "cOrdRCF" )
 try :
  o0O00oOOoo = 1
  if int ( i1111 ) > 0 :
   oo0OooOOo0 ( "[COLOR white][B]<< Página Anterior [" + str ( int ( i1111 ) ) + "[/B]][/COLOR]" , i1111 , 120 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/back-icon.png" , isFolder = False , background = "cPage" )
  i1I1iIi = int ( i1111 ) * 5
  for oooooo0O000o in range ( 0 , 5 ) :
   i1I1iIi += 1
   O00Oo000ooO0 = common . OpenURL ( "http://www.redecanais.cz/browse-filmes-dublado-videos-" + str ( i1I1iIi ) + "-" + Ooo00O00O0O0O + ".html" )
   if Ooo [ int ( oOoO ) ] != "Sem filtro (Mostrar Todos)" :
    O00Oo000ooO0 = common . OpenURL ( "http://www.redecanais.cz/browse-" + Ooo [ int ( oOoO ) ] + "-Filmes-videos-" + str ( i1I1iIi ) + "-" + Ooo00O00O0O0O + ".html" )
   OoO0O00 = re . compile ( 'href=\"([^\"]+).{70,90}src=\"([^\"]+)\".alt=\"([^\"]+)' ) . findall ( O00Oo000ooO0 )
   if OoO0O00 :
    for o0ooOooo000oOO , o0O00Oo0 , IIiII in OoO0O00 :
     o0ooOooo000oOO = re . sub ( '^\.' , "http://www.redecanais.cz/" , o0ooOooo000oOO )
     oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 95 , o0O00Oo0 , o0O00Oo0 , info = "" )
     o0O00oOOoo += 1
   else :
    break
  if o0O00oOOoo >= 60 :
   oo0OooOOo0 ( "[COLOR white][B]Próxima Página >> [" + str ( int ( i1111 ) + 2 ) + "[/B]][/COLOR]" , i1111 , 110 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/forward-icon.png" , isFolder = False , background = "cPage" )
 except :
  oo0OooOOo0 ( "Server error, tente novamente em alguns minutos" , "" , 0 , "" , "" )
def IIii11Ii1i1I ( ) :
 oo0OooOOo0 ( "[COLOR yellow][B][Genero dos Filmes]:[/B] " + Ooo [ int ( oOoO ) ] + "[/COLOR]" , "url" , 80 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/System-icon.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = False )
 I1 ( "cOrdRCF" )
 try :
  o0O00oOOoo = 1
  if int ( i11 ) > 0 :
   oo0OooOOo0 ( "[COLOR white][B]<< Página Anterior [" + str ( int ( i11 ) ) + "[/B]][/COLOR]" , i11 , 120 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/back-icon.png" , isFolder = False , background = "cPageleg" )
  i1I1iIi = int ( i11 ) * 5
  for oooooo0O000o in range ( 0 , 5 ) :
   i1I1iIi += 1
   O00Oo000ooO0 = common . OpenURL ( "http://www.redecanais.cz/browse-filmes-legendado-videos-" + str ( i1I1iIi ) + "-" + Ooo00O00O0O0O + ".html" )
   if Ooo [ int ( oOoO ) ] != "Sem filtro (Mostrar Todos)" :
    O00Oo000ooO0 = common . OpenURL ( "http://www.redecanais.cz/browse-" + Ooo [ int ( oOoO ) ] + "-Filmes-Legendado-videos-" + str ( i1I1iIi ) + "-" + Ooo00O00O0O0O + ".html" )
   OoO0O00 = re . compile ( 'href=\"([^\"]+).{70,90}src=\"([^\"]+)\".alt=\"([^\"]+)' ) . findall ( O00Oo000ooO0 )
   if OoO0O00 :
    for o0ooOooo000oOO , o0O00Oo0 , IIiII in OoO0O00 :
     o0ooOooo000oOO = re . sub ( '^\.' , "http://www.redecanais.cz/" , o0ooOooo000oOO )
     oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 95 , o0O00Oo0 , o0O00Oo0 , info = "" )
     o0O00oOOoo += 1
   else :
    break
  if o0O00oOOoo >= 60 :
   oo0OooOOo0 ( "[COLOR white][B]Próxima Página >> [" + str ( int ( i11 ) + 2 ) + "[/B]][/COLOR]" , i11 , 110 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/forward-icon.png" , isFolder = False , background = "cPageleg" )
 except :
  oo0OooOOo0 ( "Server error, tente novamente em alguns minutos" , "" , 0 , "" , "" )
def Oooo0O ( ) :
 I1 ( "cOrdRCF" )
 try :
  o0O00oOOoo = 1
  if int ( I11 ) > 0 :
   oo0OooOOo0 ( "[COLOR white][B]<< Página Anterior [" + str ( int ( I11 ) ) + "[/B]][/COLOR]" , I11 , 120 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/back-icon.png" , isFolder = False , background = "cPagenac" )
  i1I1iIi = int ( I11 ) * 5
  for oooooo0O000o in range ( 0 , 5 ) :
   i1I1iIi += 1
   O00Oo000ooO0 = common . OpenURL ( "http://www.redecanais.cz/browse-filmes-nacional-videos-" + str ( i1I1iIi ) + "-" + Ooo00O00O0O0O + ".html" )
   OoO0O00 = re . compile ( 'href=\"([^\"]+).{70,90}src=\"([^\"]+)\".alt=\"([^\"]+)' ) . findall ( O00Oo000ooO0 )
   if OoO0O00 :
    for o0ooOooo000oOO , o0O00Oo0 , IIiII in OoO0O00 :
     o0ooOooo000oOO = re . sub ( '^\.' , "http://www.redecanais.cz/" , o0ooOooo000oOO )
     oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 95 , o0O00Oo0 , o0O00Oo0 , info = "" )
     o0O00oOOoo += 1
   else :
    break
  if o0O00oOOoo >= 60 :
   oo0OooOOo0 ( "[COLOR white][B]Próxima Página >> [" + str ( int ( I11 ) + 2 ) + "[/B]][/COLOR]" , I11 , 110 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/forward-icon.png" , isFolder = False , background = "cPagenac" )
 except :
  oo0OooOOo0 ( "Server error, tente novamente em alguns minutos" , "" , 0 , "" , "" , 0 )
def oo00O0oO0O0 ( ) :
 if 96 - 96: i11iIiiIii % ooO00oOoo / OOo
 try :
  o0O00oOOoo = 1
  if int ( Oo0o0000o0o0 ) > 0 :
   oo0OooOOo0 ( "[COLOR white][B]<< Página Anterior [" + str ( int ( Oo0o0000o0o0 ) ) + "[/B]][/COLOR]" , Oo0o0000o0o0 , 120 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/back-icon.png" , isFolder = False , background = "cPagelan" )
  i1I1iIi = int ( Oo0o0000o0o0 ) * 5
  for oooooo0O000o in range ( 0 , 5 ) :
   i1I1iIi += 1
   O00Oo000ooO0 = common . OpenURL ( "https://www.redecanais.cz/browse-filmes-lancamentos-videos-" + str ( i1I1iIi ) + "-date.html" )
   OoO0O00 = re . compile ( 'href=\"([^\"]+).{70,90}src=\"([^\"]+)\".alt=\"([^\"]+)' ) . findall ( O00Oo000ooO0 )
   if OoO0O00 :
    for o0ooOooo000oOO , o0O00Oo0 , IIiII in OoO0O00 :
     o0ooOooo000oOO = re . sub ( '^\.' , "http://www.redecanais.cz/" , o0ooOooo000oOO )
     oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 95 , o0O00Oo0 , o0O00Oo0 , info = "" )
     o0O00oOOoo += 1
   else :
    break
  if o0O00oOOoo >= 60 :
   oo0OooOOo0 ( "[COLOR white][B]Próxima Página >> [" + str ( int ( Oo0o0000o0o0 ) + 2 ) + "[/B]][/COLOR]" , Oo0o0000o0o0 , 110 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/back-icon.png" , isFolder = False , background = "cPagelan" )
 except :
  oo0OooOOo0 ( "Server error, tente novamente em alguns minutos" , "" , 0 , "" , "" , 0 )
def I1IiI11 ( ) :
 try :
  O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 . replace ( "https" , "http" ) )
  iI1iiiiIii = re . compile ( '<p itemprop=\"description\"><p>(.+)<\/p><\/p>' ) . findall ( O00Oo000ooO0 )
  if iI1iiiiIii :
   iI1iiiiIii = re . sub ( '&([^;]+);' , lambda O0O00Oo : unichr ( htmlentitydefs . name2codepoint [ O0O00Oo . group ( 1 ) ] ) , iI1iiiiIii [ 0 ] ) . encode ( 'utf-8' )
  iIiIiIiI = re . compile ( '<iframe name=\"Player\".{1,8}src=\"([^\"]+)\"' ) . findall ( O00Oo000ooO0 )
  if iIiIiIiI :
   i11OOoo = common . OpenURL ( iIiIiIiI [ 0 ] )
   iIIiiiI = re . compile ( 'http.{5,95}mp4' ) . findall ( i11OOoo )
   oo0OooOOo0 ( "[B][COLOR yellow]" + OO0O000 + " [/COLOR][/B]" , iIIiiiI [ 0 ] + "?play|Referer=" + iIiIiIiI [ 0 ] , 3 , oO0O00oOOoooO , oO0O00oOOoooO , index = 0 , isFolder = False , IsPlayable = True , info = iI1iiiiIii , background = iiIiI1i1 + ";;;" + OO0O000 + ";;;RC" )
  else :
   oo0OooOOo0 ( "[B]Ocorreu um erro[/B]" , "" , 0 , oO0O00oOOoooO , oO0O00oOOoooO , index = 0 , isFolder = False , IsPlayable = False , info = "Erro" )
 except :
  oo0OooOOo0 ( "Server error, tente novamente em alguns minutos" , "" , 0 , "" , "" )
  if 60 - 60: III . iIi
  if 34 - 34: III % Oo + ooO00oOoo * OO0O0O
def Ii11 ( ) :
 try :
  o0ooOooo000oOO = re . sub ( 'redecanais\.[^\/]+' , "redecanais.cz" , iiIiI1i1 . replace ( "https" , "http" ) )
  O00Oo000ooO0 = common . OpenURL ( o0ooOooo000oOO )
  iI1iiiiIii = re . compile ( '<p itemprop=\"description\"><p>(.+)<\/p><\/p>' ) . findall ( O00Oo000ooO0 )
  if iI1iiiiIii :
   iI1iiiiIii = re . sub ( '&([^;]+);' , lambda O0O00Oo : unichr ( htmlentitydefs . name2codepoint [ O0O00Oo . group ( 1 ) ] ) , iI1iiiiIii [ 0 ] ) . encode ( 'utf-8' )
  iIiIiIiI = re . compile ( '<iframe name=\"Player\".+src=\"([^\"]+)\"' ) . findall ( O00Oo000ooO0 )
  if iIiIiIiI :
   i11OOoo = common . OpenURL ( iIiIiIiI [ 0 ] )
   iIIiiiI = re . compile ( 'http.{5,95}mp4' ) . findall ( i11OOoo )
   OOoO ( OO0O000 , iIIiiiI [ 0 ] + "?play|Referer=" + iIiIiIiI [ 0 ] , oO0O00oOOoooO , OO0O000 )
  else :
   xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Erro, tente novamente em alguns minutos' )
 except :
  xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Erro, tente novamente em alguns minutos' )
def IIiI1Ii ( x ) :
 o0ooOooo000oOO = re . sub ( 'redecanais\.[^\/]+' , "redecanais.cz" , iiIiI1i1 . replace ( "https" , "http" ) )
 O00Oo000ooO0 = common . OpenURL ( o0ooOooo000oOO ) . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '</html>' , '<span style="font' ) . replace ( "https" , "http" )
 O0O0O0Oo = re . compile ( '(<span style="font-size: x-large;">(.+?)<\/span>)' ) . findall ( O00Oo000ooO0 )
 iIiIi11 = 0
 if oooO == "None" :
  for OOOOoO00o0O , I1I1I1IIi1III in O0O0O0Oo :
   I1I1I1IIi1III = re . sub ( '<[\/]{0,1}strong>' , "" , I1I1I1IIi1III )
   try :
    I1I1I1IIi1III = re . sub ( '&([^;]+);' , lambda O0O00Oo : unichr ( htmlentitydefs . name2codepoint [ O0O00Oo . group ( 1 ) ] ) , I1I1I1IIi1III ) . encode ( 'utf-8' )
   except :
    I1I1I1IIi1III = I1I1I1IIi1III
   if not "ilme" in I1I1I1IIi1III :
    oo0OooOOo0 ( "[B][" + I1I1I1IIi1III + "][/B]" , iiIiI1i1 , 135 , oO0O00oOOoooO , oO0O00oOOoooO , info = "" , isFolder = True , background = iIiIi11 )
   iIiIi11 += 1
  oo0OooOOo0 ( "[B][Todos Episódios][/B]" , iiIiI1i1 , 139 , oO0O00oOOoooO , oO0O00oOOoooO , info = "" )
 else :
  II11IiiIII = re . compile ( 'size: x-large;\">.+?<span style\=\"font' ) . findall ( O00Oo000ooO0 )
  o0OOOo = re . compile ( '<strong>(E.+?)<\/strong>(.+?)(<br|<\/p)' ) . findall ( II11IiiIII [ int ( x ) ] )
  for IIiII , o0ooOooo000oOO , ii1iiIiIII1ii in o0OOOo :
   oO0o0oooO0oO = re . compile ( '\d+' ) . findall ( IIiII )
   if oO0o0oooO0oO :
    oO0o0oooO0oO = oO0o0oooO0oO [ 0 ]
   else :
    oO0o0oooO0oO = IIiII
   IiIiII1 = re . compile ( 'href\=\"(.+?)\"' ) . findall ( o0ooOooo000oOO )
   o0ooOooo000oOO = re . sub ( '(\w)-(\w)' , r'\1 \2' , o0ooOooo000oOO )
   try :
    Iii1iiIi1II = re . sub ( '&([^;]+);' , lambda O0O00Oo : unichr ( htmlentitydefs . name2codepoint [ O0O00Oo . group ( 1 ) ] ) , re . compile ( '([^\-]+)' ) . findall ( o0ooOooo000oOO ) [ 0 ] ) . encode ( 'utf-8' )
   except :
    Iii1iiIi1II = re . compile ( '([^\-]+)' ) . findall ( o0ooOooo000oOO ) [ 0 ]
   Iii1iiIi1II = re . sub ( '<[\/]{0,1}strong>' , "" , Iii1iiIi1II )
   if "<" in Iii1iiIi1II :
    Iii1iiIi1II = ""
   if IiIiII1 :
    IiIiII1 [ 0 ] = "http://www.redecanais.cz/" + IiIiII1 [ 0 ] if "http" not in IiIiII1 [ 0 ] else IiIiII1 [ 0 ]
   if len ( IiIiII1 ) > 1 :
    IiIiII1 [ 1 ] = "http://www.redecanais.cz/" + IiIiII1 [ 1 ] if "http" not in IiIiII1 [ 1 ] else IiIiII1 [ 1 ]
    oo0OooOOo0 ( "[COLOR lime][Dub][/COLOR] " + oO0o0oooO0oO + " " + Iii1iiIi1II , IiIiII1 [ 0 ] , 133 , oO0O00oOOoooO , oO0O00oOOoooO , info = "" , isFolder = False , IsPlayable = True )
    oo0OooOOo0 ( "[COLOR yellow][Leg][/COLOR] " + oO0o0oooO0oO + " " + Iii1iiIi1II , IiIiII1 [ 1 ] , 133 , oO0O00oOOoooO , oO0O00oOOoooO , info = "" , isFolder = False , IsPlayable = True )
   elif IiIiII1 :
    oo0OooOOo0 ( oO0o0oooO0oO + " " + Iii1iiIi1II , IiIiII1 [ 0 ] , 133 , oO0O00oOOoooO , oO0O00oOOoooO , info = "" , isFolder = False , IsPlayable = True )
def OO0O00oOo ( urlrc , pagina2 ) :
 try :
  I1 ( "cOrdRCS" )
  ii1II = eval ( pagina2 )
  o0O00oOOoo = 1
  if int ( ii1II ) > 0 :
   oo0OooOOo0 ( "[COLOR white][B]<< Página Anterior [" + str ( int ( ii1II ) ) + "[/B]][/COLOR]" , ii1II , 120 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/back-icon.png" , isFolder = False , background = pagina2 )
  i1I1iIi = int ( ii1II ) * 5
  for oooooo0O000o in range ( 0 , 5 ) :
   i1I1iIi += 1
   O00Oo000ooO0 = common . OpenURL ( "http://www.redecanais.cz/browse-" + urlrc + "-videos-" + str ( i1I1iIi ) + "-" + OooO0OO + ".html" )
   OoO0O00 = re . compile ( 'href=\"([^\"]+).{70,90}src=\"([^\"]+)\".alt=\"([^\"]+)' ) . findall ( O00Oo000ooO0 )
   if OoO0O00 :
    for o0ooOooo000oOO , o0O00Oo0 , IIiII in OoO0O00 :
     o0ooOooo000oOO = re . sub ( '^\.' , "http://www.redecanais.cz/" , o0ooOooo000oOO )
     if not "index.html" in o0ooOooo000oOO :
      oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 135 , o0O00Oo0 , o0O00Oo0 , info = "" )
      o0O00oOOoo += 1
   else :
    break
  if o0O00oOOoo >= 60 :
   oo0OooOOo0 ( "[COLOR white][B]Próxima Página >> [" + str ( int ( ii1II ) + 2 ) + "[/B]][/COLOR]" , ii1II , 110 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/forward-icon.png" , isFolder = False , background = pagina2 )
 except urllib2 . URLError , i1I1ii11i1Iii :
  oo0OooOOo0 ( "Server error, tente novamente em alguns minutos" , iiIiI1i1 , 0 , "" , "" )
def iI1I ( ) :
 O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 )
 OoO0O00 = re . compile ( '<strong>(E.+?)<\/strong>(.+?)(<br|<\/p)' ) . findall ( O00Oo000ooO0 )
 iiIiIIIiiI = 0
 if OoO0O00 :
  for IIiII , o0ooOooo000oOO , ii1iiIiIII1ii in OoO0O00 :
   oO0o0oooO0oO = re . compile ( '\d+' ) . findall ( IIiII )
   if oO0o0oooO0oO :
    oO0o0oooO0oO = oO0o0oooO0oO [ 0 ]
    if int ( oO0o0oooO0oO ) == 1 :
     iiIiIIIiiI = iiIiIIIiiI + 1
   else :
    oO0o0oooO0oO = IIiII
    if 100 - 100: OO0O0O + OOo / oo00oOOo . i11iIiiIii
   IiIiII1 = re . compile ( 'href\=\"(.+?)\"' ) . findall ( o0ooOooo000oOO )
   try :
    Iii1iiIi1II = re . sub ( '&([^;]+);' , lambda O0O00Oo : unichr ( htmlentitydefs . name2codepoint [ O0O00Oo . group ( 1 ) ] ) , re . compile ( '([^\-]+)' ) . findall ( o0ooOooo000oOO ) [ 0 ] ) . encode ( 'utf-8' )
   except :
    Iii1iiIi1II = re . compile ( '([^\-]+)' ) . findall ( o0ooOooo000oOO ) [ 0 ]
   if "<" in Iii1iiIi1II :
    Iii1iiIi1II = ""
   if IiIiII1 :
    if "http" not in IiIiII1 [ 0 ] :
     IiIiII1 [ 0 ] = "http://www.redecanais.cz/" + IiIiII1 [ 0 ]
   if len ( IiIiII1 ) > 1 :
    if "http" not in IiIiII1 [ 1 ] :
     IiIiII1 [ 1 ] = "http://www.redecanais.cz/" + IiIiII1 [ 1 ]
    oo0OooOOo0 ( "[COLOR lime][Dub][/COLOR] S" + str ( iiIiIIIiiI ) + " E" + oO0o0oooO0oO + " " + Iii1iiIi1II , IiIiII1 [ 0 ] , 133 , oO0O00oOOoooO , oO0O00oOOoooO , info = "" , isFolder = False , IsPlayable = True )
    oo0OooOOo0 ( "[COLOR yellow][Leg][/COLOR] S" + str ( iiIiIIIiiI ) + " E" + oO0o0oooO0oO + " " + Iii1iiIi1II , IiIiII1 [ 1 ] , 133 , oO0O00oOOoooO , oO0O00oOOoooO , info = "" , isFolder = False , IsPlayable = True )
   elif IiIiII1 :
    oo0OooOOo0 ( "S" + str ( iiIiIIIiiI ) + " E" + oO0o0oooO0oO + " " + Iii1iiIi1II , IiIiII1 [ 0 ] , 133 , oO0O00oOOoooO , oO0O00oOOoooO , info = "" , isFolder = False , IsPlayable = True )
    if 14 - 14: OOO * Ii11111i + Oo + Iii1I1 + i11iIiiIii
    if 77 - 77: OOO / iiiii
def IIii11I1i1I ( ) :
 oo0OooOOo0 ( "[COLOR withe][B][Nova Busca][/B][/COLOR]" , "" , 50 , "" , isFolder = False )
 I1i11 = xbmcgui . Dialog ( ) . input ( "Busca (poder demorar a carregar os resultados)" ) . replace ( " " , "+" )
 if not I1i11 :
  return o0OOoo0OO0OOO ( True )
  sys . exit ( int ( sys . argv [ 1 ] ) )
  if 99 - 99: Oo
  if 76 - 76: Oooo000o * III
  if 82 - 82: o0oo0o * Oo / o0oo
  if 36 - 36: iiiii - ii1I . Iii1I1 / ooO0OO000o + OOO
  if 33 - 33: ooO0OO000o / ooO00oOoo * Iii1I1 % o0oo0o * iIi
  if 100 - 100: OOo00O0Oo0oO . iiI1i1 / o0oo0o % OOo % ooO0OO000o - Oooo000o
  if 46 - 46: Iii1I1 * ooO0OO000o - oo00oOOo * ooO00oOoo
  if 33 - 33: o0oo0o
  if 74 - 74: Ii11111i + Iii1I1 + ii1I - ii1I + ooO0OO000o
  if 83 - 83: o0oo - III + Ii11111i
  if 5 - 5: o0oo0o
  if 46 - 46: OOo00O0Oo0oO
  if 45 - 45: ooO00oOoo
  if 21 - 21: O00ooOO . iIi . Ii11111i / oo00oOOo / iIi
  if 17 - 17: Ii11111i / Ii11111i / iiI1i1
 i1I1iIi = 0
 iIiIi11 = 0
 try :
  oo0OooOOo0 ( "[B][COLOR yellow]MM[/COLOR] [COLOR lime]Maroto:[/COLOR][/B] [COLOR white]Filmes & Séries[/COLOR]" , "" , 0 , "" , isFolder = False )
  ii1 = common . OpenURL ( "http://www.mmfilmeshd.tv/series/" )
  I1IiiI1ii1i = re . compile ( 'href\=\"(.+www.mmfilmeshd.tv.+)\" rel\=\"bookmark\"' ) . findall ( ii1 )
  for oooooo0O000o in range ( 0 , 3 ) :
   i1I1iIi += 1
   O00Oo000ooO0 = common . OpenURL ( "http://www.mmfilmeshd.tv/page/" + str ( i1I1iIi ) + "/?s=" + I1i11 )
   O0O00Oo = re . compile ( 'id\=\"post\-\d+\".+?\=.([^\"]+)\h*(?s)(.+?)(http[^\"]+)' ) . findall ( O00Oo000ooO0 )
   O0o = re . compile ( 'audioy..([^\<]*)' ) . findall ( O00Oo000ooO0 )
   oO0OoO00o = re . compile ( 'src=\"(http.+?www.mmfilmeshd.tv\/wp-content\/uploads[^\"]+)' ) . findall ( O00Oo000ooO0 )
   OooOo0oo0O0o00O = re . compile ( 'boxxer.+\s.+boxxer..([^\<]*)' ) . findall ( O00Oo000ooO0 )
   if O0O00Oo :
    for IIiII , OOOOoO00o0O , o0ooOooo000oOO in O0O00Oo :
     IIiII = IIiII . replace ( "&#8211;" , "-" ) . replace ( "&#038;" , "&" ) . replace ( "&#8217;" , "\'" )
     if not o0ooOooo000oOO in I1IiiI1ii1i :
      oo0OooOOo0 ( IIiII + " [COLOR lime]" + O0o [ iIiIi11 ] + "[/COLOR] [COLOR yellow]" + OooOo0oo0O0o00O [ iIiIi11 ] + "[/COLOR]" , o0ooOooo000oOO , 181 , oO0OoO00o [ iIiIi11 ] , oO0OoO00o [ iIiIi11 ] , isFolder = True , IsPlayable = False )
     else :
      oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 191 , oO0OoO00o [ iIiIi11 ] , oO0OoO00o [ iIiIi11 ] , isFolder = True , IsPlayable = False )
     iIiIi11 += 1
   iIiIi11 = 0
 except :
  pass
 i1I1iIi = 0
 iIiIi11 = 0
 try :
  if 11 - 11: oo00oOOo - III * ooO0OO000o . o0oo . O00ooOO
  for oooooo0O000o in range ( 0 , 3 ) :
   i1I1iIi += 1
   O00Oo000ooO0 = common . OpenURL ( "http://gofilmes.me/search?s=" + I1i11 + "&p=" + str ( i1I1iIi ) ) . replace ( "</div><div" , "\r\n" )
   O0O00Oo = re . compile ( 'href=\"([^\"]+)\" title\=\"([^\"]+).+b\" src\=\"([^\"]+).+' ) . findall ( O00Oo000ooO0 )
   for o0ooOooo000oOO , IIiII , o0O00Oo0 in O0O00Oo :
    oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 211 , o0O00Oo0 , o0O00Oo0 , isFolder = False , IsPlayable = True )
 except :
  pass
  if 61 - 61: Oo % III - OOO - ooO0OO000o % Iii1I1
  if 90 - 90: OO0O0O + o0oo + ooO00oOoo - iIi * OOo00O0Oo0oO . o0oo
def I11iiiii1II ( x ) :
 try :
  if 51 - 51: Iii1I1 % O00ooOO - ooO0OO000o
  O00Oo000ooO0 = common . OpenURL ( "https://pastebin.com/raw/" + x )
  O0O00Oo = re . compile ( '(.+)\?(.+)' ) . findall ( O00Oo000ooO0 )
  iIiIi11 = 0
  for IIiII , o0ooOooo000oOO in O0O00Oo :
   if oOOoo00O0O == "8080" :
    oo0OooOOo0 ( I1II ( IIiII ) , o0ooOooo000oOO , 103 , "a" , "a" , isFolder = False , IsPlayable = True , info = "" )
    iIiIi11 += 1
   elif not "dulto" in I1II ( IIiII ) :
    oo0OooOOo0 ( I1II ( IIiII ) , o0ooOooo000oOO , 103 , "a" , "a" , isFolder = False , IsPlayable = True , info = "" )
    iIiIi11 += 1
 except :
  oo0OooOOo0 ( "Servidor offline, tente novamente em alguns minutos" , "" , 0 , "" , "" , 0 )
def Oo000ooOOO ( ) :
 try :
  OOoO ( OO0O000 , I1II ( iiIiI1i1 ) , "" , "" , "" )
 except urllib2 . URLError , i1I1ii11i1Iii :
  xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , "Servidor offline, tente novamente em alguns minutos" )
  if 31 - 31: OO0O0O % iiI1i1 % ooO00oOoo . o0oo0o - iiI1i1
  if 17 - 17: o0oo0o
def Ii1ii1IiIII ( x ) :
 x = x . replace ( "\xe7" , "ç" ) . replace ( "\xe0" , "à" ) . replace ( "\xe1" , "á" ) . replace ( "\xe2" , "â" ) . replace ( "\xe3" , "ã" ) . replace ( "\xe8" , "è" ) . replace ( "\xe9" , "é" ) . replace ( "\xea" , "ê" ) . replace ( "\xed" , "í" ) . replace ( "\xf3" , "ó" ) . replace ( "\xf4" , "ô" ) . replace ( "\xf5" , "õ" ) . replace ( "\xfa" , "ú" )
 return x
def ooO0o ( ) :
 ooOOo00O00Oo = "{"
 try :
  xbmc . executebuiltin ( "Notification({0}, {1}, 7000, {2})" . format ( iI1 , "Carregando lista EPG. Aguarde um momento!" , i1I11i ) )
  O00Oo000ooO0 = common . OpenURL ( "http://cuzao/vertv.php" ) . replace ( '	' , '' )
  O0O00Oo = re . compile ( 'javascript:toggleCanal\(\d+,.([^\']+)\h*(?s)(.+?)\<\!-- orig' ) . findall ( O00Oo000ooO0 )
  for IiII1 , I1iIi1iIiiIiI in O0O00Oo :
   I1i11ii = ""
   Ooo0oOooo0 = re . compile ( '(.+)(\(\d+.\d+\))\s' ) . findall ( I1iIi1iIiiIiI )
   if Ooo0oOooo0 :
    for i111iI , OOoi1i11I1I1iii1 in Ooo0oOooo0 :
     I1i11ii += OOoi1i11I1I1iii1 + " " + i111iI + ";;;"
     try :
      I1i11ii = Ii1ii1IiIII ( I1i11ii )
     except :
      I1i11ii = I1i11ii
   I1i11ii = I1i11ii . replace ( "'" , "" )
   ooOOo00O00Oo += "'" + IiII1 + "' : '" + I1i11ii + "' , "
  return ooOOo00O00Oo + "'none':''}"
 except urllib2 . URLError , i1I1ii11i1Iii :
  return ""
  xbmc . executebuiltin ( "Notification({0}, {1}, 7000, {2})" . format ( iI1 , "Erro. tente novamente!" , i1I11i ) )
def I1iii11 ( ) :
 O00Oo000ooO0 = urllib2 . urlopen ( "https://site260719.wixsite.com/centraldedownloads" ) . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 OoO0O00 = re . compile ( 'url="(.+?)".+?mg="(.+?)".+?ame="(.+?)"' ) . findall ( O00Oo000ooO0 )
 for o0ooOooo000oOO , o0O00Oo0 , IIiII in OoO0O00 :
  if oOOoo00O0O == "8080" :
   oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 101 , o0O00Oo0 , o0O00Oo0 , isFolder = False , IsPlayable = True , info = "" )
  elif not "dulto" in IIiII :
   oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 101 , o0O00Oo0 , o0O00Oo0 , isFolder = False , IsPlayable = True , info = "" )
def ooo0O ( ) :
 o0ooOooo000oOO = re . sub ( 'redecanais\.[^\/]+' , "redecanais.cz" , iiIiI1i1 . replace ( "https" , "http" ) )
 try :
  O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 )
  iIiIiIiI = re . compile ( '<iframe name=\"Player\".+src=\"([^\"]+)\"' ) . findall ( O00Oo000ooO0 )
  oOOo0O00o = common . OpenURL ( iIiIiIiI [ 0 ] )
  Ooo0oOooo0 = re . compile ( 'action="([^\"]+)' ) . findall ( oOOo0O00o )
  OOo0 = common . OpenURL ( Ooo0oOooo0 [ 0 ] )
  iII1iii = re . compile ( '(http[^\"]+m3u[^\"]+)' ) . findall ( OOo0 )
  if iII1iii :
   OOoO ( OO0O000 , iII1iii [ 0 ] + "?play|Referer=" + iIiIiIiI [ 0 ] , oO0O00oOOoooO , IiIi11iI )
  else :
   xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , "Erro, aguarde atualização" )
 except urllib2 . URLError , i1I1ii11i1Iii :
  xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Erro, tente novamente em alguns minutos' )
  if 12 - 12: Ii11111i
  if 83 - 83: Oo . Iii1I1 / oo00oOOo / Ii11111i - ooO0OO000o
def oO0oO0 ( ) :
 I1i11 = xbmcgui . Dialog ( ) . select ( "Escolha o Genero" , O0O )
 if I1i11 != - 1 :
  global oOoO
  oOooOoO0Oo0O . setSetting ( "Catfo" , str ( I1i11 ) )
  oOoO = I1i11
  oOooOoO0Oo0O . setSetting ( "cPagefo1" , "0" )
  xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
  if 14 - 14: Oo
def oOOOOo0oo0O ( urlfo , pagina2 ) :
 oo0OooOOo0 ( "[COLOR lime][B]CATEGORIAS DOS FILMES:[/B] " + O0O [ int ( oOo ) ] + "[/COLOR]" , "url" , 85 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/System-icon.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = False )
 I1 ( "cOrdFO" )
 try :
  ii1II = eval ( pagina2 )
  i1I1iIi = int ( ii1II ) * 5
  o0O00oOOoo = 1
  if int ( ii1II ) > 0 :
   oo0OooOOo0 ( "[COLOR white][B]<< Página Anterior [" + str ( int ( ii1II ) ) + "[/B]][/COLOR]" , ii1II , 120 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/back-icon.png" , isFolder = False , background = pagina2 )
  for oooooo0O000o in range ( 0 , 5 ) :
   i1I1iIi += 1
   IiiIiI1Ii1i = "desc" if oOoOo00oOo == "1" else "asc"
   O00Oo000ooO0 = common . OpenURL ( "https://filmesonline.online/index.php?do=search&subaction=search&search_start=" + str ( i1I1iIi ) + "&story=" + urlfo + "&sortby=" + oOoOo00oOo + "&resorder=" + IiiIiI1Ii1i + "&catlist[]=" + Oo00OOOOO [ int ( oOo ) ] ) . replace ( "\r" , "" ) . replace ( "\n" , "" )
   O00Oo000ooO0 = re . sub ( 'Novos Filmes.+' , '' , O00Oo000ooO0 )
   O0O00Oo = re . compile ( 'src=\"(.upload[^\"]+).+?alt=\"([^\"]+).+?href=\"([^\"]+)' ) . findall ( O00Oo000ooO0 )
   Ooo0oOooo0 = re . compile ( 'numb-serial..(.+?)\<.+?afd..(\d+)' ) . findall ( O00Oo000ooO0 )
   iIiIi11 = 0
   if O0O00Oo :
    if 22 - 22: OOo00O0Oo0oO / i11iIiiIii
    for o0O00Oo0 , IIiII , o0ooOooo000oOO in O0O00Oo :
     oo0OooOOo0 ( IIiII + " (" + Ooo0oOooo0 [ iIiIi11 ] [ 0 ] + ") - " + Ooo0oOooo0 [ iIiIi11 ] [ 1 ] , o0ooOooo000oOO , 171 , "https://filmesonline.online/" + o0O00Oo0 , "https://filmesonline.online/" + o0O00Oo0 , info = "" , background = iiIiI1i1 )
     o0O00oOOoo += 1
     iIiIi11 += 1
  if o0O00oOOoo >= 80 :
   oo0OooOOo0 ( "[COLOR white][B]Próxima Página >> [" + str ( int ( ii1II ) + 2 ) + "[/B]][/COLOR]" , ii1II , 110 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/forward-icon.png" , isFolder = False , background = pagina2 )
 except urllib2 . URLError , i1I1ii11i1Iii :
  oo0OooOOo0 ( "Server error, tente novamente em alguns minutos" , "" , 0 , "" , "" )
  if 62 - 62: Oooo000o / o0oo
def ii1O000OOO0OOo ( ) :
 if re . compile ( '\d+' ) . findall ( str ( oooO ) ) :
  i1i1I111iIi1 = oooO . split ( "," )
  oo00O00oO000o = xbmcgui . Dialog ( ) . select ( "Selecione a resolucão" , i1i1I111iIi1 )
  if oo00O00oO000o != - 1 :
   O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 + "?q=" + i1i1I111iIi1 [ oo00O00oO000o ] )
   O0O00Oo = re . compile ( 'https[^\"]+\.mp4' ) . findall ( O00Oo000ooO0 )
   global oooO
   oooO = "None"
   OOoO ( OO0O000 , O0O00Oo [ 0 ] , "" , IiIi11iI )
 else :
  O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 )
  O0O00Oo = re . compile ( 'https[^\"]+\.mp4' ) . findall ( O00Oo000ooO0 )
  oooO = "None"
  OOoO ( OO0O000 , O0O00Oo [ 0 ] , "" , IiIi11iI )
  if 71 - 71: o0oo - ooO00oOoo / OOo * OOo / ii1I . ii1I
def ooo000ooO0000 ( ) :
 try :
  O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 )
  O0O00Oo = re . compile ( 'href\=\"(.+?\#Rapid)' ) . findall ( O00Oo000ooO0 )
  oOoooo000Oo00 = re . compile ( 'class=\"titleblock\"\>\s\<h1\>([^\<]+)' ) . findall ( O00Oo000ooO0 )
  iIiIi11 = re . compile ( 'class=\"p-info-text\"\>\s\<span\>([^\<]+)' ) . findall ( O00Oo000ooO0 )
  if O0O00Oo :
   oOOo0O00o = common . OpenURL ( "https://filmesonline.online" + O0O00Oo [ 0 ] )
   Ooo0oOooo0 = re . compile ( 'iframe.+?src\=\"([^\"]+)' ) . findall ( oOOo0O00o )
   if Ooo0oOooo0 :
    OOoo = oOoooo000Oo00 [ 0 ] if oOoooo000Oo00 else OO0O000
    IiIi11iI = iIiIi11 [ 0 ] if iIiIi11 else ""
    OOo0 = common . OpenURL ( "https:" + Ooo0oOooo0 [ 0 ] )
    oOOOoo00 = re . compile ( 'https[^\"]+\.mp4' ) . findall ( OOo0 )
    if oOOOoo00 :
     o00O00oO00 = re . compile ( 'q=(\d+p)' ) . findall ( OOo0 )
     o00O00oO00 = list ( reversed ( o00O00oO00 ) )
     oo0OooOOo0 ( OOoo , "https:" + Ooo0oOooo0 [ 0 ] , 172 , oO0O00oOOoooO , oO0O00oOOoooO , isFolder = False , IsPlayable = True , info = IiIi11iI , background = "," . join ( o00O00oO00 ) )
     oo0OooOOo0 ( "Resolucões: " + ", " . join ( o00O00oO00 ) , "https:" + Ooo0oOooo0 [ 0 ] , 0 , oO0O00oOOoooO , oO0O00oOOoooO , isFolder = False , info = "Clique no titulo do filme para dar play" )
    else :
     oo0OooOOo0 ( "Video offline!!" , "" , 0 , "" , "" , isFolder = False )
 except urllib2 . URLError , i1I1ii11i1Iii :
  oo0OooOOo0 ( "Video offline" , "" , 0 , "" , "" , isFolder = False )
  if 23 - 23: OO0O0O * ii1I % iiiii * OOo00O0Oo0oO
  if 9 - 9: OOo00O0Oo0oO - ooO0OO000o + Iii1I1 / OO0O0O / i11iIiiIii
def I1IIIiI1I1ii1 ( ) :
 I1i11 = xbmcgui . Dialog ( ) . select ( "Escolha o Genero" , I11i1 )
 if I1i11 != - 1 :
  global oOoO
  oOooOoO0Oo0O . setSetting ( "CatMM" , str ( I1i11 ) )
  oOoO = I1i11
  oOooOoO0Oo0O . setSetting ( "i1iiIIiiI111" , "0" )
  xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
def iiiI1I1iIIIi1 ( ) :
 i1I1iIi = 0
 iIiIi11 = 0
 try :
  ii1 = common . OpenURL ( "http://www.mmfilmeshd.tv/series/" )
  I1IiiI1ii1i = re . compile ( 'href\=\"(.+www.mmfilmeshd.tv.+)\" rel\=\"bookmark\"' ) . findall ( ii1 )
  for oooooo0O000o in range ( 0 , 5 ) :
   i1I1iIi += 1
   O00Oo000ooO0 = common . OpenURL ( "http://www.mmfilmeshd.tv/ultimos/page/" + str ( i1I1iIi ) + "/" )
   O0O00Oo = re . compile ( 'id\=\"post\-\d+\".+?\=.([^\"]+)\h*(?s)(.+?)(http[^\"]+)' ) . findall ( O00Oo000ooO0 )
   O0o = re . compile ( 'audioy..([^\<]*)' ) . findall ( O00Oo000ooO0 )
   oO0OoO00o = re . compile ( 'src=\"(http.+?www.mmfilmeshd.tv\/wp-content\/uploads[^\"]+)' ) . findall ( O00Oo000ooO0 )
   OooOo0oo0O0o00O = re . compile ( 'boxxer.+\s.+boxxer..([^\<]*)' ) . findall ( O00Oo000ooO0 )
   if O0O00Oo :
    for IIiII , OOOOoO00o0O , o0ooOooo000oOO in O0O00Oo :
     IIiII = IIiII . replace ( "&#8211;" , "-" ) . replace ( "&#038;" , "&" ) . replace ( "&#8217;" , "\'" )
     if not o0ooOooo000oOO in I1IiiI1ii1i :
      oo0OooOOo0 ( IIiII + " [COLOR lime]" + O0o [ iIiIi11 ] + "[/COLOR] [COLOR white]" + OooOo0oo0O0o00O [ iIiIi11 ] + "[/COLOR]" , o0ooOooo000oOO , 181 , oO0OoO00o [ iIiIi11 ] , oO0OoO00o [ iIiIi11 ] , isFolder = True , IsPlayable = False )
     iIiIi11 += 1
   iIiIi11 = 0
 except :
  pass
  if 17 - 17: OO0O0O . iiiii / iiI1i1 % ooO0OO000o % ii1I / i11iIiiIii
def OOOIiiiii1iI ( pagina2 ) :
 oo0OooOOo0 ( "[COLOR lime][B]CATEGORIAS DOS FILMES:[/B] " + I11i1 [ int ( oOoOoO ) ] + "[/COLOR]" , "url" , 189 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/System-icon.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = False )
 ii1II = eval ( pagina2 )
 i1I1iIi = int ( ii1II ) * 5
 o0O00oOOoo = 1
 iIiIi11 = 0
 if int ( ii1II ) > 0 :
  oo0OooOOo0 ( "[COLOR white][B]<< Página Anterior [" + str ( int ( ii1II ) ) + "[/B]][/COLOR]" , ii1II , 120 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/back-icon.png" , isFolder = False , background = pagina2 )
 try :
  ii1 = common . OpenURL ( "http://www.mmfilmeshd.tv/series/" )
  I1IiiI1ii1i = re . compile ( 'href\=\"(.+www.mmfilmeshd.tv.+)\" rel\=\"bookmark\"' ) . findall ( ii1 )
  for oooooo0O000o in range ( 0 , 5 ) :
   i1I1iIi += 1
   O00Oo000ooO0 = common . OpenURL ( "http://www.mmfilmeshd.tv/category/" + O00o0OO [ int ( oOoOoO ) ] + "/page/" + str ( i1I1iIi ) + "/" )
   O0O00Oo = re . compile ( 'id\=\"post\-\d+\".+?\=.([^\"]+)\h*(?s)(.+?)(http[^\"]+)' ) . findall ( O00Oo000ooO0 )
   O0o = re . compile ( 'audioy..([^\<]*)' ) . findall ( O00Oo000ooO0 )
   oO0OoO00o = re . compile ( 'src=\"(http.+?www.mmfilmeshd.tv\/wp-content\/uploads[^\"]+)' ) . findall ( O00Oo000ooO0 )
   OooOo0oo0O0o00O = re . compile ( 'boxxer.+\s.+boxxer..([^\<]*)' ) . findall ( O00Oo000ooO0 )
   if O0O00Oo :
    for IIiII , OOOOoO00o0O , o0ooOooo000oOO in O0O00Oo :
     IIiII = IIiII . replace ( "&#8211;" , "-" ) . replace ( "&#038;" , "&" ) . replace ( "&#8217;" , "\'" )
     if not o0ooOooo000oOO in I1IiiI1ii1i :
      oo0OooOOo0 ( IIiII + " [COLOR lime]" + O0o [ iIiIi11 ] + "[/COLOR] [COLOR white]" + OooOo0oo0O0o00O [ iIiIi11 ] + "[/COLOR]" , o0ooOooo000oOO , 181 , oO0OoO00o [ iIiIi11 ] , oO0OoO00o [ iIiIi11 ] , isFolder = True , IsPlayable = False )
     iIiIi11 += 1
     o0O00oOOoo += 1
   iIiIi11 = 0
   if o0O00oOOoo >= 50 :
    oo0OooOOo0 ( "[COLOR white][B]Próxima Página >> [" + str ( int ( ii1II ) + 2 ) + "[/B]][/COLOR]" , ii1II , 110 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/forward-icon.png" , isFolder = False , background = pagina2 )
 except :
  pass
def IIiooOooo0 ( ) :
 O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 )
 O0O00Oo = re . compile ( 'boxp\(.([^\']+)' ) . findall ( O00Oo000ooO0 )
 i111iIi1i1II1 = re . compile ( 'mCSB_container..\s(\h*(?s)(.+?))\<\/div' ) . findall ( O00Oo000ooO0 )
 i111iIi1i1II1 = i111iIi1i1II1 [ 0 ] [ 0 ] . replace ( "\t" , "" ) if i111iIi1i1II1 else ""
 if O0O00Oo :
  oOOo0O00o = common . OpenURL ( O0O00Oo [ 0 ] , headers = { 'referer' : "http://www.mmfilmeshd.tv/" } )
  Ooo0oOooo0 = re . compile ( 'opb\(.([^\']+).+?.{3}.+?[^\\>]+.([^\<]+)' ) . findall ( oOOo0O00o )
  if Ooo0oOooo0 :
   IIiII = re . sub ( ' \[.+' , '' , OO0O000 )
   for O00Oo000ooO0 , OooOo0oo0O0o00O in Ooo0oOooo0 :
    oo0OooOOo0 ( IIiII + " [COLOR lime](" + OooOo0oo0O0o00O + ")[/COLOR]" , O00Oo000ooO0 , 182 , oO0O00oOOoooO , oO0O00oOOoooO , isFolder = False , IsPlayable = True , info = i111iIi1i1II1 , background = iiIiI1i1 )
def oO0OO0 ( ) :
 O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 , headers = { 'referer' : "http://www.mmfilmeshd.tv/" } )
 O0O00Oo = re . compile ( 'addiframe\(\'([^\']+)' ) . findall ( O00Oo000ooO0 )
 if O0O00Oo :
  O0O00Oo [ 0 ] = "https://player.openload.network" + O0O00Oo [ 0 ] if not "http" in O0O00Oo [ 0 ] else O0O00Oo [ 0 ]
  oOOo0O00o = common . OpenURL ( O0O00Oo [ 0 ] , headers = { 'referer' : "https://player.openload.network" } ) . replace ( "file" , "\nfile" )
  Ooo0oOooo0 = re . compile ( 'file.+?(h[^\']+).+?(\d+p)\'' ) . findall ( oOOo0O00o )
  o0O0Oo00 = re . compile ( '([^\']+\.(vtt|srt|sub|ssa|txt|ass))' ) . findall ( oOOo0O00o )
  O0Oo0o000oO = [ ]
  I1iiii1I = [ ]
  for O00Oo000ooO0 , O0o in Ooo0oOooo0 :
   I1iiii1I . append ( O00Oo000ooO0 )
   O0Oo0o000oO . append ( O0o )
  if len ( I1iiii1I ) < 1 :
   xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Erro, video não encontrado' )
   sys . exit ( int ( sys . argv [ 1 ] ) )
  I1i11 = xbmcgui . Dialog ( ) . select ( "Selecione a resolucão" , O0Oo0o000oO )
  if I1i11 != - 1 :
   o0ooOooo000oOO = re . sub ( ' ' , '%20' , I1iiii1I [ I1i11 ] )
   global oooO
   oooO = oooO + ";;;" + OO0O000 + ";;;MM"
   if o0O0Oo00 :
    o0O0Oo00 = re . sub ( ' ' , '%20' , o0O0Oo00 [ 0 ] [ 0 ] )
    if not "http" in o0O0Oo00 :
     o0O0Oo00 = "https://player.openload.network/" + o0O0Oo00
    OOoO ( OO0O000 , o0ooOooo000oOO , oO0O00oOOoooO , IiIi11iI , sub = o0O0Oo00 )
   else :
    OOoO ( OO0O000 , o0ooOooo000oOO , oO0O00oOOoooO , IiIi11iI )
    if 99 - 99: O00ooOO * ooO0OO000o * iIi
def oOooO0OOOoO000 ( ) :
 try :
  O00Oo000ooO0 = common . OpenURL ( "http://www.mmfilmeshd.tv/series/" )
  O0O00Oo = re . compile ( 'id\=\"post\-\d+\".+?\=.([^\"]+)\h*(?s)(.+?)(http[^\"]+)' ) . findall ( O00Oo000ooO0 )
  oO0OoO00o = re . compile ( 'src=\"(http.+?www.mmfilmeshd.tv\/wp-content\/uploads[^\"]+)' ) . findall ( O00Oo000ooO0 )
  iIiIi11 = 0
  Ooo0oOooo0 = [ ]
  if O0O00Oo :
   for IIiII , OOOOoO00o0O , o0ooOooo000oOO in O0O00Oo :
    Ooo0oOooo0 . append ( [ IIiII , o0ooOooo000oOO , oO0OoO00o [ iIiIi11 ] ] )
    iIiIi11 += 1
   Ooo0oOooo0 = sorted ( Ooo0oOooo0 , key = lambda Ooo0oOooo0 : Ooo0oOooo0 [ 0 ] )
   for IIiII , o0ooOooo000oOO , oOOOO in Ooo0oOooo0 :
    IIiII = IIiII . replace ( "&#8211;" , "-" ) . replace ( "&#038;" , "&" ) . replace ( "&#8217;" , "\'" )
    oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 191 , oOOOO , oOOOO , isFolder = True , IsPlayable = False )
 except :
  oo0OooOOo0 ( "Server offline" , "" , 0 , "" , "" , isFolder = False )
def Ii ( x ) :
 O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 )
 O0O00Oo = re . compile ( 'boxp\(.([^\']+)' ) . findall ( O00Oo000ooO0 )
 i111iIi1i1II1 = re . compile ( 'mCSB_container..\s(\h*(?s)(.+?))\<\/div' ) . findall ( O00Oo000ooO0 )
 i111iIi1i1II1 = i111iIi1i1II1 [ 0 ] [ 0 ] . replace ( "\t" , "" ) if i111iIi1i1II1 else ""
 iIiIi11 = 0
 if O0O00Oo :
  if x == "None" :
   oOOo0O00o = common . OpenURL ( O0O00Oo [ 0 ] , headers = { 'referer' : "http://www.mmfilmeshd.tv/" } )
   Ooo0oOooo0 = re . compile ( 'opb\(.([^\']+).+?.{3}.+?[^\\>]+.([^\<]+)' ) . findall ( oOOo0O00o )
   O0Oo0o000oO = [ ]
   I1iiii1I = [ ]
   for O00Oo000ooO0 , O0o in Ooo0oOooo0 :
    I1iiii1I . append ( O00Oo000ooO0 )
    O0Oo0o000oO . append ( O0o )
   if len ( O0Oo0o000oO ) == 1 :
    I1i11 = 0
   else :
    I1i11 = xbmcgui . Dialog ( ) . select ( "Selecione o server:" , O0Oo0o000oO )
   if I1i11 == - 1 :
    I1i11 = 0
   if Ooo0oOooo0 :
    OOo0 = common . OpenURL ( Ooo0oOooo0 [ 0 ] [ 0 ] , headers = { 'referer' : "http://www.mmfilmeshd.tv/" } ) . replace ( "\n" , "" ) . replace ( "\r" , "" ) . replace ( '".Svplayer"' , "<end>" ) . replace ( '\t' , " " )
    OOo0 = re . sub ( '(\(s \=\= \d+\))' , r'<end>\1' , OOo0 )
    oOOOoo00 = re . compile ( 's \=\= (\d+)(.+?\<end\>)' ) . findall ( OOo0 )
    for Ii1ii111i1 in oOOOoo00 :
     oo0OooOOo0 ( "[B]Temporada " + Ii1ii111i1 [ 0 ] + "[/B]" , I1iiii1I [ I1i11 ] , 192 , oO0O00oOOoooO , oO0O00oOOoooO , isFolder = True , info = i111iIi1i1II1 , background = iIiIi11 )
     iIiIi11 += 1
def i1i1i1I ( x ) :
 OOo0 = common . OpenURL ( iiIiI1i1 , headers = { 'referer' : "http://www.mmfilmeshd.tv/" } ) . replace ( "\n" , "" ) . replace ( "\r" , "" ) . replace ( '".Svplayer"' , "<end>" ) . replace ( '\t' , " " )
 OOo0 = re . sub ( '(\(s \=\= \d+\))' , r'<end>\1' , OOo0 )
 oOOOoo00 = re . compile ( 's \=\= (\d+)(.+?\<end\>)' ) . findall ( OOo0 )
 oOoo000 = - 1
 o0O00oOOoo = 1
 OooOo0oo0O0o00O = re . compile ( "t \=\= \'([^\']+)(.+?\})" ) . findall ( oOOOoo00 [ int ( x ) ] [ 1 ] )
 o0OOOo = re . compile ( "e \=\= (\d+).+?addiframe\(\'([^\']+)" ) . findall ( oOOOoo00 [ int ( x ) ] [ 1 ] )
 for i1I1ii11i1Iii , o0ooOooo000oOO in o0OOOo :
  o0ooOooo000oOO = "https://player.openload.network" + o0ooOooo000oOO if not "http" in o0ooOooo000oOO else o0ooOooo000oOO
  if o0O00oOOoo == int ( i1I1ii11i1Iii ) :
   oOoo000 += 1
  if len ( OooOo0oo0O0o00O [ oOoo000 ] [ 1 ] ) < 30 :
   oOoo000 += 1
  IIiII = "[COLOR lime](Dub)[/COLOR]" if "dub" in OooOo0oo0O0o00O [ oOoo000 ] [ 0 ] else "[COLOR yellow](Leg)[/COLOR]"
  oo0OooOOo0 ( "Episodio " + i1I1ii11i1Iii + " [COLOR blue]" + IIiII , o0ooOooo000oOO , 194 , oO0O00oOOoooO , oO0O00oOOoooO , isFolder = False , IsPlayable = True , info = IiIi11iI )
def OooOo00o ( ) :
 if "drive.google" in iiIiI1i1 :
  xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Erro, video não encontrado' )
  sys . exit ( )
 oOOo0O00o = common . OpenURL ( iiIiI1i1 , headers = { 'referer' : "https://player.openload.network" } ) . replace ( '"' , "'" )
 Ooo0oOooo0 = re . compile ( '(h[^\']+).+?label...(\w+)' ) . findall ( oOOo0O00o )
 o0O0Oo00 = re . compile ( '([^\']+\.(vtt|srt|sub|ssa|txt|ass))' ) . findall ( oOOo0O00o )
 O0Oo0o000oO = [ ]
 I1iiii1I = [ ]
 for O00Oo000ooO0 , O0o in Ooo0oOooo0 :
  I1iiii1I . append ( O00Oo000ooO0 )
  O0Oo0o000oO . append ( O0o )
 if len ( I1iiii1I ) < 1 :
  xbmcgui . Dialog ( ) . ok ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Erro, video não encontrado' )
  sys . exit ( int ( sys . argv [ 1 ] ) )
 I1i11 = xbmcgui . Dialog ( ) . select ( "Selecione a resolucão" , O0Oo0o000oO )
 if I1i11 != - 1 :
  o0ooOooo000oOO = re . sub ( ' ' , '%20' , I1iiii1I [ I1i11 ] )
  if o0O0Oo00 :
   o0O0Oo00 = re . sub ( ' ' , '%20' , o0O0Oo00 [ 0 ] [ 0 ] )
   if not "http" in o0O0Oo00 :
    o0O0Oo00 = "https://player.openload.network/" + o0O0Oo00
   OOoO ( OO0O000 , o0ooOooo000oOO , oO0O00oOOoooO , IiIi11iI , sub = o0O0Oo00 )
  else :
   OOoO ( OO0O000 , o0ooOooo000oOO , oO0O00oOOoooO , IiIi11iI )
   if 20 - 20: ii1I * iIi + ooO0OO000o % OOO % O00ooOO
   if 13 - 13: oo00oOOo
def oOOo000oOoO0 ( ) :
 I1i11 = xbmcgui . Dialog ( ) . select ( "Escolha o Genero" , o0 )
 if I1i11 != - 1 :
  global oOoO
  oOooOoO0Oo0O . setSetting ( "CatGO" , str ( I1i11 ) )
  oOoO = I1i11
  oOooOoO0Oo0O . setSetting ( "cPageGOf" , "0" )
  xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
def OoOo00o0OO ( pagina2 ) :
 oo0OooOOo0 ( "[COLOR lime][B]CATEGORIAS DOS FILMES:[/B] " + o0 [ int ( ii1IOooO0 ) ] + "[/COLOR]" , "url" , 219 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/System-icon.png" , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/FANARTSNOVA.jpg" , isFolder = False )
 ii1II = eval ( pagina2 )
 i1I1iIi = int ( ii1II ) * 5
 o0O00oOOoo = 1
 iIiIi11 = 0
 if int ( ii1II ) > 0 :
  oo0OooOOo0 ( "[COLOR white][B]<< Página Anterior [" + str ( int ( ii1II ) ) + "[/B]][/COLOR]" , ii1II , 120 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/back-icon.png" , isFolder = False , background = pagina2 )
 try :
  for oooooo0O000o in range ( 0 , 5 ) :
   i1I1iIi += 1
   if iIi1ii1I1 [ int ( ii1IOooO0 ) ] == "all" :
    O00Oo000ooO0 = common . OpenURL ( "http://gofilmes.me/?p=" + str ( i1I1iIi ) ) . replace ( "</div></div>" , "\r\n" )
   else :
    O00Oo000ooO0 = common . OpenURL ( "http://gofilmes.me/genero/" + iIi1ii1I1 [ int ( ii1IOooO0 ) ] + "?p=" + str ( i1I1iIi ) ) . replace ( "</div></div>" , "\r\n" )
   O0O00Oo = re . compile ( 'href=\"([^\"]+)\" title\=\"([^\"]+).+b\" src\=\"([^\"]+).+n\">([^\<]+)' ) . findall ( O00Oo000ooO0 )
   for o0ooOooo000oOO , IIiII , o0O00Oo0 , i111iIi1i1II1 in O0O00Oo :
    try :
     i111iIi1i1II1 = re . sub ( '&([^;]+);' , lambda O0O00Oo : unichr ( htmlentitydefs . name2codepoint [ O0O00Oo . group ( 1 ) ] ) , i111iIi1i1II1 ) . encode ( 'utf-8' )
    except :
     pass
    IIiII = IIiII . replace ( "Assistir " , "" ) . replace ( " Online" , " -" )
    oo0OooOOo0 ( IIiII , o0ooOooo000oOO , 211 , o0O00Oo0 , o0O00Oo0 , isFolder = False , IsPlayable = True , info = i111iIi1i1II1 )
    o0O00oOOoo += 1
  if o0O00oOOoo >= 120 :
   oo0OooOOo0 ( "[COLOR white][B]Próxima Página >> [" + str ( int ( ii1II ) + 2 ) + "[/B]][/COLOR]" , ii1II , 110 , "https://raw.githubusercontent.com/BUILDTONYWARLLEY/REPOTWTUTORIAIS/master/Plugins/MM/forward-icon.png" , isFolder = False , background = pagina2 )
 except :
  oo0OooOOo0 ( "Server offline" , "" , 0 , "" , "" , isFolder = False )
def ii1IIIIiI11 ( ) :
 try :
  O00Oo000ooO0 = common . OpenURL ( iiIiI1i1 )
  O0O00Oo = re . compile ( 'iframe src\="([^\"]+)' ) . findall ( O00Oo000ooO0 )
  oOOo0O00o = common . OpenURL ( O0O00Oo [ 0 ] )
  Ooo0oOooo0 = re . compile ( 'href=\"([^\"]+)\".+?\"\>([^\<]+)' ) . findall ( oOOo0O00o )
  iI1IIIii = [ ]
  I1i11ii11 = [ ]
  iIiIi11 = 0
  for oO00ooooO0o , OO00O0oOO in Ooo0oOooo0 :
   OOo0 = common . OpenURL ( "http://paunocu.net/play/moon.php?url=" + oO00ooooO0o )
   oOOOoo00 = re . compile ( '\=(.+?x[^,]+).+\s(.+)' ) . findall ( OOo0 )
   oOOOoo00 = sorted ( oOOOoo00 , key = lambda oOOOoo00 : oOOOoo00 [ 0 ] )
   for Ii1iI111 , I1i111I in oOOOoo00 :
    I1i11ii11 . append ( "[COLOR green]" + Ooo0oOooo0 [ iIiIi11 ] [ 1 ] + "[/COLOR] " + "[COLOR yellow]" + Ii1iI111 + "[/COLOR]" )
    iI1IIIii . append ( I1i111I )
   iIiIi11 += 1
  if len ( I1i11ii11 ) >= 1 :
   I1i11 = xbmcgui . Dialog ( ) . select ( "Selecione a resolução" , I1i11ii11 )
   if I1i11 != - 1 :
    OOoO ( OO0O000 , iI1IIIii [ I1i11 ] , oO0O00oOOoooO , IiIi11iI )
  else :
   xbmcgui . Dialog ( ) . ok ( "[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]" , "Não foi possível carregar o vídeo" )
 except :
  xbmcgui . Dialog ( ) . ok ( "[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]" , "Não foi possível carregar o vídeo" )
  if 51 - 51: OOo00O0Oo0oO * Iii1I1 / ooO0OO000o . o0oo0o % Ii11111i / III
def ii1iii1I1I ( choiceTitle , fileTitle , urlTitle , choiceFile , choiceUrl , choiceNone = None , fileType = 1 , fileMask = None , defaultText = "" ) :
 oO0Ooo0ooOO0 = ''
 i1IIiIii1i = [ II111ii1II1i ( choiceFile ) , II111ii1II1i ( choiceUrl ) ]
 if choiceNone is not None :
  i1IIiIii1i = [ II111ii1II1i ( choiceNone ) ] + i1IIiIii1i
 ooOOO0OooOo = I1Ii ( II111ii1II1i ( choiceTitle ) , i1IIiIii1i )
 if choiceNone is None and ooOOO0OooOo == 0 or choiceNone is not None and ooOOO0OooOo == 1 :
  if not defaultText . startswith ( 'http' ) :
   defaultText = ""
  oO0Ooo0ooOO0 = oOO ( II111ii1II1i ( fileTitle ) , defaultText ) . strip ( ) . decode ( "utf-8" )
 elif choiceNone is None and ooOOO0OooOo == 1 or choiceNone is not None and ooOOO0OooOo == 2 :
  if defaultText . startswith ( 'http' ) :
   defaultText = ""
  oO0Ooo0ooOO0 = xbmcgui . Dialog ( ) . browse ( fileType , II111ii1II1i ( urlTitle ) , 'files' , fileMask , False , False , defaultText ) . decode ( "utf-8" )
 return oO0Ooo0ooOO0
def OOoO ( name , url , iconimage = None , info = '' , sub = '' , metah = '' ) :
 if ";;;" in oooO :
  OOOOoO00o0O = oooO . split ( ";;;" )
  if "RC" in OOOOoO00o0O [ 2 ] :
   Ii1II ( OOOOoO00o0O [ 0 ] , iconimage , OOOOoO00o0O [ 1 ] , "95" , "historic.txt" )
  elif "NC" in OOOOoO00o0O [ 2 ] :
   Ii1II ( OOOOoO00o0O [ 0 ] , iconimage , OOOOoO00o0O [ 1 ] , "78" , "historic.txt" )
  elif "MM" in OOOOoO00o0O [ 2 ] :
   Ii1II ( OOOOoO00o0O [ 0 ] , iconimage , OOOOoO00o0O [ 1 ] , "181" , "historic.txt" )
 url = re . sub ( '\.mp4$' , '.mp4?play' , url )
 url = common . getFinalUrl ( url )
 if 89 - 89: iIi + iiiii + iIi * ii1I + OO0O0O % iiI1i1
 oOo0oO = xbmcgui . ListItem ( path = url )
 if metah :
  oOo0oO . setInfo ( type = "Video" , infoLabels = metah )
 else :
  oOo0oO . setInfo ( type = "Video" , infoLabels = { "mediatype" : "video" , "Title" : name , "Plot" : info } )
 if sub != '' :
  oOo0oO . setSubtitles ( [ 'special://temp/example.srt' , sub ] )
 if iconimage is not None :
  try :
   oOo0oO . setArt ( { 'thumb' : iconimage } )
  except :
   oOo0oO . setThumbnailImage ( iconimage )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo0oO )
 if 5 - 5: Ii11111i - Ii11111i . oo00oOOo + OOo - Ii11111i . O00ooOO
def oo0OooOOo0 ( name , url , mode , iconimage = '' , logos = '' , index = - 1 , move = 0 , isFolder = True , IsPlayable = False , background = None , cacheMin = '0' , info = '' , metah = '' ) :
 IiIi1i1ii = { 'name' : name , 'url' : url , 'mode' : mode , 'iconimage' : iconimage , 'logos' : logos , 'cache' : cacheMin , 'info' : info , 'background' : background , 'metah' : metah }
 iiIi = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 if metah :
  iiIi . setInfo ( type = "Video" , infoLabels = metah )
  iiIi . setArt ( { "thumb" : metah [ 'cover_url' ] , "poster" : metah [ 'cover_url' ] , "banner" : metah [ 'cover_url' ] , "fanart" : metah [ 'backdrop_url' ] } )
 else :
  iiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : info } )
  if 71 - 71: OOo . ii1I
  iiIi . setArt ( { "poster" : iconimage , "banner" : logos , "fanart" : logos } )
  if 94 - 94: Ii11111i . iIi
 if IsPlayable :
  iiIi . setProperty ( 'IsPlayable' , 'true' )
 OoOoo0oO = [ ]
 if mode == 1 or mode == 2 :
  OoOoo0oO = [ ]
 elif mode == 61 and info == "" :
  iiIi . addContextMenuItems ( items = [ ( "Add ao fav. do [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]" , 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( name ) ) ) ] )
 elif mode == 78 :
  iiIi . addContextMenuItems ( items = [ ( "Add ao fav. do [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]" , 'XBMC.RunPlugin({0}?url={1}&mode=72&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( name ) ) ) ] )
 elif mode == 95 :
  iiIi . addContextMenuItems ( items = [ ( "Add ao fav. do [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]" , 'XBMC.RunPlugin({0}?url={1}&mode=93&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( name ) ) ) ] )
 elif mode == 135 :
  iiIi . addContextMenuItems ( items = [ ( "Add ao fav. do [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]" , 'XBMC.RunPlugin({0}?url={1}&mode=131&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( name ) ) ) ] )
 elif mode == 171 :
  iiIi . addContextMenuItems ( items = [ ( "Add ao fav. do [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]" , 'XBMC.RunPlugin({0}?url={1}&mode=175&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( name ) ) ) ] )
 elif mode == 181 :
  iiIi . addContextMenuItems ( items = [ ( "Add ao fav. do [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]" , 'XBMC.RunPlugin({0}?url={1}&mode=185&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( name ) ) ) ] )
 elif mode == 191 :
  iiIi . addContextMenuItems ( items = [ ( "Add ao fav. do [COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]" , 'XBMC.RunPlugin({0}?url={1}&mode=195&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( name ) ) ) ] )
 if info == "Filmes Favoritos" :
  OoOoo0oO = [ ( "Remover dos favoritos" , 'XBMC.RunPlugin({0}?index={1}&mode=333)' . format ( sys . argv [ 0 ] , index ) ) ,
 ( II111ii1II1i ( 30030 ) , 'XBMC.RunPlugin({0}?index={1}&mode={2}&move=-1)' . format ( sys . argv [ 0 ] , index , 338 ) ) ,
 ( II111ii1II1i ( 30031 ) , 'XBMC.RunPlugin({0}?index={1}&mode={2}&move=1)' . format ( sys . argv [ 0 ] , index , 338 ) ) ,
 ( II111ii1II1i ( 30032 ) , 'XBMC.RunPlugin({0}?index={1}&mode={2}&move=0)' . format ( sys . argv [ 0 ] , index , 338 ) ) ]
  iiIi . addContextMenuItems ( OoOoo0oO )
 if info == "Séries Favoritas" :
  OoOoo0oO = [ ( "Remover dos favoritos" , 'XBMC.RunPlugin({0}?index={1}&mode=334)' . format ( sys . argv [ 0 ] , index ) ) ,
 ( II111ii1II1i ( 30030 ) , 'XBMC.RunPlugin({0}?index={1}&mode={2}&move=-1)' . format ( sys . argv [ 0 ] , index , 339 ) ) ,
 ( II111ii1II1i ( 30031 ) , 'XBMC.RunPlugin({0}?index={1}&mode={2}&move=1)' . format ( sys . argv [ 0 ] , index , 339 ) ) ,
 ( II111ii1II1i ( 30032 ) , 'XBMC.RunPlugin({0}?index={1}&mode={2}&move=0)' . format ( sys . argv [ 0 ] , index , 339 ) ) ]
  iiIi . addContextMenuItems ( OoOoo0oO )
 if mode == 10 :
  IiIi1i1ii [ 'index' ] = index
 ii = '{0}?{1}' . format ( sys . argv [ 0 ] , urllib . urlencode ( IiIi1i1ii ) )
 xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii , listitem = iiIi , isFolder = isFolder )
 if 81 - 81: Iii1I1 % o0oo0o
def oOO ( title = "" , defaultText = "" ) :
 IiIII1i1i = xbmc . Keyboard ( defaultText , title )
 IiIII1i1i . doModal ( )
 II11I = "" if not IiIII1i1i . isConfirmed ( ) else IiIII1i1i . getText ( )
 return II11I
 if 80 - 80: Ii11111i
def I1Ii ( title , chList ) :
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 IIIOOOo = ooOO0O0ooOooO . select ( title , chList )
 return IIIOOOo
 if 69 - 69: OO0O0O * OO0O0O * i11iIiiIii + III / Ii11111i % o0oo0o
def Ii1II ( url , iconimage , name , mode , file ) :
 file = os . path . join ( i1I1ii1II1iII , file )
 O0OO0oOoO0O0O = common . ReadList ( file )
 for oo000oOo0 in O0OO0oOoO0O0O :
  if oo000oOo0 [ "url" ] . lower ( ) == url . decode ( "utf-8" ) . lower ( ) :
   if "favorites" in file :
    xbmc . executebuiltin ( "Notification({0}, '{1}' {2}, 5000, {3})" . format ( iI1 , name , II111ii1II1i ( 30011 ) , i1I11i ) )
   return
 iIiI1I1Ii = [ ]
 for IIIiIiIi11Ii in iIiI1I1Ii :
  if IIIiIiIi11Ii [ "name" ] . lower ( ) == name . decode ( "utf-8" ) . lower ( ) :
   url = IIIiIiIi11Ii [ "url" ] . encode ( "utf-8" )
   iconimage = IIIiIiIi11Ii [ "image" ] . encode ( "utf-8" )
   break
 if not iconimage :
  iconimage = ""
 iIII1i1i = { "url" : url . decode ( "utf-8" ) , "image" : iconimage . decode ( "utf-8" ) , "name" : name . decode ( "utf-8" ) , "mode" : mode }
 O0OO0oOoO0O0O . append ( iIII1i1i )
 common . SaveList ( file , O0OO0oOoO0O0O )
 if "favorites" in file :
  xbmc . executebuiltin ( "Notification({0}, '{1}' {2}, 5000, {3})" . format ( iI1 , name , II111ii1II1i ( 30012 ) , i1I11i ) )
  if 35 - 35: ooO0OO000o * iiI1i1 - iiiii . iiI1i1 . iiI1i1
def I1IIOO0 ( file , info ) :
 file = os . path . join ( i1I1ii1II1iII , file )
 iIiI1I1Ii = common . ReadList ( file )
 iIiIi11 = 0
 for IIIiIiIi11Ii in iIiI1I1Ii :
  oo0OooOOo0 ( IIIiIiIi11Ii [ "name" ] . encode ( "utf-8" ) , IIIiIiIi11Ii [ "url" ] . encode ( "utf-8" ) , IIIiIiIi11Ii [ "mode" ] , IIIiIiIi11Ii [ "image" ] . encode ( "utf-8" ) , IIIiIiIi11Ii [ "image" ] . encode ( "utf-8" ) , index = iIiIi11 , isFolder = True , IsPlayable = False , info = info )
  iIiIi11 += 1
  if 84 - 84: OOo % ooO00oOoo - OOo . OOO
def III1iI1iII1I ( file , info ) :
 file = os . path . join ( i1I1ii1II1iII , file )
 iIiI1I1Ii = common . ReadList ( file )
 for IIIiIiIi11Ii in reversed ( iIiI1I1Ii ) :
  oo0OooOOo0 ( IIIiIiIi11Ii [ "name" ] . encode ( "utf-8" ) , IIIiIiIi11Ii [ "url" ] . encode ( "utf-8" ) , IIIiIiIi11Ii [ "mode" ] , IIIiIiIi11Ii [ "image" ] . encode ( "utf-8" ) , IIIiIiIi11Ii [ "image" ] . encode ( "utf-8" ) , isFolder = True , IsPlayable = False , info = info )
  if 39 - 39: o0oo0o * ooO00oOoo / OOo * Oooo000o . iiI1i1 % ooO0OO000o
def O0OoOoO00O ( index , listFile ) :
 iIiI1I1Ii = common . ReadList ( listFile )
 if index < 0 or index >= len ( iIiI1I1Ii ) :
  return
 del iIiI1I1Ii [ index ]
 common . SaveList ( listFile , iIiI1I1Ii )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 if 96 - 96: III % oo00oOOo . o0oo + Ii11111i
def Ii11Iii1i1ii ( file ) :
 file = os . path . join ( i1I1ii1II1iII , file )
 Ii1i1i1111 = oOO ( II111ii1II1i ( 30014 ) )
 if len ( Ii1i1i1111 ) < 1 :
  return
 o0oO0O00oOo = oOO ( II111ii1II1i ( 30015 ) )
 if len ( o0oO0O00oOo ) < 1 :
  return
 I1111I1II11 = ii1iii1I1I ( 30023 , 30023 , 30023 , 30024 , 30025 , 30021 , fileType = 2 )
 if 30 - 30: iiiii % iiiii
 O0OO0oOoO0O0O = common . ReadList ( file )
 for oo000oOo0 in O0OO0oOoO0O0O :
  if oo000oOo0 [ "url" ] . lower ( ) == o0oO0O00oOo . decode ( "utf-8" ) . lower ( ) :
   xbmc . executebuiltin ( "Notification({0}, '{1}' {2}, 5000, {3})" . format ( iI1 , Ii1i1i1111 , II111ii1II1i ( 30011 ) , i1I11i ) )
   return
 iIII1i1i = { "url" : o0oO0O00oOo . decode ( "utf-8" ) , "image" : I1111I1II11 , "name" : Ii1i1i1111 . decode ( "utf-8" ) }
 O0OO0oOoO0O0O . append ( iIII1i1i )
 if common . SaveList ( file , O0OO0oOoO0O0O ) :
  xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
  if 52 - 52: o0oo + o0oo . ooO0OO000o
def Iii ( index , step , listFile ) :
 IIIII1iii = common . ReadList ( listFile )
 if index + step >= len ( IIIII1iii ) or index + step < 0 :
  return
 if step == 0 :
  step = IIiiii ( len ( IIIII1iii ) , index )
 if step < 0 :
  iI111i1I1II = IIIII1iii [ 0 : index + step ] + [ IIIII1iii [ index ] ] + IIIII1iii [ index + step : index ] + IIIII1iii [ index + 1 : ]
 elif step > 0 :
  iI111i1I1II = IIIII1iii [ 0 : index ] + IIIII1iii [ index + 1 : index + 1 + step ] + [ IIIII1iii [ index ] ] + IIIII1iii [ index + 1 + step : ]
 else :
  return
 common . SaveList ( listFile , iI111i1I1II )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 if 96 - 96: iIi / oo00oOOo * ooO0OO000o - Oo * oo00oOOo
def o0Ii1Iii111IiI1 ( title , defaultt = '' ) :
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 oO0Ooo0ooOO0 = ooOO0O0ooOooO . input ( title , defaultt = defaultt , type = xbmcgui . INPUT_NUMERIC )
 return None if oO0Ooo0ooOO0 == '' else int ( oO0Ooo0ooOO0 )
 if 98 - 98: iIi - iiiii % III + Iii1I1 . o0oo0o
def IIiiii ( listLen , index ) :
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 OoOO = o0Ii1Iii111IiI1 ( '{0} (1-{1})' . format ( II111ii1II1i ( 30033 ) , listLen ) )
 return 0 if OoOO is None or OoOO > listLen or OoOO <= 0 else OoOO - 1 - index
 if 44 - 44: Ii11111i
def O0O0o0o0o ( ) :
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 if 9 - 9: oo00oOOo + OOo - OO0O0O - o0oo0o + OOO
def o000O0OOoo ( url , background ) :
 oOooOoO0Oo0O . setSetting ( background , str ( int ( url ) - 1 ) )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 if 60 - 60: III * iIi % Oooo000o + O00ooOO
def o0ooO00OOooo0Ooo ( url , background ) :
 if 66 - 66: O00ooOO
 oOooOoO0Oo0O . setSetting ( background , str ( int ( url ) + 1 ) )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 if 91 - 91: O00ooOO + III
def I1II ( t ) :
 OoOooo = '' . join ( chr ( ord ( letter ) - 1 ) for letter in t )
 return OoOooo
 if 74 - 74: OO0O0O * OOo00O0Oo0oO % OOo
 if 36 - 36: iiiii - O00ooOO
def OOooo ( url ) :
 try :
  import urllib . request as urllib2
 except ImportError :
  import urllib2
 oOO0OO0O = urllib2 . build_opener ( )
 oOO0OO0O . addheaders = [ ( 'User-Agent' , 'Mozilla/5.0' ) ]
 if 78 - 78: o0oo0o / ooO0OO000o % OOo
 oOooO0 = oOO0OO0O . open ( url )
 iIII1i1i = oOooO0 . read ( ) . decode ( 'utf-8' )
 oO00OoOO = iIII1i1i
 return oO00OoOO
 if 18 - 18: ooO00oOoo - OOo % ii1I + Iii1I1 + i11iIiiIii + ii1I
 if 91 - 91: OOo + ooO00oOoo . III
 if 71 - 71: Oo % OOO / Ii11111i / oo00oOOo
 if 66 - 66: oo00oOOo - OOO * OOo00O0Oo0oO + OOo + OOO - OO0O0O
def iiiI1ii11 ( x ) :
 x = str ( x )
 oO0OOOO0 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 OOo0oO00ooO00 = os . path . join ( oO0OOOO0 , "study.txt" )
 file = open ( OOo0oO00ooO00 , "w" )
 file . write ( x )
 file . close ( )
 if 49 - 49: iiiii / i11iIiiIii * i11iIiiIii
ooOooo0OO = dict ( urlparse . parse_qsl ( sys . argv [ 2 ] . replace ( '?' , '' ) ) )
iiIiI1i1 = ooOooo0OO . get ( 'url' )
IiiI11i1I = ooOooo0OO . get ( 'logos' , '' )
OO0O000 = ooOooo0OO . get ( 'name' )
oO0O00oOOoooO = ooOooo0OO . get ( 'iconimage' )
OOo0iiIii1IIi = int ( ooOooo0OO . get ( 'cache' , '0' ) )
ii1IiIiI1 = int ( ooOooo0OO . get ( 'index' , '-1' ) )
OOOoOo00O = int ( ooOooo0OO . get ( 'move' , '0' ) )
O0ooOo0o0Oo = int ( ooOooo0OO . get ( 'mode' , '0' ) )
IiIi11iI = ooOooo0OO . get ( 'info' )
oooO = ooOooo0OO . get ( 'background' )
Oo0O00O000 = ooOooo0OO . get ( 'metah' )
if 71 - 71: OO0O0O - Ii11111i . III % iiiii + Ii11111i
if O0ooOo0o0Oo == 0 :
 OO0OoO0o00 ( True )
 if 26 - 26: oo00oOOo + Ii11111i / Oooo000o % OOo % o0oo + ooO0OO000o
elif O0ooOo0o0Oo == - 1 : IIiI1I ( )
elif O0ooOo0o0Oo == - 2 : Oo0oOOo ( )
elif O0ooOo0o0Oo == - 3 : I1111I1iII11 ( )
elif O0ooOo0o0Oo == - 4 : MDesenhos ( )
elif O0ooOo0o0Oo == 3 or O0ooOo0o0Oo == 32 :
 OOoO ( OO0O000 , iiIiI1i1 , oO0O00oOOoooO , IiIi11iI )
elif O0ooOo0o0Oo == 301 :
 I1IIOO0 ( 'favoritesf.txt' , "Filmes Favoritos" )
 III1i1i ( )
elif O0ooOo0o0Oo == 302 :
 I1IIOO0 ( 'favoritess.txt' , "Séries Favoritas" )
 iiI1 ( )
elif O0ooOo0o0Oo == 305 :
 III1iI1iII1I ( 'historic.txt' , "Historico" )
 iiI1 ( )
elif O0ooOo0o0Oo == 31 :
 Ii1II ( iiIiI1i1 , oO0O00oOOoooO , OO0O000 , "61" , 'favoritess.txt' )
elif O0ooOo0o0Oo == 72 :
 Ii1II ( iiIiI1i1 , oO0O00oOOoooO , OO0O000 , "78" , 'favoritesf.txt' )
elif O0ooOo0o0Oo == 93 :
 Ii1II ( iiIiI1i1 , oO0O00oOOoooO , OO0O000 , "95" , 'favoritesf.txt' )
elif O0ooOo0o0Oo == 131 :
 Ii1II ( iiIiI1i1 , oO0O00oOOoooO , OO0O000 , "135" , 'favoritess.txt' )
elif O0ooOo0o0Oo == 175 :
 Ii1II ( iiIiI1i1 , oO0O00oOOoooO , OO0O000 , "171" , 'favoritesf.txt' )
elif O0ooOo0o0Oo == 185 :
 Ii1II ( iiIiI1i1 , oO0O00oOOoooO , OO0O000 , "181" , 'favoritesf.txt' )
elif O0ooOo0o0Oo == 195 :
 Ii1II ( iiIiI1i1 , oO0O00oOOoooO , OO0O000 , "191" , 'favoritess.txt' )
elif O0ooOo0o0Oo == 333 :
 O0OoOoO00O ( ii1IiIiI1 , ooo )
elif O0ooOo0o0Oo == 338 :
 Iii ( ii1IiIiI1 , OOOoOo00O , ooo )
elif O0ooOo0o0Oo == 334 :
 O0OoOoO00O ( ii1IiIiI1 , ii1I1i1I )
elif O0ooOo0o0Oo == 339 :
 Iii ( ii1IiIiI1 , OOOoOo00O , ii1I1i1I )
elif O0ooOo0o0Oo == 38 :
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 i11I1I1iiI = ooOO0O0ooOooO . yesno ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Deseja Mesmo Excluir Todos os Filmes Favoritos?' )
 if i11I1I1iiI :
  common . DelFile ( ooo )
  sys . exit ( )
elif O0ooOo0o0Oo == 39 :
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 i11I1I1iiI = ooOO0O0ooOooO . yesno ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Deseja Mesmo Excluir Todos as Séries Favoritas?' )
 if i11I1I1iiI :
  common . DelFile ( ii1I1i1I )
  sys . exit ( )
elif O0ooOo0o0Oo == 40 :
 ooOO0O0ooOooO = xbmcgui . Dialog ( )
 i11I1I1iiI = ooOO0O0ooOooO . yesno ( '[COLOR yellow]MM[/COLOR] [COLOR lime]Maroto[/COLOR]' , 'Deseja Mesmo Excluir Todo o Histórico?' )
 if i11I1I1iiI :
  common . DelFile ( OOoo0O0 )
  sys . exit ( )
  if 34 - 34: iiI1i1 % ooO00oOoo . Iii1I1 . OO0O0O
elif O0ooOo0o0Oo == 41 :
 addon_log ( "puxarconf" )
 xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR] [COLOR white]CONFIGURAÇÕES![B][COLOR yellow]|[/COLOR][COLOR blue]|[/COLOR][COLOR yellow]|[/COLOR] [/B]' , '[B][COLOR yellow]|[/COLOR][/B] [B]ATIVAR E DESATIVAR AS MENSAGENS [/B][B][COLOR yellow]|[/COLOR] CONFIGURAR MM MAROTO[/B] [B][COLOR yellow]|[/COLOR][/B]' )
 xbmcaddon . Addon ( ) . openSettings ( )
 xbmcgui . Dialog ( ) . ok ( '[B][COLOR yellow]LEIA COM ATENÇÃO:[/COLOR][/B]' , '[B][COLOR yellow]|[/COLOR][/B][COLOR white] POR FAVOR SAIR DO ADD-ON E ENTRE NOVAMENTE,[B] [COLOR yellow]|[/COLOR][/B] PARA ATUALIZAR AS CONFIGURAÇÕES![B] [COLOR yellow]|[/COLOR][/B]' )
 xbmc . executebuiltin ( "XBMC.Container.Refresh(%s?mode=None, replace)" % sys . argv [ 0 ] )
 xbmcplugin . endOfDirectory ( sys . exit ( 0 ) )
 if 93 - 93: ii1I . i11iIiiIii . oo00oOOo
elif O0ooOo0o0Oo == 42 :
 addon_log ( "infovip" )
 xbmcgui . Dialog ( ) . ok ( titulo_vip , url_vip_dialogo )
 #OOOooOO0 ( True )
 xbmcaddon . Addon ( ) . openSettings ( )
 xbmc . executebuiltin ( "XBMC.Container.Refresh(%s?mode=None, replace)" % sys . argv [ 0 ] )
 xbmcplugin . endOfDirectory ( sys . exit ( 0 ) )
 if 99 - 99: iiI1i1 - iIi - O00ooOO % Oooo000o
elif O0ooOo0o0Oo == 43 :
 #o00oO0oOo00 ( True )
 if 21 - 21: ooO0OO000o % o0oo . ii1I - iiiii
if O0ooOo0o0Oo == 44 :
 OOOooOO0 ( True )
 if 4 - 4: iiiii . ooO00oOoo
if O0ooOo0o0Oo == 45 :
 II111iiiI1Ii ( True )
 if 78 - 78: o0oo + iiI1i1 - Iii1I1
if O0ooOo0o0Oo == 46 :
 o0o ( True )
 if 10 - 10: iIi % III
 if 97 - 97: iiiii - iIi
elif O0ooOo0o0Oo == 54 :
 OO ( True )
 if 58 - 58: OO0O0O + Iii1I1
 if 30 - 30: ooO00oOoo % Oo * Ii11111i - o0oo * o0oo0o % ooO00oOoo
 if 46 - 46: i11iIiiIii - Iii1I1 . O00ooOO
elif O0ooOo0o0Oo == 50 :
 O0O0o0o0o ( )
elif O0ooOo0o0Oo == 60 :
 ii1iii1i ( )
 III1i1i ( )
elif O0ooOo0o0Oo == 61 :
 IiII111i1i11 ( oooO )
 III1i1i ( )
elif O0ooOo0o0Oo == 62 :
 II11IiIi11 ( )
 III1i1i ( )
elif O0ooOo0o0Oo == 71 :
 o0O ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 78 :
 OOOooo ( )
 III1i1i ( )
elif O0ooOo0o0Oo == 79 :
 OooO0OOo0OOo0o0O0O ( )
 III1i1i ( )
elif O0ooOo0o0Oo == 80 :
 o0OO0o0oOOO0O ( )
elif O0ooOo0o0Oo == 81 :
 OooooOOoo0 ( iiIiI1i1 )
elif O0ooOo0o0Oo == 90 :
 OooooO0oOOOO ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 91 :
 IIii11Ii1i1I ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 92 :
 Oooo0O ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 95 :
 I1IiI11 ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 100 :
 I1iii11 ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 101 :
 ooo0O ( )
elif O0ooOo0o0Oo == 102 :
 I11iiiii1II ( iiIiI1i1 )
 iiI1 ( )
elif O0ooOo0o0Oo == 103 :
 Oo000ooOOO ( )
elif O0ooOo0o0Oo == 105 :
 oOooOoO0Oo0O . setSetting ( "cEPG" , "1" )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
elif O0ooOo0o0Oo == 110 :
 o0ooO00OOooo0Ooo ( iiIiI1i1 , oooO )
elif O0ooOo0o0Oo == 120 :
 o000O0OOoo ( iiIiI1i1 , oooO )
elif O0ooOo0o0Oo == 130 :
 OO0O00oOo ( "series" , "cPageser" )
 III1i1i ( )
elif O0ooOo0o0Oo == 135 :
 IIiI1Ii ( oooO )
 III1i1i ( )
elif O0ooOo0o0Oo == 133 :
 Ii11 ( )
 III1i1i ( )
elif O0ooOo0o0Oo == 139 :
 iI1I ( )
 III1i1i ( )
elif O0ooOo0o0Oo == 140 :
 OO0O00oOo ( "animes" , "cPageani" )
 III1i1i ( )
elif O0ooOo0o0Oo == 150 :
 OO0O00oOo ( "desenhos" , "cPagedes" )
 III1i1i ( )
elif O0ooOo0o0Oo == 160 :
 IIii11I1i1I ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 170 :
 oOOOOo0oo0O ( "Rapidvideo" , "cPagefo1" )
 iiI1 ( )
elif O0ooOo0o0Oo == 171 :
 ooo000ooO0000 ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 172 :
 ii1O000OOO0OOo ( )
elif O0ooOo0o0Oo == 85 :
 oO0oO0 ( )
elif O0ooOo0o0Oo == 180 :
 OOOIiiiii1iI ( "i1iiIIiiI111" )
 iiI1 ( )
elif O0ooOo0o0Oo == 181 :
 IIiooOooo0 ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 182 :
 oO0OO0 ( )
elif O0ooOo0o0Oo == 184 :
 iiiI1I1iIIIi1 ( )
 iiI1 ( )
elif O0ooOo0o0Oo == 189 :
 I1IIIiI1I1ii1 ( )
elif O0ooOo0o0Oo == 190 :
 oOooO0OOOoO000 ( )
 III1i1i ( )
elif O0ooOo0o0Oo == 191 :
 Ii ( oooO )
 III1i1i ( )
elif O0ooOo0o0Oo == 192 :
 i1i1i1I ( oooO )
 III1i1i ( )
elif O0ooOo0o0Oo == 194 :
 OooOo00o ( )
 if 100 - 100: III / OOO * Oo . Iii1I1 / Ii11111i
 if 83 - 83: iIi
elif O0ooOo0o0Oo == 210 :
 OoOo00o0OO ( "cPageGOf" )
 iiI1 ( )
elif O0ooOo0o0Oo == 211 :
 ii1IIIIiI11 ( )
elif O0ooOo0o0Oo == 219 :
 oOOo000oOoO0 ( )
elif O0ooOo0o0Oo == 220 :
 oOOoo00O00o ( )
elif O0ooOo0o0Oo == 221 :
 ooO0O0O0ooOOO ( )
elif O0ooOo0o0Oo == 229 :
 oooOo0OOOoo0 ( )
 if 48 - 48: ooO0OO000o * Ii11111i * iIi
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 50 - 50: OOo00O0Oo0oO % ii1I
# Bandido Filho da Puta.... Cornaum...kkkkkk CHUPA MAIS ESSE...KKK
