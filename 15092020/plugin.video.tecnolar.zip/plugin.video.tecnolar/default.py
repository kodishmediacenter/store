
# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.tecnolar'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')





def addDir(title,url,icons):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} ) 
    liz.setArt({'thumb':icons,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':
    YOUTUBE_CHANNEL_ID1 = "channel/UCmIKEn8zuSH8YQ45xxDafQQ"
    icon1 = "https://yt3.ggpht.com/a/AATXAJzSR1-lCLJAxSELTytZtdYRFVFatajz47SislH5wQ=s256-c-k-c0xffffffff-no-rj-mo"
    YOUTUBE_CHANNEL_ID2 = "channel/UCmIKEn8zuSH8YQ45xxDafQQ/live"
    icon2 = "https://yt3.ggpht.com/a/AATXAJzSR1-lCLJAxSELTytZtdYRFVFatajz47SislH5wQ=s256-c-k-c0xffffffff-no-rj-mo"
   

    
   
    

    addDir(title="Canal Tecnolar Tecnlogia",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",icons=icon1)
    addDir(title="Live [Quando estiiver ao vivo]"            , url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",icons=icon2)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
