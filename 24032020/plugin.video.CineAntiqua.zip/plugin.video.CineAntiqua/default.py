
# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.CineAntiqua'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')





def addDir(title,url,icons):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} ) 
    liz.setArt({'thumb':icons,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':
    YOUTUBE_CHANNEL_ID1 = "channel/UC7wpTuQLxFnw5K4-CshHquA"
    icon1 = "https://yt3.ggpht.com/a/AATXAJzDK5h834CBUCYL6u7P_iRktM40_wbrOPoIfw=s256-c-k-c0xffffffff-no-rj-mo"
    
    YOUTUBE_CHANNEL_ID2 = "channel/UCH3Rr4lLEF28T9Yllqs5Dnw"
    icon2 = "https://yt3.ggpht.com/a/AATXAJxmGGXQSE-V60f3p788-ToBTDCJKnPsYr104Q=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID3 = "channel/UCoiezkY41Q6Qm3Il5VxJUeA"
    icon3 = "https://yt3.ggpht.com/a/AATXAJyHdtxPBDtKGaa1DBox6GxO2in_Rvz6i8Xdwg=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID4 = "channel/UCbXecOJ2z42e9nyG7qNrszg"
    icon4 = "https://yt3.ggpht.com/a/AATXAJyY0w9Va7kgX_6iNFiDFqURWZ39NJwBhe9PgQ=s256-c-k-c0xffffffff-no-rj-mo"

    YOUTUBE_CHANNEL_ID5 = "channel/UCstTh_IJTpw9ruYZyigd0hQ"
    icon5 = "https://yt3.ggpht.com/a/AATXAJzAXXFmz_ym8Zwdh9QlNXDeQU3v6U96a3CgdA=s256-c-k-c0xffffffff-no-rj-mo"

   

    
   
    

    addDir(title="Cine Antiqua - Filmes Classicos",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",icons=icon1)
    addDir(title="Cine Antiqua Purple            ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",icons=icon2)
    #addDir(title="Cine Antiqua Black             ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",icons=icon3)
    addDir(title="Cine Antiqua Gold              ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",icons=icon4)
    addDir(title="Cine Antiqua Red               ",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",icons=icon5)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
