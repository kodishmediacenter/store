import xbmcgui
import xbmc
import os

stremio = os.path.join(xbmc.translatePath("special://home/addons/plugin.executable/stremio.sh").decode("utf-8"))


dialog = xbmcgui.Dialog()
ret = dialog.select('[COLOR yellow]Kodish Config [/COLOR]', ['Ajuste do Monitor','Navegador de Internet','Terminal Linux','Gparted','', '','','', '','','','','','','','','',''])


if ret == 0:
	os.system("xfce4-display-settings")

if ret == 1:
	dialog = xbmcgui.Dialog()
	d = dialog.input('Digite O Site que deseja acessar: ', type=xbmcgui.INPUT_ALPHANUM)
	os.system('google-chrome-stable --kiosk '+d+'')

if ret == 2:
	os.system("exo-open --launch TerminalEmulator")
if ret == 3:
	os.system("/usr/sbin/gparted")
	


	


