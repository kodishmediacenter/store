import os
os.system('google-chrome-stable --kiosk https://www.google.com/')


	


