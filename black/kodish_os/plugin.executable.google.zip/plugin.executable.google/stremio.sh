cd "/opt/kodish/plex/" 
./Plex_Media_Player.AppImage %U