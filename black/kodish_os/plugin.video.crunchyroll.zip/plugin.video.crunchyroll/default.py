# -*- coding: cp1252 -*-
import xbmc
import xbmcgui
import webbrowser

def webplayer(url):
    if xbmc . getCondVisibility ( 'system.platform.android' ) :
        ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+url+'' ) )
    else:
        ost = webbrowser . open ( ''+url+'' )

def menu_animes():
    dialog = xbmcgui.Dialog()
    ret2 = dialog.select('[B].:::  Crunchyroll TV  Animes :::.[/B]', ['Populares','Transmiss�o Simult�nea','Atualizados','Ordem Alfab�tica','G�neros','Temporadas'])

    if ret2 == 0:
        url = "https://www.crunchyroll.com/pt-br/videos/anime/popular"
        webplayer(url)
    if ret2 == 1:
        url = "https://www.crunchyroll.com/pt-br/videos/anime/simulcasts"
        webplayer(url)
    if ret2 == 2:
        url = "https://www.crunchyroll.com/pt-br/videos/anime/updated"
        webplayer(url)
    if ret2 == 3:
        url = "https://www.crunchyroll.com/pt-br/videos/anime/alpha"
        webplayer(url)
    if ret2 == 4:
        url = "https://www.crunchyroll.com/pt-br/videos/anime/genres"
        webplayer(url)
    if ret2 == 5:
        url = "https://www.crunchyroll.com/pt-br/videos/anime/seasons"
        webplayer(url)
        
        

def menu_dramas():
    dialog = xbmcgui.Dialog()
    ret3 = dialog.select('[B].:::  Crunchyroll TV  Dramas :::.[/B]', ['Populares','Transmiss�o Simult�nea','Atualizados','Ordem Alfab�tica','G�neros','Temporadas'])    

    if ret3 == 0:
        url = "https://www.crunchyroll.com/pt-br/videos/drama/popular"
        webplayer(url)
    if ret3 == 1:
        url = "https://www.crunchyroll.com/pt-br/videos/drama/simulcasts"
        webplayer(url)
    if ret3 == 2:
        url = "https://www.crunchyroll.com/pt-br/videos/drama/updated"
        webplayer(url)
    if ret3 == 3:
        url = "https://www.crunchyroll.com/pt-br/videos/drama/alpha"
        webplayer(url)
    if ret3 == 4:
        url = "https://www.crunchyroll.com/pt-br/videos/drama/genres"
        webplayer(url)
    if ret3 == 5:
        url = "https://www.crunchyroll.com/pt-br/videos/drama/seasons"
        webplayer(url)
        
dialog = xbmcgui.Dialog()
ret4 = dialog.select('[B].:::  Crunchyroll TV   :::.[/B]', ['Animes','Drama'])

if ret4 == 0:
    menu_animes()
if ret4 == 1:
    menu_dramas()
    


   
    
