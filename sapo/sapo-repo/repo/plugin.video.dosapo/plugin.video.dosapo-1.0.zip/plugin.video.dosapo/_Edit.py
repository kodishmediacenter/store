import xbmcaddon

MainBase = 'http://pastebin.com/raw/Jdexu0Mb'
addon = xbmcaddon.Addon('plugin.video.dosapo')