def pegarchave():
        pkeyfile = "hash.txt"
        data = open(pkeyfile,"r") 
        pkey2 =  str(data.readlines()).replace("['",'').replace("']",'')

        print(pkey2)
        
        pkey = "282683f3fec72033a8821daa2ac25d38"
        #       282683f3fec72033a8821daa2ac25d38

        if pkey == pkey2:
                return 1
                print("1")
        else:
                return 0
                print("0")


print(pegarchave())
