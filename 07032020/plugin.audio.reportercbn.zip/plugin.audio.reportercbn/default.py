# -*- coding: cp1252 -*-

import requests
from bs4 import BeautifulSoup
import xbmc,os,xbmcgui,xbmcaddon,xbmcplugin
import urllib

i = 0
j = 0
w = 0

AddonID = 'plugin.audio.reportercbn'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")

links  = os.path.join(xbmc.translatePath("special://home/addons/plugin.audio.reportercbn/link.txt").decode("utf-8"))
titulos  = os.path.join(xbmc.translatePath("special://home/addons/plugin.audio.reportercbn/titulo.txt").decode("utf-8"))
servers = os.path.join(xbmc.translatePath("special://home/addons/plugin.audio.reportercbn/server.m3u").decode("utf-8"))
icon = os.path.join(xbmc.translatePath("special://home/addons/plugin.audio.reportercbn/icon.png").decode("utf-8"))
#print(soup)
def getLocaleString(id):
	return Addon.getLocalizedString(id).encode('utf-8')

def echo_play():
        xbmc.Player().play(""+servers+"")

	
def clen_file():
        arq2 = open(links, 'w')
        arq = open(titulos, 'w')
        podcast = open(servers, 'w')
        arq.close()
        arq2.close()
        podcast.close

def main ():
    i = 0
    j = 0
    w = 0

    
    link2 = 0

   
            

    if link2 == 0:
            
            site = "http://audio.globoradio.globo.com/podcast/feed/623/reporter-cbn"
            
            pagina_de_busca = requests.get(site)
            soup = BeautifulSoup(pagina_de_busca.text, "html.parser")
            clen_file()        
            for titulo in soup.find_all('title'):
                data2 = str(titulo)
                i = i + 1
                titulo = data2.replace("<title>O Assunto</title>","").replace("<title>","").replace("</title>","")
                #print(titulo)
                arq = open(titulos, 'a')
                arq.write(titulo)
                arq.write("\n")
                arq.close()
                
            for item in soup.find_all('guid', attrs={'isPermaLink': ''}):
                data = str(item)
                j = j + 1
                link = data.replace('<guid ispermalink="false">','').replace('</guid>','')
                #print(link)
                arq2 = open(links, 'a')
                arq2.write(link)
                arq2.write("\n")
                arq2.close()


            linkss = open(links, 'r')
            tituloss = open(titulos, 'r')

            t2 = (linkss.readlines())
            t3 = (tituloss.readlines())

            t2s = len(t2)
            t3s = len(t3)

            podcast = open(servers, 'a')
            podcast.write("#EXTM3U")
            podcast.write("\n")
            podcast.close()
            for t in range(0,t2s):
                rt = str(t3[2+t].replace("\n","")) #,
                rt2 = str(t2[t].replace("\n",""))
                print('#EXTINF:-1 tvg-id="" tvg-logo="",'+rt+'')
                print(rt2)

                podcast = open(servers, 'a')
                podcast.write('#EXTINF:-1 tvg-id="" tvg-logo="",'+rt+'')
                podcast.write("\n")
                podcast.write(rt2)
                podcast.write("\n")
                podcast.close()
            echo_play()
                

main()
