
# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.circulo'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')





def addDir(title,url,icons):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} ) 
    liz.setArt({'thumb':icons,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':
    YOUTUBE_CHANNEL_ID1 = "channel/UC_SRQEScGB2ZdO6hZlmBUlw/playlists"
    icon1 = "https://yt3.ggpht.com/a/AGF-l7_6rMEqhQl50rw2IzvYTBAo2AP_yc1AIiquMw=s288-c-k-c0xffffffff-no-rj-mo"
    YOUTUBE_CHANNEL_ID2 = "channel/UC_SRQEScGB2ZdO6hZlmBUlw/live"
    icon2 = "https://yt3.ggpht.com/a/AGF-l7_6rMEqhQl50rw2IzvYTBAo2AP_yc1AIiquMw=s288-c-k-c0xffffffff-no-rj-mo"
   

    
   
    

    addDir(title="Circulo",url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",icons=icon1)
    addDir(title="Live [Quando estiiver ao vivo]"            , url="plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",icons=icon2)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
