import xbmcaddon

MainBase = 'https://pastebin.com/raw/ND5895gi'
addon = xbmcaddon.Addon('plugin.video.milhano')