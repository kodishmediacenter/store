from Tkinter import *
from paramiko import SSHClient
import paramiko
from datetime import datetime

class Application:
    def __init__(self, master=None):
        self.widget1 = Frame(master)
        self.widget1.pack()
        self.titulo = Label(self.widget1, text="Digite User/Mac - 6 Meses")
        self.titulo["font"] = ("Arial", "10", "bold")
        self.titulo.pack()
        self.nomeLabel = Label(self.widget1,text="Nome", font=self.widget1)
        self.nomeLabel.pack(side=LEFT)
        self.nome = Entry(self.widget1)
        self.nome["width"] = 30
        self.nome["font"] = self.widget1
        self.nome.pack()
		
        self.autenticar = Button(self.widget1)
        self.autenticar["text"] = "Cadastrar"
        self.autenticar["font"] = ("Calibri", "8")
        self.autenticar["width"] = 12
        self.autenticar["command"] = self.cadastrar
        self.autenticar.pack()

        self.mensagem = Label(self.widget1, text="", font=self.widget1)
        self.mensagem.pack()

        self.ssh = SSHClient()
        self.ssh.load_system_host_keys()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(hostname='173.249.8.202',username='root',password='sonic@2012')

    def exec_cmd(self,cmd):
        stdin,stdout,stderr = self.ssh.exec_command(cmd)
        if stderr.channel.recv_exit_status() != 0:
            print stderr.read()
        else:
            print stdout.read()
  

    def cadastrar(self):
        data = self.nome.get()
        self.mensagem["text"] = ""+data+""
        if __name__ == '__main__':
            ssh = Application()
            user = data
            user2 = str(user)
            ssh.exec_cmd("mkdir /home/lista/users/"+user2+"")
            ssh.exec_cmd("ln -s /home/lista /home/lista/users/"+user2+"")
            ssh.exec_cmd("echo rm -r /home/lista/users/"+user2+"  >> /home/lista/users/"+user2+".txt")
            ssh.exec_cmd("at -f /home/lista/users/"+user2+".txt  now + 6 month")
            ssh.exec_cmd("at -l")
  
root = Tk()
Application(root)
root.mainloop()
