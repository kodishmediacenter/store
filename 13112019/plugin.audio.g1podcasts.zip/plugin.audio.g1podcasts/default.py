# -*- coding: cp1252 -*-

import requests
from bs4 import BeautifulSoup
import xbmc,os,xbmcgui,xbmcaddon,xbmcplugin
import urllib

i = 0
j = 0
w = 0

AddonID = 'plugin.audio.g1podcasts'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")

links  = os.path.join(xbmc.translatePath("special://home/addons/plugin.audio.g1podcasts/link.txt").decode("utf-8"))
titulos  = os.path.join(xbmc.translatePath("special://home/addons/plugin.audio.g1podcasts/titulo.txt").decode("utf-8"))
servers = os.path.join(xbmc.translatePath("special://home/addons/plugin.audio.g1podcasts/server.m3u").decode("utf-8"))
icon = os.path.join(xbmc.translatePath("special://home/addons/plugin.audio.g1podcasts/icon.png").decode("utf-8"))
#print(soup)
def getLocaleString(id):
	return Addon.getLocalizedString(id).encode('utf-8')

def AddDir(name, url, mode, iconimage, logos="", index=-1, move=0, isFolder=True, background=None):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&logos="+urllib.quote_plus(logos)+"&index="+str(index)+"&move="+str(move)

	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels={ "Title": name})
	listMode = 21 # Lists
	if background != None:
		liz.setProperty('fanart_image', background)
	if mode == 1 or mode == 2:
		items = [(getLocaleString(10008), 'XBMC.RunPlugin({0}?index={1}&mode=22)'.format(sys.argv[0], index)),
		(getLocaleString(10026), 'XBMC.RunPlugin({0}?index={1}&mode=23)'.format(sys.argv[0], index)),
		(getLocaleString(10027), 'XBMC.RunPlugin({0}?index={1}&mode=24)'.format(sys.argv[0], index)),
		(getLocaleString(10028), 'XBMC.RunPlugin({0}?index={1}&mode=25)'.format(sys.argv[0], index))]
		if mode == 2:
			items.append((getLocaleString(10029), 'XBMC.RunPlugin({0}?index={1}&mode=26)'.format(sys.argv[0], index)))
	elif mode == 3:
		liz.setProperty('IsPlayable', 'true')
		liz.addContextMenuItems(items = [('{0}'.format(getLocaleString(10009)), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
	elif mode == 32:
		liz.setProperty('IsPlayable', 'true')
		items = [(getLocaleString(10010), 'XBMC.RunPlugin({0}?index={1}&mode=33)'.format(sys.argv[0], index)),
		(getLocaleString(10026), 'XBMC.RunPlugin({0}?index={1}&mode=35)'.format(sys.argv[0], index)),
		(getLocaleString(10027), 'XBMC.RunPlugin({0}?index={1}&mode=36)'.format(sys.argv[0], index)),
		(getLocaleString(10028), 'XBMC.RunPlugin({0}?index={1}&mode=37)'.format(sys.argv[0], index))]
		listMode = 38 # Favourits
	if mode == 1 or mode == 2 or mode == 32:
		items += [(getLocaleString(10030), 'XBMC.RunPlugin({0}?index={1}&mode={2}&move=-1)'.format(sys.argv[0], index, listMode)),
		(getLocaleString(10031), 'XBMC.RunPlugin({0}?index={1}&mode={2}&move=1)'.format(sys.argv[0], index, listMode)),
		(getLocaleString(10032), 'XBMC.RunPlugin({0}?index={1}&mode={2}&move=0)'.format(sys.argv[0], index, listMode))]
		liz.addContextMenuItems(items)
		
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)


	
def clen_file():
        arq2 = open(links, 'w')
        arq = open(titulos, 'w')
        podcast = open(servers, 'w')
        arq.close()
        arq2.close()
        podcast.close

def main ():
    i = 0
    j = 0
    w = 0

    dialog2 = xbmcgui.Dialog()
    link2 = dialog2.select('G1 Podcast',['Temas do Podcasts','Ouvir'])

    if link2 == 1:
            xbmc.Player().play(""+servers+"")

    if link2 == 0:
            dialog = xbmcgui.Dialog()
            link = dialog.select('G1 Podcast', ['#Engajadxs - Como Sera?','Bem Estar','Desenrola, Rio','G1 - Educacao Financeira','G1 - Funciona assim','G1 - Livro Falado','G1 - Semana Pop','G1 ouviu - seu guia de novidades musicais','GloboNews - Em Movimento','GloboNews Internacional','HUB GloboNews','Isso � Fantastico','O Assunto','O tema e - Como Sera?','Papo de Pol�tica','Resumao'])


            dic = {
                    0:"http://audio.globoradio.globo.com/podcast/feed/707/engajadxs-como-sera",
                    1:"http://audio.globoradio.globo.com/podcast/feed/705/bem-estar",
                    2:"http://audio.globoradio.globo.com/podcast/feed/704/desenrola-rio",
                    3:"http:/audio.globoradio.globo.com/podcast/feed/531/educacao-financeira",
                    4:"http://audio.globoradio.globo.com/podcast/feed/566/funciona-assim-g1-eleicoes",
                    5:"http://audio.globoradio.globo.com/podcast/feed/592/g1-livro-falado",
                    6:"http://audio.globoradio.globo.com/podcast/feed/539/semana-pop",
                    7:"http://audio.globoradio.globo.com/podcast/feed/537/g1-ouviu-seu-guia-de-novidades-musicais",
                    8:"http://audio.globoradio.globo.com/podcast/feed/666/em-movimento",
                    9:"http://audio.globoradio.globo.com/podcast/feed/673/globonews-internacional",
                    10:"http://audio.globoradio.globo.com/podcast/feed/676/hub-globonews",
                    11:"http://audio.globoradio.globo.com/podcast/feed/651/isso-e-fantastico",
                    12:"http://audio.globoradio.globo.com/podcast/feed/702/o-assunto",
                    13:"http://audio.globoradio.globo.com/podcast/feed/708/o-tema-e-como-sera",
                    14:"http://audio.globoradio.globo.com/podcast/feed/706/papo-de-politica",
                    15:"http://audio.globoradio.globo.com/podcast/feed/703/resumao",
                }

            site = dic[link]
            
            pagina_de_busca = requests.get(site)
            soup = BeautifulSoup(pagina_de_busca.text, "html.parser")
            clen_file()        
            for titulo in soup.find_all('title'):
                data2 = str(titulo)
                i = i + 1
                titulo = data2.replace("<title>O Assunto</title>","").replace("<title>","").replace("</title>","")
                #print(titulo)
                arq = open(titulos, 'a')
                arq.write(titulo)
                arq.write("\n")
                arq.close()
                
            for item in soup.find_all('guid', attrs={'isPermaLink': ''}):
                data = str(item)
                j = j + 1
                link = data.replace('<guid ispermalink="false">','').replace('</guid>','')
                #print(link)
                arq2 = open(links, 'a')
                arq2.write(link)
                arq2.write("\n")
                arq2.close()


            linkss = open(links, 'r')
            tituloss = open(titulos, 'r')

            t2 = (linkss.readlines())
            t3 = (tituloss.readlines())

            t2s = len(t2)
            t3s = len(t3)

            podcast = open(servers, 'a')
            podcast.write("#EXTM3U")
            podcast.write("\n")
            podcast.close()
            for t in range(0,t2s):
                rt = str(t3[2+t].replace("\n","")) #,
                rt2 = str(t2[t].replace("\n",""))
                print('#EXTINF:-1 tvg-id="" tvg-logo="",'+rt+'')
                print(rt2)

                podcast = open(servers, 'a')
                podcast.write('#EXTINF:-1 tvg-id="" tvg-logo="",'+rt+'')
                podcast.write("\n")
                podcast.write(rt2)
                podcast.write("\n")
                podcast.close()

main()
