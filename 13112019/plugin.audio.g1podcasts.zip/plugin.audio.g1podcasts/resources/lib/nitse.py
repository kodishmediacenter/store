from pyenigma import enigma
from pyenigma import rotor
import base64

def nitserec(data): 
        engine = enigma.Enigma(rotor.ROTOR_Reflector_A, rotor.ROTOR_I,
                                        rotor.ROTOR_II, rotor.ROTOR_III, key="KDS",
                                        plugs="AV BS CG DL FU HZ IN KM OW RX")
        
        secret = base64.b64encode(engine.encipher(data))
        return secret

def nitseffw(data): 
        engine = enigma.Enigma(rotor.ROTOR_Reflector_A, rotor.ROTOR_I,
                                        rotor.ROTOR_II, rotor.ROTOR_III, key="ABC",
                                        plugs="AV BS CG DL FU HZ IN KM OW RX")
        
        secret2 = engine.encipher(data)
        return secret2

def nitseplay(data):
        play = base64.b64decode(data)
        desc = nitseffw(play)
        return desc
        
        


data = input("Digite texto a ser cifrado: ")
datas = str(data)
print(nitserec(datas))
#print(nitseplay(datad))
