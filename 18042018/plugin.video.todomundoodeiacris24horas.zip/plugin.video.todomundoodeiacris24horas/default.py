# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint
import base64
import naomi

tunel = "UmVmZXJlcj1odHRwOi8vd3d3LnJlZGVjYW5haXMuY29tLmJyLw=="
ftunel = base64.b64decode(tunel)

addonID = 'plugin.video.todomundoodeiacris24horas'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,88)


eng2sp = {1:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP01.mp4|"+ftunel+"",
2:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP02.mp4|"+ftunel+"",
3:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP03.mp4|"+ftunel+"",
4:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP04.mp4|"+ftunel+"",
5:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP05.mp4|"+ftunel+"",
6:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP06.mp4|"+ftunel+"",
7:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP07.mp4|"+ftunel+"",
8:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP08.mp4|"+ftunel+"",
9:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP09.mp4|"+ftunel+"",
10:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP10.mp4|"+ftunel+"",
11:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP11.mp4|"+ftunel+"",
12:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP12.mp4|"+ftunel+"",
13:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP13.mp4|"+ftunel+"",
14:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP14.mp4|"+ftunel+"",
15:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP15.mp4|"+ftunel+"",
16:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP16.mp4|"+ftunel+"",
17:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP17.mp4|"+ftunel+"",
18:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP18.mp4|"+ftunel+"",
19:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP19.mp4|"+ftunel+"",
20:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP20.mp4|"+ftunel+"",
21:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP21.mp4|"+ftunel+"",
22:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT01EP22.mp4|"+ftunel+"",
23:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP01.mp4|"+ftunel+"",
24:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP02.mp4|"+ftunel+"",
25:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP03.mp4|"+ftunel+"",
26:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP04.mp4|"+ftunel+"",
27:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP05.mp4|"+ftunel+"",
28:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP06.mp4|"+ftunel+"",
29:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP07.mp4|"+ftunel+"",
30:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP08.mp4|"+ftunel+"",
31:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP09.mp4|"+ftunel+"",
32:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP10.mp4|"+ftunel+"",
33:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP11.mp4|"+ftunel+"",
34:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP12.mp4|"+ftunel+"",
35:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP13.mp4|"+ftunel+"",
36:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP14.mp4|"+ftunel+"",
37:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP15.mp4|"+ftunel+"",
38:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP16.mp4|"+ftunel+"",
39:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP17.mp4|"+ftunel+"",
40:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP18.mp4|"+ftunel+"",
41:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP19.mp4|"+ftunel+"",
42:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP20.mp4|"+ftunel+"",
43:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP21.mp4|"+ftunel+"",
44:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT02EP22.mp4|"+ftunel+"",
45:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP01.mp4|"+ftunel+"",
46:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP02.mp4|"+ftunel+"",
47:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP03.mp4|"+ftunel+"",
48:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP04.mp4|"+ftunel+"",
49:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP05.mp4|"+ftunel+"",
50:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP06.mp4|"+ftunel+"",
51:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP07.mp4|"+ftunel+"",
52:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP08.mp4|"+ftunel+"",
53:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP09.mp4|"+ftunel+"",
54:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP10.mp4|"+ftunel+"",
55:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP11.mp4|"+ftunel+"",
56:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP12.mp4|"+ftunel+"",
57:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP13.mp4|"+ftunel+"",
58:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP14.mp4|"+ftunel+"",
59:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP15.mp4|"+ftunel+"",
60:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP16.mp4|"+ftunel+"",
61:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP17.mp4|"+ftunel+"",
62:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP18.mp4|"+ftunel+"",
63:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP19.mp4|"+ftunel+"",
64:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP20.mp4|"+ftunel+"",
65:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP21.mp4|"+ftunel+"",
66:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT03EP22.mp4|"+ftunel+"",
67:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP01.mp4|"+ftunel+"",
68:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP02.mp4|"+ftunel+"",
69:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP03.mp4|"+ftunel+"",
70:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP04.mp4|"+ftunel+"",
71:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP05.mp4|"+ftunel+"",
72:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP06.mp4|"+ftunel+"",
73:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP07.mp4|"+ftunel+"",
74:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP08.mp4|"+ftunel+"",
75:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP09.mp4|"+ftunel+"",
76:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP10.mp4|"+ftunel+"",
77:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP11.mp4|"+ftunel+"",
78:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP12.mp4|"+ftunel+"",
79:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP13.mp4|"+ftunel+"",
80:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP14.mp4|"+ftunel+"",
81:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP15.mp4|"+ftunel+"",
82:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP16.mp4|"+ftunel+"",
83:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP17.mp4|"+ftunel+"",
84:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP18.mp4|"+ftunel+"",
85:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP19.mp4|"+ftunel+"",
86:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP20.mp4|"+ftunel+"",
87:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP21.mp4|"+ftunel+"",
88:"http://fabiolmg.local/RCServer01/videos/TDMNDOCT04EP22.mp4|"+ftunel+"",
}

        
for j in range(eps,(eps+30)):
        
        file = open(""+m3u+"","a")
        eps = naomi.getserver(eng2sp[j])
        file.write(eps)
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

