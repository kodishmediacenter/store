# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint
import base64
import naomi

tunel = "UmVmZXJlcj1odHRwOi8vd3d3LnJlZGVjYW5haXMuY29tLmJyLw=="
ftunel = base64.b64decode(tunel)

addonID = 'plugin.video.eupatroaeascriancas'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,123)
ieps = 123 - eps

eng2sp = {1:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP01.mp4|"+ftunel+"",
2:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP02.mp4|"+ftunel+"",
3:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP03.mp4|"+ftunel+"",
4:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP04.mp4|"+ftunel+"",
5:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP05.mp4|"+ftunel+"",
6:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP06.mp4|"+ftunel+"",
7:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP07.mp4|"+ftunel+"",
8:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP08.mp4|"+ftunel+"",
9:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP09.mp4|"+ftunel+"",
10:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP10.mp4|"+ftunel+"",
11:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT01EP11.mp4|"+ftunel+"",
12:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP01.mp4|"+ftunel+"",
13:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP02.mp4|"+ftunel+"",
14:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP03.mp4|"+ftunel+"",
15:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP04.mp4|"+ftunel+"",
16:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP05.mp4|"+ftunel+"",
17:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP06.mp4|"+ftunel+"",
18:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP07.mp4|"+ftunel+"",
19:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP08.mp4|"+ftunel+"",
20:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP09.mp4|"+ftunel+"",
21:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP10.mp4|"+ftunel+"",
22:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP11.mp4|"+ftunel+"",
23:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP12.mp4|"+ftunel+"",
24:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP13.mp4|"+ftunel+"",
25:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP14.mp4|"+ftunel+"",
26:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP15.mp4|"+ftunel+"",
27:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP16.mp4|"+ftunel+"",
28:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP17.mp4|"+ftunel+"",
29:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP18.mp4|"+ftunel+"",
30:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP19.mp4|"+ftunel+"",
31:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP20.mp4|"+ftunel+"",
32:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP21.mp4|"+ftunel+"",
33:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP22.mp4|"+ftunel+"",
34:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP23.mp4|"+ftunel+"",
35:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP24.mp4|"+ftunel+"",
36:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP25.mp4|"+ftunel+"",
37:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP26.mp4|"+ftunel+"",
38:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP27.mp4|"+ftunel+"",
39:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP28.mp4|"+ftunel+"",
40:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT02EP29.mp4|"+ftunel+"",
41:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP01.mp4|"+ftunel+"",
42:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP02.mp4|"+ftunel+"",
43:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP03.mp4|"+ftunel+"",
44:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP04.mp4|"+ftunel+"",
45:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP05.mp4|"+ftunel+"",
46:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP06.mp4|"+ftunel+"",
47:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP07.mp4|"+ftunel+"",
48:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP08.mp4|"+ftunel+"",
49:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP09.mp4|"+ftunel+"",
50:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP10.mp4|"+ftunel+"",
51:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP11.mp4|"+ftunel+"",
52:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP12.mp4|"+ftunel+"",
53:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP13.mp4|"+ftunel+"",
54:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP14.mp4|"+ftunel+"",
55:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP15.mp4|"+ftunel+"",
56:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP16.mp4|"+ftunel+"",
57:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP17.mp4|"+ftunel+"",
58:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP18.mp4|"+ftunel+"",
59:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP19.mp4|"+ftunel+"",
60:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP20.mp4|"+ftunel+"",
61:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP21.mp4|"+ftunel+"",
62:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP22.mp4|"+ftunel+"",
63:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP23.mp4|"+ftunel+"",
64:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP24.mp4|"+ftunel+"",
65:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP25.mp4|"+ftunel+"",
66:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP26.mp4|"+ftunel+"",
67:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT03EP27.mp4|"+ftunel+"",
68:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP01.mp4|"+ftunel+"",
69:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP02.mp4|"+ftunel+"",
70:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP03.mp4|"+ftunel+"",
71:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP04.mp4|"+ftunel+"",
72:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP05.mp4|"+ftunel+"",
73:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP06.mp4|"+ftunel+"",
74:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP07.mp4|"+ftunel+"",
75:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP08.mp4|"+ftunel+"",
76:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP09.mp4|"+ftunel+"",
77:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP10.mp4|"+ftunel+"",
78:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP11.mp4|"+ftunel+"",
79:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP12.mp4|"+ftunel+"",
80:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP13.mp4|"+ftunel+"",
81:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP14.mp4|"+ftunel+"",
82:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP15.mp4|"+ftunel+"",
83:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP16.mp4|"+ftunel+"",
84:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP17.mp4|"+ftunel+"",
85:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP18.mp4|"+ftunel+"",
86:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP19.mp4|"+ftunel+"",
87:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP20.mp4|"+ftunel+"",
88:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP21.mp4|"+ftunel+"",
89:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP22.mp4|"+ftunel+"",
90:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP23.mp4|"+ftunel+"",
91:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP24.mp4|"+ftunel+"",
92:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP25.mp4|"+ftunel+"",
93:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP26.mp4|"+ftunel+"",
94:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP27.mp4|"+ftunel+"",
95:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP28.mp4|"+ftunel+"",
96:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP29.mp4|"+ftunel+"",
97:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT04EP30.mp4|"+ftunel+"",
98:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP01.mp4|"+ftunel+"",
99:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP02.mp4|"+ftunel+"",
100:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP03.mp4|"+ftunel+"",
101:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP04.mp4|"+ftunel+"",
102:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP05.mp4|"+ftunel+"",
103:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP06.mp4|"+ftunel+"",
104:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP07.mp4|"+ftunel+"",
105:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP08.mp4|"+ftunel+"",
106:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP09.mp4|"+ftunel+"",
107:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP10.mp4|"+ftunel+"",
108:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP11.mp4|"+ftunel+"",
109:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP12.mp4|"+ftunel+"",
110:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP13.mp4|"+ftunel+"",
111:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP14.mp4|"+ftunel+"",
112:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP15.mp4|"+ftunel+"",
113:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP16.mp4|"+ftunel+"",
114:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP17.mp4|"+ftunel+"",
115:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP18.mp4|"+ftunel+"",
116:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP19.mp4|"+ftunel+"",
117:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP20.mp4|"+ftunel+"",
118:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP21.mp4|"+ftunel+"",
119:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP22.mp4|"+ftunel+"",
120:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP23.mp4|"+ftunel+"",
121:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP24.mp4|"+ftunel+"",
122:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP25.mp4|"+ftunel+"",
123:"http://fabiolmg.local/RCServer01/videos/EUAPTEACT05EP26.mp4|"+ftunel+"",
}

        
for j in range(ieps,(ieps+30)):
        
        file = open(""+m3u+"","a")
        eps = naomi.getserver(eng2sp[j])
        file.write(eps)
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

