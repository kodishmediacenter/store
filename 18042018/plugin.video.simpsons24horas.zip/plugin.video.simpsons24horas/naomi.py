# Biblioteca converte links emulado para real

def getserver(link):


    if link[0:32] == "http://fabiolmg.local/RCServer01":
        naomi = "http://d15rb4p4373nzv.redecanais.video/RedeCanais/RedeCanais/RCServer01"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:33] == "http://fabiolmg.local/RCFServer01":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCFServer1"
        tam = len(link)
        linkf = ""+naomi+""+link[33:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer02":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCServer02"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:33] == "http://fabiolmg.local/RCFServer02":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCFServer2"
        tam = len(link)
        linkf = ""+naomi+""+link[33:tam]+""
        return linkf

    if link[0:33] == "http://fabiolmg.local/RCFServer03":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCFServer3"
        tam = len(link)
        linkf = ""+naomi+""+link[33:tam]+""
        return linkf

    if link[0:33] == "http://fabiolmg.local/RCFServer04":
        naomi = "http://d15rb4p4373nzv.redecanais.video/RedeCanais/RedeCanais/RCFServer4"
        tam = len(link)
        linkf = ""+naomi+""+link[33:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCFServer04":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCServer04"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
 
    
    if link[0:32] == "http://fabiolmg.local/RCServer05":
        naomi = "http://d15rb4p4373nzv.redecanais.video/RedeCanais/RedeCanais/RCServer05"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer07":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCServer07"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer08":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCServer08"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer09":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCServer09"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer10":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCServer10"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer11":
        naomi = "http://d2vsc6y0jm4dyz.redecanais.video/RedeCanais/RedeCanais/RCServer11"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer12":
        naomi = "http://d15rb4p4373nzv.redecanais.video/RedeCanais/RedeCanais/RCServer12"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    
