import xbmc
import xbmcgui

dialog = xbmcgui.Dialog()
ret = dialog.select('[COLOR yellow]Tunicity [/COLOR]', ['[COLOR green]60s[/COLOR]', '[COLOR yellow]70s[/COLOR]','[COLOR red]Pop Sounds 80s[/COLOR]', '[COLOR orange]90s and 00[/COLOR]','[COLOR gray]Sound by Artist[/COLOR]','[COLOR blue]Disco[/COLOR]','[COLOR red]Filipino[/COLOR]','[COLOR pink]Heavy Metal[/COLOR]','[COLOR deepskyblue]K-Pop[/COLOR]','[COLOR blue]Pop[/COLOR]'])


if ret == 0:
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/60s/)")

if ret == 1:
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/70s/)")

if ret == 2: 
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/80spop/)")

if ret == 3: 
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/90s-00s/)")

if ret == 4:
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/artist/)")

if ret == 5:
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/artist/)")
    
if ret == 6:
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/disco/)")

if ret == 7:
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/filipino/)")
if ret == 8:
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/heavymetal/)")
if ret == 9:
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/kpop/)")
if ret == 10:
    xbmc.executebuiltin("ActivateWindow(10502,http://www.tunicity.com/content/pop/)")
    
