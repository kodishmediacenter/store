# -*- coding: cp1252 -*-
import xbmcgui
import xbmc
import xbmcplugin
import webbrowser
import os
import xbmcaddon

dialog = xbmcgui.Dialog()
link = dialog.select('Bem Vindo Ao Addon do Ucolecionador', ['Quem Sou Eu','Canal do Ucolecionador','Grupo do Facebook','Arquivos do Grupo do Facebook'])

# Plugin Info
ADDON_ID      = 'plugin.video.ucolecionador'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

def addDir(title, url):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':ICON,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)



if link == 0:
    url = "plugin://plugin.video.youtube/play/?video_id=rm3_l7gNVD4"
    xbmc.Player().play(url)
if link == 1:
    addDir(title="Ucolecionador Ao Vivo", url="plugin://plugin.video.youtube/channel/UCYQWpNzyDn-88Wm4G0W8UPw/live/")
    addDir(title="Ucolecionador Canal", url="plugin://plugin.video.youtube/channel/UCYQWpNzyDn-88Wm4G0W8UPw/")
    addDir(title="Ucolecionador Playlist", url="plugin://plugin.video.youtube/channel/UCYQWpNzyDn-88Wm4G0W8UPw/playlists/")
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)

if link == 2:
     if xbmc . getCondVisibility ( 'system.platform.android' ) :
         xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.facebook.com/groups/1048963411821151/' ) )
     else:
        webbrowser . open ( 'https://www.facebook.com/groups/1048963411821151/' )

if link == 3:
     if xbmc . getCondVisibility ( 'system.platform.android' ) :
         xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.facebook.com/groups/1048963411821151/files/' ) )
     else:
        webbrowser . open ( 'https://www.facebook.com/groups/1048963411821151/files/' )

if link == 4:
     if xbmc . getCondVisibility ( 'system.platform.android' ) :
         xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://chat.whatsapp.com/ExB0EOEbufMJTSgLyq6TdM' ) )
     else:
        webbrowser . open ( 'https://chat.whatsapp.com/ExB0EOEbufMJTSgLyq6TdM' )

if link == 5:
    dialog = xbmcgui.Dialog()
    link2 = dialog.select('Bem Vindo Ao Addon do Ucolecionador', ['Descricao','Video','Cartao SD Mega Drive'])

    if link2 == 0:
        dialog = xbmcgui.Dialog()
        dialog.textviewer('Descricao', 'E um cart�o SD com toda existencia do Mega Drive pronto para colocar e Jogar')
        
    if link2 == 1:
        url = "plugin://plugin.video.youtube/play/?video_id=YQo4YScJsTQ"
        xbmc.Player().play(url)
     
    
    
