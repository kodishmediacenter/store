import xbmcaddon

MainBase = 'http://sergiogracas.com/emular/kodi/menu.txt'
addon = xbmcaddon.Addon('plugin.video.VelhosTempos')