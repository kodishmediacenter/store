import xbmcaddon
import base64


host = "=knWwl3dTljevcXYy9SbvNmLulmYlR3chB3LvoDc0RHa"
tam = len(host)
basedem = host[::-1]
MainBase = base64.b64decode(basedem)
addon = xbmcaddon.Addon('plugin.video.NeXus')