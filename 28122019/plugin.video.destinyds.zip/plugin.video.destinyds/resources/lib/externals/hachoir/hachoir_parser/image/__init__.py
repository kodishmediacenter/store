from resources.lib.externals.hachoir.hachoir_parser.image.bmp import BmpFile
from resources.lib.externals.hachoir.hachoir_parser.image.gif import GifFile
from resources.lib.externals.hachoir.hachoir_parser.image.ico import IcoFile
from resources.lib.externals.hachoir.hachoir_parser.image.jpeg import JpegFile
from resources.lib.externals.hachoir.hachoir_parser.image.pcx import PcxFile
from resources.lib.externals.hachoir.hachoir_parser.image.psd import PsdFile
from resources.lib.externals.hachoir.hachoir_parser.image.png import PngFile
from resources.lib.externals.hachoir.hachoir_parser.image.tga import TargaFile
from resources.lib.externals.hachoir.hachoir_parser.image.tiff import TiffFile
from resources.lib.externals.hachoir.hachoir_parser.image.wmf import WMF_File
from resources.lib.externals.hachoir.hachoir_parser.image.xcf import XcfFile

