-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 21/02/2014 às 18:31
-- Versão do servidor: 5.5.35-cll
-- Versão do PHP: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `vamoslai_5`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `BuyerTable`
--

CREATE TABLE IF NOT EXISTS `BuyerTable` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BuyerEmail` text NOT NULL,
  `BuyerName` text NOT NULL,
  `ItemName` text NOT NULL,
  `userid` text NOT NULL,
  `ItemAmount` text NOT NULL,
  `ItemQTY` text NOT NULL,
  `TransactionID` text NOT NULL,
  `forma` text NOT NULL,
  `horario` time NOT NULL,
  `data` date NOT NULL,
  `status` text NOT NULL,
  `creditado` text NOT NULL,
  `tempo` text NOT NULL,
  `moeda` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=875370289 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `configuracoes`
--

CREATE TABLE IF NOT EXISTS `configuracoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tokenpagseguro` text NOT NULL,
  `emailpagseguro` text NOT NULL,
  `PayPalApiUsername` text NOT NULL,
  `PayPalApiPassword` text NOT NULL,
  `PayPalApiSignature` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  `email` text NOT NULL,
  `h1` text NOT NULL,
  `twitter` text NOT NULL,
  `twitterid` text NOT NULL,
  `facebook` text NOT NULL,
  `noticias` text NOT NULL,
  `cop` text NOT NULL,
  `chat` text NOT NULL,
  `728x90` text NOT NULL,
  `300x250` text NOT NULL,
  `livestream.com` text NOT NULL,
  `titulocanais` text NOT NULL,
  `descricao` text NOT NULL,
  `nomedosite` text NOT NULL,
  `diasgratis` text NOT NULL,
  `versao` int(11) NOT NULL,
  `analytics` text NOT NULL,
  `link` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Fazendo dump de dados para tabela `configuracoes`
--

INSERT INTO `configuracoes` (`id`, `tokenpagseguro`, `emailpagseguro`, `PayPalApiUsername`, `PayPalApiPassword`, `PayPalApiSignature`, `title`, `description`, `keywords`, `email`, `h1`, `twitter`, `twitterid`, `facebook`, `noticias`, `cop`, `chat`, `728x90`, `300x250`, `livestream.com`, `titulocanais`, `descricao`, `nomedosite`, `diasgratis`, `versao`, `analytics`, `link`) VALUES
(1, '', '', '', '', '', 'Script tv online Com painel de usuario e area vip', 'Script de tv para monstar um site onde podera cobrar dos usuarios', '', 'roneyrogerio92@gmail.com', 'Script 5.1', 'Legendarios', '436993479940378624', 'http://www.facebook.com/LegendariosOficial', 'http://feeds.folha.uol.com.br/folha/mundo/rss091.xml', 'Seusite.COM© 2011-2014. Todos os direitos reservados.', '199524805', '<a href="/painel/cadastrar.php" target="_blank"><img src="http://i.imgur.com/ptUvlAf.png" alt="tv" border="0"></a>', '<a href="/painel/cadastrar.php" target="_blank"><img src="http://i.imgur.com/URdfEOf.png" alt="tv" border="0"></a>', 'xAgrwt_ROQicMzGCnvrYcb-ekPzYx2WesRw5-DZm5b9GK1ugNN1BYSWYLdRVXdC-YfrwlOMr-aDpR3KLZqceu4xNXybEvrSKyti61eQnDZXnJRgMWhX9SvALRfLGqTCd', 'Assistir %%nome_do_canal%% ao vivo no %%nome_do_site%%', 'Assista  %%nome_do_canal%%', 'Script tv online', '5', 2, '', '%%nome_do_canal%%-online');

-- --------------------------------------------------------

--
-- Estrutura para tabela `dados_beta`
--

CREATE TABLE IF NOT EXISTS `dados_beta` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `url_do_canal` varchar(9000) NOT NULL,
  `nome_do_canal` text NOT NULL,
  `linkdcanal` varchar(10000) NOT NULL,
  `nome_foto` varchar(9000) NOT NULL,
  `categoria` text NOT NULL,
  `tipo` text NOT NULL,
  `palavras` text NOT NULL,
  `ligar` text NOT NULL,
  `estado` text NOT NULL,
  `vip` text NOT NULL,
  `lugar` text NOT NULL,
  `propaganda` text NOT NULL,
  `form` text NOT NULL,
  `linkvip` text NOT NULL,
  `prog` varchar(80) DEFAULT NULL,
  `titulo` text NOT NULL,
  `titulo2` text NOT NULL,
  `direc` text NOT NULL,
  `direc2` text NOT NULL,
  `direc1` text NOT NULL,
  `direc22` text NOT NULL,
  `hora` text NOT NULL,
  `hora2` text NOT NULL,
  `timest` text NOT NULL,
  `resumo` text NOT NULL,
  `resumo2` text NOT NULL,
  `small_data` text NOT NULL,
  `small_data2` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Fazendo dump de dados para tabela `dados_beta`
--

INSERT INTO `dados_beta` (`ID`, `url_do_canal`, `nome_do_canal`, `linkdcanal`, `nome_foto`, `categoria`, `tipo`, `palavras`, `ligar`, `estado`, `vip`, `lugar`, `propaganda`, `form`, `linkvip`, `prog`, `titulo`, `titulo2`, `direc`, `direc2`, `direc1`, `direc22`, `hora`, `hora2`, `timest`, `resumo`, `resumo2`, `small_data`, `small_data2`) VALUES
(3, '', 'Filmes online', 'http://megafilmeshd.net/', 'filmes-online-menu-5307cbf428849', 'variedades', 'iframe', '', 's', '', 'na', 'menu', 's', '', 'filmes-online-vip-5307cbf428849', NULL, '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, '', 'Séries Online', 'http://megafilmeshd.net/series/', 'series-online-menu-5307cc0cd03bf', 'variedades', 'iframe', '', 's', '', 'na', 'menu', 's', '', 'series-online-vip-5307cc0cd03bf', NULL, '', '', '', '', '', '', '', '', '', '', '', '', ''),
(5, '', 'Gravados', 'http://www.supertela.org/novelas/', 'gravados-menu-5307cc22b8667', 'variedades', 'iframe', '', 's', '', 'na', 'menu', 's', '', 'gravados-vip-5307cc22b8667', NULL, '', '', '', '', '', '', '', '', '', '', '', '', ''),
(6, '', 'Futebol ao vivo', '/futebol-ao-vivo/', 'futebol-ao-vivo-menu-5307cc3f6d3ec', 'variedades', 'iframe', '', 's', '', 'na', 'menu', 'n', '', 'futebol-ao-vivo-vip-5307cc3f6d3ec', NULL, '', '', '', '', '', '', '', '', '', '', '', '', ''),
(7, 'images/canais/gazeta-online-ao-vivo-gratis-5307d051e1715.png', 'gazeta', '<iframe src="http://new.livestream.com/accounts/5381476/events/2395418/player?width=468&height=360&autoPlay=true&mute=false" width="468" height="360" frameborder="0" scrolling="no"> </iframe>', 'gazeta-online-5307d051e1715', 'variedades', 'embed', '', 's', '', 'na', 'canais', 's', 'cadastro', 'gazeta-area-vip-5307d051e1715', 'http://www.meuguia.tv/programacao/canal/GAZ', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(8, 'images/canais/um-maluco-no-pedaco-online-ao-vivo-gratis-5307d0cd291a2.png', 'um maluco no pedaco', 'http://www.canaistv.net/swf/player.swf?file=maluconopedaco.flv&type=rtmp&streamer=rtmp://174.36.42.92/tvamigos/&autostart=true&bufferlength=1&displayclick=fullscreen&controlbar=none', 'um-maluco-no-pedaco-online-5307d0cd291a2', 'cinema', 'swf', '', 's', '', 'na', 'canais', 's', 'cadastro', 'um-maluco-no-pedaco-area-vip-5307d0cd291a2', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(9, 'images/canais/esporte-interativo-nordeste-online-ao-vivo-gratis-5307d1785a7c7.png', 'esporte interativo nordeste', 'rtmp://wz5-ei.fluxmedia.com.br/eine/aovivo', 'esporte-interativo-nordeste-online-5307d1785a7c7', 'esportes', 'rtmp', '', 's', '', 'na', 'canais', 's', 'cadastro', 'esporte-interativo-nordeste-area-vip-5307d1785a7c7', 'http://www.meuguia.tv/programacao/canal/SPI', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(10, 'images/canais/familia-dinossauro-online-ao-vivo-gratis-5307d3744c644.png', 'familia dinossauro', 'tvtfamiliadinosauros', 'familia-dinossauro-online-5307d3744c644', 'infantil', 'livestream', '', 's', '', 'na', 'canais', 's', 'cadastro', 'familia-dinossauro-area-vip-5307d3744c644', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, 'images/canais/capital-tv-online-ao-vivo-gratis-5307d717b29bc.png', 'capital tv', 'rtmp://cdn-sov-2.musicradio.com:80/LiveVideo/Capital', 'capital-tv-online-5307d717b29bc', 'clipes', 'rtmp', '', 's', '', 'na', 'canais', 's', 'cadastro', 'capital-tv-area-vip-5307d717b29bc', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(12, 'images/canais/europa-plus-online-ao-vivo-gratis-5307d909caf87.png', 'europa plus', 'rtmp://europaplus.cdnvideo.ru:1935/europaplus-live/mp4:eptv_main.sdp', 'europa-plus-online-5307d909caf87', 'clipes', 'rtmp', '', 's', '', 's', 'canais', 's', 'cadastro', 'europa-plus-area-vip-5307d909caf87', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(13, 'images/canais/for-music-online-ao-vivo-gratis-5307dcf53ae4a.png', 'for music', 'rtmp://wowza1.top-ix.org/quartaretetv1/formusicweb', 'for-music-online-5307dcf53ae4a', 'clipes', 'rtmp', '', 's', '', 'na', 'canais', 's', 'cadastro', 'for-music-area-vip-5307dcf53ae4a', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `formaspag`
--

CREATE TABLE IF NOT EXISTS `formaspag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valor` text NOT NULL,
  `tempo` text NOT NULL,
  `moeda` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Fazendo dump de dados para tabela `formaspag`
--

INSERT INTO `formaspag` (`id`, `valor`, `tempo`, `moeda`) VALUES
(27, '27.90', '3', 'BRL'),
(26, '18.90', '2', 'BRL'),
(25, '9.90', '1', 'BRL');

-- --------------------------------------------------------

--
-- Estrutura para tabela `horarios`
--

CREATE TABLE IF NOT EXISTS `horarios` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `0` text NOT NULL,
  `1` text NOT NULL,
  `2` text NOT NULL,
  `3` text NOT NULL,
  `4` text NOT NULL,
  `5` text NOT NULL,
  `6` text NOT NULL,
  `7` text NOT NULL,
  `8` text NOT NULL,
  `9` text NOT NULL,
  `10` text NOT NULL,
  `11` text NOT NULL,
  `12` text NOT NULL,
  `13` text NOT NULL,
  `14` text NOT NULL,
  `15` text NOT NULL,
  `16` text NOT NULL,
  `17` text NOT NULL,
  `18` text NOT NULL,
  `19` text NOT NULL,
  `20` text NOT NULL,
  `21` text NOT NULL,
  `22` text NOT NULL,
  `23` text NOT NULL,
  `cvip` text NOT NULL,
  `caberto` text NOT NULL,
  `tipo` text NOT NULL,
  `catcvip` text NOT NULL,
  `catcaberto` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Fazendo dump de dados para tabela `horarios`
--

INSERT INTO `horarios` (`ID`, `0`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`, `12`, `13`, `14`, `15`, `16`, `17`, `18`, `19`, `20`, `21`, `22`, `23`, `cvip`, `caberto`, `tipo`, `catcvip`, `catcaberto`) VALUES
(1, '2', '2', '6', '6', '5', '5', '6', '1', '5', '4', '4', '1', '3', '2', '3', '3', '3', '3', '3', '3', '2', '3', '3', '2', 'capital-tv-area-vip-5307d717b29bc', 'capital-tv-online-5307d717b29bc', '1', '5', '5');

-- --------------------------------------------------------

--
-- Estrutura para tabela `termos`
--

CREATE TABLE IF NOT EXISTS `termos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `termos` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Fazendo dump de dados para tabela `termos`
--

INSERT INTO `termos` (`id`, `termos`) VALUES
(1, '1° Este site não é Tv por Assinatura, Não usa Receptor, Não usa Antena, Não Envia Faturas pelos Correios, Não é CS (cardsharing), Somente envia (retransmite) pela Internet imagem e som dos canais, A Qualidade HD é padrão Internet, não é 380p, 420p, 720p e 1080p, é medida por KBPS de Transmissão, Transmissão em HD media de 750kbps, Comparando com os canais Grátis pela Internet que são em no máximo 250kbps.<br><br>2° O site não fica responsável por qualquer oscilação de internet ou erro que esteja no computador do cliente, O Cliente tem que estar ciente que deve manter uma boa Qualidade de Internet, mínimo de 1mb (1024kbps). Vale Lembrar que no Brasil as operadoras de Internet Banda Larga por Lei devem garantir pelo menos 10% velocidade contratada, Só assine o site caso tenha certeza que sua Operadora de Internet Garante e tenha Qualidade para executar as velocidades descritas dos canais acima, Lembrando que esta é a velocidade constante dos canais, se a velocidade de sua internet por 1 segundo ficar abaixo do mínimo necessário, a sua recepção do sinal vai sofrer oscilação.<br><br>3° O Site é feito para uso no PC (Computador ou notebook), podendo ser inserido em sua TV Via Cabo HDMI ou RCA, Porém Vale Lembrar que foi feito para PC e Garantimos Qualidade de Imagem para esta Plataforma.<br><br>4° Não Existe Fidelidade, Não tem tempo de permanência como cliente ao mesmo, o serviço funciona como Pré-Pago, sem multa ou envio de cobrança.<br><br>5° Suporte Via E-mail 24horas.<br><br>6° O Cliente fica ciente do número de canais poderá ser alterado a qualquer momento sem aviso prévio.<br><br>7° O site é Hospedada (Seus Servidores) internacional, Seu domínio (.com) é Internacional. O Cliente fica ciente que o mesmo não é um site Brasileiro e sim Internacional.<br><br>8° A Liberação Imediata do acesso ao cliente aos canais é feito Automaticamente após a APROVAÇÃO do pagamento junto ao Paypal ou pagseguro.<br><br>Estes Termos de Uso, Visa a transparência do serviço prestado.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `md5_id` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `full_name` tinytext COLLATE latin1_general_ci NOT NULL,
  `user_name` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_email` varchar(220) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_level` tinyint(4) NOT NULL DEFAULT '1',
  `pwd` varchar(220) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `date` date NOT NULL DEFAULT '0000-00-00',
  `users_ip` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `approved` int(1) NOT NULL DEFAULT '0',
  `activation_code` int(10) NOT NULL DEFAULT '0',
  `banned` int(1) NOT NULL DEFAULT '0',
  `ckey` varchar(220) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ctime` varchar(220) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `data` date NOT NULL,
  `vencimento` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_email` (`user_email`),
  FULLTEXT KEY `idx_search` (`full_name`,`user_email`,`user_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=240 ;

--
-- Fazendo dump de dados para tabela `users`
--

INSERT INTO `users` (`id`, `md5_id`, `full_name`, `user_name`, `user_email`, `user_level`, `pwd`, `date`, `users_ip`, `approved`, `activation_code`, `banned`, `ckey`, `ctime`, `data`, `vencimento`) VALUES
(54, '', 'admin', 'admin', 'admin@admin.com', 5, 'e21d7cb524423f1604f1b43d8dd9836109962d27525f6c413', '2010-05-04', '', 1, 0, 0, 'bku6evg', '1393019815', '2014-02-13', '2021-11-19'),
(238, '', 'usuario', 'usuario', 'usuario@usuario.com', 1, '535f64b507dfd0781d1df633ebefdcda0aa026e4a3cb6b09a', '2014-02-21', '', 1, 0, 0, '', '', '2014-02-22', '2013-11-20'),
(239, '', 'usuariovip', 'usuariovip', 'usuariovip@usuariovip.com', 1, 'bdd0a667d57ca2ce14ffe257fc54c470bfcf4d2a265e9b8a2', '2014-02-21', '', 1, 0, 0, '', '', '2014-02-22', '2018-08-18');

-- --------------------------------------------------------

--
-- Estrutura para tabela `foradoar`
--

CREATE TABLE IF NOT EXISTS `foradoar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliques` int(11) NOT NULL,
  `tempo` int(11) NOT NULL,
  `user` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=906 ;


-- --------------------------------------------------------

--
-- Estrutura para tabela `users_sessions`
--

CREATE TABLE IF NOT EXISTS `users_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` text NOT NULL,
  `ip` text,
  `ultima` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Fazendo dump de dados para tabela `users_sessions`
--

INSERT INTO `users_sessions` (`id`, `session_id`, `ip`, `ultima`) VALUES
(54, '76312c79fd2224492eedaf1f2c6493cd', '191.169.148.37', '1393019816');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
