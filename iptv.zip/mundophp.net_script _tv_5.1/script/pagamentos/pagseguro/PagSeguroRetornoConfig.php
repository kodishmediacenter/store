﻿<?php 
require_once('../../painel/comfig.php'); 
/*

 Retorno PagSeguro 2.0 - PHP e MySQL
 por Diogo Dourado - www.dourado.net
 Última Atualização: 09/06/2011
 
 Se você ainda não é cadastrado no PagSeguro, utilize o link abaixo para se cadastrar:
 https://pagseguro.uol.com.br/?ind=528005

*/

$retorno_site = 'CompraConcluida.html';  // Site para onde o usuário vai ser redirecionado ao termino do pagamento
$retorno_token = $configuracoes['tokenpagseguro']; // Token gerado pelo PagSeguro
?>