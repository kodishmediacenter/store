<?php
require_once('../../painel/comfig.php'); ?>
<?php
session_start();
if($_POST){

    $user_id = strip_tags(mysql_real_escape_string($_SESSION['user_id'])); // Parametro passado pelo sistema de login!
	$email_cobranca = $configuracoes['emailpagseguro'];
	$tipo = 'CP';
	$moeda = 'BRL';
	$ref_transacao = $user_id+1772;;
	$item_valor_1 = strip_tags(mysql_real_escape_string($_POST["item_valor_1"]));
	$cliente_email = strip_tags(mysql_real_escape_string($_POST["cliente_email"]));
	
	//selecionando dados da tabela para pegar o tempo para o cliente
                    $sql458 = "SELECT * FROM formaspag WHERE valor=$item_valor_1";
                    $query458 = mysql_query($sql458);
					
					$verificapreco = mysql_num_rows($query458);
					if($verificapreco < 1){
					$item_valor_1 = '1000000.00';
					$item_descr_1 = utf8_encode('Ocorreu um erro tente novamente');
					}
					
                    while($sql458 = mysql_fetch_array($query458)){
					$tempoemmes = $sql458['tempo'];
	                if($tempoemmes >= '2'){
	                $mes = 'Meses';
	                }else{
	                $mes = 'M�s';
	                }
                    $item_descr_1 = urlencode($sql458["tempo"].' '.$mes);
                    //onde $tempo � a variavel que rerpresenta a coluna "tempo" nessa
                    //mesma tabela.
                    }
	
	
$url = 'https://pagseguro.uol.com.br/security/webpagamentos/webpagto.aspx?email_cobranca='.$email_cobranca.'&tipo='.$tipo.'&moeda='.$moeda.'&ref_transacao='.$ref_transacao.'&item_id_1=1&item_descr_1='.$item_descr_1.'&item_quant_1=1&item_valor_1='.$item_valor_1;

header("HTTP/1.1 301 Moved Permanently");
header("Location: $url");
exit();}
?>