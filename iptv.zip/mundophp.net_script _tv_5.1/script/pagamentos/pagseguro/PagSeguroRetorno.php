<?php
ob_start();
/*

 Retorno PagSeguro 2.0 - PHP e MySQL
 por Diogo Dourado - www.dourado.net
 �ltima Atualiza��o: 09/06/2011
 
 Se voc� ainda n�o � cadastrado no PagSeguro, utilize o link abaixo para se cadastrar:
 https://pagseguro.uol.com.br/?ind=528005

*/

header('Content-Type: text/html; charset=ISO-8859-1');

/* Edite este arquivo e insira suas configura��es */

include 'PagSeguroRetornoConfig.php'; 

/* N�o � necess�rio alterar nada desta linha para baixo */

include 'PagSeguroRetornoFuncoes.php';
define('TOKEN', $retorno_token);

if (count($_POST) > 0) {
	
	$npi = new PagSeguroNpi();
	$result = $npi->notificationPost();
	
	$transacaoID = isset($_POST['TransacaoID']) ? $_POST['TransacaoID'] : '';
	
	if ($result == "VERIFICADO") {
	
		// Recebendo Dados
		$VendedorEmail  = $_POST['VendedorEmail'];
		$TransacaoID = $_POST['TransacaoID'];
		$Referencia = $_POST['Referencia'];
		$Extras = MoedaBR($_POST['Extras']);
		$TipoFrete = $_POST['TipoFrete'];
		$ValorFrete = MoedaBR($_POST['ValorFrete']);
		$DataTransacao = ConverterData($_POST['DataTransacao']);
		$Anotacao = $_POST['Anotacao'];
		$TipoPagamento = $_POST['TipoPagamento'];
		$StatusTransacao = $_POST['StatusTransacao'];

		$CliNome = $_POST['CliNome'];
		$CliEmail = $_POST['CliEmail'];
		$CliEndereco = $_POST['CliEndereco'];
		$CliNumero = $_POST['CliNumero'];
		$CliComplemento = $_POST['CliComplemento'];
		$CliBairro = $_POST['CliBairro'];
		$CliCidade = $_POST['CliCidade'];
		$CliEstado = $_POST['CliEstado'];
		$CliCEP = $_POST['CliCEP'];
		$CliTelefone = $_POST['CliTelefone'];
		$preco = MoedaBR($_POST["ProdValor_1"]);
		$prodid = $_POST['ProdID_1'];
		$prodref = $Referencia-1772;
		$proddesc = $_POST['ProdDescricao_1'];

		$NumItens = $_POST['NumItens'];
		
		$ID = preg_replace("/[^0-9\s]/", "", $TransacaoID);
		$ID = substr($ID, 0, 9); 
		$horario = date("H:i:s");
		$data = date("Y-m-d");
		
		//selecionando dados da tabela para pegar o tempo para o cliente
                    $sql458 = "SELECT * FROM formaspag WHERE valor=$preco AND moeda='BRL'";
                    $query458 = mysql_query($sql458);
                    while($sql458 = mysql_fetch_array($query458)){
                    $tempo = $sql458["tempo"];
                    //onde $tempo � a variavel que rerpresenta a coluna "tempo" nessa
                    //mesma tabela.
                    }if(isset($tempo)){
					}else{
					$tempo = '0';
					}
		
		// Gravando Dados
		
		mysql_query("INSERT INTO BuyerTable 
					(BuyerName, BuyerEmail, TransactionID, ItemName, userid, ItemAmount, ItemQTY, status, forma, horario, creditado, data, tempo, moeda, ID)
					VALUES 
					('$CliNome','$CliEmail','$TransacaoID','$proddesc','$prodref','$preco','$NumItens','$StatusTransacao','pagseguro','$horario','n','$data','$tempo', 'BRL', $ID)
					ON DUPLICATE KEY UPDATE horario='$horario', data='$data', status='$StatusTransacao', userid='$prodref'");
		
	} 
} else {
	header("Location: $retorno_site");
	exit();
}
?>