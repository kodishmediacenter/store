<?php
require_once('../../painel/comfig.php'); ?>
<?php
$PayPalMode 			= 'live'; // sandbox or live
$PayPalApiUsername 		= $configuracoes['PayPalApiUsername']; //PayPal API Username
$PayPalApiPassword 		= $configuracoes['PayPalApiPassword']; //Paypal API password
$PayPalApiSignature 	= $configuracoes['PayPalApiSignature']; //Paypal API Signature
$PayPalCurrencyCode 	= 'BRL'; //Paypal Currency Code
$PayPalReturnURL 		= $siteurl.'/pagamentos/paypal/process.php'; //Point to process.php page
$PayPalCancelURL 		= $siteurl.'/painel/'; //Cancel URL if user clicks cancel
?>