<?php
require_once('../../painel/comfig.php'); ?>
<?php
session_start();
include_once("config.php");
include_once("paypal.class.php");


if($_POST) //Post Data received from product list page.
{
	
	//Mainly we need 4 variables from an item, Item Name, Item Price, Item Number and Item Quantity.
	$ItemPrice = strip_tags(mysql_real_escape_string($_POST["itemprice"])); //Item Price
	$ItemQty = '1'; // Item Quantity
	$ItemTotalPrice = ($ItemPrice*$ItemQty); //(Item Price x Quantity = Total) Get total amount of product; 
	
	//selecionando dados da tabela para pegar o tempo para o cliente
                    $sql458 = "SELECT * FROM formaspag WHERE valor=$ItemPrice";
                    $query458 = mysql_query($sql458);
					
					$verificapreco = mysql_num_rows($query458);
					if($verificapreco < 1){
					$ItemPrice = '1000000.00';
					$ItemTotalPrice = ($ItemPrice*$ItemQty);
					$ItemName = utf8_encode('Ocorreu um erro tente novamente');
					$ItemNumber = '1'; //Item Number
					}
					
                    while($sql458 = mysql_fetch_array($query458)){
					$tempoemmes = $sql458['tempo'];
	                if($tempoemmes >= '2'){
	                $mes = 'Meses';
	                }else{
	                $mes = 'M�s';
	                }
                    $ItemName = utf8_encode($sql458["tempo"].' '.$mes);
					$ItemNumber = $sql458['tempo']; //Item Number
                    //onde $tempo � a variavel que rerpresenta a coluna "tempo" nessa
                    //mesma tabela.
                    }

	//Data to be sent to paypal
	$padata = 	'&CURRENCYCODE='.urlencode($PayPalCurrencyCode).
				'&PAYMENTACTION=Sale'.
				'&LOCALECODE=BR'.
				'&ALLOWNOTE=1'.
				'&PAYMENTREQUEST_0_CURRENCYCODE='.urlencode($PayPalCurrencyCode).
				'&PAYMENTREQUEST_0_AMT='.urlencode($ItemTotalPrice).
				'&PAYMENTREQUEST_0_ITEMAMT='.urlencode($ItemTotalPrice). 
				'&L_PAYMENTREQUEST_0_QTY0='. urlencode($ItemQty).
				'&L_PAYMENTREQUEST_0_AMT0='.urlencode($ItemPrice).
				'&L_PAYMENTREQUEST_0_NAME0='.urlencode($ItemName).
				'&L_PAYMENTREQUEST_0_NUMBER0='.urlencode($ItemNumber).
				'&AMT='.urlencode($ItemTotalPrice).				
				'&RETURNURL='.urlencode($PayPalReturnURL ).
				'&CANCELURL='.urlencode($PayPalCancelURL);	
		
		//We need to execute the "SetExpressCheckOut" method to obtain paypal token
		$paypal= new MyPayPal();
		$httpParsedResponseAr = $paypal->PPHttpPost('SetExpressCheckout', $padata, $PayPalApiUsername, $PayPalApiPassword, $PayPalApiSignature, $PayPalMode);
		
		//Respond according to message we receive from Paypal
		if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"]))
		{
					
				// If successful set some session variable we need later when user is redirected back to page from paypal. 
				$_SESSION['itemprice'] =  $ItemPrice;
				$_SESSION['totalamount'] = $ItemTotalPrice;
				$_SESSION['itemName'] =  $ItemName;
				$_SESSION['itemNo'] =  $ItemNumber;
				$_SESSION['itemQTY'] =  $ItemQty;
				
				if($PayPalMode=='sandbox')
				{
					$paypalmode 	=	'.sandbox';
				}
				else
				{
					$paypalmode 	=	'';
				}
				//Redirect user to PayPal store with Token received.
			 	$paypalurl ='https://www'.$paypalmode.'.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token='.$httpParsedResponseAr["TOKEN"].'';
				header('Location: '.$paypalurl);
			 
		}else{
			//Show error message
			echo '<div style="color:red"><b>Error : </b>'.urldecode($httpParsedResponseAr["L_LONGMESSAGE0"]).'</div>';
			echo '<pre>';
			print_r($httpParsedResponseAr);
			echo '</pre>';
		}

}

//Paypal redirects back to this page using ReturnURL, We should receive TOKEN and Payer ID
if(isset($_GET["token"]) && isset($_GET["PayerID"]))
{
	//we will be using these two variables to execute the "DoExpressCheckoutPayment"
	//Note: we haven't received any payment yet.
	
	$token = $_GET["token"];
	$playerid = $_GET["PayerID"];
	
	//get session variables
	$ItemPrice 		= $_SESSION['itemprice'];
	$ItemTotalPrice = $_SESSION['totalamount'];
	$ItemName 		= utf8_decode($_SESSION['itemName']);
	$ItemNumber2 	= $_SESSION['itemNo'];
	$ItemQTY 		=$_SESSION['itemQTY'];
	
	$padata = 	'&TOKEN='.urlencode($token).
						'&PAYERID='.urlencode($playerid).
						'&PAYMENTACTION='.urlencode("SALE").
						'&AMT='.urlencode($ItemTotalPrice).
						'&CURRENCYCODE='.urlencode($PayPalCurrencyCode);
	
	//We need to execute the "DoExpressCheckoutPayment" at this point to Receive payment from user.
	$paypal= new MyPayPal();
	$httpParsedResponseAr = $paypal->PPHttpPost('DoExpressCheckoutPayment', $padata, $PayPalApiUsername, $PayPalApiPassword, $PayPalApiSignature, $PayPalMode);
	
	//Check if everything went ok..
	if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"])) 
	{
			
				/*
				//Sometimes Payment are kept pending even when transaction is complete. 
				//May be because of Currency change, or user choose to review each payment etc.
				//hence we need to notify user about it and ask him manually approve the transiction
				*/
				
				$transactionID = urlencode($httpParsedResponseAr["TRANSACTIONID"]);
				$ID = preg_replace("/[^0-9\s]/", "", $transactionID);
				$ID = substr($ID, 0, 9); 
				$nvpStr = "&TRANSACTIONID=".$transactionID;
				$paypal= new MyPayPal();
				$httpParsedResponseAr = $paypal->PPHttpPost('GetTransactionDetails', $nvpStr, $PayPalApiUsername, $PayPalApiPassword, $PayPalApiSignature, $PayPalMode);
				$status = $httpParsedResponseAr["PAYMENTSTATUS"];
				
				if('Completed' == $httpParsedResponseAr["PAYMENTSTATUS"])
				{
					
					#### SAVE BUYER INFORMATION IN DATABASE ###
					$buyerName = urldecode($httpParsedResponseAr["FIRSTNAME"].' '.$httpParsedResponseAr["LASTNAME"]);
					$buyerEmail = urldecode($httpParsedResponseAr["EMAIL"]);
					$moeda = $httpParsedResponseAr["CURRENCYCODE"];
					$horario = date("H:i:s");
					$ItemNumber = strip_tags(mysql_real_escape_string($_SESSION['user_id']));
					$data = date("Y-m-d");
					
					$ItemTotalPrice = urldecode($httpParsedResponseAr["AMT"]);
					//selecionando dados da tabela para pegar o tempo para o cliente
                    $sql458 = "SELECT * FROM formaspag WHERE valor=$ItemTotalPrice AND moeda='$moeda'";
                    $query458 = mysql_query($sql458);
                    while($sql458 = mysql_fetch_array($query458)){
                    $tempo = $sql458["tempo"];
                    //onde $tempo � a variavel que rerpresenta a coluna "tempo" nessa
                    //mesma tabela.
                    }if(isset($tempo)){
					}else{
					$tempo = '0';
					}
					
					mysql_query("INSERT INTO BuyerTable 
					(BuyerName, BuyerEmail, TransactionID, ItemName, userid, ItemAmount, ItemQTY, status, forma, horario, creditado, data, tempo, moeda, ID)
					VALUES 
					('$buyerName','$buyerEmail','$transactionID','$ItemName',$ItemNumber,$ItemTotalPrice,$ItemQTY,'$status','paypal','$horario','n', '$data','$tempo','$moeda',$ID)
					ON DUPLICATE KEY UPDATE horario='$horario', data='$data', status='$status'");
					
					header("Location: CompraConcluida.html");
	                exit();
					
				}
				elseif('Pending' == $httpParsedResponseAr["PAYMENTSTATUS"])
				{
					echo '<div style="color:red">Transa��o completa, mas o pagamento ainda est� pendente! Voc� precisa autorizar manualmente esse pagamento em sua <a target="_new" href="http://www.paypal.com"> conta Paypal </a> </div>';
				}
			


				if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"])) {
				
				} else  {
					echo '<div style="color:red"><b>Pegar detalhes da transa��o falhou:</b>'.urldecode($httpParsedResponseAr["L_LONGMESSAGE0"]).'</div>';
					echo '<pre>';
					print_r($httpParsedResponseAr);
					echo '</pre>';

				}
	
	}else{
			echo '<div style="color:red"><b>Erro : </b>'.urldecode($httpParsedResponseAr["L_LONGMESSAGE0"]).'</div>';
			echo '<pre>';
			print_r($httpParsedResponseAr);
			echo '</pre>';
	}
}
?>
