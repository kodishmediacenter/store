<ol>
                <li data-slide-name="variedades">
                    <h2><span>VARIEDADES / ABERTOS</span></h2>
                    <div>
    <table width="auto" align="left" cellspacing="0" class="canais">
    <tr>
	<?
    $i = 1;
    $colunas = 7;
	$fundoa = 1;
	$fundol = 1;

	if($separar == 's'){
    $path = 'vip';
    }else{
    $path = 'aberto';
    }
    $linkcsssplit = $siteurl.'/icones/'.$path.'/variedades.jpeg';
    
    $q_canais_variedades = mysql_query("SELECT * FROM dados_beta WHERE categoria LIKE 'variedades' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
	$limitando = 1;
    while(($canais_variedades = mysql_fetch_object($q_canais_variedades)) && ($limitando<5000)){
    $resto = $i % $colunas;
   
	$checar1 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$canais_variedades->nome_foto."' AND lugar LIKE 'canais' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') $naoconta LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	if(($result1 == 1) && ($canais_variedades->ligar == 'n')){
	$limitando++;
    while($sql458 = mysql_fetch_array($checar1)){
					?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} if(($result1 == 1) && ($canais_variedades->ligar == 's')&& ($canais_variedades->vip == 'n') && ($separar == 's')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 1) && ($canais_variedades->ligar == 's') && ($canais_variedades->vip == 's' or $canais_variedades->vip == 'na') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_variedades->$linkvip; ?>" title="<? echo $canais_variedades->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_variedades->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 1) && ($canais_variedades->ligar == 's') && ($separar == 'n')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_variedades->$linkvip; ?>" title="<? echo $canais_variedades->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_variedades->nome_do_canal; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 0) && ($canais_variedades->ligar == 's') && ($separar == 'n')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_variedades->$linkvip; ?>" title="<? echo $canais_variedades->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_variedades->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 0) && ($canais_variedades->ligar == 's') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_variedades->$linkvip; ?>" title="<? echo $canais_variedades->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_variedades->nome_do_canal; ?></span></a></div></td>
<? } ?>
	<?
    if(($resto == 0)){
    print "</tr>
	<tr>
	";
	$fundol = 1;
	$fundoa = $fundoa+51;
    }else{
	$fundol = $fundol+71;
	}
    
    $i++;
    
    }
    if($resto != 0){ ?></tr>
<? } $variedades = $limitando - 1; ?>
    </table>
                    </div>
                </li>
                <li data-slide-name="cinema">
                    <h2><span>CINEMA / SERIES</span></h2>
                  <div>
	<table width="auto" align="left" cellspacing="0" class="canais">
    <tr>
	<?
    $i = 1;
    $colunas = 7;
	$fundoa = 1;
	$fundol = 1;
	
	if($separar == 's'){
    $path = 'vip';
    }else{
    $path = 'aberto';
    }
    $linkcsssplit = $siteurl.'/icones/'.$path.'/cinema.jpeg';
    
    $q_canais_cinema = mysql_query("SELECT * FROM dados_beta WHERE categoria LIKE 'cinema' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
	$limitando = 1;
    while(($canais_cinema = mysql_fetch_object($q_canais_cinema)) && ($limitando<5000)){
    $resto = $i % $colunas;
    
	$checar1 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$canais_cinema->nome_foto."' AND lugar LIKE 'canais' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') $naoconta LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	if(($result1 == 1) && ($canais_cinema->ligar == 'n')){
	$limitando++;
    while($sql458 = mysql_fetch_array($checar1)){
					?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} if(($result1 == 1) && ($canais_cinema->ligar == 's')&& ($canais_cinema->vip == 'n') && ($separar == 's')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 1) && ($canais_cinema->ligar == 's') && ($canais_cinema->vip == 's' or $canais_cinema->vip == 'na') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_cinema->$linkvip; ?>" title="<? echo $canais_cinema->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_cinema->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 1) && ($canais_cinema->ligar == 's') && ($separar == 'n')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_cinema->$linkvip; ?>" title="<? echo $canais_cinema->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_cinema->nome_do_canal; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 0) && ($canais_cinema->ligar == 's') && ($separar == 'n')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_cinema->$linkvip; ?>" title="<? echo $canais_cinema->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_cinema->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 0) && ($canais_cinema->ligar == 's') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_cinema->$linkvip; ?>" title="<? echo $canais_cinema->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_cinema->nome_do_canal; ?></span></a></div></td>
<? } ?>
	<?
    if(($resto == 0)){
    print "</tr>
	<tr>
	";
	$fundol = 1;
	$fundoa = $fundoa+51;
    }else{
	$fundol = $fundol+71;
	}
    
    $i++;
    
    }
    if($resto != 0){ ?></tr>
<? } $cinema = $limitando - 1; ?>
    </table>
</div>
                </li>
                <li data-slide-name="esportes">
                    <h2><span>ESPORTES</span></h2>
                    <div>
	<table width="auto" align="left" cellspacing="0" class="canais">
    <tr>
	<?
    $i = 1;
    $colunas = 7;
	$fundoa = 1;
	$fundol = 1;
	
	if($separar == 's'){
    $path = 'vip';
    }else{
    $path = 'aberto';
    }
    $linkcsssplit = $siteurl.'/icones/'.$path.'/esportes.jpeg';
    
    $q_canais_esportes = mysql_query("SELECT * FROM dados_beta WHERE categoria LIKE 'esportes' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
	$limitando = 1;
    while(($canais_esportes = mysql_fetch_object($q_canais_esportes)) && ($limitando<5000)){
    $resto = $i % $colunas;
    
	$checar1 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$canais_esportes->nome_foto."' AND lugar LIKE 'canais' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') $naoconta LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	if(($result1 == 1) && ($canais_esportes->ligar == 'n') ){
	$limitando++;
    while($sql458 = mysql_fetch_array($checar1)){
					?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} if(($result1 == 1) && ($canais_esportes->ligar == 's')&& ($canais_esportes->vip == 'n') && ($separar == 's')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 1) && ($canais_esportes->ligar == 's') && ($canais_esportes->vip == 's' or $canais_esportes->vip == 'na') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_esportes->$linkvip; ?>" title="<? echo $canais_esportes->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_esportes->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 1) && ($canais_esportes->ligar == 's') && ($separar == 'n')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_esportes->$linkvip; ?>" title="<? echo $canais_esportes->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_esportes->nome_do_canal; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 0) && ($canais_esportes->ligar == 's') && ($separar == 'n')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_esportes->$linkvip; ?>" title="<? echo $canais_esportes->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_esportes->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 0) && ($canais_esportes->ligar == 's') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_esportes->$linkvip; ?>" title="<? echo $canais_esportes->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_esportes->nome_do_canal; ?></span></a></div></td>
<? } ?>
	<?
    if(($resto == 0)){
    print "</tr>
	<tr>
	";
	$fundol = 1;
	$fundoa = $fundoa+51;
    }else{
	$fundol = $fundol+71;
	}
    
    $i++;
    
    }
    if($resto != 0){ ?></tr>
<? } $esportes = $limitando - 1; ?>
    </table>
                    </div>
                </li>
                <li data-slide-name="infantil">
                    <h2><span>INFANTIL / DESENHOS</span></h2>
                    <div>
	<table width="auto" align="left" cellspacing="0" class="canais">
    <tr>
	<?
    $i = 1;
    $colunas = 7;
	$fundoa = 1;
	$fundol = 1;
	
	if($separar == 's'){
    $path = 'vip';
    }else{
    $path = 'aberto';
    }
    $linkcsssplit = $siteurl.'/icones/'.$path.'/infantil.jpeg';
    
    $q_canais_infantil = mysql_query("SELECT * FROM dados_beta WHERE categoria LIKE 'infantil' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
	$limitando = 1;
    while(($canais_infantil = mysql_fetch_object($q_canais_infantil)) && ($limitando<5000)){
    $resto = $i % $colunas;
    
	$checar1 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$canais_infantil->nome_foto."' AND lugar LIKE 'canais' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') $naoconta LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	if(($result1 == 1) && ($canais_infantil->ligar == 'n')){
	
    while($sql458 = mysql_fetch_array($checar1)){
					?>	
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} if(($result1 == 1) && ($canais_infantil->ligar == 's')&& ($canais_infantil->vip == 'n') && ($separar == 's')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 1) && ($canais_infantil->ligar == 's') && ($canais_infantil->vip == 's' or $canais_infantil->vip == 'na') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_infantil->$linkvip; ?>" title="<? echo $canais_infantil->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_infantil->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 1) && ($canais_infantil->ligar == 's') && ($separar == 'n')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_infantil->$linkvip; ?>" title="<? echo $canais_infantil->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_infantil->nome_do_canal; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 0) && ($canais_infantil->ligar == 's') && ($separar == 'n')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_infantil->$linkvip; ?>" title="<? echo $canais_infantil->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_infantil->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 0) && ($canais_infantil->ligar == 's') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_infantil->$linkvip; ?>" title="<? echo $canais_infantil->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_infantil->nome_do_canal; ?></span></a></div></td>
<? } ?>
	<?
    if(($resto == 0)){
    print "</tr>
	<tr>
	";
	$fundol = 1;
	$fundoa = $fundoa+51;
    }else{
	$fundol = $fundol+71;
	}
    
    $i++;
    
    }
    if($resto != 0){ ?></tr>
<? } $infantil = $limitando - 1; ?>
    </table>
                    </div>
                </li>
				<li data-slide-name="clipes">
                    <h2><span>CLIPES / MUSICAIS</span></h2>
                    <div>
    <table width="auto" align="left" cellspacing="0" class="canais">
    <tr>
	<?
    $i = 1;
    $colunas = 7;
	$fundoa = 1;
	$fundol = 1;
	
	if($separar == 's'){
    $path = 'vip';
    }else{
    $path = 'aberto';
    }
    $linkcsssplit = $siteurl.'/icones/'.$path.'/clipes.jpeg';
    
    $q_canais_clipes = mysql_query("SELECT * FROM dados_beta WHERE categoria LIKE 'clipes' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
	$limitando = 1;
    while(($canais_clipes = mysql_fetch_object($q_canais_clipes)) && ($limitando<5000)){
    $resto = $i % $colunas;
    
	$checar1 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$canais_clipes->nome_foto."' AND lugar LIKE 'canais' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') $naoconta LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	if(($result1 == 1) && ($canais_clipes->ligar == 'n')){
	$limitando++;
    while($sql458 = mysql_fetch_array($checar1)){
					?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} if(($result1 == 1) && ($canais_clipes->ligar == 's')&& ($canais_clipes->vip == 'n') && ($separar == 's')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 1) && ($canais_clipes->ligar == 's') && ($canais_clipes->vip == 's' or $canais_clipes->vip == 'na') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $$linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_clipes->$linkvip; ?>" title="<? echo $canais_clipes->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_clipes->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 1) && ($canais_clipes->ligar == 's') && ($separar == 'n')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_clipes->$linkvip; ?>" title="<? echo $canais_clipes->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_clipes->nome_do_canal; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 0) && ($canais_clipes->ligar == 's') && ($separar == 'n')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_clipes->$linkvip; ?>" title="<? echo $canais_clipes->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_clipes->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 0) && ($canais_clipes->ligar == 's') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_clipes->$linkvip; ?>" title="<? echo $canais_clipes->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_clipes->nome_do_canal; ?></span></a></div></td>
<? } ?>
	<?
    if(($resto == 0)){
    print "</tr>
	<tr>
	";
	$fundol = 1;
	$fundoa = $fundoa+51;
    }else{
	$fundol = $fundol+71;
	}
    
    $i++;
    
    }
    if($resto != 0){ ?></tr>
<? } $clipes = $limitando - 1; ?>
</table>
                    </div>
                </li>
                <li data-slide-name="religiosos">
                    <h2><span>RELIGIOSOS</span></h2>
                    <div>
    <table width="auto" align="left" cellspacing="0" class="canais">
    <tr>
	<?
    $i = 1;
    $colunas = 7;
	$fundoa = 1;
	$fundol = 1;
	
	if($separar == 's'){
    $path = 'vip';
    }else{
    $path = 'aberto';
    }
    $linkcsssplit = $siteurl.'/icones/'.$path.'/religiosos.jpeg';
    
    $q_canais_religiosos = mysql_query("SELECT * FROM dados_beta WHERE categoria LIKE 'religiosos' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
	$limitando = 1;
    while(($canais_religiosos = mysql_fetch_object($q_canais_religiosos)) && ($limitando<5000)){
    $resto = $i % $colunas;
    
	$checar1 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$canais_religiosos->nome_foto."' AND lugar LIKE 'canais' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') $naoconta LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	if(($result1 == 1) && ($canais_religiosos->ligar == 'n')){
	$limitando++;
    while($sql458 = mysql_fetch_array($checar1)){
					?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} if(($result1 == 1) && ($canais_religiosos->ligar == 's')&& ($canais_religiosos->vip == 'n') && ($separar == 's')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 1) && ($canais_religiosos->ligar == 's') && ($canais_religiosos->vip == 's' or $canais_religiosos->vip == 'na') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_religiosos->$linkvip; ?>" title="<? echo $canais_religiosos->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_religiosos->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 1) && ($canais_religiosos->ligar == 's') && ($separar == 'n')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_religiosos->$linkvip; ?>" title="<? echo $canais_religiosos->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_religiosos->nome_do_canal; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 0) && ($canais_religiosos->ligar == 's') && ($separar == 'n')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_religiosos->$linkvip; ?>" title="<? echo $canais_religiosos->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_religiosos->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 0) && ($canais_religiosos->ligar == 's') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_religiosos->$linkvip; ?>" title="<? echo $canais_religiosos->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_religiosos->nome_do_canal; ?></span></a></div></td>
<? } ?>
	<?
    if(($resto == 0)){
    print "</tr>
	<tr>
	";
	$fundol = 1;
	$fundoa = $fundoa+51;
    }else{
	$fundol = $fundol+71;
	}
    
    $i++;
    
    }
    if($resto != 0){ ?></tr>
<? } $religiosos = $limitando - 1; ?>
    </table>
                    </div>
                </li>
				<li data-slide-name="documentarios">
                    <h2><span>DOCUMENTARIOS</span></h2>
                    <div>
	<table width="auto" align="left" cellspacing="0" class="canais">
    <tr>
	<?
    $i = 1;
    $colunas = 7;
	$fundoa = 1;
	$fundol = 1;
	
	if($separar == 's'){
    $path = 'vip';
    }else{
    $path = 'aberto';
    }
    $linkcsssplit = $siteurl.'/icones/'.$path.'/documentarios.jpeg';
    
    $q_canais_documentarios = mysql_query("SELECT * FROM dados_beta WHERE categoria LIKE 'documentarios' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
	$limitando = 1;
    while(($canais_documentarios = mysql_fetch_object($q_canais_documentarios)) && ($limitando<5000)){
    $resto = $i % $colunas;
    
	$checar1 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$canais_documentarios->nome_foto."' AND lugar LIKE 'canais' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') $naoconta LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	if(($result1 == 1) && ($canais_documentarios->ligar == 'n')){
	$limitando++;
    while($sql458 = mysql_fetch_array($checar1)){
					?>	
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} if(($result1 == 1) && ($canais_documentarios->ligar == 's')&& ($canais_documentarios->vip == 'n') && ($separar == 's')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 1) && ($canais_documentarios->ligar == 's') && ($canais_documentarios->vip == 's' or $canais_documentarios->vip == 'na') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_documentarios->$linkvip; ?>" title="<? echo $canais_documentarios->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_documentarios->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 1) && ($canais_documentarios->ligar == 's') && ($separar == 'n')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_documentarios->$linkvip; ?>" title="<? echo $canais_documentarios->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_documentarios->nome_do_canal; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 0) && ($canais_documentarios->ligar == 's') && ($separar == 'n')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_documentarios->$linkvip; ?>" title="<? echo $canais_documentarios->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_documentarios->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 0) && ($canais_documentarios->ligar == 's') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_documentarios->$linkvip; ?>" title="<? echo $canais_documentarios->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_documentarios->nome_do_canal; ?></span></a></div></td>
<? } $documentarios?>
	<?
    if(($resto == 0)){
    print "</tr>
	<tr>
	";
	$fundol = 1;
	$fundoa = $fundoa+51;

    }else{
	$fundol = $fundol+71;
	}
    
    $i++;
    
    }
    if($resto != 0){ ?></tr>
<? } $documentarios  = $limitando - 1; ?>
    </table>
                    </div>
                </li>
				<li data-slide-name="noticias">
                    <h2><span>NOTICIAS</span></h2>
                    <div>
    <table width="auto" align="left" cellspacing="0" class="canais">
    <tr>
	<?
    $i = 1;
    $colunas = 7;
	$fundoa = 1;
	$fundol = 1;
	
	if($separar == 's'){
    $path = 'vip';
    }else{
    $path = 'aberto';
    }
    $linkcsssplit = $siteurl.'/icones/'.$path.'/noticias.jpeg';
    
    $q_canais_noticias = mysql_query("SELECT * FROM dados_beta WHERE categoria LIKE 'noticias' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
	$limitando = 1;
    while(($canais_noticias = mysql_fetch_object($q_canais_noticias)) && ($limitando<5000)){
    $resto = $i % $colunas;
    
	$checar1 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$canais_noticias->nome_foto."' AND lugar LIKE 'canais' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') $naoconta LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	if(($result1 == 1) && ($canais_noticias->ligar == 'n')){
	$limitando++;
    while($sql458 = mysql_fetch_array($checar1)){
					?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} if(($result1 == 1) && ($canais_noticias->ligar == 's')&& ($canais_noticias->vip == 'n') && ($separar == 's')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$sql458[$linkvip]; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="canaisbox"><span><? echo $sql458['nome_do_canal']; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 1) && ($canais_noticias->ligar == 's') && ($canais_noticias->vip == 's' or $canais_noticias->vip == 'na') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_noticias->$linkvip; ?>" title="<? echo $canais_noticias->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_noticias->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 1) && ($canais_noticias->ligar == 's') && ($separar == 'n')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_noticias->$linkvip; ?>" title="<? echo $canais_noticias->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_noticias->nome_do_canal; ?></span></a></div></td>
<? }} ?>
<? if(($result1 == 0) && ($canais_noticias->ligar == 's') && ($separar == 'n')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_noticias->$linkvip; ?>" title="<? echo $canais_noticias->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_noticias->nome_do_canal; ?></span></a></div></td>
<? } ?>
<? if(($result1 == 0) && ($canais_noticias->ligar == 's') && ($separar == 's')){ $limitando++;
?>
	<td><div class="imagem" style="background:url('<? echo $linkcsssplit; ?>?nocache=<? echo $idunico; ?>') -<? echo $fundol; ?>px -<? echo $fundoa; ?>px no-repeat;"><a href="<? echo $siteurl.'/tv/'.$canais_noticias->$linkvip; ?>" title="<? echo $canais_noticias->nome_do_canal; ?>" target="canaisbox"><span><? echo $canais_noticias->nome_do_canal; ?></span></a></div></td>
<? } ?>
	<?
    if(($resto == 0)){
    print "</tr>
	<tr>
	";
	$fundol = 1;
	$fundoa = $fundoa+51;
    }else{
	$fundol = $fundol+71;
	}
    
    $i++;
    
    }
    if($resto != 0){ ?></tr>
<? } $noticias = $limitando - 1; ?>
    </table>
                </div>
                </li>
</ol>