<?php 
ob_start();
require_once('painel/comfig.php'); ?>
<div style="padding: 3px;
overflow: auto;
position: relative;

height: 105%;">
<?php

session_start();
$_SESSION['canal_aberto'] = '';
$_SESSION['canal_aberto_nome'] = '';
//verifica�ao vip
if (!isset($_SESSION['user_id']) && !isset($_SESSION['user_name']) ){
if(isset($_COOKIE['user_id']) && isset($_COOKIE['user_key'])){
	/* we double check cookie expiry time against stored in database */
	
	$cookie_user_id  = filter($_COOKIE['user_id']);
	$rs_ctime = mysql_query("select `ckey`,`ctime` from `users` where `id` ='$cookie_user_id'") or die(mysql_error());
	list($ckey,$ctime) = mysql_fetch_row($rs_ctime);
	// coookie expiry
	if( (time() - $ctime) > 60*60*24*COOKIE_TIME_OUT) {

		logout();
		}
/* Security check with untrusted cookies - dont trust value stored in cookie. 		
/* We also do authentication check of the `ckey` stored in cookie matches that stored in database during login*/

	 if( !empty($ckey) && is_numeric($_COOKIE['user_id']) && isUserID($_COOKIE['user_name']) && $_COOKIE['user_key'] == sha1($ckey)  ) {
	 	  session_regenerate_id(); //against session fixation attacks.
	
		  $_SESSION['user_id'] = $_COOKIE['user_id'];
		  $_SESSION['user_name'] = $_COOKIE['user_name'];
		/* query user level from database instead of storing in cookies */	
		  list($user_level) = mysql_fetch_row(mysql_query("select user_level from users where id='$_SESSION[user_id]'"));

		  $_SESSION['user_level'] = $user_level;
		  $_SESSION['HTTP_USER_AGENT'] = md5($_SERVER['HTTP_USER_AGENT']);
		  
		  $session_id=session_id();
		  $id = $_SESSION['user_id'];
          $savsessionquery="INSERT INTO users_sessions (id, session_id) VALUES ('".$id."', '".$session_id."') ON DUPLICATE KEY UPDATE session_id='".$session_id."'";
          $savesessionresult=mysql_query($savsessionquery);
		  
	   }

  }
}

if(isset($_SESSION['user_id']) && isset($_SESSION['user_name'])){
$user_id = $_SESSION['user_id'];
$boas_vindas = mysql_query("SELECT id, vencimento, data FROM users WHERE id = '$user_id'")
or die(mysql_error());
if(@mysql_num_rows($boas_vindas) <= '0') 
echo "Erro ao selecionar o usuário";
else{
while($res_boas_vindas=mysql_fetch_array($boas_vindas)){
$vencimento = $res_boas_vindas[1];
$data = $res_boas_vindas[2];


$dataI= date('Y/m/d');
$I= strtotime($dataI);
$dataII= $vencimento;
$II= strtotime($dataII);
$dataIII= $data;
$III= strtotime($dataIII);


// Define os valores a serem usados
$data_inicial = $data;
$data_final = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial = strtotime($data_inicial);
$time_final = strtotime($data_final);

// Calcula a diferença de segundos entre as duas datas:
$diferenca = $time_final - $time_inicial; // 19522800 segundos

// Calcula a diferença de dias
$dias = (int)floor( $diferenca / (60 * 60 * 24)); // 225 dias


// Define os valores a serem usados
$data_inicial1 = $dataI;
$data_final1 = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial1 = strtotime($data_inicial1);
$time_final1 = strtotime($data_final1);

// Calcula a diferença de segundos entre as duas datas:
$diferenca1 = $time_final1 - $time_inicial1; // 19522800 segundos

// Calcula a diferença de dias
$dias1 = (int)floor( $diferenca1 / (60 * 60 * 24)); // 225 dias

$porc = $dias+0.000001;
$valor = $dias1;
$resul = $valor/$porc;
$fim = $resul*100;

if ($I >= $II){ 
$separar = 'n';
$linkvip = 'nome_foto';
}else{
$separar = 's';
$linkvip = 'linkvip';
}
}
}
}else{
$separar = 'n';
$linkvip = 'nome_foto';
}
//fim verifica�ao vip
function nomeico($extensao){
 $arquivo1111 = pathinfo($extensao, PATHINFO_EXTENSION);
 if($arquivo1111 == 'jpg'){
 return $file = basename($extensao, ".jpg");
 }
 if($arquivo1111 == 'png'){
 return $file = basename($extensao, ".png");
 }
 if($arquivo1111 == 'gif'){
 return $file = basename($extensao, ".gif");
 }
}
function linkico($vip, $link){
global $siteurl;
if($vip==s){ return $siteurl.'/icones/pequeno/vip/'.nomeico($link).'.jpeg';}
if($vip==n){ return $siteurl.'/icones/pequeno/aberto/'.nomeico($link).'.jpeg';}
if($vip==na){ return $siteurl.'/icones/pequeno/aberto/'.nomeico($link).'.jpeg';}
}

$palavra = mysql_real_escape_string(utf8_decode($_GET["palavra"]));

$sql = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND ligar!='n' AND (vip='$separar' or vip='na') AND (nome_do_canal LIKE '%".$palavra."%' OR categoria LIKE '%".$palavra."%' OR palavras LIKE '%".$palavra."%'  OR titulo LIKE '%".$palavra."%'  OR titulo2 LIKE '%".$palavra."%' OR resumo LIKE '%".$palavra."%'  OR resumo2 LIKE '%".$palavra."%' OR small_data LIKE '%".$palavra."%' OR small_data2 LIKE '%".$palavra."%') ORDER BY nome_do_canal");
$result = mysql_num_rows($sql);
if($result>=1) {
    echo "<center><div style='padding:4px;font-size:14px;font-family:tahoma;border:1px solid #000;margin-top:2px;margin-bottom:2px;background:#D9E9FB;'>A Sua busca por <b>".$palavra."</b> retornou <b>".$result."</b> resultados.</div></center>";
    while ($dados = mysql_fetch_array($sql)) {
    if($dados['form'] == 'opt'){
	$sql4581 = "SELECT * FROM dados_beta WHERE nome_foto='".$dados['categoria']."' AND lugar='canais' LIMIT 1";
                    $query4581 = mysql_query($sql4581);
                    while($sqla4581 = mysql_fetch_array($query4581)){
					if($sqla4581['ligar'] == 'n'){
					$imagem1 = linkico($sqla4581['vip'], $sqla4581['url_do_canal']);
					$categoria = $sqla4581['categoria'];
					}
					if($sqla4581['ligar'] == 's'){
					$imagem1 = linkico($sqla4581['vip'], $sqla4581['url_do_canal']);
					$categoria = $sqla4581['categoria'];
					}
					}
	}else{
	$imagem1 = linkico($dados['vip'], $dados['url_do_canal']);
	$categoria = $dados['categoria'];
	}
	$agora = $dados['titulo'];
	if(!empty($agora)){
	$agora = '<tr>
    <td>Passando agora: '.$agora.'</td>
  </tr>';
	}
	$proximo = $dados['titulo2'];
	if(!empty($agora)){
	$proximo = '<tr>
    <td>Pr�ximo: '.$proximo.'</td>
  </tr>';
	}
    echo "<table width='468' height='50' border='0'>
  <tr>
    <td width='70' rowspan='5'><img width='70' height='50' src='$imagem1' /></td>
    <td width='388'>Nome: $dados[nome_do_canal]</td>
  </tr>
  <tr>
    <td>Categoria: $categoria</td>
  </tr>
  $agora
  $proximo
  <tr>
    <td><b><a href='$siteurl/tv/$dados[$linkvip]&play=1' target='canaisbox' style='color:#006600'>>>Assistir este canal</a></b></td>
  </tr>
</table>"; 
    echo "<hr>";
}
 
} else {
    echo "<center>
  <div style='padding:4px;font-size:14px;font-family:tahoma;border:1px solid #990000;margin-top:2px;margin-bottom:2px;background:#FDB5BC;'>Sua busca por <b>".$palavra."</b> n�o retornou nenhum resultado.</div>
</center>";
}
?>
</div>
<? if(!empty($configuracoes['analytics'])){ ?>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', '<? echo $configuracoes['analytics']; ?>', '<? $parse = parse_url($siteurl);  echo $parse['host'];  ?>');
  ga('send', 'pageview');

</script>
<? } ?>