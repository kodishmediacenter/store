<?php 
require_once(dirname(__FILE__).'/banco_de_dados/bd.php'); 
$link = mysql_connect(DB_HOST, DB_USER, DB_PASS) or die("");
$db = mysql_select_db(DB_NAME, $link) or die("");
date_default_timezone_set('America/Sao_Paulo');

error_reporting(0);
ini_set('display_errors', 0 );

$pro = 0; #0desligado, 1 ligado :proxy
// Create a stream
$opts = array(
        'http'=>array(
            'method'=>"GET",
			'timeout' => 5,
            'header'=>"Accept-language: en\r\n" .
            "Cookie: foo=bar\r\n",
            'proxy' => 'tcp://91.121.103.144:8080',
            )
);

$context = stream_context_create($opts);

function entre_string($str,$antes,$depois)
{
	$arr1 = explode($antes,$str);
	$arr2 = explode($depois,$arr1[1]);
	return utf8_decode($arr2[0]);
}
function entre_string2($str,$antes)
{
	preg_match_all("/<span class=\"$antes\">(.+?)<\/span>/is", $str, $out4);
	return utf8_decode($out4[1][1]);
}

$sql = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND trim(coalesce(prog, '')) <>''"); 
while ($dados = mysql_fetch_array($sql))
{
	$id = $dados['ID'];
	$categoria = $dados['nome_foto'];
	$timest = $dados['timest'];
	$timezone = 'GMT-3:00 DST';
	$agora = strtotime(date('d-m-Y H:i:s', strtotime(date("d-m-Y H:i:s"))) . ' '. $timezone);
	if(empty($timest))
	{
		$timest = 0;
	}

	if($timest < $agora)
	{	
		// Endere�o do site
		$urlprog = $dados['prog'];

		// Pegando dados do Site e colocando em uma String
		// Open the file using the HTTP headers set above
		if($pro >= 1)
		{
			$dadosSite = file_get_contents($urlprog, false, $context);
		}
		else
		{
			$dadosSite = file_get_contents($urlprog);
		}
		$arq = $dadosSite;

		preg_match_all("/<div class='prog_comp_data'>(.+?)<\/div>/is", $arq, $out);

		$texto = $out[1][0];
		$texto = preg_replace ('/<[^>]*>/', ' ', $texto);
		$texto1 =  str_replace("\n", "", trim($texto));
		$titulo = utf8_decode(trim($texto1));

		$texto = $out[1][1];
		$texto = preg_replace ('/<[^>]*>/', ' ', $texto);
		$texto1 =  str_replace("\n", "", trim($texto));
		$titulo1 = utf8_decode(trim($texto1));

		$info = getdate();
		$hour = $info['hours'];
		$min = $info['minutes'];

		$horanow = $hour.":".$min;
		$date = $info['mday'];
		$month = $info['mon'];
		$year = $info['year'];
		$datanow = $year."/".$month."/".$date;

		$hora = substr($titulo, 0, 5);
		$hora = str_replace('h', ':', $hora);

		$hora2 = substr($titulo1, 0, 5);
		$hora2 = str_replace('h', ':', $hora2);

		$horacorreta1 = explode(':', $hora2);
		$horacorreta1 = $horacorreta1[0];
		$horacorreta2 = explode(':', $horanow);
		$horacorreta2 = $horacorreta2[0];
 
		if($horacorreta1 < $horacorreta2){
			$datanow = date('Y-m-d', strtotime(' +1 day',strtotime($datanow. ' '. $timezone)));
		}
		$timest2 = $datanow.' '.$hora2;
		$timest2 = strtotime($timest2. ' '. $timezone);
		
	
		$match = array();
		preg_match_all("/\/programacao\/programa\/[0-9]+/",$arq,$match);
		$i = 1;
		foreach($match[0] as $value)
		{
			if($i < 3)
			{
				if($pro >= 1)
				{
        			$conteudo = file_get_contents("http://www.meuguia.tv" . $value, false, $context);
        		}
				else
				{
	    			$conteudo = file_get_contents("http://www.meuguia.tv" . $value);
        		}
		
				${"titulo".$i} = entre_string($conteudo,'<span class="tit">','</span>');
		
				${"texto".$i} = entre_string($conteudo,'<span class="texto">','</span>');
				${"texto".$i} = preg_replace ('/<[^>]*>/', ' ', ${"texto".$i});
				${"texto".$i} =  preg_replace('<script type="text/javascript">', "", ${"texto".$i});
        		${"texto".$i} =  str_replace('document.write(str.replace(".tvp.", ""));', "", ${"texto".$i});
				${"texto".$i} =  str_replace('";', "", ${"texto".$i});
				${"texto".$i} =  str_replace('var str="', "", ${"texto".$i});
        		${"texto".$i} =  str_replace("\n", "", trim(${"texto".$i}));
		
				${"direcao".$i} = entre_string($conteudo,'<span class="texto2">','</span>');
				${"direcao".$i} = str_replace('<strong>Compartilhe:</strong>', "", ${"direcao".$i});
		
				${"elenco".$i} = entre_string2($conteudo,'texto2');
				${"elenco".$i} = str_replace('<strong>Compartilhe:</strong>', "", ${"elenco".$i});
		
				${"small_data".$i} = entre_string($conteudo,'<span class="small_data">','</span>');

				${"small_data".$i} = trim(${"small_data".$i});
        		${"small_data".$i} =  str_replace('<strong>Compartilhe:</strong>', "", ${"small_data".$i});
			}
			$i++;
		}

		$id = mysql_real_escape_string($id);
		$titulofull= mysql_real_escape_string($titulo1);
		$titulofull1= mysql_real_escape_string($titulo2);
		$direc= mysql_real_escape_string($direcao1);
		$direc2= mysql_real_escape_string($elenco1);
		$direc1= mysql_real_escape_string($direcao2);
		$direc21= mysql_real_escape_string($elenco2);
		$hora= mysql_real_escape_string($hora);
		$hora2= mysql_real_escape_string($hora2);
		$timest2= mysql_real_escape_string($timest2);
		$resumo= mysql_real_escape_string($texto1);
		$resumo1= mysql_real_escape_string($texto2);
		$small_data= mysql_real_escape_string($small_data1);
		$small_data1= mysql_real_escape_string($small_data2);

		$result = mysql_query("UPDATE dados_beta SET titulo='$titulofull', titulo2='$titulofull1', `direc`='$direc', `direc2`='$direc2', `direc1`='$direc1', `direc22`='$direc21', `hora`='$hora', `hora2`='$hora2', `timest`='$timest2', `resumo`='$resumo', `resumo2`='$resumo1', `small_data`='$small_data', `small_data2`='$small_data1' WHERE (ID=$id or categoria='$categoria')");

		if (!$result)
		{
    		echo mysql_errno() . ": " . mysql_error() . "\n";
    		die();
		}
		echo $id.'<br>';
	}
}

$sql1 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' AND trim(coalesce(prog, '')) ='' AND trim(coalesce(timest, '')) <>''");
while ($dados2 = mysql_fetch_array($sql1))
{
	$id2 = $dados2['ID'];
	$categoria2 = $dados2['nome_foto'];
	mysql_query("UPDATE dados_beta SET titulo='', titulo2='', `direc`='', `direc2`='', `direc1`='', `direc22`='', `hora`='', `hora2`='', `timest`='', `resumo`='', `resumo2`='', `small_data`='', `small_data2`='' WHERE (ID=$id2 or categoria='$categoria2')");
}
?>