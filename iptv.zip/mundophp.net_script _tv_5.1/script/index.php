<?php
require_once('painel/comfig.php'); ?>
<?php
session_start();

//verifica�ao vip
if (!isset($_SESSION['user_id']) && !isset($_SESSION['user_name']) ){
if(isset($_COOKIE['user_id']) && isset($_COOKIE['user_key'])){
	/* we double check cookie expiry time against stored in database */
	
	$cookie_user_id  = filter($_COOKIE['user_id']);
	$rs_ctime = mysql_query("select `ckey`,`ctime` from `users` where `id` ='$cookie_user_id'") or die(mysql_error());
	list($ckey,$ctime) = mysql_fetch_row($rs_ctime);
	// coookie expiry
	if( (time() - $ctime) > 60*60*24*COOKIE_TIME_OUT) {

		logout();
		}
/* Security check with untrusted cookies - dont trust value stored in cookie. 		
/* We also do authentication check of the `ckey` stored in cookie matches that stored in database during login*/

	 if( !empty($ckey) && is_numeric($_COOKIE['user_id']) && isUserID($_COOKIE['user_name']) && $_COOKIE['user_key'] == sha1($ckey)  ) {
	 	  session_regenerate_id(); //against session fixation attacks.
	
		  $_SESSION['user_id'] = $_COOKIE['user_id'];
		  $_SESSION['user_name'] = $_COOKIE['user_name'];
		/* query user level from database instead of storing in cookies */	
		  list($user_level) = mysql_fetch_row(mysql_query("select user_level from users where id='$_SESSION[user_id]'"));

		  $_SESSION['user_level'] = $user_level;
		  $_SESSION['HTTP_USER_AGENT'] = md5($_SERVER['HTTP_USER_AGENT']);
		  
		  $session_id=session_id();
		  $id = $_SESSION['user_id'];
          $savsessionquery="INSERT INTO users_sessions (id, session_id) VALUES ('".$id."', '".$session_id."') ON DUPLICATE KEY UPDATE session_id='".$session_id."'";
          $savesessionresult=mysql_query($savsessionquery);
		  
	   }

  }
}
if(isset($_SESSION['user_id']) && isset($_SESSION['user_name'])){
page_protect();

$user_id = $_SESSION['user_id'];
$boas_vindas = mysql_query("SELECT id, vencimento, data FROM users WHERE id = '$user_id'")
or die(mysql_error());
if(@mysql_num_rows($boas_vindas) <= '0') 
echo "Erro ao selecionar o usuário";
else{
while($res_boas_vindas=mysql_fetch_array($boas_vindas)){
$vencimento = $res_boas_vindas[1];
$data = $res_boas_vindas[2];


$dataI= date('Y/m/d');
$I= strtotime($dataI);
$dataII= $vencimento;
$II= strtotime($dataII);
$dataIII= $data;
$III= strtotime($dataIII);


// Define os valores a serem usados
$data_inicial = $data;
$data_final = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial = strtotime($data_inicial);
$time_final = strtotime($data_final);

// Calcula a diferença de segundos entre as duas datas:
$diferenca = $time_final - $time_inicial; // 19522800 segundos

// Calcula a diferença de dias
$dias = (int)floor( $diferenca / (60 * 60 * 24)); // 225 dias


// Define os valores a serem usados
$data_inicial1 = $dataI;
$data_final1 = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial1 = strtotime($data_inicial1);
$time_final1 = strtotime($data_final1);

// Calcula a diferença de segundos entre as duas datas:
$diferenca1 = $time_final1 - $time_inicial1; // 19522800 segundos

// Calcula a diferença de dias
$dias1 = (int)floor( $diferenca1 / (60 * 60 * 24)); // 225 dias

$porc = $dias+0.000001;
$valor = $dias1;
$resul = $valor/$porc;
$fim = $resul*100;

if ($I >= $II){ 
page_protect();
$separar = 'n';
$linkvip = 'nome_foto';
$vip = 'nao';
}else{
page_protect();
$separar = 's';
$linkvip = 'linkvip';
$vip = 'sim';
}
}
}
}else{
$separar = 'n';
$linkvip = 'nome_foto';
}
//fim verifica�ao vip

$site = $siteurl.'/';
$site2 = $siteurl.'/index.php';
if(($site == $siteurlb ) or ($site2 == $siteurlb )){
}else{
header("HTTP/1.1 301 Moved Permanently");
header("Location: $site");
exit();
}

mysql_select_db($database_comfig, $link);
$query_horarios = "SELECT * FROM horarios";
$horarios = mysql_query($query_horarios, $link) or die(mysql_error());
$row_horarios = mysql_fetch_assoc($horarios);
$totalRows24784_horarios = mysql_num_rows($horarios);

$checar12451 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' ORDER BY ID DESC");
while($res12451 = mysql_fetch_array($checar12451)){
$confere1 = mysql_query("SELECT * from dados_beta WHERE categoria='".$res12451['nome_foto']."' AND ligar='s' AND (vip = '$separar' or vip = 'na') AND lugar='canais' LIMIT 1");
$result12451 = mysql_num_rows($confere1);
if($result12451 == 1){
if(!isset($conta)){
$conta = 'ID = '.$res12451['ID'];
}else{
$conta = $conta.' OR ID = '.$res12451['ID'];
}}}
if(isset($conta)){
$or = '('.$conta.') or ';
}

$checar1245 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' AND ligar = 'n' ORDER BY ID DESC");
while($res1245 = mysql_fetch_array($checar1245)){
$confere = mysql_query("SELECT * from dados_beta WHERE categoria='".$res1245['nome_foto']."' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') AND lugar='canais' LIMIT 1");
$result1245 = mysql_num_rows($confere);
if($result1245 == 0){
if(!isset($naoconta)){
$naoconta = 'AND ID !='.$res1245['ID'];
}else{
$naoconta = $naoconta.' AND ID !='.$res1245['ID'];
}}}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//pt-br" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $configuracoes['title']; ?></title>
<meta name="keywords" content="<?php echo $configuracoes['keywords']; ?>" />
<meta name="description" content="<?php echo $configuracoes['description']; ?>" />
<meta http-equiv="content-language" content="pt-br"/>
<link rel="canonical" href="<?php echo $siteurl; ?>/" />
<meta property='og:locale' content='pt_BR'/>
<meta property='og:type' content='website'/>
<meta property='og:title' content='<?php echo $configuracoes['title']; ?>'/>
<meta property='og:url' content='<?php echo $siteurl; ?>/'/>
<link href="css/templatemo_style.css" rel="stylesheet" type="text/css" />
<!-- jQuery -->
<script src="js/jquery.js"></script>
<script src="/js/jquery.confirm.js"></script>
<link rel="stylesheet" type="text/css" href="/css/jquery.confirm.css" />
<script>
function mens(title, message)
{
var elem = $(this).closest('.item');
		
		$.confirm({
			'title'		: title,
			'message'	: message,
			'buttons'	: {
				'Ok'	: {
					'class'	: 'blue',
					'action': function(){
						elem.slideUp();
					}
				}
			}
		});
}
</script>
<script>
function loadDoc()
{
$.post( "/foradoar.php", { id:'n' }, function( data ) {
	if(data.mens != "0"){	  
	  
	  var elem = $(this).closest('.item');
		
		$.confirm({
			'title'		: data.title,
			'message'	: data.mens,
			'buttons'	: {
				'Sim'	: {
					'class'	: 'blue',
					'action': function(){
						elem.slideUp();
						$.post( "/foradoar.php", { id:data.id }, function( data ) {
		                mens(data.title, data.mens);
						}, "json");
					}
				},
				'N�o'	: {
					'class'	: 'gray',
					'action': function(){}	// Nothing to do in this case. You can as well omit the action property.
				}
			}
		});
	  
	}else{
	mens(data.title, data.mens2);
	}
    }, "json");
}
</script>
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

        <!-- liteAccordion css -->
        <link href="css/liteaccordion.css" rel="stylesheet" />

        <!-- easing -->
        <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>

        <!-- liteAccordion js -->
        <script type="text/javascript" src="js/liteaccordion.jquery.js"></script>
		
		<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css" />
        <link rel="stylesheet" type="text/css" href="css/jquery.fancybox-buttons.css"  />
        <script type="text/javascript" src="js/jquery.fancybox.js"></script>
        <script type="text/javascript" src="js/jquery.fancybox-buttons.js"></script>

</head>
<body id="home">
<script type="text/javascript">
if (parent !== self) {
    parent.top.location = location;
}
 </script>
<div id="templatemo_wrapper">
	<div id="templatemo_top">
	
    	<div id="templatemo_login">
            <? if (!isset($vip)){ ?>
			<form action="painel/login.php" method="post" name="logForm" id="logForm">
              <input type="text" value="Usuario" name="usr_email" id="logar" size="10" title="username" onFocus="clearText(this)" onBlur="clearText(this)" class="txt_field" />
              <input type="password" value="password" name="pwd" id="senha" size="10" title="password" onFocus="clearText(this)" onBlur="clearText(this)" class="txt_field" />
			  <input name="remember" type="hidden" id="remember" value="1" checked="checked">
			  <input class="sub_btn" name="doLogin" type="submit" id="doLogin3" value="Login" >
            </form>
			<? } ?>
			<? if (isset($vip)){ ?>
			<a href="painel/index.php">Painel usu�rio</a> | <a href="painel/index.php">Renovar acesso</a> | <a href="painel/logout.php">[<? echo $_SESSION['user_name']; ?>] Sair</a>
			<? } ?>
		</div>
    </div> <!-- end of top -->
    
  	<div id="templatemo_header">
    	<div id="site_title"><h1><a href="<?php
echo"$siteurl";
?>"><?php echo $configuracoes['h1']; ?></a></h1></div>
        <div id="templatemo_menu" class="ddsmoothmenu">
            <ul>
<li><a target="_top" href='/'>Inicio</a></li>
<?
$sql458 = "SELECT * FROM dados_beta WHERE lugar LIKE 'menu' AND ligar LIKE 's' AND (vip = '$separar' or vip LIKE 'na') ORDER BY ID ASC";
                    $query458 = mysql_query($sql458);
                    while($sql458 = mysql_fetch_array($query458)){
					$count = mb_strlen( $sql458['nome_do_canal'] );
					$i = $count + $i + 6;
					if($i < 95){
					echo '<li><a target="canaisbox" href="tv/'.$sql458[$linkvip].'">'.$sql458['nome_do_canal'].'</a></li>';
					}else{
					$i = $i - ($count + 6);
					}
                    //onde $tempo � a variavel que rerpresenta a coluna "tempo" nessa
                    //mesma tabela.
                    }
 ?>
<li><a target="_top" href='/contato.php'>Contato</a></li></ul>
            <br style="clear: left" />
        </div> <!-- end of templatemo_menu -->
    </div> 
  	<!-- end of header -->
	    <div id="three">
            <? require_once('menu.php'); ?>
            <noscript>
                <p>Ative o JavaScript para ter a experi�ncia completa.</p>
            </noscript>
        </div>
  <p>Menu:
            <a class="links" href="#variedades">Variedades/Abertos</a><a class="links"> | </a>
            <a class="links" href="#cinema">Cinema/Series</a><a class="links"> | </a>
            <a class="links" href="#esportes">Esportes</a><a class="links"> | </a>
            <a class="links" href="#infantil">Infantil/Desenhos</a><a class="links"> | </a>
            <a class="links" href="#clipes">Clipes/Musicais</a><a class="links"> | </a>
			<a class="links" href="#religiosos">Religiosos</a><a class="links"> | </a>
			<a class="links" href="#documentarios">Document�rios</a><a class="links"> | </a>
			<a class="links" href="#noticias">Not�cias</a></p>
			
  <div style="width:958px; margin-bottom:5px; float:left; background:#353535; border-style:solid; border-width:1px; border-color:#030303; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; padding-top: 4px;"><form action="../../busca.php" target="canaisbox" method="get" accept-charset="UTF-8">
      <input class="busca" id="texto" type="text" onFocus="clearText(this)" onBlur="clearText(this)" value="Busque um canal ou evento ex: futebol" name="palavra" />
      <input onClick="return CollapseExpand()" class="botao" type="submit" value="Buscar"/>
</form>
<button class="botao" type="button" onClick="loadDoc()">O canal n�o pegou? clique aqui para avisar!</button>
<script type="text/javascript">
        $(document).ready(function(){
            $("#shadow").css("height", $(document).height()).hide();
            $(".lightSwitcher").click(function(){
                $("#shadow").toggle();
                if ($("#shadow").is(":hidden"))
                    $(this).html("Desligar luz").removeClass("turnedOff");
                 else
                    $(this).html("Ligar luz").addClass("turnedOff");
            });
            
        });
    </script>
	<a class="lightSwitcher" style="position:relative; z-index:102;">Desligar luz</a>
</div>
<div id="MyDiv1" class="divVisible1" align="center" style="position:relative; z-index:103;">
  <div style="float:left; margin-right:2px; height:435px; width:468px;">
<?php $hr = date(" H ");
  
     if($hr >= 0 && $hr<1) {  
          $resp1548 = $row_horarios['0'];  
  
     }
	 if($hr >= 1 && $hr<2) {  
          $resp1548 = $row_horarios['1'];  
  
     }
	 if($hr >= 2 && $hr<3) {  
          $resp1548 = $row_horarios['2'];  
  
     }
	 if($hr >= 3 && $hr<4) {  
          $resp1548 = $row_horarios['3'];  
  
     }
	 if($hr >= 4 && $hr<5) {  
          $resp1548 = $row_horarios['4'];  
  
     }
	 if($hr >= 5 && $hr<6) {  
          $resp1548 = $row_horarios['5'];  
  
     }
	 if($hr >= 6 && $hr<7) {  
          $resp1548 = $row_horarios['6'];  
  
     }
	 if($hr >= 7 && $hr<8) {  
          $resp1548 = $row_horarios['7'];  
  
     }
	 if($hr >= 8 && $hr<9) {  
          $resp1548 = $row_horarios['8'];  
  
     }
	 if($hr >= 9 && $hr<10) {  
          $resp1548 = $row_horarios['9'];  
  
     }
	 if($hr >= 10 && $hr<11) {  
          $resp1548 = $row_horarios['10'];  
  
     }
	 if($hr >= 11 && $hr<12) {  
          $resp1548 = $row_horarios['11'];  
  
     }
	 if($hr >= 12 && $hr<13) {  
          $resp1548 = $row_horarios['12'];  
  
     }
	 if($hr >= 13 && $hr<14) {  
          $resp1548 = $row_horarios['13'];  
  
     }
	 if($hr >= 14 && $hr<15) {  
          $resp1548 = $row_horarios['14'];  
  
     }
	 if($hr >= 15 && $hr<16) {  
          $resp1548 = $row_horarios['15'];  
  
     }
	 if($hr >= 16 && $hr<17) {  
          $resp1548 = $row_horarios['16'];  
  
     }
	 if($hr >= 17 && $hr<18) {  
          $resp1548 = $row_horarios['17'];  
  
     }
	 if($hr >= 18 && $hr<19) {  
          $resp1548 = $row_horarios['18'];  
  
     }
	 if($hr >= 19 && $hr<20) {  
          $resp1548 = $row_horarios['19'];  
  
     }
	 if($hr >= 20 && $hr<21) {  
          $resp1548 = $row_horarios['20'];  
  
     }
	 if($hr >= 21 && $hr<22) {  

          $resp1548 = $row_horarios['21'];  
  
     }
	 if($hr >= 22 && $hr<23) {  
          $resp1548 = $row_horarios['22'];  
  
     }
	 if($hr >= 23 && $hr<24) {  
          $resp1548 = $row_horarios['23'];  
  
     }
	 
         if($resp1548 == 1 ) {  
              $resp = "variedades";  
         }
		 if ($resp1548 == 2 ){  
              $resp = "cinema";  
         }
		 if ($resp1548 == 3 ){  
              $resp = "esportes";  
         }
		 if ($resp1548 == 4 ){  
              $resp = "infantil";  
         }
		 if ($resp1548 == 5 ){  
              $resp = "clipes";  
         }
		 if ($resp1548 == 6 ){  
              $resp = "religiosos";  
         }
		 if ($resp1548 == 7 ){  
              $resp = "documentarios";  
         }
		 if ($resp1548 == 8 ){  
              $resp = "noticias";  
         }

	 ?>
<iframe height="435px" width="468px" frameborder="0" id="canaisbox" name="canaisbox" scrolling="no" src="<?php
 if($row_horarios['tipo'] == 1){
 if($row_horarios['tipo'] == 1 && $separar == s){
		$r48 = $row_horarios['cvip'];
	}
 if($row_horarios['tipo'] == 1 && $separar == n){
		$r48 = $row_horarios['caberto'];
	}
	
$query_canailexiste = mysql_query("SELECT * FROM dados_beta WHERE (nome_foto = '".$r48."' or linkvip = '".$r48."') AND ligar='s' AND tipo!='swf' AND lugar='canais' AND (vip='$separar' or vip='na')  LIMIT 1");
$canailexiste = mysql_num_rows($query_canailexiste);

 if($row_horarios['tipo'] == 1 && $separar == s && $canailexiste > 0){
		$string1 = $siteurl.'/tv/'.$row_horarios['cvip'].'&play=1';
		$resp1548 = $row_horarios['catcvip'];
	}
 if($row_horarios['tipo'] == 1 && $separar == n && $canailexiste > 0){
		$string1 = $siteurl.'/tv/'.$row_horarios['caberto'].'&play=1';
		$resp1548 = $row_horarios['catcaberto'];
	}
	}
 if(($row_horarios['tipo'] == 2) or (!isset($canailexiste)) or ($canailexiste < 1)){
		$query_canais1223= sprintf("SELECT * FROM dados_beta WHERE categoria='$resp' AND ligar='s' AND tipo!='swf' AND lugar='canais' AND (vip='$separar' or vip='na') ORDER BY RAND() LIMIT 1");
        $canais1223 = mysql_query($query_canais1223) or die(mysql_error());
        $row_canais1223 = mysql_fetch_assoc($canais1223);
		$row_canais1223num_rows = mysql_num_rows($canais1223);
		if($row_canais1223num_rows > 0){
		$string1 = $siteurl.'/tv/'.$row_canais1223[$linkvip].'&play=1';
		}
	}

$string1 = str_replace("/tv/", "/frame/", $string1);
for( $i = 0 ; $i < strlen ( $string1 );++ $i ){
$n = rand ( 0 , 1 );
if( $n )
$finished1 .= '&#x' . sprintf ( "%X" , ord ( $string1 { $i })). ';' ;
else
$finished1 .= '&#' . ord ( $string1 { $i }). ';' ;
}
echo $finished1;
?>"></iframe>
	</div>
  <div style="float:right; width:490px; height:435px;">
  <embed bgcolor="#000000" src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="490" height="435" name="chat" flashvars="id=<?php echo $configuracoes['chat']; ?>&amp;rl=Brazilian" align="middle" allowscriptaccess="sameDomain" wmode="transparent" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.shtml">  </div>
  </div>
<script>
                $('#three').liteAccordion({ firstSlide : <?php echo  "$resp1548"; ?>, containerHeight : <?php 
	 $colunas = ceil(max(array($variedades, $cinema, $esportes, $infantil, $clipes, $religiosos, $documentarios, $noticias)) / 7);
	 $colunas = ($colunas * 55) - 5;
	 if($colunas < 270){ $colunas = 270;}
	 echo $colunas;
	 ?>});
            </script>

    <!-- end of templatemo_middle -->
    <? if ($vip != 'sim'){ ?>
    <div id="templatemo_main">
    	<div class="col_fw">
    	  <div class="col_w240 col_last" style="position:relative; z-index:103;">
		 <?php if(!empty($configuracoes['728x90'])) { echo $configuracoes['728x90']; } ?>
          </div>
            <div class="cleaner"></div>
        </div>
        
        <div class="col_fw_last">
       	  <div class="col_allw300">
            	<h3>Noticias</h3>
				 
  <?php
  function load_file($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    # ignore header
    curl_setopt($ch, CURLOPT_HEADER, false);
    # Return http response in string
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $xml = @simplexml_load_string(curl_exec($ch));
    return $xml;
  }
   
  $feedurl = $configuracoes['noticias'];
  $rss = load_file($feedurl);
   
  foreach ($rss->channel->item as $item) {
    print '<div class="news_box">
                        <p>' .
    utf8_decode($item->title) . '</p>';
    print '<a  href="' . urldecode($item->link) .  '" target="_blank"> Ver Noticia</a></div>
    ';
    $contador ++;
    if ($contador >= 4)
    break;
  }
?> 
          </div>
          <div class="col_allw300">
            	<h3>Facebook</h3>
				
				<iframe src="//www.facebook.com/plugins/likebox.php?href=<?php echo $configuracoes['facebook']; ?>&amp;width=300&amp;height=335&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:300px; height:335px;" allowTransparency="true"></iframe>

          </div>
            <div class="col_allw300 col_rm">
            	<h3>Twitter</h3>
				
<a class="twitter-timeline" width="300" height="313" href="https://twitter.com/<?php echo $configuracoes['twitter']; ?>" data-tweet-limit="3" data-widget-id="<?php echo $configuracoes['twitterid']; ?>"  data-chrome="transparent noborders noscrollbar nofooter noheader" ></a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
				
				
          	</div>
        </div>
        <div class="cleaner"></div>
  </div> <!-- end of main -->
  <? } ?>
</div> <!-- end of wrapper -->
<div id="templatemo_footer_wrapper2">
</div>

<div id="templatemo_footer_wrapper">
    <div id="templatemo_footer">
        <?php echo $configuracoes['cop']; ?>
        <div class="cleaner"></div>
    </div>
</div>
<div id="shadow"></div>
<? if(!empty($configuracoes['analytics'])){ ?>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', '<? echo $configuracoes['analytics']; ?>', '<? $parse = parse_url($siteurl);  echo $parse['host'];  ?>');
  ga('send', 'pageview');

</script>
<? } ?>
</body>
</html>