<?php
require_once('../painel/comfig.php'); ?>
<?php
// This is to check if the request is coming from a specific URL
$ref = $_SERVER['HTTP_REFERER'];
$parse = parse_url($ref);
$ref = 'http://'.$parse['host'];

if($ref !== $siteurl) {
  die("para continuar desenbaralhe as letras e coloque na url o-ri-o-ta");
}
?>
<style>
/* A full-screen element that is not the root element should be stretched to cover the viewport. */
:-webkit-full-screen:not(:root) {
  width: 100% !important;
  float: none !important;
}
:-webkit-full-screen:not .tohide2 {
  display: none;
}
:-moz-full-screen:not .tohide2 {
  display: none;
}
:-webkit-full-screen video {
  width: 100%;
}
:-webkit-full-screen .tohide {
  display: none;
}
:-moz-full-screen:not(:root) {
  width: 100% !important;
  float: none !important;
}
:-moz-full-screen #fs-inner {
  display: table-cell;
  vertical-align: middle;
  vertical-align:top;
}
:-moz-full-screen #fs {
  width: 100%;
  margin: auto;
}
#fs:-webkit-full-screen {
background:#000000;
}
:-moz-full-screen video {
  width: 100%;
}
:-moz-full-screen .tohide {
  display: none;
}
#fs-container:-moz-full-screen {
  display: table;
  margin: auto;
  float: none;
  width: 100%;
  height: 100%;
}
#fs {
  width: 100%;
  text-align: center;
  display: -webkit-box;
  -webkit-box-orient: vertical;
}
#fs div:first-of-type {
  text-transform: uppercase;
}
button {
  display: inline-block;
  background: -webkit-gradient(linear, 0% 40%, 0% 70%, from(#F9F9F9), to(#E3E3E3));
  background: -webkit-linear-gradient(#F9F9F9 40%, #E3E3E3 70%);
  background: -moz-linear-gradient(#F9F9F9 40%, #E3E3E3 70%);
  background: -ms-linear-gradient(#F9F9F9 40%, #E3E3E3 70%);
  background: -o-linear-gradient(#F9F9F9 40%, #E3E3E3 70%);
  background: linear-gradient(#F9F9F9 40%, #E3E3E3 70%);
  border: 1px solid #999;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  padding: 5px 8px;
  outline: none;
  white-space: nowrap;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  cursor: pointer;
  text-shadow: 1px 1px #fff;
  font-weight: 700;
  font-size: 10pt;
}
button:hover {
  border-color: black;
}
button:active {
  background: -webkit-gradient(linear, 0% 40%, 0% 70%, from(#E3E3E3), to(#F9F9F9));
  background: -webkit-linear-gradient(#E3E3E3 40%, #F9F9F9 70%);
  background: -moz-linear-gradient(#E3E3E3 40%, #F9F9F9 70%);
  background: -ms-linear-gradient(#E3E3E3 40%, #F9F9F9 70%);
  background: -o-linear-gradient(#E3E3E3 40%, #F9F9F9 70%);
  background: linear-gradient(#E3E3E3 40%, #F9F9F9 70%);
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
</style>

<div id="fs-container">
  <div id="fs-inner">
    <div id="fs">
      <iframe id="div_SomeDivYouWantToAdjust" src="<? $id = $_GET['id']; $id = strip_tags(mysql_real_escape_string($id)); echo base64_decode ($id); ?>" width="100%" scrolling="no" frameborder="0" allowfullscreen webkitallowfullscreen mozallowfullscreen></iframe>
      <div align="right"><button id="enter-exit-fs" onClick="enterFullscreen()"><small class="tohide"></small> <small class="tohide2">Tela cheia |X|</small></button></div>
    </div>
  </div>
</div>

<script type="text/javascript">
$(window).ready(function() {
						   
$('#div_SomeDivYouWantToAdjust').css('height', ($(window).height()- 60)+'px');
$('#fs-container').css('width', ($(window).width()-30)+'px');
$('.fancybox-inner').css('overflow', 'hidden');

});
$(window).resize(function() {
						   
$('#div_SomeDivYouWantToAdjust').css('height', ($(window).height()- 60)+'px');
$('#fs-container').css('width', ($(window).width()-30)+'px');
$('.fancybox-inner').css('overflow', 'hidden');
	
});
$(window).resize(function() {
						   
$(':-moz-full-screen #div_SomeDivYouWantToAdjust').css('height', ($(window).height()- 30)+'px');
$(':-webkit-full-screen #div_SomeDivYouWantToAdjust').css('height', ($(window).height()- 30)+'px');
	
});
</script>
<script>

document.cancelFullScreen = document.webkitExitFullscreen || document.mozCancelFullScreen || document.exitFullscreen;

var elem = document.querySelector(document.webkitExitFullscreen ? "#fs" : "#fs-container");

document.addEventListener('keydown', function(e) {
  switch (e.keyCode) {
    case 13: // ENTER. ESC should also take you out of fullscreen by default.
      e.preventDefault();
      document.cancelFullScreen(); // explicitly go out of fs.
      break;
    case 70: // f
      enterFullscreen();
      break;
  }
}, false);

function toggleFS(el) {
  if (el.webkitEnterFullScreen) {
    el.webkitEnterFullScreen();
  } else {
    if (el.mozRequestFullScreen) {
      el.mozRequestFullScreen();
    } else {
      el.requestFullscreen();
    }
  }

  el.ondblclick = exitFullscreen;
}

function onFullScreenEnter() {
  console.log("Entered fullscreen!");
  elem.onwebkitfullscreenchange = onFullScreenExit;
  elem.onmozfullscreenchange = onFullScreenExit;
};

// Called whenever the browser exits fullscreen.
function onFullScreenExit() {
  console.log("Exited fullscreen!");
};

// Note: FF nightly needs about:config full-screen-api.enabled set to true.
function enterFullscreen() {
  console.log("enterFullscreen()");
  elem.onwebkitfullscreenchange = onFullScreenEnter;
  elem.onmozfullscreenchange = onFullScreenEnter;
  elem.onfullscreenchange = onFullScreenEnter;
  if (elem.webkitRequestFullscreen) {
    elem.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
  } else {
    if (elem.mozRequestFullScreen) {
      elem.mozRequestFullScreen();
    } else {
      elem.requestFullscreen();
    }
  }
  document.getElementById('enter-exit-fs').onclick = exitFullscreen;
}

function exitFullscreen() {
  console.log("exitFullscreen()");
  document.cancelFullScreen();
  document.getElementById('enter-exit-fs').onclick = enterFullscreen;
}
</script>