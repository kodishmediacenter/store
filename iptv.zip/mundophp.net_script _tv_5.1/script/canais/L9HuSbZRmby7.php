<?php
require_once('../painel/comfig.php'); ?>
<?
error_reporting(0);
ini_set('display_errors', 0 );
session_start();
//verifica�ao vip
if (!isset($_SESSION['user_id']) && !isset($_SESSION['user_name']) ){
if(isset($_COOKIE['user_id']) && isset($_COOKIE['user_key'])){
	/* we double check cookie expiry time against stored in database */
	
	$cookie_user_id  = filter($_COOKIE['user_id']);
	$rs_ctime = mysql_query("select `ckey`,`ctime` from `users` where `id` ='$cookie_user_id'") or die(mysql_error());
	list($ckey,$ctime) = mysql_fetch_row($rs_ctime);
	// coookie expiry
	if( (time() - $ctime) > 60*60*24*COOKIE_TIME_OUT) {

		logout();
		}
/* Security check with untrusted cookies - dont trust value stored in cookie. 		
/* We also do authentication check of the `ckey` stored in cookie matches that stored in database during login*/

	 if( !empty($ckey) && is_numeric($_COOKIE['user_id']) && isUserID($_COOKIE['user_name']) && $_COOKIE['user_key'] == sha1($ckey)  ) {
	 	  session_regenerate_id(); //against session fixation attacks.
		  
		  $_SESSION['user_id'] = $_COOKIE['user_id'];
		  $_SESSION['user_name'] = $_COOKIE['user_name'];
		/* query user level from database instead of storing in cookies */	
		  list($user_level) = mysql_fetch_row(mysql_query("select user_level from users where id='$_SESSION[user_id]'"));

		  $_SESSION['user_level'] = $user_level;
		  $_SESSION['HTTP_USER_AGENT'] = md5($_SERVER['HTTP_USER_AGENT']);
		  
		  $session_id=session_id();
		  $id = $_SESSION['user_id'];
          $savsessionquery="INSERT INTO users_sessions (id, session_id) VALUES ('".$id."', '".$session_id."') ON DUPLICATE KEY UPDATE session_id='".$session_id."'";
          $savesessionresult=mysql_query($savsessionquery);
		  
	   }

  }
}
if(isset($_SESSION['user_id']) && isset($_SESSION['user_name'])){
page_protect();

$user_id = $_SESSION['user_id'];
$boas_vindas = mysql_query("SELECT id, vencimento, data FROM users WHERE id = '$user_id'")
or die(mysql_error());
if(@mysql_num_rows($boas_vindas) <= '0') 
echo "Erro ao selecionar o usuário";
else{
while($res_boas_vindas=mysql_fetch_array($boas_vindas)){
$vencimento = $res_boas_vindas[1];
$data = $res_boas_vindas[2];


$dataI= date('Y/m/d');
$I= strtotime($dataI);
$dataII= $vencimento;
$II= strtotime($dataII);
$dataIII= $data;
$III= strtotime($dataIII);


// Define os valores a serem usados
$data_inicial = $data;
$data_final = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial = strtotime($data_inicial);
$time_final = strtotime($data_final);

// Calcula a diferença de segundos entre as duas datas:
$diferenca = $time_final - $time_inicial; // 19522800 segundos

// Calcula a diferença de dias
$dias = (int)floor( $diferenca / (60 * 60 * 24)); // 225 dias


// Define os valores a serem usados
$data_inicial1 = $dataI;
$data_final1 = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial1 = strtotime($data_inicial1);
$time_final1 = strtotime($data_final1);

// Calcula a diferença de segundos entre as duas datas:
$diferenca1 = $time_final1 - $time_inicial1; // 19522800 segundos

// Calcula a diferença de dias
$dias1 = (int)floor( $diferenca1 / (60 * 60 * 24)); // 225 dias

$porc = $dias+0.000001;
$valor = $dias1;
$resul = $valor/$porc;
$fim = $resul*100;

if ($I >= $II){ 
page_protect();
$separar = 'n';
$linkvip = 'nome_foto';
$vip = 'nao';
}else{
page_protect();
$separar = 's';
$linkvip = 'linkvip';
$vip = 'sim';
}
}
}
}else{
$separar = 'n';
$linkvip = 'nome_foto';
}
//fim verifica�ao vip
function nomeico($extensao){
 $arquivo1111 = pathinfo($extensao, PATHINFO_EXTENSION);
 if($arquivo1111 == 'jpg'){
 return $file = basename($extensao, ".jpg");
 }
 if($arquivo1111 == 'png'){
 return $file = basename($extensao, ".png");
 }
 if($arquivo1111 == 'gif'){
 return $file = basename($extensao, ".gif");
 }
}
function linkico($vip, $link){
global $siteurl;
if($vip==s){ return $siteurl.'/icones/pequeno/vip/'.nomeico($link).'.jpeg';}
if($vip==n){ return $siteurl.'/icones/pequeno/aberto/'.nomeico($link).'.jpeg';}
if($vip==na){ return $siteurl.'/icones/pequeno/aberto/'.nomeico($link).'.jpeg';}
}
function linkicogrande($vip, $link){
global $siteurl;
if($vip==s){ return $siteurl.'/icones/grande/vip/'.nomeico($link).'.jpeg';}
if($vip==n){ return $siteurl.'/icones/grande/aberto/'.nomeico($link).'.jpeg';}
if($vip==na){ return $siteurl.'/icones/grande/aberto/'.nomeico($link).'.jpeg';}
}

$url = $_SERVER[HTTP_REFERER];
$refer = parse_url($url);
$refer = 'http://'.$refer['host'];
$refer2 = parse_url($url);
$refer2 = $refer2['path'];
if(!isset($refer2)){
$refer2 = '/';
}
$refer3 = dirname($url);
 ?>
<?php
ob_start();

mysql_select_db($database_comfig, $link);
$query_horarios = "SELECT * FROM horarios";
$horarios = mysql_query($query_horarios, $link) or die(mysql_error());
$row_horarios = mysql_fetch_assoc($horarios);
$totalRows46852_horarios = mysql_num_rows($horarios);

if (isset($_GET['ID'])) {
  $colname_canais = strip_tags(mysql_real_escape_string($_GET['ID']));
}

$checar = mysql_query("SELECT * FROM dados_beta WHERE (lugar='canais' OR lugar='menu') AND ligar LIKE 's' AND $linkvip LIKE '$colname_canais' AND (vip = '$separar' or vip LIKE 'na')");
$result = mysql_num_rows($checar);
if($result==1) {
   $col_canais = strip_tags(mysql_real_escape_string($_GET['ID']));
}
else {
$che = mysql_query("SELECT * FROM dados_beta WHERE lugar='canais' AND ligar = 's' AND (categoria = '$colname_canais') AND (vip = '$separar' or vip = 'na')");
$row_ch = mysql_fetch_assoc($che);
$result5 = mysql_num_rows($che);
if($result5>0) {
$redir1 = $siteurl.'/tv/'.$row_ch[$linkvip];
header("Location: $redir1");
exit();
}
if($result5<=0) {
$redir1 = $siteurl;
header("Location: $redir1");
exit();
}
}

$query_canais = sprintf("SELECT * FROM dados_beta WHERE $linkvip LIKE '$colname_canais' LIMIT 1");
$canais = mysql_query($query_canais) or die(mysql_error());
$row_canais = mysql_fetch_assoc($canais);

$checar12451 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' ORDER BY ID DESC");
while($res12451 = mysql_fetch_array($checar12451)){
$confere1 = mysql_query("SELECT * from dados_beta WHERE categoria='".$res12451['nome_foto']."' AND ligar='s' AND (vip = '$separar' or vip = 'na') AND lugar='canais' LIMIT 1");
$result12451 = mysql_num_rows($confere1);
if($result12451 == 1){
if(!isset($conta)){
$conta = 'ID = '.$res12451['ID'];
}else{
$conta = $conta.' OR ID = '.$res12451['ID'];
}}}
if(isset($conta)){
$or = '('.$conta.') or ';
}

$checar1245 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' AND ligar = 'n' ORDER BY ID DESC");
while($res1245 = mysql_fetch_array($checar1245)){
$confere = mysql_query("SELECT * from dados_beta WHERE categoria='".$res1245['nome_foto']."' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') AND lugar='canais' LIMIT 1");
$result1245 = mysql_num_rows($confere);
if($result1245 == 0){
if(!isset($naoconta)){
$naoconta = 'AND ID !='.$res1245['ID'];
}else{
$naoconta = $naoconta.' AND ID !='.$res1245['ID'];
}}}

// Javascript/HTML hex encode
function encode($input)
{
    $temp = '';
    $length = strlen($input);
    for($i = 0; $i < $length; $i++)
        $temp .= '%' . bin2hex($input[$i]);
    return $temp;
}
?>
<?php

	                $titulofull = $row_canais['titulo'];
                    $resumo = $row_canais['resumo'];
                    $small_data = $row_canais['small_data'];
                    $direc = $row_canais['direc'];
                    $direc2 = $row_canais['direc2'];
                    $titulofull1 = $row_canais['titulo2'];
                    $resumo1 = $row_canais['resumo2'];
                    $small_data1 = $row_canais['small_data2'];
                    $direc1 = $row_canais['direc1'];
                    $direc21 = $row_canais['direc22'];
					$hora = $row_canais['hora'];
					$hora2 = $row_canais['hora2'];
?>
<? 
if((($refer3 == $siteurl) && ($refer2 != '/busca.php') && /* coloquei isto para quando entrar na index.php nao redirecionar o iframe >>>>>>>*/($refer2 != '/index.php')) or (($refer3 == $siteurl.'/mover') && ($refer == $siteurl)) or (($refer !== $siteurl)) ){
$sitecanallink = $siteurl.'/tv/'.$colname_canais;
$sitecanallink2 = $siteurl.'/tv/'.$colname_canais.'&play=1';
if(($siteurlb !== $sitecanallink) && ($siteurlb !== $sitecanallink2)){
header("Location: $sitecanallink");
exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//pt-br" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="pt" prefix="og: http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml" xml:lang="pt-br">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title><?php $title = str_replace("%%nome_do_canal%%",$row_canais['nome_do_canal'],$configuracoes['titulocanais']); $title = str_replace("%%nome_do_site%%",$configuracoes['nomedosite'],$title); echo  $title; ?></title>
<meta name="description" content="<?php $descricao = str_replace("%%nome_do_canal%%",$row_canais['nome_do_canal'],$configuracoes['descricao']); $title = str_replace("%%nome_do_site%%",$configuracoes['nomedosite'],$descricao); echo  $descricao; ?>">
<meta name="keywords" content="assistir <?php echo $row_canais['nome_do_canal']; ?> online, ver <?php echo $row_canais['nome_do_canal']; ?> online, assistir <?php echo $row_canais['nome_do_canal']; ?> ao vivo, ver <?php echo $row_canais['nome_do_canal']; ?> ao vivo"/>
<meta http-equiv="content-language" content="pt-br"/> 
<link rel='index' title='Ver <?php echo $row_canais['nome_do_canal']; ?> online' href='<?php echo $siteurl; ?>/tv/<?php echo $row_canais['nome_foto']; ?>' />
<meta name="robots" content="index,follow">

<meta property="og:title" content="<?php echo  $title; ?>"/>
<meta property="og:type" content="article"/>
<meta property="og:url" content="<?php echo $siteurl; ?>/tv/<?php echo $row_canais['nome_foto']; ?>"/>
<meta property="og:image" content="<?php
if($row_canais['form'] == 'opt'){
	$sql4581 = "SELECT * FROM dados_beta WHERE nome_foto='".$row_canais['categoria']."' AND lugar='canais' AND (vip ='$separar' or vip = 'na') LIMIT 1";
                    $query4581 = mysql_query($sql4581);
                    while($sqla4581 = mysql_fetch_array($query4581)){
					if($sqla4581['ligar'] == 'n'){
					$imagem1 = linkicogrande($sqla4581['vip'], $sqla4581['url_do_canal']);
					}
					if($sqla4581['ligar'] == 's'){
					$imagem1 = linkicogrande($sqla4581['vip'], $sqla4581['url_do_canal']);
					}
					}
	}else{
	$imagem1 = linkicogrande($row_canais['vip'], $row_canais['url_do_canal']);
	}
echo $imagem1; ?>"/>
<meta property="og:description" content="Estou assistindo <? if(!empty($titulofull)){echo "&quot;".$titulofull."&quot; no canal ".$row_canais['nome_do_canal'].', veja ao vivo gratis no site';} else {echo $row_canais['nome_do_canal'];} ?> <?php echo $siteurl; ?>/tv/<?php echo $row_canais['nome_foto']; ?>"/>

<link href="/css/templatemo_style.css" rel="stylesheet" type="text/css" />
<!-- jQuery -->
<script src="/js/jquery.js"></script>
<script src="/js/jquery.confirm.js"></script>
<link rel="stylesheet" type="text/css" href="/css/jquery.confirm.css" />
<script>
function mens(title, message)
{
var elem = $(this).closest('.item');
		
		$.confirm({
			'title'		: title,
			'message'	: message,
			'buttons'	: {
				'Ok'	: {
					'class'	: 'blue',
					'action': function(){
						elem.slideUp();
					}
				}
			}
		});
}
</script>
<script>
function loadDoc()
{
$.post( "/foradoar.php", { id:'n' }, function( data ) {
	if(data.mens != "0"){	  
	  
	  var elem = $(this).closest('.item');
		
		$.confirm({
			'title'		: data.title,
			'message'	: data.mens,
			'buttons'	: {
				'Sim'	: {
					'class'	: 'blue',
					'action': function(){
						elem.slideUp();
						$.post( "/foradoar.php", { id:data.id }, function( data ) {
		                mens(data.title, data.mens);
						}, "json");
					}
				},
				'N�o'	: {
					'class'	: 'gray',
					'action': function(){}	// Nothing to do in this case. You can as well omit the action property.
				}
			}
		});
	  
	}else{
	mens(data.title, data.mens2);
	}
    }, "json");
}
</script>
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
<link rel="stylesheet" type="text/css" href="/css/ddsmoothmenu.css" />

        <!-- liteAccordion css -->
        <link href="/css/liteaccordion.css" rel="stylesheet" />
		
        <!-- easing -->
        <script type="text/javascript" src="/js/jquery.easing.1.3.js"></script>



        <!-- liteAccordion js -->
        <script type="text/javascript" src="/js/liteaccordion.jquery.js"></script>


        <link rel="stylesheet" type="text/css" href="/css/jquery.fancybox.css" />
        <link rel="stylesheet" type="text/css" href="/css/jquery.fancybox-buttons.css"  />
        <script type="text/javascript" src="/js/jquery.fancybox.js"></script>
        <script type="text/javascript" src="/js/jquery.fancybox-buttons.js"></script>

      
</head>
<body id="home">
<div id="templatemo_wrapper">
	<div id="templatemo_top">
	
    	<div id="templatemo_login">
		    <? if (!isset($vip)){ ?>
            <form action="/painel/login.php" method="post" name="logForm" id="logForm">
              <input type="text" value="Usuario" name="usr_email" id="logar" size="10" title="username" onFocus="clearText(this)" onBlur="clearText(this)" class="txt_field" />
              <input type="password" value="password" name="pwd" id="senha" size="10" title="password" onFocus="clearText(this)" onBlur="clearText(this)" class="txt_field" />
			  <input name="remember" type="hidden" id="remember" value="1" checked="checked">
			  <input class="sub_btn" name="doLogin" type="submit" id="doLogin3" value="Login" >
            </form>
			<? } ?>
			<? if (isset($vip)){ ?>
			<a href="/painel/index.php">Painel usu�rio</a> | <a href="/painel/index.php">Renovar acesso</a> | <a href="/painel/logout.php">[<? echo $_SESSION['user_name']; ?>] Sair</a>
			<? } ?>
		</div>
    </div> <!-- end of top -->
    
  	<div id="templatemo_header">
    	<div id="site_title"><h1><a href="<?php echo $siteurl; ?>/tv/<?php echo $row_canais['nome_foto']; ?>">Ver <?php echo $row_canais['nome_do_canal']; ?> online - Assistir <?php echo $row_canais['nome_do_canal']; ?> online</a></h1></div>
        <div id="templatemo_menu" class="ddsmoothmenu">
            <ul>
<li><a href='/'>Inicio</a></li>
<?
$sql458 = "SELECT * FROM dados_beta WHERE lugar LIKE 'menu' AND ligar LIKE 's' AND (vip = '$separar' or vip LIKE 'na') ORDER BY ID ASC";
                    $query458 = mysql_query($sql458);
                    while($sql458 = mysql_fetch_array($query458)){
					$count = mb_strlen( $sql458['nome_do_canal'] );
					$i = $count + $i + 6;
					if($i < 95){
					echo '<li><a target="canaisbox" href="../tv/'.$sql458[$linkvip].'">'.$sql458['nome_do_canal'].'</a></li>';
					}else{
					$i = $i - ($count + 6);
					}
                    }
 ?>
<li><a target="_top" href='/contato.php'>Contato</a></li></ul>
            <br style="clear: left" />
        </div> <!-- end of templatemo_menu -->
    </div> 
  	<!-- end of header -->
	    <div id="three">
            <? require_once('../menu.php'); ?>
            <noscript>
               <p>Ative o JavaScript para ter a experi�ncia completa.</p>
            </noscript>
        </div>
  <p>Menu:
            <a class="links" href="#variedades">Variedades/Abertos</a><a class="links"> | </a>
            <a class="links" href="#cinema">Cinema/Series</a><a class="links"> | </a>
            <a class="links" href="#esportes">Esportes</a><a class="links"> | </a>
            <a class="links" href="#infantil">Infantil/Desenhos</a><a class="links"> | </a>
            <a class="links" href="#clipes">Clipes/Musicais</a><a class="links"> | </a>
			<a class="links" href="#religiosos">Religiosos</a><a class="links"> | </a>
			<a class="links" href="#documentarios">Document�rios</a><a class="links"> | </a>
			<a class="links" href="#noticias">Not�cias</a></p>
		
  <div style="width:958px; margin-bottom:5px; float:left; background:#353535; border-style:solid; border-width:1px; border-color:#030303; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; padding-top: 4px;"><form action="/busca.php" target="canaisbox" method="get" accept-charset="UTF-8">
      <input class="busca" id="texto" type="text" onFocus="clearText(this)" onBlur="clearText(this)" value="Busque um canal ou evento ex: futebol" name="palavra" />
      <input onClick="return CollapseExpand()" class="botao" type="submit" value="Buscar"/>
</form>
<button class="botao" type="button" onClick="loadDoc()">O canal n�o pegou? clique aqui para avisar!</button>
<script type="text/javascript">
        $(document).ready(function(){
            $("#shadow").css("height", $(document).height()).hide();
            $(".lightSwitcher").click(function(){
                $("#shadow").toggle();
                if ($("#shadow").is(":hidden"))
                    $(this).html("Desligar luz").removeClass("turnedOff");
                 else
                    $(this).html("Ligar luz").addClass("turnedOff");
            });
            
        });
    </script>
	<a class="lightSwitcher" style="position:relative; z-index:102;">Desligar luz</a>
</div>
  <div id="MyDiv1" class="divVisible1" align="center" style="position:relative; z-index:103;">
  <div style="float:left; margin-right:2px; height:435px; width:468px;">
<iframe height="435px" width="468px" frameborder="0" id="canaisbox" name="canaisbox" scrolling="no" src="<?php
$string1 = str_replace("/tv/", "/frame/", $siteurlb);
for( $i = 0 ; $i < strlen ( $string1 );++ $i ){
$n = rand ( 0 , 1 );
if( $n )
$finished1 .= '&#x' . sprintf ( "%X" , ord ( $string1 { $i })). ';' ;
else
$finished1 .= '&#' . ord ( $string1 { $i }). ';' ;
}
echo $finished1;
?>"></iframe>
	</div>
  <div style="float:right; width:490px; height:435px;">
  <embed bgcolor="#000000" src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="490" height="435" name="chat" flashvars="id=<?php echo $configuracoes['chat']; ?>&amp;rl=Brazilian" align="middle" allowscriptaccess="sameDomain" wmode="transparent" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.shtml">
  </div>
  </div>

<script>
                $('#three').liteAccordion({ firstSlide : <?php 
				$este = $row_canais['categoria'];
 $checar1 = mysql_query("SELECT * FROM dados_beta WHERE nome_foto='$este' AND lugar LIKE 'canais' ORDER BY nome_do_canal ASC LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	if($result1 == 1){
	
    while($sql458 = mysql_fetch_array($checar1)){
					$hr = $sql458['categoria'];
			}}else{
			$hr = $este;
			}
  
     if($hr == variedades ) {  
          $resp = "1";  
  
     }
	 if($hr == cinema ) {  
          $resp = "2";  
  
     }
	 if($hr == esportes ) {  
          $resp = "3";  
  
     }
	 if($hr == infantil ) {  
          $resp = "4";  
  
     }
	 if($hr == clipes ) {  
          $resp = "5";  
  
     }
	 if($hr == religiosos ) {  
          $resp = "6";  
  
     }
	 if($hr == documentarios ) {  
          $resp = "7";  
  
     }
	 if($hr == noticias ) {  
          $resp = "8";  
  
     }
     echo  "$resp";
	 ?>, containerHeight : <?php 
	 $colunas = ceil(max(array($variedades, $cinema, $esportes, $infantil, $clipes, $religiosos, $documentarios, $noticias)) / 7);
	 $colunas = ($colunas * 55) - 5;
	 if($colunas < 270){ $colunas = 270;}
	 echo $colunas;
	 ?>});
            </script>

    <!-- end of templatemo_middle -->
    <? if ($vip != 'sim'){ ?>
    <div id="templatemo_main">
    	<div class="col_fw">
    	  <div class="col_w240 col_last" style="position:relative; z-index:103;">
		  <?php if(!empty($configuracoes['chat'])) { echo $configuracoes['728x90']; } ?>
		  </div>
            <div class="cleaner"></div>
        </div>
        
        <div class="col_fw_last">
       	  <div class="col_allw300">
  <? if(empty($titulofull)){ ?>
            	<h3>Noticias</h3>
				 
  <?php
  function load_file($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    # ignore header
    curl_setopt($ch, CURLOPT_HEADER, false);
    # Return http response in string
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $xml = @simplexml_load_string(curl_exec($ch));
    return $xml;
  }
   
  $feedurl = $configuracoes['noticias'];
  $rss = load_file($feedurl);
   
  foreach ($rss->channel->item as $item) {
    print '<div class="news_box">
                        <p>' .
    utf8_decode($item->title) . '</p>';
    print '<a  href="' . urldecode($item->link) .  '" target="_blank"> Ver Noticia</a></div>
    ';
    $contador ++;
    if ($contador >= 4)
    break;
  }
?> 
<? }else{ ?>
           	<h3>Programa��o <?php echo $row_canais['nome_do_canal']; ?></h3>
			<h5><strong>Agora: </strong><?php echo $titulofull; ?></h5>
			<div class="news_box">
                        <p><? echo $resumo; ?></p>
						</div>
			<h5><strong>A seguir: </strong><?php echo $titulofull1; ?></h5>
            <div class="news_box">
                        <p><? echo $resumo1; ?></p>
						</div>
<? } ?>
          </div>
          <div class="col_allw300">
            	<h3>Facebook</h3>
				
		        <iframe src="//www.facebook.com/plugins/likebox.php?href=<?php echo $configuracoes['facebook']; ?>&amp;width=300&amp;height=335&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:300px; height:335px;" allowtransparency="true"></iframe>
          </div>
          <div class="col_allw300 col_rm">
            	<h3>Twitter</h3>
				
                 <a class="twitter-timeline" width="300" height="313" href="https://twitter.com/<?php echo $configuracoes['twitter']; ?>" data-tweet-limit="3" data-widget-id="<?php echo $configuracoes['twitterid']; ?>"  data-chrome="transparent noborders noscrollbar nofooter noheader" ></a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

          	</div>
        </div>
        <div class="cleaner"></div>
  </div> <!-- end of main -->
  <? } ?>
</div> <!-- end of wrapper -->
<div id="templatemo_footer_wrapper2">
</div>
<div id="templatemo_footer_wrapper">
    <div id="templatemo_footer">
        <?php echo $configuracoes['cop']; ?>
        <div class="cleaner"></div>
    </div>
</div>
<div id="shadow"></div>
<? if(!empty($configuracoes['analytics'])){ ?>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try{
var pageTracker = _gat._getTracker("<? echo $configuracoes['analytics']; ?>");
pageTracker._trackPageview('<?php echo '/tv/'.$row_canais[$linkvip]; ?>');
} catch(err) {}</script>
<? } ?>
<script type="text/javascript">
if (parent !== self) {
    parent.top.location = '<? echo $siteurl.'/mover/'.$row_canais[$linkvip]; ?>';
}
 </script>
</body>
</html>
<?
}else{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="pt" xmlns:fb="http://www.facebook.com/2008/fbml" xml:lang="pt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<link href="/css/templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/css/jquery-ui.min.css" />
<script src="/js/jquery.js"></script>
<script src="/js/jquery-ui.js"></script>
<script>
$(function() {
$( "#dialog" ).dialog({
autoOpen: false,
width: 400,
height: 300,
position: { my: "center", at: "center", of: window },
show: {
effect: "blind",
duration: 1000
},
hide: {
effect: "explode",
duration: 1000
}
});
$( "#opener" ).click(function() {
$( "#dialog" ).dialog( "open" );
});
});
</script>
<script>
$(function() {
$( "#dialog1" ).dialog({
autoOpen: false,
width: 400,
height: 300,
position: { my: "center", at: "center", of: window },
show: {
effect: "blind",
duration: 1000
},
hide: {
effect: "explode",
duration: 1000
}
});
$( "#opener1" ).click(function() {
$( "#dialog1" ).dialog( "open" );
});
});
</script>
<script>var mensagem="";function clickIE(){if(document.all){(mensagem);return false;}}
function clickNS(e){if
(document.layers||(document.getElementById&&!document.all)){if(e.which==2||e.which==3){(mensagem);return false;}}}
if(document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")</script>	

<?php 
	     $sc = $row_canais['tipo'];
	     $hrr = $sc;
         if(($hrr == rtmp ) or ($hrr == m3u8)) {  
              $respsc = '<script src="/player/jwplayer2.js"></script>
<script>jwplayer.key = "xMRYAL2RatWkKACzmgDbFrKaiLuWS36yA/RBSPYDTf8="</script>';  
         }
		 if(($hrr == swf )) { ?>
		 <link rel="stylesheet" type="text/css" href="/css/jquery.fancybox.css" />
        <link rel="stylesheet" type="text/css" href="/css/jquery.fancybox-buttons.css"  />
        <script type="text/javascript" src="/js/jquery.fancybox.js"></script>
        <script type="text/javascript" src="/js/jquery.fancybox-buttons.js"></script>
<script>
/* <![CDATA[ */
$(document).ready(function() {
$(".abrir").click(function(){
parent.$.fancybox({
type: 'html',
width: $( window.parent.document ).width(),
height: $( window.parent.document ).height(),
autoSize: false,
content: '<div id="wrap2"></div>',
beforeClose: function() {
$(".fancybox-inner").unwrap();
},
			helpers: {
				overlay: {
				opacity: 0.3
				} // overlay
			}
}); //fancybox
$(function() {
parent.$("#wrap2").load("/js/swf.php?id=<? echo base64_encode ($row_canais['linkdcanal']); ?>"); 
}); 
return false;
}); //click	
}); // ready
/* ]]> */
</script>  <?
         }
		 echo  "$respsc";
		 ?>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}
-->
</style></head>

<body>
<?
//verifica se esta op�ao de canal esta com o canal principal desativado ou ativo
    if($row_canais['form'] == 'opt'){
	$sql458 = "SELECT * FROM dados_beta WHERE nome_foto='".$row_canais['categoria']."' AND lugar LIKE 'canais' LIMIT 1";
                    $query458 = mysql_query($sql458);
                    while($sqla458 = mysql_fetch_array($query458)){
					if($sqla458['ligar'] == 'n'){
					$termo = $sqla458['nome_foto'];
					$imagem = linkico($sqla458['vip'], $sqla458['url_do_canal']);
					$idcanal = $row_canais['ID'];
					}
					if($sqla458['ligar'] == 's'){
					$termo = $sqla458['nome_foto'];
					$imagem = linkico($sqla458['vip'], $sqla458['url_do_canal']);
					$idcanal = $row_canais['ID'];
					}
					}
	}else{
	$termo = '';
	$imagem = linkico($row_canais['vip'], $row_canais['url_do_canal']);
	$idcanal = '';
	}
	// verifica se tem op�oes para o canal
	if($row_canais['form'] == 'opt'){
	$contaisto = "OR categoria='".$row_canais['categoria']."'";
	}
	$checar1 = mysql_query("SELECT * from dados_beta WHERE (categoria='".$row_canais['nome_foto']."' OR categoria='$termo' OR nome_foto='$termo' $contaisto) AND ID !='$idcanal' AND ID !='".$row_canais['ID']."' AND ligar='s' AND (vip='$separar' OR vip='na')");
    $result1 = mysql_num_rows($checar1);
	if($result1 >= 1){
	$opcs111 = 1;
	}else{
	$opcs111 = 0;
	}
	?>
<?
if((!isset($_GET['play'])) && ($opcs111 == 1)){
$coloca1 = 1;
}
 if((($row_canais['lugar'] !== "menu") or (($row_canais['lugar'] == "menu") && ($row_canais['tipo'] !== "iframe"))) && ((isset($_GET['play'])) or (!isset($_GET['play']))) && (($_GET['play'] == "1") or ($_GET['play'] == "")) && (($opcs111 == 1) or ($opcs111 == 0)) && (($coloca1 !== 1) or (!isset($coloca1))) ){ ?>
<table id="Tabela_01" width="468" height="75" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td  width="70" height="65">
			<div align="center">
<div class="g-plusone" data-size="tall" data-href="<? echo $siteurl.'/tv/'.$row_canais['nome_foto']; ?>"></div>

<!-- Posicione esta tag depois da �ltima tag do bot�o +1. -->
<script type="text/javascript">
  window.___gcfg = {lang: 'pt-BR'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script></div></td>
		<td width="70">
	  <div align="center"><a href="#"
   onclick="
     window.open(
       'https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent('<?php echo $siteurl; ?>/tv/<?php echo $row_canais['nome_foto'].'&fbrefresh='.rand(1,10000000); ?>'),
       'facebook-share-dialog',
       'width=626,height=436');
     return false;"><div align="center" style="width:57px; height:64px; background-image:url(/images/UHP63uz.png);"></div></a></div></td>
		<td width="70"><div align="center"><a href="https://twitter.com/share" class="twitter-share-button" data-url="<? echo $siteurl; ?>/tv/<?php echo $row_canais['nome_foto']; ?>" data-counturl="<?php echo str_replace("http://", "", str_replace("www.", "", $siteurl)); ?>" data-text="Estou assistindo <? if(!empty($titulofull)){echo "&quot;".substr($titulofull, 0, 39);} if((strlen($titulofull)) > 39){ echo "...";} if(!empty($titulofull)){ echo "&quot; no canal ".substr($row_canais['nome_do_canal'], 0, 17).', veja ao vivo gratis no site';} else {echo $row_canais['nome_do_canal'];} ?>" data-lang="en" data-count="vertical">Tweet</a>
    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script></div></td>
	<td width="258">
<div style="display:none;" id="dialog" title="<? echo $titulofull; ?>">
<p><? echo $resumo; ?></p>
<p><? echo $small_data; ?></p>
<p><? echo $direc; ?></p>
<p><? echo $direc2; ?></p>
</div>
<input <? if((strlen($resumo)) > 5){ ?> id="opener" <? } ?> value="<?php
if(empty($titulofull)){
$titulofull = 'Programa��o indispon�vel';
$align = '1';
}else{
$titulofull = $hora.' '.$titulofull;
}
echo  substr($titulofull, 0, 32); if((strlen($titulofull)) > 32){ echo "...";}
?>" style="font-size:13px; height:30px;
    background: #353535; border-radius: 10px 20px 30px 35px; <? if((strlen($resumo)) > 5){ ?>cursor: pointer;<?php } if(empty($align)){ ?> text-align:left;<? } ?> margin-top:2px;
    color: #FFF; border:none; width:270px; font-weight:bold;" type="button">
<div style="display:none;" id="dialog1" title="<? echo $titulofull1; ?>">
<p><? echo $resumo1; ?></p>
<p><? echo $small_data1; ?></p>
<p><? echo $direc1; ?></p>
<p><? echo $direc21; ?></p>
</div>
<input name="Input"<? if((strlen($resumo1)) > 5){ ?> id="opener1" <? } ?>value="<?php
if(empty($titulofull1)){
$titulofull1 = '*';
}else{
$titulofull1 = $hora2.' '.$titulofull1;
}
echo  substr($titulofull1, 0, 32); if((strlen($titulofull1)) > 32){ echo "...";}
?>" style="font-size:13px; height:30px;
    background: #353535; margin-top:2px;
    color: #FFF; border:none; border-radius: 10px 20px 30px 35px; width:270px; font-weight:bold;<? if((strlen($resumo1)) > 5){ ?>cursor: pointer; <?php } if(empty($align)){ ?>text-align:left;<? } ?>" type="button">
</td>
    </tr>
</table>
<? } ?>
<div id="canais">

<?
if((!isset($_GET['play'])) && ($opcs111 == 1)){

echo '<div style="overflow: auto; position: relative; height: 440px;"><div style=" background:url('.$imagem.'); background-size:70px 50px; background-repeat:no-repeat; cursor: pointer; width:70px; height:50px; border-radius: 5px; border:1px; border-style:solid; margin:20px; border-color:#000000;float:left;" onclick="parent.canaisbox.location=\''.$siteurl.'/tv/'.$row_canais[$linkvip].'&play=1\';" title="'.$row_canais['nome_do_canal'].'"><a style="background-color:#000000; color:#FFFFFF; border-radius: 2px; margin-left:12px; line-height:10%;">Op��o 1</a>
</div>';

$numero = '2';
                    while($sql458 = mysql_fetch_array($checar1)){
					echo '<div style=" background:url('.$imagem.'); background-size:70px 50px; background-repeat:no-repeat; cursor: pointer; width:70px; height:50px; border-radius: 5px; border:1px; border-style:solid; margin:20px; border-color:#000000;float:left;" onclick="parent.canaisbox.location=\''.$siteurl.'/tv/'.$sql458[$linkvip].'&play=1\';" title="'.$sql458['nome_do_canal'].'"><a style="background-color:#000000; color:#FFFFFF; border-radius: 2px; margin-left:12px; line-height:10%;">Op��o '.$numero.'</a>
</div>';
$numero++;
}
echo '</div>';
$coloca = 1;
$GLOBALS['coloca'] = 1;
$_SESSION['canal_aberto'] = '';
$_SESSION['canal_aberto_nome'] = '';
}elseif(((isset($_GET['play'])) or (!isset($_GET['play']))) && (($_GET['play'] == "1") or ($_GET['play'] == "")) && (($opcs111 == 1) or ($opcs111 == 0)) && (($coloca !== 1) or (!isset($coloca))) ){
?>
<? $propaganda = $row_canais['propaganda']; if($propaganda == 's' && $vip != 'sim'){ ?>
<?php if(!empty($configuracoes['300x250'])) {?>
<script> 
         $(document).ready(function(){
		  $('#floatLayer3').css('display','');
		  $('#floatLayer3').css('top', $("#canais").offset().top+35);
		  $('#floatLayer3').css('left', $("#canais").offset().left+84);
        });
       </script>
<div id="floatLayer3" style="position: absolute; height:250px; z-index:99; width:300px; padding-top:-5px; display:none; background-color: #FFFFFF">
<div style=" position:relative; left:<? echo rand(10, 290); ?>px; top:<? echo rand(10, 240); ?>px; height:0px; width:0px;"><span onMouseUp="document.getElementById('floatLayer3').style.display='none'"><img alt="FECHAR" border="0" height="9" src="/images/fechar.png" width="9" /></span></div>
<?php  echo $configuracoes['300x250']; ?>
</div>
<? } ?>
<? } ?>
<?php
$string = $row_canais['linkdcanal'];
for( $i = 0 ; $i < strlen ( $string );++ $i ){
$n = rand ( 0 , 1 );
if( $n )
$finished .= '&#x' . sprintf ( "%X" , ord ( $string { $i })). ';' ;
else
$finished .= '&#' . ord ( $string { $i }). ';' ;
}
?>
         <?php
		 $tipo = $row_canais['tipo'];
         $hr = $tipo;
		 $hr2 = $row_canais['lugar'];
		 $nome = $row_canais['nome_do_canal'];
		 $linkcanal = $row_canais['linkdcanal']; 
		 $linkcanallinha = str_replace("\r\n",";",trim($linkcanal));
		 if ($vip != 'sim'){
		 $logotipo = '/images/logo.png';
		 }
         if(($hr == iframe) && ($hr2 == canais) ) {  
              $resp = "<div id='iframe-holder'><iframe src='$finished'  width='468' marginwidth='0' height='380' marginheight='0' scrolling='no' frameborder='0'></iframe></div>";  
         }
		 if(($hr == iframe) && ($hr2 == menu) ) {  
              $resp = "<iframe src='$finished'  width='468' height='435' scrolling='no' frameborder='0'></iframe>";  
         }
		 if($hr == wmp ) {  
              $resp = "<embed  type='application/x-mplayer2' pluginspage='http://www.microsoft.com/Windows/MediaPlayer/'
                src='$linkcanallinha' align='middle' width='468' height='360' EnableContextMenu='false' ShowStatusBar='true' autostart='true'  defaultframe='rightFrame' id='MediaPlayer2' />";  
         }
		 if($hr == embed ) {  
              $resp = "$linkcanal";
         }
		 if($hr == livestream ) {  
              $resp = "<script type='text/javascript' src='/player/jwplayer.js'></script>
<div id='player_7416'></div>
<script type='text/javascript'>
  jwplayer('player_7416').setup({
    'flashplayer': '/player/playertv2.swf',
	'type':'livestream',
    'file':'$linkcanallinha',
    'livestream.devkey':'".$configuracoes['livestream.com']."',
	'bufferlength':'3',
    'width': '468',
	'stretching':'fill',
    'height': '360',
    'autostart':'true',
	'logo.file':'$logotipo',
	'logo.hide':'false',
	'logo.position':'top-right',
	'logo.link':'$siteurl',
	'abouttext':'Player $nome',
    'aboutlink': '$siteurl',
	'logo.margin':'10',
	'skin':'/player/tm2.zip',
	'logo.out':'1',
  });
</script>";  
         }
		 if($hr == m3u8 ) {  
              $resp = "<div id='tv'>Carregando o canal $nome</div>
   <script type='text/javascript'>
       jwplayer('tv').setup({
           file: '$linkcanallinha',
	height: 360,
	width: 468,
    autostart: 'true',
	bufferlength: '1',
	flashplayer: '/player/jwplayer.flash.swf',
	html5player: '/player/jwplayer.html5.js',
	abouttext :'Player $nome',
	aboutlink : '$siteurl',
	logo: {
    file: '$logotipo',
    link: '$siteurl'
  }
       });
   </script>";  
         }
		 if ($hr == rtmp ){  
              $resp = "<div id='tv'>Carregando o canal $nome</div>
   <script type='text/javascript'>
       jwplayer('tv').setup({
           file: '$linkcanallinha',
    flashplayer: '/player/jwplayer.flash.swf',
	html5player: '/player/jwplayer.html5.js',
	height: 360,
	width: 468,
    autostart: 'true',
	stretching: 'exactfit',
	bufferlength: '1',
	abouttext :'Player $nome',
	aboutlink : '$siteurl',
	logo: {
    file: '$logotipo',
    link: '$siteurl'
  }
       });
   </script>";  
         }
		 if ($hr == swf ){  
              $resp = "<div id=\"wrap\"><a class=\"abrir\" href=\"$linkcanallinha\"></a></div>
			  <script>
    jQuery(function(){
      jQuery('.abrir').click();
    });
</script>";  
         }
		 
   $str = encode($resp);
if(($hr2 == menu) or (($hr == embed) && ($hr2 == canais))){

         echo  "$resp"; 

}else{
       
	   echo  "<script language=\"javascript\">
document.write(unescape('$str'));
</script>";
 
}  
if ($row_canais['lugar'] !== "menu"){
$_SESSION['canal_aberto'] = $row_canais['ID'];
$_SESSION['canal_aberto_nome'] = $row_canais['nome_do_canal'];
}
if ($row_canais['lugar'] == "menu"){
$_SESSION['canal_aberto'] = '';
$_SESSION['canal_aberto_nome'] = '';
}
    ?>
	<? 
}else{
header("Location: $siteurl");
exit();
}
?>
</div>
<? if(!empty($configuracoes['analytics'])){ ?>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try{
var pageTracker = _gat._getTracker("<? echo $configuracoes['analytics']; ?>");
pageTracker._trackPageview('<?php echo '/tv/'.$row_canais[$linkvip]; ?>');
} catch(err) {}</script>
<? } ?>
</body>
</html>
<?

}
?>