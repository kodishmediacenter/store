<?php
ob_start();
require_once('../painel/comfig.php'); ?>
<?
$url = $_SERVER[HTTP_REFERER];
$refer = parse_url($url);
$refer = 'http://'.$refer['host'];
$refer3 = dirname($siteurlb);
 ?><? 
if(($refer == $siteurl) && ($refer3 !== $siteurl.'/mover')){
require_once('L9HuSbZRmby7.php');
?>
<?
} else{
$siteurlbframe = str_replace("/frame/", "/mover/", $siteurlb);
header("HTTP/1.1 301 Moved Permanently");
header("Location: $siteurlbframe");
exit();
}
?>