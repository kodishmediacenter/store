<?php
ob_start();
require_once('../painel/comfig.php'); ?>
<?
$refer3 = dirname($siteurlb);
 ?><?
if(($refer3 == $siteurl.'/mover')){
?>
<script type="text/javascript">
    parent.top.location = '<? echo $siteurl.'/tv/'.strip_tags(mysql_real_escape_string($_GET['ID'])); ?>';
 </script>
<?
} else{
$siteurlbframe = str_replace("/frame/", "/tv/", $siteurlb);
header("HTTP/1.1 301 Moved Permanently");
header("Location: $siteurlbframe");
exit();
}
?>