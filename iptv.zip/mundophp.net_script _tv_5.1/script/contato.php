<?php
require_once('painel/comfig.php'); 
session_start();
//verifica�ao vip
if (!isset($_SESSION['user_id']) && !isset($_SESSION['user_name']) ){
if(isset($_COOKIE['user_id']) && isset($_COOKIE['user_key'])){
	/* we double check cookie expiry time against stored in database */
	
	$cookie_user_id  = filter($_COOKIE['user_id']);
	$rs_ctime = mysql_query("select `ckey`,`ctime` from `users` where `id` ='$cookie_user_id'") or die(mysql_error());
	list($ckey,$ctime) = mysql_fetch_row($rs_ctime);
	// coookie expiry
	if( (time() - $ctime) > 60*60*24*COOKIE_TIME_OUT) {

		logout();
		}
/* Security check with untrusted cookies - dont trust value stored in cookie. 		
/* We also do authentication check of the `ckey` stored in cookie matches that stored in database during login*/

	 if( !empty($ckey) && is_numeric($_COOKIE['user_id']) && isUserID($_COOKIE['user_name']) && $_COOKIE['user_key'] == sha1($ckey)  ) {
	 	  session_regenerate_id(); //against session fixation attacks.
	
		  $_SESSION['user_id'] = $_COOKIE['user_id'];
		  $_SESSION['user_name'] = $_COOKIE['user_name'];
		/* query user level from database instead of storing in cookies */	
		  list($user_level) = mysql_fetch_row(mysql_query("select user_level from users where id='$_SESSION[user_id]'"));

		  $_SESSION['user_level'] = $user_level;
		  $_SESSION['HTTP_USER_AGENT'] = md5($_SERVER['HTTP_USER_AGENT']);
		  
		  $session_id=session_id();
		  $id = $_SESSION['user_id'];
          $savsessionquery="INSERT INTO users_sessions (id, session_id) VALUES ('".$id."', '".$session_id."') ON DUPLICATE KEY UPDATE session_id='".$session_id."'";
          $savesessionresult=mysql_query($savsessionquery);
		  
	   }

  }
}
if(isset($_SESSION['user_id']) && isset($_SESSION['user_name'])){
page_protect();

$user_id = $_SESSION['user_id'];
$boas_vindas = mysql_query("SELECT id, vencimento, data FROM users WHERE id = '$user_id'")
or die(mysql_error());
if(@mysql_num_rows($boas_vindas) <= '0') 
echo "Erro ao selecionar o usuário";
else{
while($res_boas_vindas=mysql_fetch_array($boas_vindas)){
$vencimento = $res_boas_vindas[1];
$data = $res_boas_vindas[2];


$dataI= date('Y/m/d');
$I= strtotime($dataI);
$dataII= $vencimento;
$II= strtotime($dataII);
$dataIII= $data;
$III= strtotime($dataIII);


// Define os valores a serem usados
$data_inicial = $data;
$data_final = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial = strtotime($data_inicial);
$time_final = strtotime($data_final);

// Calcula a diferença de segundos entre as duas datas:
$diferenca = $time_final - $time_inicial; // 19522800 segundos

// Calcula a diferença de dias
$dias = (int)floor( $diferenca / (60 * 60 * 24)); // 225 dias


// Define os valores a serem usados
$data_inicial1 = $dataI;
$data_final1 = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial1 = strtotime($data_inicial1);
$time_final1 = strtotime($data_final1);

// Calcula a diferença de segundos entre as duas datas:
$diferenca1 = $time_final1 - $time_inicial1; // 19522800 segundos

// Calcula a diferença de dias
$dias1 = (int)floor( $diferenca1 / (60 * 60 * 24)); // 225 dias

$porc = $dias+0.000001;
$valor = $dias1;
$resul = $valor/$porc;
$fim = $resul*100;

if ($I >= $II){ 
page_protect();
$separar = 'n';
$linkvip = 'nome_foto';
$vip = 'nao';
setcookie("user", '', time()+60*60*24*COOKIE_TIME_OUT, "/icones/vip");
}else{
page_protect();
$separar = 's';
$linkvip = 'linkvip';
$vip = 'sim';
setcookie("user", 's', time()+60*60*24*COOKIE_TIME_OUT, "/icones/vip");
}
}
}
}else{
$separar = 'n';
$linkvip = 'nome_foto';
}
//fim verifica�ao vip
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//pt-br" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Contato</title>
<link href="css/templatemo_style.css" rel="stylesheet" type="text/css" />

<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "templatemo_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<!--////// CHOOSE ONE OF THE 3 PIROBOX STYLES  \\\\\\\-->
<link href="css_pirobox/white/style.css" media="screen" title="shadow" rel="stylesheet" type="text/css" />
<!--<link href="css_pirobox/white/style.css" media="screen" title="white" rel="stylesheet" type="text/css" />
<link href="css_pirobox/black/style.css" media="screen" title="black" rel="stylesheet" type="text/css" />-->
<!--////// END  \\\\\\\-->

<!--////// INCLUDE THE JS AND PIROBOX OPTION IN YOUR HEADER  \\\\\\\-->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/piroBox.1_2.js"></script>
<script type="text/javascript">
$(document).ready(function() {
$().piroBox({
        my_speed: 600, //animation speed
        bg_alpha: 0.5, //background opacity
        radius: 4, //caption rounded corner
        scrollImage : false, // true == image follows the page, false == image remains in the same open position
        pirobox_next : 'piro_next', // Nav buttons -> piro_next == inside piroBox , piro_next_out == outside piroBox
        pirobox_prev : 'piro_prev',// Nav buttons -> piro_prev == inside piroBox , piro_prev_out == outside piroBox
        close_all : '.piro_close',// add class .piro_overlay(with comma)if you want overlay click close piroBox
        slideShow : 'slideshow', // just delete slideshow between '' if you don't want it.
        slideSpeed : 4 //slideshow duration in seconds(3 to 6 Recommended)
});
});
</script>
<!--////// END  \\\\\\\-->
  
</head>
<body id="sub_page">
<div id="templatemo_wrapper">
	<div id="templatemo_top">
    	<div id="templatemo_login">
            <? if (!isset($vip)){ ?>
			<form action="painel/login.php" method="post" name="logForm" id="logForm">
              <input type="text" value="Usuario" name="usr_email" id="logar" size="10" title="username" onFocus="clearText(this)" onBlur="clearText(this)" class="txt_field" />
              <input type="password" value="password" name="pwd" id="senha" size="10" title="password" onFocus="clearText(this)" onBlur="clearText(this)" class="txt_field" />
			  <input name="remember" type="hidden" id="remember" value="1" checked="checked">
			  <input class="sub_btn" name="doLogin" type="submit" id="doLogin3" value="Login" >
            </form>
			<? } ?>
			<? if (isset($vip)){ ?>
			<a href="painel/index.php">Painel usu�rio</a> | <a href="painel/logout.php">[<? echo $_SESSION['user_name']; ?>] Sair</a>
			<? } ?>
		</div>
    </div> <!-- end of top -->
    
  	<div id="templatemo_header">
    	<div id="site_title"><h1><a href="<?php
echo"$siteurl";
?>"><?php echo $configuracoes['h1']; ?></a></h1></div>
        <div id="templatemo_menu" class="ddsmoothmenu">
            <ul>
<li><a target="_top" href='/'>Inicio</a></li>
<?
$sql458 = "SELECT * FROM dados_beta WHERE lugar LIKE 'menu' AND ligar LIKE 's' AND (vip = '$separar' or vip LIKE 'na') ORDER BY ID ASC";
                    $query458 = mysql_query($sql458);
                    while($sql458 = mysql_fetch_array($query458)){
					$count = mb_strlen( $sql458['nome_do_canal'] );
					$i = $count + $i + 6;
					if($i < 95){
					echo '<li><a target="_top" href="tv/'.$sql458[$linkvip].'">'.$sql458['nome_do_canal'].'</a></li>';
					}else{
					$i = $i - ($count + 6);
					}
                    //onde $tempo � a variavel que rerpresenta a coluna "tempo" nessa
                    //mesma tabela.
                    }
 ?>
<li><a target="_top" href='/contato.php'>Contato</a></li></ul>
            <br style="clear: left" />
        </div> <!-- end of templatemo_menu -->
    </div> <!-- end of header -->
    
    <div id="templatemo_main">
    	<h2>Contato</h2>
        <div class="col_w630 float_l">
        	
             <div id="contact_form">
        
                <h4><span id="result_box" lang="pt" xml:lang="pt">Envie-nos uma mensagem</span>...</h4>
                
                <form method="POST" name="contact" action="#">
					
					<label for="author">Nome:</label> <input type="text" id="author" name="nome" class="required input_field" />
					<div class="cleaner h10"></div>
																	
					<label for="email">Email:</label> <input type="text" class="validate-email required input_field" name="email" id="email" />
					<div class="cleaner h10"></div>
															
					<label for="subject">Assunto:</label> 
					<input type="text" class="validate-subject required input_field" name="assunto" id="subject"/>				               
					<div class="cleaner h10"></div>
											
					<label for="text">Mensagem:</label> <textarea id="text" name="mensagem" rows="0" cols="0" class="required"></textarea>
					<div class="cleaner h10"></div>				
																
					<input type="submit" value="Enviar" id="submit" name="submit" class="submit_btn float_l" />
					<input type="reset" value="Reset" id="reset" name="reset" class="submit_btn float_r" />
										
				</form>
        
          </div> 
        </div>
		
        <div class="cleaner"></div>
    </div> <!-- end of main -->
</div> <!-- end of wrapper -->

<div id="templatemo_footer_wrapper">
    <div id="templatemo_footer">
        <?php echo $configuracoes['cop']; ?>
        <div class="cleaner"></div>
    </div>
</div> 
<?
// aqui come�a o script
//pega as variaveis por POST
$nome      = strip_tags(mysql_real_escape_string($_POST["nome"]));
$email   = strip_tags(mysql_real_escape_string($_POST["email"]));
$assunto   = strip_tags(mysql_real_escape_string($_POST["assunto"]));
$mensagem  = strip_tags(mysql_real_escape_string($_POST["mensagem"]));

global $email; //fun��o para validar a vari�vel $email no script todo

if(!empty($mensagem) && $_POST){
$data      = date("d/m/y");                     //fun��o para pegar a data de envio do e-mail
$ip        = $_SERVER['REMOTE_ADDR'];           //fun��o para pegar o ip do usu�rio
$navegador = $_SERVER['HTTP_USER_AGENT'];       //fun��o para pegar o navegador do visitante
$hora      = date("H:i");                       //para pegar a hora com a fun��o date
$mais      = $configuracoes['email'];
$host  = $_SERVER['HTTP_HOST'];
//aqui envia o e-mail para voc�
mail ("$mais",                       //email aonde o php vai enviar os dados do form
      "$assunto",
      "Nome: $nome\nData: $data\nIp: $ip\nNavegador: $navegador\nHora: $hora\nE-mail: $email\n\nMensagem: $mensagem",
      "From: $email"
     );

//aqui s�o as configura��es para enviar o e-mail para o visitante
$site   = "auto-reply@".$host;                    //o e-mail que aparecer� na caixa postal do visitante
$titulo = "CONTATO TV";                  //titulo da mensagem enviada para o visitante
$msg    = "$nome, obrigado por entrar em contato conosco, em breve entraremos em contato";

//aqui envia o e-mail de auto-resposta para o visitante
mail("$email",
     "$titulo",
     "$msg",
     "From: $site"
    );
echo "<script type='text/javascript'>
alert('sua mensagem foi enviada');
</script>"; 
}if(empty($mensagem) && $_POST){
echo "<script type='text/javascript'>
alert('sua mensagem n�o foi enviada, a mensagem esta em branco!');
</script>"; 
} ?>
</body>
</html>