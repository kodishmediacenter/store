<?php
require_once('../painel/comfig.php');
page_protect();
	  if(!checkAdmin()) {
header("Location: login.php");
exit();
}
$PHPprotectV0 = 1;
while ($PHPprotectV0 < 9) {

$PHPprotectV1 = 's';
$PHPprotectV2 = 'linkvip';

if(($PHPprotectV0 == 1) or ($PHPprotectV0 == 9)){
$PHPprotectV3 = 'variedades';
}
if(($PHPprotectV0 == 2) or ($PHPprotectV0 == 10)){
$PHPprotectV3 = 'cinema';
}
if(($PHPprotectV0 == 3) or ($PHPprotectV0 == 11)){
$PHPprotectV3 = 'esportes';
}
if(($PHPprotectV0 == 4) or ($PHPprotectV0 == 12)){
$PHPprotectV3 = 'infantil';
}
if(($PHPprotectV0 == 5) or ($PHPprotectV0 == 13)){
$PHPprotectV3 = 'clipes';
}
if(($PHPprotectV0 == 6) or ($PHPprotectV0 == 14)){
$PHPprotectV3 = 'religiosos';
}
if(($PHPprotectV0 == 7) or ($PHPprotectV0 == 15)){
$PHPprotectV3 = 'documentarios';
}
if(($PHPprotectV0 == 8) or ($PHPprotectV0 == 16)){
$PHPprotectV3 = 'noticias';
}

$PHPprotectV4 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' AND categoria='$PHPprotectV3' ORDER BY ID DESC");
while($PHPprotectV5 = mysql_fetch_array($PHPprotectV4)){
$PHPprotectV6 = mysql_query("SELECT * from dados_beta WHERE categoria='".$PHPprotectV5['nome_foto']."' AND ligar='s' AND (vip = 's' or vip = 'na') AND lugar='canais' LIMIT 1");
$PHPprotectV7 = mysql_num_rows($PHPprotectV6);
if($PHPprotectV7 == 1){
if(!isset($PHPprotectV8)){
$PHPprotectV8 = 'ID = '.$PHPprotectV5['ID'];
}else{
$PHPprotectV8 = $PHPprotectV8.' OR ID = '.$PHPprotectV5['ID'];
}}}
if(isset($PHPprotectV8)){
$PHPprotectV9 = '('.$PHPprotectV8.') or ';
}

$PHPprotectV10 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' AND categoria='$PHPprotectV3' AND ligar = 'n' ORDER BY ID DESC");
while($PHPprotectV11 = mysql_fetch_array($PHPprotectV10)){
$PHPprotectV12 = mysql_query("SELECT * from dados_beta WHERE categoria='".$PHPprotectV11['nome_foto']."' AND ligar='s' AND (vip = '$PHPprotectV1' or vip LIKE 'na') AND lugar='canais' LIMIT 1");
$PHPprotectV13 = mysql_num_rows($PHPprotectV12);
if($PHPprotectV13 == 0){
if(!isset($PHPprotectV14)){
$PHPprotectV14 = 'AND ID !='.$PHPprotectV11['ID'];
}else{
$PHPprotectV14 = $PHPprotectV14.' AND ID !='.$PHPprotectV11['ID'];
}}}

$PHPprotectV15 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$PHPprotectV3."' AND lugar LIKE 'canais' AND ($PHPprotectV9 (vip = '$PHPprotectV1' or vip LIKE 'na')) $PHPprotectV14 ORDER BY nome_do_canal ASC");
$PHPprotectV16 = mysql_num_rows($PHPprotectV15);

$PHPprotectV17 = array();
while ($PHPprotectV18 = mysql_fetch_array($PHPprotectV15)) {
    array_push($PHPprotectV17, $PHPprotectV18["url_do_canal"]);
}

?>
<?php
$PHPprotectV19 = $PHPprotectV17;
 
$PHPprotectV20 = 70;
$PHPprotectV21 = 50;
$PHPprotectV22 = 7;
$PHPprotectV23 = 1;
$PHPprotectV24 = 1;
$PHPprotectV25 = 1;
$PHPprotectV26 = 70;
$PHPprotectV27 = 50;
 
$PHPprotectV16 = ($PHPprotectV16 / $PHPprotectV22);
$PHPprotectV16 = ceil($PHPprotectV16);
$PHPprotectV28 = ($PHPprotectV20 + $PHPprotectV23) * $PHPprotectV22 + 1;
$PHPprotectV29 = ($PHPprotectV21 + $PHPprotectV23) * $PHPprotectV16 + 1;
 
$PHPprotectV30 = imagecreatetruecolor($PHPprotectV28, $PHPprotectV29);
 
/*
 *  PUT SRC IMAGES ON BASE IMAGE
 */
 
foreach ($PHPprotectV19 as $PHPprotectV31 => $PHPprotectV32)
{
 list ($PHPprotectV33, $PHPprotectV34) = indexToCoords($PHPprotectV31);
 $PHPprotectV35 = $PHPprotectV32;
 $PHPprotectV35 = pathinfo($PHPprotectV35, PATHINFO_EXTENSION);
 if($PHPprotectV35 == 'jpg'){
 $PHPprotectV36 = imagecreatefromjpeg('../'.$PHPprotectV32);
 }
 if($PHPprotectV35 == 'png'){
 $PHPprotectV36 = imagecreatefrompng('../'.$PHPprotectV32);
 }
 if($PHPprotectV35 == 'gif'){
 $PHPprotectV36 = imagecreatefromgif('../'.$PHPprotectV32);
 }
 $PHPprotectV37 = $PHPprotectV36;
 
 
 list($PHPprotectV38,$PHPprotectV39)=getimagesize('../'.$PHPprotectV32);
 if(($PHPprotectV38 != 70) && ($PHPprotectV39 != 50)){
 $PHPprotectV40=imagecreatetruecolor($PHPprotectV26,$PHPprotectV27);
 imagecopyresampled($PHPprotectV40,$PHPprotectV37,0,0,0,0,$PHPprotectV26,$PHPprotectV27,$PHPprotectV38,$PHPprotectV39);
 imagecopy($PHPprotectV30, $PHPprotectV40, $PHPprotectV33, $PHPprotectV34, 0, 0, $PHPprotectV20, $PHPprotectV21);
 imagedestroy($PHPprotectV40);
 }else{
 imagecopy($PHPprotectV30, $PHPprotectV37, $PHPprotectV33, $PHPprotectV34, 0, 0, $PHPprotectV20, $PHPprotectV21);
 }
 imagedestroy($PHPprotectV37);
 }
 
/*
 * RESCALE TO THUMB FORMAT
 */

if($PHPprotectV1 == 's'){
$PHPprotectV41 = 'vip';
}else{
$PHPprotectV41 = 'aberto';
}
$PHPprotectV42 = $_SERVER['DOCUMENT_ROOT'].'/icones/'.$PHPprotectV41.'/'.$PHPprotectV3.'.jpeg';
imagejpeg($PHPprotectV30, $PHPprotectV42, 90);
$PHPprotectV0++;
}

?>
