<?php require_once('../painel/comfig.php');
      require_once('ico.php');
      page_protect();
	  if(!checkAdmin()) {
header("Location: ../painel/login.php");
exit();
}
$unid = uniqid();
function encode($input)
{
    $temp = '';
    $length = strlen($input);
    for($i = 0; $i < $length; $i++)
        $temp .= '%' . bin2hex($input[$i]);
    return $temp;
}
function nomeico($extensao){
 $arquivo1111 = pathinfo($extensao, PATHINFO_EXTENSION);
 if($arquivo1111 == 'jpg'){
 return $file = basename($extensao, ".jpg");
 }
 if($arquivo1111 == 'png'){
 return $file = basename($extensao, ".png");
 }
 if($arquivo1111 == 'gif'){
 return $file = basename($extensao, ".gif");
 }
}
function linkico($vip, $link){
global $siteurl;
if($vip==s){ echo $siteurl.'/icones/pequeno/vip/'.nomeico($link).'.jpeg';}
if($vip==n){ echo $siteurl.'/icones/pequeno/aberto/'.nomeico($link).'.jpeg';}
if($vip==na){ echo $siteurl.'/icones/pequeno/aberto/'.nomeico($link).'.jpeg';}
}

function indexToCoords($index)
{
 global $tileWidth, $pxBetweenTiles, $leftOffSet, $topOffSet, $numberOfTiles;
 
 $x = ($index % 7) * ($tileWidth + $pxBetweenTiles) + $leftOffSet;
 $y = floor($index / 7) * ($tileWidth + $pxBetweenTiles - 20) + $topOffSet;
 return Array($x, $y);
}

function friendlyUrl($string) {

    $table = array(
            '�'=>'S', '�'=>'s', '�'=>'D', 'd'=>'d', '�'=>'Z', '�'=>'z', 'C'=>'C', 'c'=>'c', 'C'=>'C', 'c'=>'c',
            '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'C', '�'=>'E', '�'=>'E',
            '�'=>'E', '�'=>'E', '�'=>'I', '�'=>'I', '�'=>'I', '�'=>'I', '�'=>'N', '�'=>'O', '�'=>'O', '�'=>'O',
            '�'=>'O', '�'=>'O', '�'=>'O', '�'=>'U', '�'=>'U', '�'=>'U', '�'=>'U', '�'=>'Y', '�'=>'B', '�'=>'Ss',
            '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'c', '�'=>'e', '�'=>'e',
            '�'=>'e', '�'=>'e', '�'=>'i', '�'=>'i', '�'=>'i', '�'=>'i', '�'=>'o', '�'=>'n', '�'=>'o', '�'=>'o',
            '�'=>'o', '�'=>'o', '�'=>'o', '�'=>'o', '�'=>'u', '�'=>'u', '�'=>'u', '�'=>'y', '�'=>'y', '�'=>'b',
            '�'=>'y', 'R'=>'R', 'r'=>'r', '/' => '-', ' ' => '-', '&'=>'e'
    );

    // -- Remove duplicated spaces
    $stripped = preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $string);

    // -- Returns the slug
    return strtolower(strtr($string, $table));


}
$nomedosite = friendlyUrl($configuracoes['nomedosite']);
?>
<?php
if(($_GET['tabdef'] == '2') or ($_POST['tabdef'] == '2')){
$tabdef1 ='class="tab"';
$tabdefs1 ='class="tab-content"';
$tabdef2 ='class="default-tab"';
$tabdefs2 ='class="tab-content default-tab"';
}else{
$tabdef1 ='class="default-tab"';
$tabdefs1 ='class="tab-content default-tab"';
$tabdef2 ='class="tab"';
$tabdefs2 ='class="tab-content"';
}


//editar op�oes>>
if ((isset($_POST["editarform"])) && ($_POST["editarform"] == "editarnovo")) {

$nomedocanal = strip_tags(mysql_real_escape_string($_POST['nomedocanal']));
$tipodocanal = strip_tags(mysql_real_escape_string($_POST['tipodocanal']));
$linkdocanal = $_POST['linkdocanal'];
$hiddenField = strip_tags(mysql_real_escape_string($_POST['hiddenField']));
$result = urldecode ($linkdocanal);
$retorno = strip_tags(mysql_real_escape_string($_POST['retorno']));

$updateSQL = sprintf("UPDATE dados_beta SET `nome_do_canal`='$nomedocanal', tipo='$tipodocanal', linkdcanal='$result' WHERE ID='$hiddenField'");

$Result1 = mysql_query($updateSQL) or die(mysql_error());
$insertGoTo = "$retorno";
header(sprintf("Location: %s", $insertGoTo));
}
//fim editar op�oes<<<<

//pagina�ao e busca>>
$editFormAction = $_SERVER['PHP_SELF']; 
if (isset($_SERVER['QUERY_STRING'])) { 
$editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']); 
}
	
$get    = strip_tags(mysql_real_escape_string(utf8_decode($_GET['busca'])));
$pagina = strip_tags(mysql_real_escape_string($_GET['pagina']));
if(!empty($pagina)){
}else{
$pagina = 1;
}

$get1    = strip_tags(mysql_real_escape_string(utf8_decode($_GET['busca1'])));
$pagina1 = strip_tags(mysql_real_escape_string($_GET['pagina1']));
if(!empty($pagina1)){
}else{
$pagina1 = 1;
}
     
// DEFINA AQUI O LIMITE DE RESULTADOS POR P�GINA             
$inicio = 0;
$limite = 4;

if($pagina != ''){ $inicio = ($pagina - 1) * $limite;}

// DEFINA AQUI O LIMITE DE RESULTADOS POR P�GINA             
$inicio1 = 0;
$limite1 = 4;

if($pagina1 != ''){ $inicio1 = ($pagina1 - 1) * $limite1;}

$sql = mysql_query("SELECT * from foradoar ORDER BY tempo ASC LIMIT $inicio, $limite") or die("Erro ao consultar");
$sql2 = mysql_query("SELECT * from foradoar ORDER BY tempo ASC LIMIT $inicio, $limite") or die("Erro ao consultar");
    
$sqlContar = mysql_query("SELECT * from foradoar") or die("Erro ao consultar");
$total = mysql_num_rows($sqlContar);
 
//fim pagina�ao e busca<<

//deletar registro
if ((isset($_GET['deletar'])) && ($_GET['deletar'] != "")) {

$iddelete = $_GET['deletar'];
$retorno = 'http://'.base64_decode($_GET['retorna']);

mysql_query("DELETE FROM foradoar WHERE id=$iddelete");

header(sprintf("Location: %s", $retorno));
exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		
		<!--                       CSS                       -->
	  
		<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />
		
		<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
		<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />	
		
		<!-- Colour Schemes
	  
		Default colour scheme is green. Uncomment prefered stylesheet to use it.
		
		<link rel="stylesheet" href="resources/css/blue.css" type="text/css" media="screen" />
		
		<link rel="stylesheet" href="resources/css/red.css" type="text/css" media="screen" />  
	 
		-->
		
		<!-- Internet Explorer Fixes Stylesheet -->
		
		<!--[if lte IE 7]>
			<link rel="stylesheet" href="resources/css/ie.css" type="text/css" media="screen" />
		<![endif]-->
		
		<!--                       Javascripts                       -->
  
		<!-- jQuery -->
		<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>
		
		<!-- jQuery Configuration -->
		<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>
		
		<!-- Facebox jQuery Plugin -->
		<script type="text/javascript" src="resources/scripts/facebox.js"></script>
		
		<!--[if IE]><script type="text/javascript" src="resources/scripts/jquery.bgiframe.js"></script><![endif]-->

			<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
		<!-- Internet Explorer .png-fix -->
		
		<!--[if IE 6]>
			<script type="text/javascript" src="resources/scripts/DD_belatedPNG_0.0.7a.js"></script>
			<script type="text/javascript">
				DD_belatedPNG.fix('.png_bg, img, li');
			</script>
		<![endif]-->
		<script language="javascript">
<!-- chama a fun��o (nomeform) -->
function valida_dados (novoform1)
{
    if (novoform1.nome.value=="")
    {
        alert ("Por favor digite o nome.");
        return false;
    }
	
	if (novoform1.arquivo.value=="")
    {
        alert ("Por favor fa�a upload da imagem.");
        return false;
    }
	
	if (novoform1.urlcanal.value=="")
    {
        alert ("Por favor coloque a url, rtmp ou wmp.");
        return false;
    }
    
return true;
}
</script>
	</head>
  
	<body><div id="body-wrapper"> <!-- Wrapper for the radial gradient background -->
		
		<div id="sidebar"><div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
			
			<h1 id="sidebar-title"><a href="#">Simpla Admin</a></h1>
		  
			<!-- Logo (221px wide) -->
			<a href="#"><img id="logo" src="resources/images/logo.png" alt="Simpla Admin logo" /></a>
		  
			<!-- Sidebar Profile links -->
			<div id="profile-links">
				<?php require_once('top.php'); ?>
			</div>        
			
			<ul id="main-nav">  <!-- Accordion Menu -->
				
				<?php require_once('mnu.php'); ?>
				
			</ul> <!-- End #main-nav -->
			
		</div></div> <!-- End #sidebar -->
		
		<div id="main-content"> <!-- Main Content Section with everything -->
			
			<noscript> <!-- Show a notification if the user has disabled javascript -->
				<div class="notification error png_bg">
					<div>
						Javascript is disabled or is not supported by your browser. Please <a href="http://browsehappy.com/" title="Upgrade to a better browser">upgrade</a> your browser or <a href="http://www.google.com/support/bin/answer.py?answer=23852" title="Enable Javascript in your browser">enable</a> Javascript to navigate the interface properly.</div>
				</div>
			</noscript>
			
			<!-- Page Head -->
			
			<div class="clear"></div> <!-- End .clear -->
			
			<div class="content-box"><!-- Start Content Box -->
				
				<div class="content-box-header">
					
					<h3><? echo 'Resultados: '.$total; ?></h3>
					
					<ul class="content-box-tabs">
						<li><a href="#tab1" <? echo $tabdef1; ?>>Canais fora do ar</a></li><!-- href must be unique and match the id of target div -->
					</ul>
					
					<div class="clear"></div>
					
				</div> <!-- End .content-box-header -->
				
				<div class="content-box-content">
					
					<div <? echo $tabdefs1; ?> id="tab1" > <!-- This is the target div. id must match the href of this div's tab -->
						
						<table>
							

							<thead>
								<tr>
								   <th width="15%">Imagem</th>
								   <th width="15%">nome</th>
								   <th width="15%">Categoria</th>
								   <th width="15%">Tipo</th>
								   <th width="15%">Tecnologia</th>
								   <th width="13%">Ativo</th>
								   <th width="12%">Op�oes</th>
								</tr>
								
							</thead>
							<tbody>
	<?
           while($res = mysql_fetch_array($sql)){
		   $sql22 = mysql_query("SELECT * from dados_beta WHERE ID='".$res['id']."'") or die("Erro ao consultar");
		   $res = mysql_fetch_array($sql22);
		   
		   
    ?>
	<tr>
									<td><img src="<?php
									if($res['form'] == 'opt'){
	$sql4581 = "SELECT * FROM dados_beta WHERE nome_foto='".$res['categoria']."' AND lugar='canais' LIMIT 1";
                    $query4581 = mysql_query($sql4581);
                    while($sqla4581 = mysql_fetch_array($query4581)){
					if($sqla4581['ligar'] == 'n'){
					$imagem1 = linkico($sqla4581['vip'], $sqla4581['url_do_canal']);
					$hr = $sqla4581['categoria'];
					}
					if($sqla4581['ligar'] == 's'){
					$imagem1 = linkico($sqla4581['vip'], $sqla4581['url_do_canal']);
					$hr = $sqla4581['categoria'];
					}
					}
	}else{
	$imagem1 = linkico($res['vip'], $res['url_do_canal']);
	$hr = $res['categoria'];
	}
         if($hr == variedades ) {  
              $resp = "variedades / abertos";  
         }
		 if ($hr == cinema ){  
              $resp = "cinema / series";  
         }
		 if ($hr == esportes ){  
              $resp = "esportes";  
         }
		 if ($hr == infantil ){  
              $resp = "infantil / desenhos";  
         }
		 if ($hr == clipes ){  
              $resp = "clipes / musicas";  
         }
		 if ($hr == religiosos ){  
              $resp = "religiosos";  
         }
		 if ($hr == documentarios ){  
              $resp = "documentarios";  
         }
		 if ($hr == noticias ){  
              $resp = "noticias";  
         }
		 $tipo4444 = $res['vip'];
         $hr = $tipo4444;
         if($hr == s ) {  
              $resp2 = "vip";  
         }
		 if ($hr == n ){  
              $resp2 = "aberto";  
         }
		 if ($hr == na ){  
              $resp2 = "aberto e vip";  
         }
echo $imagem1; ?>" width="70" height="50" /></td>
									<td><?php echo $res['nome_do_canal']; ?></td>
									<td><?php echo $resp; ?></td>
									<td><?php echo $resp2; ?></td>
									<td><?php echo  $res['tipo']; ?></td>
									<td><?php echo  $res['ligar']; ?></td>
									<td>
										<a title='Editar' href='#<? echo $res['ID']; ?>' rel='modal'><img src='resources/images/icons/hammer_screwdriver.png' alt='Editar' /></a>
										<? if($result1258 == 0){ ?><a href='?deletar=<? echo $res['ID']; ?>&retorna=<? echo base64_encode($_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']); ?>' title='Deletar aviso' onclick="return confirm('Excluir aviso do canal <? echo $res['nome_do_canal']; ?> ?')"><img src='resources/images/icons/cross.png' alt='Deletar aviso' /></a><? } ?>
						 <a title='testar canal' target="_blank" href='ver.php?id=<? echo $res['ID']; ?>'><img src='resources/images/icons/lupa.png' alt='testar canal' /></a>
									</td>
									
							  </tr>
					
                                </tr>
	<? } ?>

	
	
	
	
	
	
	

							</tbody>
						<tfoot>
								<tr>
									<td colspan="7">
										<div class="bulk-actions align-left" style="margin-right:20px;">
										</div>
										
										<?php
	$menos = $pagina - 1;
    $mais  = $pagina + 1;
 
    $pgs = ceil($total / $limite);
 
    if($pgs > 1 ){
    echo '<div class="pagination">';
 
    if($menos > 0){ echo "<a href=".$_SERVER['PHP_SELF']."?pagina=$menos>&laquo; Anterior</a> ";}
 
	for($i=1;$i <= $pgs;$i++){
	  if($i != $pagina) {
		  echo " <a style=\"margin-bottom:15px;\" class=\"number\" href=".$_SERVER['PHP_SELF']."?pagina=".($i).">$i</a> ";
	  } else {
		  echo " <a style=\"margin-bottom:15px;\" class=\"number current\" href=".$_SERVER['PHP_SELF']."?pagina=".($i).">".$i."</a> ";
	  }
	}
 
	if($mais <= $pgs){
		echo " <a href=".$_SERVER['PHP_SELF']."?&pagina=$mais>Pr�xima &raquo;</a>";
	}
	echo '<div>';
    }
    ?> 
								
										<div class="clear"></div>
									</td>
								</tr>
						  </tfoot>
						</table>
					</div> <!-- End #tab1 -->
					
					<div class="tab-content" id="tab2">
						
					</div> <!-- End #tab2 -->        
					
				</div> <!-- End .content-box-content -->
				
			</div> <!-- End .content-box -->
			<div class="clear"></div>
			
		</div> <!-- End #main-content -->
		
	</div>
	<?
           while($res = mysql_fetch_array($sql2)){
		   $sql22 = mysql_query("SELECT * from dados_beta WHERE ID='".$res['id']."'") or die("Erro ao consultar");
		   $res = mysql_fetch_array($sql22);
		   $varios = $res;
		   
		   
    ?>
	<div id="<? echo $varios['ID']; ?>" style="display:none;">
							 
							 <form action="<?php echo $editFormAction; ?>" id="editarnovo" name="editarnovo" method="POST" enctype="multipart/form-data">
  <input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $varios['ID']; ?>" />
  
  <label>Nome do canal*e</label> 
  <input name="nomedocanal" type="text" id="nomedocanal" size="30" value="<?php echo $varios['nome_do_canal']; ?>" />
  
  <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
	  <?php
         $hr = $varios['tipo'];
         if($hr == iframe ) {  
              $resp1 = "checked='checked'"; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == rtmp ) {
			  $resp1 = ""; 
			  $resp2 = "checked='checked'";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == wmp ) {
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "checked='checked'";

			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == livestream ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "checked='checked'";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == embed ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "checked='checked'";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == m3u8 ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "checked='checked'";
			  $resp7 = "";
         }
		 if ($hr == swf ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "checked='checked'";
         }
    ?>
	                    <input type="radio" name="tipodocanal" id="tipodocanal" value="iframe" <?php echo  "$resp1"; ?>>iframe (url)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp2"; ?> value="rtmp">rtmp (streaming)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp3"; ?> value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp4"; ?> value="livestream">Livestream.com
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp5"; ?> value="embed">Embed
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp6"; ?> value="m3u8">m3u8(playlist)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp7"; ?> value="swf">swf
						
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label>
	<textarea name="linkdocanal" cols="30" rows="2" id="linkdocanal"><?php echo $varios['linkdcanal']; ?></textarea>
	
	   <br>
        
        <div align="center">

          <input type="submit" class="button" name="button" id="button" value="Salvar" />
        </div>

  <p>
    <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME']; if (strpos($_SERVER ['REQUEST_URI'], 'tabdef=2')){ echo str_replace('tabdef=2', "", $_SERVER ['REQUEST_URI']);} else{ echo $_SERVER ['REQUEST_URI'];} ?>" /> 
    <input type="hidden" name="editarform" value="editarnovo" />
</p> 
</form>
							 
							 </div>
	<? } ?>
	</body>
</html>