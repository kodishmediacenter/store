<?php 
ob_start();

include '../painel/comfig.php';
page_protect();

if(!checkAdmin()) {
header("Location: login.php");
exit();
}

$page_limit = 10; 
$data = date("y-m-d");


$host  = $_SERVER['HTTP_HOST'];
$host_upper = strtoupper($host);
$login_path = @ereg_replace('admin','',dirname($_SERVER['PHP_SELF']));
$path   = rtrim($login_path, '/\\');

// filter GET values
foreach($_GET as $key => $value) {
	$get[$key] = filter($value);
}

foreach($_POST as $key => $value) {
	$post[$key] = filter($value);
}

if($post['doBan'] == 'Banir') {

if(!empty($_POST['u'])) {
	foreach ($_POST['u'] as $uid) {
		$id = filter($uid);
		mysql_query("update users set banned='1' where id='$id' and `user_name` <> 'admin'");
	}
 }
 $ret = $_SERVER['PHP_SELF'] . '?'.$_POST['query_str'];;
 
 header("Location: $ret");
 exit();
}

if($_POST['doUnban'] == 'Desbanir') {

if(!empty($_POST['u'])) {
	foreach ($_POST['u'] as $uid) {
		$id = filter($uid);
		mysql_query("update users set banned='0' where id='$id'");
	}
 }
 $ret = $_SERVER['PHP_SELF'] . '?'.$_POST['query_str'];;
 
 header("Location: $ret");
 exit();
}

if($_POST['doDelete'] == 'Delete') {

if(!empty($_POST['u'])) {
	foreach ($_POST['u'] as $uid) {
		$id = filter($uid);
		mysql_query("delete from users where id='$id' and `user_name` <> 'admin'");
	}
 }
 $ret = $_SERVER['PHP_SELF'] . '?'.$_POST['query_str'];;
 
 header("Location: $ret");
 exit();
}

if($_POST['doApprove'] == 'Aprovar') {

if(!empty($_POST['u'])) {
	foreach ($_POST['u'] as $uid) {
		$id = filter($uid);
		mysql_query("update users set approved='1' where id='$id'");
		
	list($to_email) = mysql_fetch_row(mysql_query("select user_email from users where id='$uid'"));	
 
$message = 
utf8_encode("Ola \n
Obrigado por se cadastrar conosco. Sua conta foi ativada...\n

*****LOGIN LINK*****\n
$siteurl/painel/login.php

Obrigado

Administrador
$host_upper
______________________________________________________
ESTA � UMA RESPOSTA AUTOM�TICA. 
***N�O RESPONDA A ESTE E-MAIL****
");

@mail($to_email, "Ativa��o de Usu�rio", $message,
    "From: \"Inscri��o de membro\" <auto-reply@$host>\r\n" .
     "X-Mailer: PHP/" . phpversion()); 
	 
	}
 }
 
 $ret = $_SERVER['PHP_SELF'] . '?'.$_POST['query_str'];	 
 header("Location: $ret");
 exit();
}

$rs_all = mysql_query("select count(*) as total_all from users") or die(mysql_error());
$rs_active = mysql_query("select count(*) as total_active from users where approved='1'") or die(mysql_error());
$rs_total_pending = mysql_query("select count(*) as tot from users where approved='0'");						   

list($total_pending) = mysql_fetch_row($rs_total_pending);
list($all) = mysql_fetch_row($rs_all);
list($active) = mysql_fetch_row($rs_active);


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
				
		<!--                       CSS                       -->
	  
		<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />
		
		<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
		<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />	
		<link href="../vip/styles.css" rel="stylesheet" type="text/css">
		
		<!-- Colour Schemes
	  
		Default colour scheme is green. Uncomment prefered stylesheet to use it.
		
		<link rel="stylesheet" href="resources/css/blue.css" type="text/css" media="screen" />
		
		<link rel="stylesheet" href="resources/css/red.css" type="text/css" media="screen" />  
	 
		-->
		
		<!-- Internet Explorer Fixes Stylesheet -->
		
		<!--[if lte IE 7]>
			<link rel="stylesheet" href="resources/css/ie.css" type="text/css" media="screen" />
		<![endif]-->
		
		<!--                       Javascripts                       -->
  
		<!-- jQuery -->
		<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>
		 <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script>
<script>
/* Portuguese initialisation for the jQuery UI date picker plugin. */
jQuery(function ($) {
    $.datepicker.regional['pt'] = {
        closeText: 'Fechar',
        prevText: '<Anterior',
        nextText: 'Seguinte',
        currentText: 'Hoje',
        monthNames: ['Janeiro', 'Fevereiro', 'Mar&ccedil;o', 'Abril', 'Maio', 'Junho',
        'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
        'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
        dayNames: ['Domingo', 'Segunda-feira', 'Ter&ccedil;a-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'S&aacute;bado'],
        dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'S&aacute;b'],
        dayNamesMin: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'S&aacute;b'],
        weekHeader: 'Sem',
        dateFormat: 'yy-mm-dd',
        firstDay: 0,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''
    };
    $.datepicker.setDefaults($.datepicker.regional['pt']);
});
$(function() {
$( ".ui-datepicker-trigger" ).datepicker();
});
</script>
		
		<!-- jQuery Configuration -->
		<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>
		<!--[if IE]><script type="text/javascript" src="resources/scripts/jquery.bgiframe.js"></script><![endif]-->

		
		<!-- Internet Explorer .png-fix -->
		
		<!--[if IE 6]>
			<script type="text/javascript" src="resources/scripts/DD_belatedPNG_0.0.7a.js"></script>
			<script type="text/javascript">
				DD_belatedPNG.fix('.png_bg, img, li');
			</script>
		<![endif]-->
		
	</head>
  
	<body><div id="body-wrapper"> <!-- Wrapper for the radial gradient background -->
		
		<div id="sidebar"><div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
			
			<h1 id="sidebar-title"><a href="#">Simpla Admin</a></h1>
		  
			<!-- Logo (221px wide) -->
			<a href="#"><img id="logo" src="resources/images/logo.png" alt="Simpla Admin logo" /></a>
		  
			<!-- Sidebar Profile links -->
			<div id="profile-links">
				<?php require_once('top.php'); ?>
			</div>        
			
			<ul id="main-nav">  <!-- Accordion Menu -->
				
				<?php require_once('mnu.php'); ?>
				
			</ul> <!-- End #main-nav -->
			
			
		</div></div> <!-- End #sidebar -->
		
		<div id="main-content"> <!-- Main Content Section with everything -->
			
			<noscript> <!-- Show a notification if the user has disabled javascript -->
				<div class="notification error png_bg">
					<div>
						Javascript is disabled or is not supported by your browser. Please <a href="http://browsehappy.com/" title="Upgrade to a better browser">upgrade</a> your browser or <a href="http://www.google.com/support/bin/answer.py?answer=23852" title="Enable Javascript in your browser">enable</a> Javascript to navigate the interface properly.
					</div>
				</div>
			</noscript>
			
			<!-- Page Head -->
			
			<div class="clear"></div> <!-- End .clear -->
			
			<div class="content-box"><!-- Start Content Box -->
				
				<div class="content-box-header">
					
					<h3>Usu&aacute;rios</h3>
					
					<ul class="content-box-tabs">
					</ul>
					
					<div class="clear"></div>
					
			  </div> <!-- End .content-box-header -->
				
				<div class="content-box-content">
					
					<div class="tab-content default-tab" id="tab1"> <!-- This is the target div. id must match the href of this div's tab -->
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="74%" valign="top" style="padding: 10px;">
      <table width="100%" border="0" cellpadding="5" cellspacing="0" class="myaccount">
        <tr>
          <td>Total de usu&aacute;rios: <?php echo $all;?></td>
          <td>Usu&aacute;rios ativos : <?php echo $active; ?></td>
          <td>Usu&aacute;rios pendentes : <?php echo $total_pending; ?></td>
        </tr>
      </table>
      <p><?php 
	  if(!empty($msg)) {
	  echo $msg[0];
	  }
	  ?></p>
      <table width="80%" border="0" align="center" cellpadding="10" cellspacing="0" style="background-color: #E4F8FA;padding: 2px 5px;" >
        <tr>
          <td><form name="form1" method="get" action="us.php">
              <p align="center">Buscar 
                <input name="q" type="text" id="q" size="40">
                <br>
                [Coloque o email ou nome de usuario] </p>
              <p align="center"> 
                <input type="radio" name="qoption" value="pending">
                Usu&aacute;rios pendentes
                <input type="radio" name="qoption" value="recent">
                <span id="result_box" lang="pt" xml:lang="pt">Registrados recentemente</span>
                <input type="radio" name="qoption" value="banned">
                <span id="result_box" lang="pt" xml:lang="pt">Usu&aacute;rios banidos</span><br>
                <br>
                [<span id="result_box" lang="pt" xml:lang="pt">Voc&ecirc; pode deixar em branco a pesquisa, se voc&ecirc; usar as op&ccedil;&otilde;es acima</span>]</p>
              <p align="center"> 
                <input name="doSearch" type="submit" id="doSearch2" value="Buscar">
              </p>
              </form></td>
        </tr>
      </table>
      <p>
        <?php if ($get['doSearch'] == 'Buscar') {
	  $cond = '';
	  if($get['qoption'] == 'pending') {
	  $cond = "where `approved`='0' order by date desc";
	  }
	  if($get['qoption'] == 'recent') {
	  $cond = "order by id desc";
	  }
	  if($get['qoption'] == 'banned') {
	  $cond = "where `banned`='1' order by date desc";
	  }
	  
	  if($get['q'] == '') { 
	  $sql = "select * from users $cond"; 
	  } 
	  else { 
	  $sql = "select * from users where `user_email` = '$_REQUEST[q]' or `user_name`='$_REQUEST[q]' ";
	  }

	  
	  $rs_total = mysql_query($sql) or die(mysql_error());
	  $total = mysql_num_rows($rs_total);
	  
	  if (!isset($_GET['page']) )
		{ $start=0; } else
		{ $start = ($_GET['page'] - 1) * $page_limit; }
	  
	  $rs_results = mysql_query($sql . " limit $start,$page_limit") or die(mysql_error());
	  $total_pages = ceil($total/$page_limit);
	  
	  ?>
      <p><span id="result_box" lang="pt" xml:lang="pt">Aprovar -&gt; Um e-mail de notifica&ccedil;&atilde;o ser&aacute; enviado para ativa&ccedil;&atilde;o notificando usu&aacute;rio.<br />
        Banir -&gt; Nenhum e-mail de notifica&ccedil;&atilde;o ser&aacute; enviada para o usu&aacute;rio.</span>
      <p><span id="result_box" lang="pt" xml:lang="pt">* Nota: Uma vez que o usu&aacute;rio foi banido, ele / ela nunca ser&aacute; capaz de registrar uma nova conta com o mesmo endere&ccedil;o de e-mail.</span>
      <p align="right"> 
        <?php 
	  
	  // outputting the pages
		if ($total > $page_limit)
		{
		echo "<div><strong>Pages:</strong> ";
		$i = 0;
		while ($i < $page_limit)
		{
		
		
		$page_no = $i+1;
		$qstr = ereg_replace("&page=[0-9]+","",$_SERVER['QUERY_STRING']);
		echo "<a href=\"us.php?$qstr&page=$page_no\">$page_no</a> ";
		$i++;
		}
		echo "</div>";
		}  ?>
		</p>
		<form name "searchform" action="us.php" method="post">
        <table width="100%" border="0" align="center" cellpadding="2" cellspacing="0">
          <tr bgcolor="#E6F3F9"> 
            <td width="4%"><strong>ID</strong></td>
            <td> <strong>Data</strong></td>
            <td><div align="center"><strong>Nome de usu&aacute;rio</strong></div></td>
            <td width="24%"><strong>Email</strong></td>
            <td width="10%"><strong>Aprovado</strong></td>
            <td width="10%"> <strong>Banido</strong></td>
            <td width="25%">&nbsp;</td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td width="10%">&nbsp;</td>
            <td width="17%"><div align="center"></div></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <?php while ($rrows = mysql_fetch_array($rs_results)) {?>
          <tr> 
            <td><input name="u[]" type="checkbox" value="<?php echo $rrows['id']; ?>" id="u[]"></td>
            <td><?php echo $rrows['date']; ?></td>
            <td> <div align="center"><?php echo $rrows['user_name'];?></div></td>
            <td><?php echo $rrows['user_email']; ?></td>
            <td> <span id="Aprovar<?php echo $rrows['id']; ?>"> 
              <?php if(!$rrows['approved']) { echo "Pendente"; } else {echo "Ativo"; }?>
              </span> </td>
            <td><span id="banir<?php echo $rrows['id']; ?>"> 
              <?php if(!$rrows['banned']) { echo "Nao"; } else {echo "Sim"; }?>
              </span> </td>
            <td> <font size="2"><a href="javascript:void(0);" onclick='$.get("do.php",{ cmd: "Aprovar", id: "<?php echo $rrows['id']; ?>" } ,function(data){ $("#Aprovar<?php echo $rrows['id']; ?>").html(data); });'>Aprovar</a> 
              <a href="javascript:void(0);" onclick='$.get("do.php",{ cmd: "banir", id: "<?php echo $rrows['id']; ?>" } ,function(data){ $("#banir<?php echo $rrows['id']; ?>").html(data); });'>Banir</a> 
              <a href="javascript:void(0);" onclick='$.get("do.php",{ cmd: "desbanir", id: "<?php echo $rrows['id']; ?>" } ,function(data){ $("#banir<?php echo $rrows['id']; ?>").html(data); });'>Desbanir</a> 
              <a href="javascript:void(0);" onclick='$("#edit<?php echo $rrows['id'];?>").show("slow");'>Editar</a> 
              </font> </td>
          </tr>
          <tr> 
            <td colspan="7">
			
			<div style="display:none;font: normal 11px arial; padding:10px; background: #e6f3f9" id="edit<?php echo $rrows['id']; ?>">
			
			<input type="hidden" name="id<?php echo $rrows['id']; ?>" id="id<?php echo $rrows['id']; ?>" value="<?php echo $rrows['id']; ?>">
			Usu&aacute;rio: <input name="user_name<?php echo $rrows['id']; ?>" id="user_name<?php echo $rrows['id']; ?>" type="text" size="10" value="<?php echo $rrows['user_name']; ?>" >
			Email:<input id="user_email<?php echo $rrows['id']; ?>" name="user_email<?php echo $rrows['id']; ?>" type="text" size="20" value="<?php echo $rrows['user_email']; ?>" >Vencimento De:<input id="data<?php echo $rrows['id']; ?>" class="ui-datepicker-trigger" name="data<?php echo $rrows['id']; ?>" type="text" size="20" value="<?php echo $rrows['data']; ?>" >At�:<input id="vencimento<?php echo $rrows['id']; ?>" class="ui-datepicker-trigger" name="vencimento<?php echo $rrows['id']; ?>" type="text" size="20" value="<?php echo $rrows['vencimento']; ?>" >
			Level: <input id="user_level<?php echo $rrows['id']; ?>" name="user_level<?php echo $rrows['id']; ?>" type="text" size="5" value="<?php echo $rrows['user_level']; ?>" > 1->usu&aacute;rio,5->admin
			<br><br>Nova senha: <input id="pass<?php echo $rrows['id']; ?>" name="pass<?php echo $rrows['id']; ?>" type="text" size="20" value="" > (deixe em branco)
			<input name="doSave" type="button" id="doSave" value="Salvar" 
			onclick='$.get("do.php",{ cmd: "edit", pass:$("input#pass<?php echo $rrows['id']; ?>").val(),user_level:$("input#user_level<?php echo $rrows['id']; ?>").val(),user_email:$("input#user_email<?php echo $rrows['id']; ?>").val(),data:$("input#data<?php echo $rrows['id']; ?>").val(),vencimento:$("input#vencimento<?php echo $rrows['id']; ?>").val(),user_name: $("input#user_name<?php echo $rrows['id']; ?>").val(),id: $("input#id<?php echo $rrows['id']; ?>").val() } ,function(data){ $("#msg<?php echo $rrows['id']; ?>").html(data); });'> 
			<a  onclick='$("#edit<?php echo $rrows['id'];?>").hide();' href="javascript:void(0);">Fechar</a>
		 
		  <div style="color:red" id="msg<?php echo $rrows['id']; ?>" name="msg<?php echo $rrows['id']; ?>"></div>
		  </div>		  </td>
          </tr>
          <?php } ?>
        </table>
	    <p><br>
          <input name="doApprove" type="submit" id="doApprove" value="Aprovar">
          <input name="doBan" type="submit" id="doBan" value="Banir">
          <input name="doUnban" type="submit" id="doUnban" value="Desbanir">
          <input name="doDelete" type="submit" id="doDelete" value="Delete">
          <input name="query_str" type="hidden" id="query_str" value="<?php echo $_SERVER['QUERY_STRING']; ?>">
          <span id="result_box" lang="pt" xml:lang="pt">Nota: Se voc&ecirc; excluir o usu&aacute;rio pode registrar novamente, em vez disso bani o usu&aacute;rio.</span></p>
      </form>
	  
	  <?php } ?>
      &nbsp;</p>
	  <?php
	  if($_POST['doSubmit'] == 'Criar')
{
$rs_dup = mysql_query("select count(*) as total from users where user_name='$post[user_name]' OR user_email='$post[user_email]'") or die(mysql_error());
list($dups) = mysql_fetch_row($rs_dup);

if($dups > 0) {
	die("O nome de usu�rio ou e-mail j� existe no sistema");
	}

if(!empty($_POST['pwd'])) {
  $pwd = $post['pwd'];	
  $hash = PwdHash($post['pwd']);
 }  
 else
 {
  $pwd = GenPwd();
  $hash = PwdHash($pwd);
  
 }
 
mysql_query("INSERT INTO users (`user_name`,`full_name`,`user_email`,`pwd`,`approved`,`date`,`user_level`,`data`,`vencimento`)
			 VALUES ('$post[user_name]','$post[user_name]','$post[user_email]','$hash','1',now(),'$post[user_level]','$data','$post[vencimento]')
			 ") or die(mysql_error()); 


$message = 
utf8_encode("Ola \n
Obrigado por se cadastrar conosco. Aqui est�o os detalhes de login...\n

Usu�rio: $user_name
Email: $post[user_email] \n 
Senha: $pwd \n

*****LOGIN LINK*****\n
$siteurl/painel/login.php

Obrigado

Administrador
$host_upper
______________________________________________________
ESTA � UMA RESPOSTA AUTOM�TICA. 
***N�O RESPONDA A ESTE E-MAIL****
");

if($_POST['send'] == '1') {

	mail($post['user_email'], "Dados de Acesso", $message,
    "From: \"Inscri��o de membro\" <auto-reply@$host>\r\n" .
     "X-Mailer: PHP/" . phpversion()); 
 }
echo "<div class=\"msg\">Usu�rio criado com senha $pwd....feito.</div>"; 
}

	  ?>
	  
      <h2><font color="#FF0000">Criar novo usuario</font></h2>
      <table width="80%" border="0" cellpadding="5" cellspacing="2" class="myaccount">
        <tr>
          <td><form name="form1" method="post" action="us.php">
              <p>User ID 
                <input name="user_name" type="text" id="user_name">
                (Nome usuario)</p>
              <p>Email 
                <input name="user_email" type="text" id="user_email">
              </p>
              <p>Nivel do usuario
                <select name="user_level" id="user_level">
                  <option value="1">Usuario</option>
                  <option value="5">Admin</option>
                </select>
              </p>
              <p>Senha 
                <input name="pwd" type="text" id="pwd">
                (se estiver vazio uma senha ser� gerada automaticamente)</p>
              <p>
			  <p>Vencimento 
                <input name="vencimento" class="ui-datepicker-trigger" type="text" id="vencimento"></p>
              <p> 
                <input name="send" type="checkbox" id="send" value="1" checked>
                Enviar email</p>
              <p> 
                <input name="doSubmit" type="submit" id="doSubmit" value="Criar">
              </p>
            </form>
            <p>** Todos os usu�rios criados ser�o aprovados por padr�o.</p></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
  </tr>
</table>

				  </div> 
					<!-- End #tab1 -->
					
				  <div class="tab-content" id="tab2"></div> 
					<!-- End #tab2 -->        
					
				</div> <!-- End .content-box-content -->
				
			</div>
<div class="clear"></div>
			
			
			<!-- Start Notifications --><!-- End Notifications -->
			
		</div> <!-- End #main-content -->
		
	</div></body>
  

<!-- Download From www.exet.tk-->
</html>
