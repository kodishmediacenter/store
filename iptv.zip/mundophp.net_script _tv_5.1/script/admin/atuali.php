<?php
require_once('../painel/comfig.php');
page_protect();
	  if(!checkAdmin()) {
header("Location: login.php");
exit();
}

$i = 1;
while ($i < 9) {

$separar = 'n';
$linkvip = 'nome_foto';

if(($i == 1) or ($i == 9)){
$categoria = 'variedades';
}
if(($i == 2) or ($i == 10)){
$categoria = 'cinema';
}
if(($i == 3) or ($i == 11)){
$categoria = 'esportes';
}
if(($i == 4) or ($i == 12)){
$categoria = 'infantil';
}
if(($i == 5) or ($i == 13)){
$categoria = 'clipes';
}
if(($i == 6) or ($i == 14)){
$categoria = 'religiosos';
}
if(($i == 7) or ($i == 15)){
$categoria = 'documentarios';
}
if(($i == 8) or ($i == 16)){
$categoria = 'noticias';
}

$checar12451 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' AND categoria='$categoria' ORDER BY ID DESC");
while($res12451 = mysql_fetch_array($checar12451)){
$confere1 = mysql_query("SELECT * from dados_beta WHERE categoria='".$res12451['nome_foto']."' AND ligar='s' AND (vip = '$separar' or vip = 'na') AND lugar='canais' LIMIT 1");
$result12451 = mysql_num_rows($confere1);
if($result12451 == 1){
if(!isset($conta)){
$conta = 'ID = '.$res12451['ID'];
}else{
$conta = $conta.' OR ID = '.$res12451['ID'];
}}}
if(isset($conta)){
$or = '('.$conta.') or ';
}

$checar1245 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' AND categoria='$categoria' AND ligar = 'n' ORDER BY ID DESC");
while($res1245 = mysql_fetch_array($checar1245)){
$confere = mysql_query("SELECT * from dados_beta WHERE categoria='".$res1245['nome_foto']."' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') AND lugar='canais' LIMIT 1");
$result1245 = mysql_num_rows($confere);
if($result1245 == 0){
if(!isset($naoconta)){
$naoconta = 'AND ID !='.$res1245['ID'];
}else{
$naoconta = $naoconta.' AND ID !='.$res1245['ID'];
}}}

$result = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$categoria."' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
$num_rows = mysql_num_rows($result);

$data = array();
while ($row = mysql_fetch_array($result)) {
    array_push($data, $row["url_do_canal"]);
}
?>
<?php
$srcImagePaths = $data;
 
$tileWidth = 70;
$tileHeight = 50;
$numberOfTiles = 7;
$pxBetweenTiles = 1;
$leftOffSet = 1;
$topOffSet = 1;
$new_width = 70;
$new_height = 50;
 
$num_rows = ($num_rows / $numberOfTiles);
$num_rows = ceil($num_rows);
$mapWidth = ($tileWidth + $pxBetweenTiles) * $numberOfTiles + 1;
$mapHeight = ($tileHeight + $pxBetweenTiles) * $num_rows + 1;
 
$mapImage = imagecreatetruecolor($mapWidth, $mapHeight);
 
/*
 *  PUT SRC IMAGES ON BASE IMAGE
 */
 
foreach ($srcImagePaths as $index => $srcImagePath)
{
 list ($x, $y) = indexToCoords($index);
 $arquivo1111 = $srcImagePath;
 $arquivo1111 = pathinfo($arquivo1111, PATHINFO_EXTENSION);
 if($arquivo1111 == 'jpg'){
 $func = imagecreatefromjpeg('../'.$srcImagePath);
 }
 if($arquivo1111 == 'png'){
 $func = imagecreatefrompng('../'.$srcImagePath);
 }
 if($arquivo1111 == 'gif'){
 $func = imagecreatefromgif('../'.$srcImagePath);
 }
 $tileImg = $func;
 
 // Resize
 list($width,$height)=getimagesize('../'.$srcImagePath);
 if(($width != 70) && ($height != 50)){
 $tmp=imagecreatetruecolor($new_width,$new_height);
 imagecopyresampled($tmp,$tileImg,0,0,0,0,$new_width,$new_height,$width,$height);
 imagecopy($mapImage, $tmp, $x, $y, 0, 0, $tileWidth, $tileHeight);
 imagedestroy($tmp);
 }else{
 imagecopy($mapImage, $tileImg, $x, $y, 0, 0, $tileWidth, $tileHeight);
 }
 imagedestroy($tileImg);
 }
 
/*
 * RESCALE TO THUMB FORMAT
 */

if($separar == 's'){
$path = 'vip';
}else{
$path = 'aberto';
}
$link = $_SERVER['DOCUMENT_ROOT'].'/icones/'.$path.'/'.$categoria.'.jpeg';
imagejpeg($mapImage, $link, 90);
$i++;
}
?>