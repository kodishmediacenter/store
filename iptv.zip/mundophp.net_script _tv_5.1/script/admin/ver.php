<? ob_start(); 
require_once('../painel/comfig.php');
page_protect();
if(!checkAdmin()) {
header("Location: ../painel/login.php");
exit();
}     
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<script src="/js/jquery.js"></script>
        		 <link rel="stylesheet" type="text/css" href="/css/jquery.fancybox.css" />
        <link rel="stylesheet" type="text/css" href="/css/jquery.fancybox-buttons.css"  />
        <script type="text/javascript" src="/js/jquery.fancybox.js"></script>
        <script type="text/javascript" src="/js/jquery.fancybox-buttons.js"></script>
</head>

<body>
<?php    
         $id = trim(strip_tags(mysql_real_escape_string($_GET['id'])));
         if(!empty($id)){
         if (is_numeric($id)) {
         $sql22 = mysql_query("SELECT * from dados_beta WHERE ID='".$id."'") or die("Erro ao consultar");
		 $varios = mysql_fetch_array($sql22);
		 $tipo = $varios['tipo'];
         $hr = $tipo;
		 $hr2 = $varios['lugar'];
		 $nome = $varios['nome_do_canal'];
		 $linkcanal = $varios['linkdcanal']; 
		 $linkcanallinha = str_replace("\r\n",";",trim($linkcanal));
		 if ($vip != 'sim'){
		 $logotipo = '/images/logo.png';
		 }
         if(($hr == iframe) && ($hr2 == canais) ) {  
              $resp = "<div id='iframe-holder'><iframe src='$linkcanal'  width='468' marginwidth='0' height='380' marginheight='0' scrolling='no' frameborder='0'></iframe></div>";  
         }
		 if(($hr == iframe) && ($hr2 == menu) ) {  
              $resp = "<iframe src='$linkcanal'  width='468' height='435' scrolling='no' frameborder='0'></iframe>";  
         }
		 if($hr == wmp ) {  
              $resp = "<embed  type='application/x-mplayer2' pluginspage='http://www.microsoft.com/Windows/MediaPlayer/'
                src='$linkcanallinha' align='middle' width='468' height='360' EnableContextMenu='false' ShowStatusBar='true' autostart='true'  defaultframe='rightFrame' id='MediaPlayer2' />";  
         }
		 if($hr == embed ) {  
              $resp = "$linkcanal";
         }
		 if($hr == livestream ) {  
              $resp = "<script type='text/javascript' src='/player/jwplayer.js'></script>
<div id='player_7416'></div>
<script type='text/javascript'>
  jwplayer('player_7416').setup({
    'flashplayer': '/player/playertv2.swf',
	'type':'livestream',
    'file':'$linkcanallinha',
    'livestream.devkey':'".$configuracoes['livestream.com']."',
	'bufferlength':'3',
    'width': '468',
	'stretching':'fill',
    'height': '360',
    'autostart':'true',
	'abouttext':'Player $nome',
    'aboutlink': '$siteurl',
	'logo.margin':'10',
	'skin':'/player/tm2.zip',
	'logo.out':'1',
  });
</script>";  
         }
		 if($hr == m3u8 ) {
		 ?><script src="/player/jwplayer2.js"></script>
        <script>jwplayer.key = "xMRYAL2RatWkKACzmgDbFrKaiLuWS36yA/RBSPYDTf8="</script><? 
              $resp = "<div id='tv'>Carregando o canal $nome</div>
   <script type='text/javascript'>
       jwplayer('tv').setup({
           file: '$linkcanallinha',
	height: 360,
	width: 468,
    autostart: 'true',
	bufferlength: '1',
	flashplayer: '/player/jwplayer.flash.swf',
	html5player: '/player/jwplayer.html5.js',
	abouttext :'Player $nome',
	aboutlink : '$siteurl',
       });
   </script>";  
         }
		 if ($hr == rtmp ){
		?><script src="/player/jwplayer2.js"></script>
        <script>jwplayer.key = "xMRYAL2RatWkKACzmgDbFrKaiLuWS36yA/RBSPYDTf8="</script><?
              $resp = "<div id='tv'>Carregando o canal $nome</div>
   <script type='text/javascript'>
       jwplayer('tv').setup({
           file: '$linkcanallinha',
    flashplayer: '/player/jwplayer.flash.swf',
	html5player: '/player/jwplayer.html5.js',
	height: 360,
	width: 468,
    autostart: 'true',
	stretching: 'exactfit',
	bufferlength: '1',
	abouttext :'Player $nome',
	aboutlink : '$siteurl',
       });
   </script>";  
         }
		 if ($hr == swf ){  
              $resp = "<div id=\"wrap\"><a class=\"abrir\" href=\"$linkcanallinha\"></a></div>
			  <script>
    jQuery(function(){
      jQuery('.abrir').click();
    });
</script>"; 
?>
<script>
/* <![CDATA[ */
$(document).ready(function() {
$(".abrir").click(function(){
parent.$.fancybox({
type: 'html',
width: $( window.parent.document ).width(),
height: $( window.parent.document ).height(),
autoSize: false,
content: '<div id="wrap2"></div>',
beforeClose: function() {
$(".fancybox-inner").unwrap();
},
			helpers: {
				overlay: {
				opacity: 0.3
				} // overlay
			}
}); //fancybox
$(function() {
parent.$("#wrap2").load("/js/swf.php?id=<? echo base64_encode ($varios['linkdcanal']); ?>"); 
}); 
return false;
}); //click	
}); // ready
/* ]]> */
</script>
<? 
         }
		 

         echo  "$resp"; 
}}
?>
</body>
</html>
