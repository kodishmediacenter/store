<?php require_once('../painel/comfig.php');
      require_once('ico.php');
      page_protect();
	  if(!checkAdmin()) {
header("Location: ../painel/login.php");
exit();
}
$unid = uniqid();

function nomeico($extensao){
 $arquivo1111 = pathinfo($extensao, PATHINFO_EXTENSION);
 if($arquivo1111 == 'jpg'){
 return $file = basename($extensao, ".jpg");
 }
 if($arquivo1111 == 'png'){
 return $file = basename($extensao, ".png");
 }
 if($arquivo1111 == 'gif'){
 return $file = basename($extensao, ".gif");
 }
}
function linkico($vip, $link){
global $siteurl;
if($vip==s){ echo $siteurl.'/icones/pequeno/vip/'.nomeico($link).'.jpeg';}
if($vip==n){ echo $siteurl.'/icones/pequeno/aberto/'.nomeico($link).'.jpeg';}
if($vip==na){ echo $siteurl.'/icones/pequeno/aberto/'.nomeico($link).'.jpeg';}
}

function quantidade( $categoria, $separar) {
	$checar12451 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' ORDER BY ID DESC");
while($res12451 = mysql_fetch_array($checar12451)){
$confere1 = mysql_query("SELECT * from dados_beta WHERE categoria='".$res12451['nome_foto']."' AND ligar='s' AND (vip = '$separar' or vip = 'na') AND lugar='canais' LIMIT 1");
$result12451 = mysql_num_rows($confere1);
if($result12451 == 1){
if(!isset($conta)){
$conta = 'ID = '.$res12451['ID'];
}else{
$conta = $conta.' OR ID = '.$res12451['ID'];
}}}
if(isset($conta)){
$or = '('.$conta.') or ';
}

$checar1245 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' AND ligar = 'n' ORDER BY ID DESC");
while($res1245 = mysql_fetch_array($checar1245)){
$confere = mysql_query("SELECT * from dados_beta WHERE categoria='".$res1245['nome_foto']."' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') AND lugar='canais' LIMIT 1");
$result1245 = mysql_num_rows($confere);
if($result1245 == 0){
if(!isset($naoconta)){
$naoconta = 'AND ID !='.$res1245['ID'];
}else{
$naoconta = $naoconta.' AND ID !='.$res1245['ID'];
}}}

    $quantidade = 0;
    $q_canais_variedades = mysql_query("SELECT * FROM dados_beta WHERE categoria = '$categoria' AND lugar LIKE 'canais' AND ($or (vip = '$separar' or vip LIKE 'na')) $naoconta ORDER BY nome_do_canal ASC");
	$limitando = 1;
    while(($canais_variedades = mysql_fetch_object($q_canais_variedades))  && ($limitando<50)){
    
	$checar1 = mysql_query("SELECT * FROM dados_beta WHERE categoria='".$canais_variedades->nome_foto."' $naoconta AND lugar LIKE 'canais' AND ligar='s' AND (vip = '$separar' or vip LIKE 'na') LIMIT 1");
	
    $result1 = mysql_num_rows($checar1);
	if(($result1 == 1) && ($canais_variedades->ligar == 'n')){
	$limitando++;
    while($sql458 = mysql_fetch_array($checar1)){
	
	$quantidade++;
	
	 }} if(($result1 == 1) && ($canais_variedades->ligar == 's')&& ($canais_variedades->vip == 'n') && ($separar == 's')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){

$quantidade++;

 }}  if(($result1 == 1) && ($canais_variedades->ligar == 's') && ($canais_variedades->vip == 's' or $canais_variedades->vip == 'na') && ($separar == 's')){ $limitando++;

$quantidade++;

 }  if(($result1 == 1) && ($canais_variedades->ligar == 's') && ($separar == 'n')){ $limitando++;
while($sql458 = mysql_fetch_array($checar1)){

$quantidade++;

 }}  if(($result1 == 0) && ($canais_variedades->ligar == 's') && ($separar == 'n')){ $limitando++;

$quantidade++;

 } 
  if(($result1 == 0) && ($canais_variedades->ligar == 's') && ($separar == 's')){ $limitando++;

$quantidade++;

 }  } 
 return $quantidade;
 } //fim function quantidade


 function libera( $categoria, $vip) {
 if($vip == 's'){
 return quantidade($categoria, $vip);
 }
 if($vip == 'n'){
 return quantidade($categoria, $vip);
 }
 if($vip == 'na'){
 $aberto = quantidade($categoria, 'n');
 $fechado = quantidade($categoria, 's');
 if(($aberto >= 49) or ($fechado >= 49)){
 return 50;
 }else{
 return 48;
 }
 }
 }//fim function libera

function indexToCoords($index)
{
 global $tileWidth, $pxBetweenTiles, $leftOffSet, $topOffSet, $numberOfTiles;
 
 $x = ($index % 7) * ($tileWidth + $pxBetweenTiles) + $leftOffSet;
 $y = floor($index / 7) * ($tileWidth + $pxBetweenTiles - 20) + $topOffSet;
 return Array($x, $y);
}

function friendlyUrl($string) {

    $table = array(
            '�'=>'S', '�'=>'s', '�'=>'D', 'd'=>'d', '�'=>'Z', '�'=>'z', 'C'=>'C', 'c'=>'c', 'C'=>'C', 'c'=>'c',
            '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'C', '�'=>'E', '�'=>'E',
            '�'=>'E', '�'=>'E', '�'=>'I', '�'=>'I', '�'=>'I', '�'=>'I', '�'=>'N', '�'=>'O', '�'=>'O', '�'=>'O',
            '�'=>'O', '�'=>'O', '�'=>'O', '�'=>'U', '�'=>'U', '�'=>'U', '�'=>'U', '�'=>'Y', '�'=>'B', '�'=>'Ss',
            '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'c', '�'=>'e', '�'=>'e',
            '�'=>'e', '�'=>'e', '�'=>'i', '�'=>'i', '�'=>'i', '�'=>'i', '�'=>'o', '�'=>'n', '�'=>'o', '�'=>'o',
            '�'=>'o', '�'=>'o', '�'=>'o', '�'=>'o', '�'=>'u', '�'=>'u', '�'=>'u', '�'=>'y', '�'=>'y', '�'=>'b',
            '�'=>'y', 'R'=>'R', 'r'=>'r', '/' => '-', ' ' => '-', '&'=>'e'
    );

    // -- Remove duplicated spaces
    $stripped = preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $string);

    // -- Returns the slug
    return strtolower(strtr($string, $table));


}
$nomedosite = friendlyUrl($configuracoes['nomedosite']);
?>
<?php
if(($_GET['tabdef'] == '2') or ($_POST['tabdef'] == '2')){
$tabdef1 ='class="tab"';
$tabdefs1 ='class="tab-content"';
$tabdef2 ='class="default-tab"';
$tabdefs2 ='class="tab-content default-tab"';
}else{
$tabdef1 ='class="default-tab"';
$tabdefs1 ='class="tab-content default-tab"';
$tabdef2 ='class="tab"';
$tabdefs2 ='class="tab-content"';
}

//verifica�ao quantidade de canais cadastro>>>
$informa = strip_tags(mysql_real_escape_string($_POST['vip']));
$categoria = strip_tags(mysql_real_escape_string($_POST['categoria']));


if((isset($_POST["MM_insert1"])) && ($_POST["MM_insert1"] == "novoform1")){
$qtd1 = libera($categoria, $informa);
}
//<<fim verifica�ao cadastro

//verifica�ao quantidade de canais cadastro op��o>>>
$informa = strip_tags(mysql_real_escape_string($_POST['vip']));
if((isset($_POST["addopt"])) && ($_POST["addopt"] == "novo")){

$qtd1 = libera($categoria, $informa);

$principalligar = strip_tags(mysql_real_escape_string($_POST['principalligar']));
$principalvip = strip_tags(mysql_real_escape_string($_POST['principalvip']));
$novocvip = strip_tags(mysql_real_escape_string($_POST['vip']));
if(($principalligar == s) && ($principalvip  == $novocvip) ){
$qtd1 = '2';
}
if(($principalligar == s) && ($principalvip  == 'na') ){
$qtd1 = '2';
}
if(($principalvip != $novocvip) && ($principalvip != na) && ($novocvip == na) && ($principalligar == s)){
if(($novocvip == na) && ($principalvip == n)){
$qtd1 = libera($categoria, 's');
}
if(($novocvip == na) && ($principalvip == s)){
$qtd1 = libera($categoria, 'n');
}
}
}
//<<fim verifica�ao cadastro op��o

//verifica�ao quantidade de canais edita op��o>>>
$informa1 = strip_tags(mysql_real_escape_string($_POST['vipedit']));

if((isset($_POST["editarform"])) && ($_POST["editarform"] == "editarnovo")){

$qtd1 = libera($categoria, $informa1);

$principalligar = strip_tags(mysql_real_escape_string($_POST['principalligar']));
$principalvip = strip_tags(mysql_real_escape_string($_POST['principalvip']));
$novocvip = strip_tags(mysql_real_escape_string($_POST['vipedit']));
if(($principalligar == s) && ($principalvip  == $novocvip) ){
$qtd1 = '2';
}
if(($principalligar == s) && ($principalvip  == 'na') ){
$qtd1 = '2';
}
}
//<<fim verifica�ao edita op��o

//verifica�ao edita canal >>
$informa1 = $_POST['vipedit'];
$informa2 = $_POST['tipoanteri'];

$informacat1 = strip_tags(mysql_real_escape_string($_POST['categoria']));
$informacat2 = $_POST['catanteri'];

$inlig1 = $_POST['ligared'];
$inlig2 = $_POST['infolig'];


if((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "lolo")){

$qtd2 = libera($informacat1, $informa1);

if(($informa1 == $informa2) && ($informacat1  == $informacat2)){
$qtd2 = '2';
}
if(($inlig2 == s) && ($informa2  == na)){
$qtd2 = '2';
}
if(($inlig2 == n) && ($inlig1 == n)){
$qtd2 = '2';
}
if(($inlig2 == n) && ($inlig1 == s)){
$qtd2 = libera($informacat1, $informa1);
$con = mysql_query("SELECT * from dados_beta WHERE categoria='".strip_tags(mysql_real_escape_string($_POST['nome_foto']))."' AND ligar='s' AND (vip = '$informa1' or vip = 'na') AND lugar='canais' LIMIT 1");
$quant = mysql_num_rows($con);
if($quant > 0){
$qtd2 = '2';
}
}
if(($inlig2 == s) && ($inlig1 == n)){
$qtd2 = '2';
}
if(($inlig2 == $inlig1) && (($informa2 == $informa1) or ($informa2 == na)) && ($informacat1 != $informacat2)){
$qtd2 = libera($informacat1, $informa1);
}
}
//<< fim verifica�ao edita


//insere imagem add canal>>
if ((isset($_POST["MM_insert1"])) && ($_POST["MM_insert1"] == "novoform1") && ("$qtd1" <= "48000")) {
$nome = $_POST['nome']; 
// Pasta onde o arquivo vai ser salvo 
$_UP['pasta'] = '../images/canais/'; 
 
// Tamanho m�ximo do arquivo (em Bytes) 
$_UP['tamanho'] = 1024 * 1024 * 2; // 2Mb 
 
// Array com as extens�es permitidas 
$_UP['extensoes'] = array('jpg', 'png', 'gif'); 
 
// Renomeia o arquivo? (Se true, o arquivo ser� salvo como .jpg e um nome �nico) 
$_UP['renomeia'] = true; 
 
// Array com os tipos de erros de upload do PHP 
$_UP['erros'][0] = 'N�o houve erro'; 
$_UP['erros'][1] = 'O arquivo no upload � maior do que o limite do PHP'; 
$_UP['erros'][2] = 'O arquivo ultrapassa o limite de tamanho especifiado no HTML'; 
$_UP['erros'][3] = 'O upload do arquivo foi feito parcialmente'; 
$_UP['erros'][4] = 'N�o foi feito o upload do arquivo'; 
 
// Verifica se houve algum erro com o upload. Se sim, exibe a mensagem do erro 
if ($_FILES['arquivo']['error'] != 0) { 
die("N�o foi poss�vel fazer o upload, erro:<br />" . $_UP['erros'][$_FILES['arquivo']['error']]); 
exit; // Para a execu��o do script 
} 
 
// Caso script chegue a esse ponto, n�o houve erro com o upload e o PHP pode continuar 

// Faz a verifica��o da extens�o do arquivo 
$extensao = strtolower(end(explode('.', $_FILES['arquivo']['name']))); 
if (array_search($extensao, $_UP['extensoes']) === false) { 
echo "<Script Language='JavaScript'>";
echo "alert('extens�es permitidas: jpg, png ou gif');";
echo "</Script>";
$uploadsuc = 0;
} 
 
// Faz a verifica��o do tamanho do arquivo 
else if ($_UP['tamanho'] < $_FILES['arquivo']['size']) { 
echo "<Script Language='JavaScript'>";
echo "alert('O arquivo enviado � muito grande, envie arquivos de at� 2Mb.');";
echo "</Script>";
$uploadsuc = 0;
} 
// O arquivo passou em todas as verifica��es, hora de tentar mov�-lo para a pasta 
else { 
// Primeiro verifica se deve trocar o nome do arquivo 
if ($_UP['renomeia'] == true) { 
// Cria um nome baseado no UNIX TIMESTAMP atual e com extens�o .jpg 
$variavel = $nome;
$variavel_limpa = friendlyUrl($variavel);

$nome_final = $variavel_limpa.'-'."online-"."ao-"."vivo-"."gratis-".$unid.'.'.$extensao; 
} else { 
// Mant�m o nome original do arquivo 
$nome_final = $_FILES['arquivo']['name']; 
} 
$nome_finalsemex = str_replace("%%nome_do_canal%%",$variavel_limpa,$configuracoes['link']);
$nome_finalsemex = str_replace("%%nome_do_site%%",$nomedosite,$nome_finalsemex);
$nome_finalsemex = $nome_finalsemex.'-'.$unid;

$nome_finalsemex2 = $variavel_limpa.'-'."area-vip-".$unid; 
// Depois verifica se � poss�vel mover o arquivo para a pasta escolhida 
if (move_uploaded_file($_FILES['arquivo']['tmp_name'], $_UP['pasta'] . $nome_final)) { 
// Upload efetuado com sucesso, exibe uma mensagem e um link para o arquivo 
$uploadsucess1 = 1;
} else { 
// N�o foi poss�vel fazer o upload, provavelmente a pasta est� incorreta 
echo "<Script Language='JavaScript'>";
echo "alert('N�o foi poss�vel enviar o arquivo, tente novamente');";
echo "</Script>";
$uploadsucess1 = 0;
} 
 
} 
 
// coloca a url correta da imagem no banco de dados  
$url = 'images'; 
$server = $_SERVER['SERVER_NAME'];   
$url_imagem = $url.'/canais/'.$nome_final; }
//fim insere imagem add canal<<

//add canal>>
if ((isset($_POST["MM_insert1"])) && ($_POST["MM_insert1"] == "novoform1") && ("$qtd1" <= "48000") && ($uploadsucess1 != 0) && (isset($uploadsucess1)) ) {

$nome = strip_tags(mysql_real_escape_string($_POST['nome']));
$urlcanal = $_POST['urlcanal'];
$categoria = strip_tags(mysql_real_escape_string($_POST['categoria']));
$palavras = strip_tags(mysql_real_escape_string($_POST['palavras']));
$ligar = strip_tags(mysql_real_escape_string($_POST['ligar']));
$propaganda = strip_tags(mysql_real_escape_string($_POST['propaganda']));
$vip = strip_tags(mysql_real_escape_string($_POST['vip']));
$tipo = strip_tags(mysql_real_escape_string($_POST['tipo']));
$retorno = strip_tags(mysql_real_escape_string($_POST['retorno']));
$prog = strip_tags(mysql_real_escape_string($_POST['urlprog']));
  
$insertSQL = "INSERT INTO dados_beta (url_do_canal, `nome_do_canal`, linkdcanal, nome_foto, linkvip, categoria, tipo, palavras, ligar, propaganda, lugar, vip, form, prog) VALUES ('$url_imagem', '$nome', '$urlcanal', '$nome_finalsemex', '$nome_finalsemex2', '$categoria', '$tipo', '$palavras', '$ligar', '$propaganda', 'canais', '$vip', 'cadastro', '$prog')";
					    
$Result1 = mysql_query($insertSQL) or die(mysql_error()); 
include('atuali.php'); include('atuali2.php');
$id = mysql_insert_id();
criaicone($id);
$insertGoTo = "$retorno";
header(sprintf("Location: %s", $insertGoTo)); 
}if("$qtd1" >= "49000"){
$retorno = $_POST['retorno'];
echo "<Script Language='JavaScript'>";
echo "alert('ATEN��O - limite de 49 canais por categoria!');";
echo "window.location.replace('$retorno');";
echo "</Script>";
}
//fim add canal<<

//editar op�ao canal>>
if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "lolo") && ("$qtd2" <= "48000") && ($_POST["libera"] == "libera")) {

$nomedocanal = strip_tags(mysql_real_escape_string($_POST['nomedocanal']));
$tipodocanal = strip_tags(mysql_real_escape_string($_POST['tipodocanal']));
$linkdocanal = $_POST['linkdocanal'];
$propagandaedit = strip_tags(mysql_real_escape_string($_POST['propagandaedit']));
$palavrased = strip_tags(mysql_real_escape_string($_POST['palavrased']));
$ligared = strip_tags(mysql_real_escape_string($_POST['ligared']));
$vipedit = strip_tags(mysql_real_escape_string($_POST['vipedit']));
$hiddenField = strip_tags(mysql_real_escape_string($_POST['hiddenField']));
$retorno = strip_tags(mysql_real_escape_string($_POST['retorno']));

$result = htmlspecialchars($linkdocanal); 

$updateSQL = mysql_query("UPDATE dados_beta SET `nome_do_canal`='$nomedocanal', tipo='$tipodocanal', linkdcanal='$result', propaganda='$propagandaedit', palavras='$palavrased', ligar='$ligared', vip='$vipedit' WHERE ID='$hiddenField'");

include('atuali.php'); include('atuali2.php');
criaicone($hiddenField);
$insertGoTo = "$retorno";
header(sprintf("Location: %s", $insertGoTo));
}if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "lolo") && ("$qtd2" <= "48000") && ($_POST["libera"] !== "libera")) {

$nomedocanal = strip_tags(mysql_real_escape_string($_POST['nomedocanal']));
$tipodocanal = strip_tags(mysql_real_escape_string($_POST['tipodocanal']));
$linkdocanal = $_POST['linkdocanal'];
$categoria = strip_tags(mysql_real_escape_string($_POST['categoria']));
$propagandaedit = strip_tags(mysql_real_escape_string($_POST['propagandaedit']));
$palavrased = strip_tags(mysql_real_escape_string($_POST['palavrased']));
$ligared = strip_tags(mysql_real_escape_string($_POST['ligared']));
$vipedit = strip_tags(mysql_real_escape_string($_POST['vipedit']));
$hiddenField = strip_tags(mysql_real_escape_string($_POST['hiddenField']));
$retorno = strip_tags(mysql_real_escape_string($_POST['retorno']));
$prog = strip_tags(mysql_real_escape_string($_POST['linkdaprog']));

$result = htmlspecialchars($linkdocanal); 

$updateSQL = mysql_query("UPDATE dados_beta SET `nome_do_canal`='$nomedocanal', tipo='$tipodocanal', linkdcanal='$result', categoria='$categoria', propaganda='$propagandaedit', palavras='$palavrased', ligar='$ligared', vip='$vipedit', prog='$prog' WHERE ID='$hiddenField'");

include('atuali.php'); include('atuali2.php');
criaicone($hiddenField);
$insertGoTo = "$retorno";
header(sprintf("Location: %s", $insertGoTo));
}if("$qtd2" >= "49000"){
$retorno = $_POST['retorno'];
echo "<Script Language='JavaScript'>";
echo "alert('ATEN��O - limite de 49 canais por categoria!');";
echo "window.location.replace('$retorno');";
echo "</Script>";

}
//fim editar canal<<<

//editar imagem>>>
if((!empty($_FILES['arquivoeditar']['name'])) && ("$qtd2" <= "48000")){
/// altera��o de imagem 

$nome = $_POST['nomedocanal']; 
// Pasta onde o arquivo vai ser salvo 
$_UP['pasta'] = '../images/canais/'; 
 
// Tamanho m�ximo do arquivo (em Bytes) 
$_UP['tamanho'] = 1024 * 1024 * 2; // 2Mb 
 
// Array com as extens�es permitidas 
$_UP['extensoes'] = array('jpg', 'png', 'gif'); 
 
// Renomeia o arquivo? (Se true, o arquivo ser� salvo como .jpg e um nome �nico) 
$_UP['renomeia'] = true; 
 
// Array com os tipos de erros de upload do PHP 
$_UP['erros'][0] = 'N�o houve erro'; 
$_UP['erros'][1] = 'O arquivo no upload � maior do que o limite do PHP'; 
$_UP['erros'][2] = 'O arquivo ultrapassa o limite de tamanho especifiado no HTML'; 
$_UP['erros'][3] = 'O upload do arquivo foi feito parcialmente'; 
$_UP['erros'][4] = 'N�o foi feito o upload do arquivo'; 
 
// Verifica se houve algum erro com o upload. Se sim, exibe a mensagem do erro 
if ($_FILES['arquivoeditar']['error'] != 0) { 
die("N�o foi poss�vel fazer o upload, erro:<br />" . $_UP['erros'][$_FILES['arquivoeditar']['error']]); 
exit; // Para a execu��o do script 
} 
 
// Caso script chegue a esse ponto, n�o houve erro com o upload e o PHP pode continuar 

// Faz a verifica��o da extens�o do arquivo 
$extensao = strtolower(end(explode('.', $_FILES['arquivoeditar']['name']))); 
if (array_search($extensao, $_UP['extensoes']) === false) { 
echo "extens�es permitidas: jpg, png ou gif.";
$uploadsuc = 0;
} 
 
// Faz a verifica��o do tamanho do arquivo 
else if ($_UP['tamanho'] < $_FILES['arquivoeditar']['size']) { 
echo "O arquivo enviado � muito grande, envie arquivos de at� 2Mb.";
$uploadsuc = 0;
} 
// O arquivo passou em todas as verifica��es, hora de tentar mov�-lo para a pasta 
else { 
// Cria um nome baseado no UNIX TIMESTAMP atual e com extens�o .jpg 
$nome_final = friendlyUrl($nome).'-'."online-"."ao-"."vivo-"."gratis-".$unid.'.'.$extensao; 

$nome_finalsemex = friendlyUrl($nome).'-'."online-"."ao-"."vivo-"."gratis-".$unid; 
// Depois verifica se � poss�vel mover o arquivo para a pasta escolhida 
if (move_uploaded_file($_FILES['arquivoeditar']['tmp_name'], $_UP['pasta'] . $nome_final)) { 
// Upload efetuado com sucesso, exibe uma mensagem e um link para o arquivo 
$uploadsuc = 1;
} else { 
// N�o foi poss�vel fazer o upload, provavelmente a pasta est� incorreta 
echo "N�o foi poss�vel enviar o arquivo, tente novamente"; 
$uploadsuc = 0;
} 
 
} 

if($uploadsuc != 0){
$urlfil = $_POST['ulrdaimagem']; 
$extensao = strtolower(end(explode('images/canais/', $urlfil)));  
$ext = $extensao; 
$url = '../images/canais/';
unlink($url.$ext);
// coloca a url correta da imagem no banco de dados  
$url = 'images'; 
$server = $_SERVER['SERVER_NAME'];   
$url_imagem = $url.'/canais/'.$nome_final;
$coisaabaixo = $_POST['editarimagemid'];

$updateSQL = mysql_query("UPDATE dados_beta SET `url_do_canal`='$url_imagem' WHERE ID='$coisaabaixo'");
include('atuali.php'); include('atuali2.php');
criaicone($coisaabaixo);
}
}
else{
}
//fim editar imagem<<<

//add op�oes do canal>>>
if ((isset($_POST["addopt"])) && ($_POST["addopt"] == "novo") && ("$qtd1" <= "48000")) {

$nome = strip_tags(mysql_real_escape_string($_POST['nome']));
$urlcanal = $_POST['urlcanal'];
$palavras = strip_tags(mysql_real_escape_string($_POST['palavras']));
$ligar = strip_tags(mysql_real_escape_string($_POST['ligar']));
$propaganda = strip_tags(mysql_real_escape_string($_POST['propaganda']));
$vip = strip_tags(mysql_real_escape_string($_POST['vip']));
$tipo = strip_tags(mysql_real_escape_string($_POST['tipo']));
$nomefoto = strip_tags(mysql_real_escape_string($_POST['nomefoto']));
$retorno = strip_tags(mysql_real_escape_string($_POST['retorno']));

$variavel_limpa = friendlyUrl($nome);
$nome_finalsemex2 = $variavel_limpa.'-'."area-vip-".$unid; 
$nomef = str_replace("%%nome_do_canal%%",$variavel_limpa,$configuracoes['link']);
$nomef = str_replace("%%nome_do_site%%",$nomedosite,$nomef);
$nomef = $nomef.'-'.$unid;
  
$insertSQL = "INSERT INTO dados_beta (`nome_do_canal`, linkdcanal, categoria, tipo, palavras, ligar, propaganda, lugar, vip, form, nome_foto, linkvip) VALUES ('$nome', '$urlcanal', '$nomefoto', '$tipo', '$palavras', '$ligar', '$propaganda', 'canais', '$vip', 'opt', '$nomef', '$nome_finalsemex2')";
					    
$Result1 = mysql_query($insertSQL) or die(mysql_error()); 
include('atuali.php'); include('atuali2.php');
$id = mysql_insert_id();
criaicone($id);
$insertGoTo = "$retorno";
 
header(sprintf("Location: %s", $insertGoTo)); 
}if("$qtd1" >= "49000"){
$retorno = $_POST['retorno'];
echo "<Script Language='JavaScript'>";
echo "alert('ATEN��O - limite de 49 canais por categoria!');";
echo "window.location.replace('$retorno');";
echo "</Script>";

}
//fim add op�oes do canal<<

//editar op�oes>>
if ((isset($_POST["editarform"])) && ($_POST["editarform"] == "editarnovo") && ("$qtd1" <= "48000")) {

$nomedocanal = strip_tags(mysql_real_escape_string($_POST['nomedocanal']));
$tipodocanal = strip_tags(mysql_real_escape_string($_POST['tipodocanal']));
$linkdocanal = $_POST['linkdocanal'];
$propagandaedit =strip_tags(mysql_real_escape_string($_POST['propagandaedit']));
$palavrased = strip_tags(mysql_real_escape_string($_POST['palavrased']));
$ligared = strip_tags(mysql_real_escape_string($_POST['ligared']));
$vipedit = strip_tags(mysql_real_escape_string($_POST['vipedit']));
$hiddenField = strip_tags(mysql_real_escape_string($_POST['hiddenField']));
$retorno = strip_tags(mysql_real_escape_string($_POST['retorno']));

$result = htmlspecialchars($linkdocanal); 

$updateSQL = mysql_query("UPDATE dados_beta SET `nome_do_canal`='$nomedocanal', tipo='$tipodocanal', linkdcanal='$result', propaganda='$propagandaedit', palavras='$palavrased', ligar='$ligared', vip='$vipedit' WHERE ID='$hiddenField'");

include('atuali.php'); include('atuali2.php');
criaicone($hiddenField);
$insertGoTo = "$retorno";
header(sprintf("Location: %s", $insertGoTo));
}if("$qtd1" >= "49000"){
$retorno = $_POST['retorno'];
echo "<Script Language='JavaScript'>";
echo "alert('ATEN��O - limite de 49 canais por categoria!');";
echo "window.location.replace('$retorno');";
echo "</Script>";

}
//fim editar op�oes<<<<

//pagina�ao e busca>>
$editFormAction = $_SERVER['PHP_SELF']; 
if (isset($_SERVER['QUERY_STRING'])) { 
$editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']); 
}
	
$get    = strip_tags(mysql_real_escape_string(utf8_decode($_GET['busca'])));
$pagina = strip_tags(mysql_real_escape_string($_GET['pagina']));
if(!empty($pagina)){
}else{
$pagina = 1;
}

$get1    = strip_tags(mysql_real_escape_string(utf8_decode($_GET['busca1'])));
$pagina1 = strip_tags(mysql_real_escape_string($_GET['pagina1']));
if(!empty($pagina1)){
}else{
$pagina1 = 1;
}
     
// DEFINA AQUI O LIMITE DE RESULTADOS POR P�GINA             
$inicio = 0;
$limite = 4;

if($pagina != ''){ $inicio = ($pagina - 1) * $limite;}

// DEFINA AQUI O LIMITE DE RESULTADOS POR P�GINA             
$inicio1 = 0;
$limite1 = 4;

if($pagina1 != ''){ $inicio1 = ($pagina1 - 1) * $limite1;}

$checar1245 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' AND ligar = 'n' ORDER BY ID DESC");
while($res1245 = mysql_fetch_array($checar1245)){
$confere = mysql_query("SELECT * from dados_beta WHERE categoria='".$res1245['nome_foto']."' AND ligar='s' AND lugar='canais' LIMIT 1");
$result1245 = mysql_num_rows($confere);
if($result1245 == 0){
if(!isset($naoconta)){
$naoconta = 'AND ID !='.$res1245['ID'];
}else{
$naoconta = $naoconta.' AND ID !='.$res1245['ID'];
}}}

$sql = mysql_query("SELECT * from dados_beta WHERE (nome_do_canal LIKE '%".$get."%' OR categoria LIKE '%".$get."%' OR palavras LIKE '%".$get."%') AND lugar='canais' $naoconta AND form='cadastro' ORDER BY ID DESC LIMIT $inicio, $limite") or die("Erro ao consultar");
$sql2 = mysql_query("SELECT * from dados_beta WHERE (nome_do_canal LIKE '%".$get."%' OR categoria LIKE '%".$get."%' OR palavras LIKE '%".$get."%') $naoconta AND lugar='canais' AND form='cadastro' ORDER BY ID DESC LIMIT $inicio, $limite") or die("Erro ao consultar");
    
$sqlContar = mysql_query("SELECT * from dados_beta WHERE (nome_do_canal LIKE '%".$get."%' OR categoria LIKE '%".$get."%' OR palavras LIKE '%".$get."%') $naoconta AND form='cadastro'") or die("Erro ao consultar");
$total = mysql_num_rows($sqlContar);
 
//fim pagina�ao e busca<<

//deletar registro com foto >>
if ((isset($_GET['deletar'])) && (isset($_GET['url'])) && ($_GET['deletar'] != "") && ($_GET['url'] != "")) {

$iddelete = $_GET['deletar'];
$retorno = 'http://'.base64_decode($_GET['retorna']);

mysql_query("DELETE FROM dados_beta WHERE ID=$iddelete");
mysql_query("DELETE FROM foradoar WHERE id=$iddelete");

$urlfil = strip_tags(mysql_real_escape_string($_GET['url'])); 
$extensao = strtolower(end(explode('images/canais/', $urlfil)));  
$ext = $extensao; 
$url = '../images/canais/';  
 
unlink($url.$ext);
 
 $arquivo1111 = pathinfo($extensao, PATHINFO_EXTENSION);
 if($arquivo1111 == 'jpg'){
 $file = basename($extensao, ".jpg");
 }
 if($arquivo1111 == 'png'){
 $file = basename($extensao, ".png");
 }
 if($arquivo1111 == 'gif'){
 $file = basename($extensao, ".gif");
 }

$link = $_SERVER['DOCUMENT_ROOT'].'/icones/pequeno/aberto/'.$file.'.jpeg';
$link2 = $_SERVER['DOCUMENT_ROOT'].'/icones/grande/aberto/'.$file.'.jpeg';
$link3 = $_SERVER['DOCUMENT_ROOT'].'/icones/pequeno/vip/'.$file.'.jpeg';
$link4 = $_SERVER['DOCUMENT_ROOT'].'/icones/grande/vip/'.$file.'.jpeg';

if (file_exists($link)) {   
unlink($link);                    
}
if (file_exists($link2)) {   
unlink($link2);                    
}
if (file_exists($link3)) {   
unlink($link3);                    
}
if (file_exists($link4)) {   
unlink($link4);                    
}

include('atuali.php'); include('atuali2.php');
header(sprintf("Location: %s", $retorno));
exit();
}
//deletar registro sem foto >>
if ((isset($_GET['deletar'])) && ($_GET['deletar'] != "")) {

$iddelete = strip_tags(mysql_real_escape_string($_GET['deletar']));
$retorno = 'http://'.base64_decode(strip_tags(mysql_real_escape_string($_GET['retorna'])));

mysql_query("DELETE FROM dados_beta WHERE ID=$iddelete");
mysql_query("DELETE FROM foradoar WHERE id=$iddelete");
include('atuali.php'); include('atuali2.php');
header(sprintf("Location: %s", $retorno));
exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		
		<!--                       CSS                       -->
	  
		<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />
		
		<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
		<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />	
		
		<!-- Colour Schemes
	  
		Default colour scheme is green. Uncomment prefered stylesheet to use it.
		
		<link rel="stylesheet" href="resources/css/blue.css" type="text/css" media="screen" />
		
		<link rel="stylesheet" href="resources/css/red.css" type="text/css" media="screen" />  
	 
		-->
		
		<!-- Internet Explorer Fixes Stylesheet -->
		
		<!--[if lte IE 7]>
			<link rel="stylesheet" href="resources/css/ie.css" type="text/css" media="screen" />
		<![endif]-->
		
		<!--                       Javascripts                       -->
  
		<!-- jQuery -->
		<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>
		
		<!-- jQuery Configuration -->
		<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>
		
		<!-- Facebox jQuery Plugin -->
		<script type="text/javascript" src="resources/scripts/facebox.js"></script>
		
		<!--[if IE]><script type="text/javascript" src="resources/scripts/jquery.bgiframe.js"></script><![endif]-->

			<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
		<!-- Internet Explorer .png-fix -->
		
		<!--[if IE 6]>
			<script type="text/javascript" src="resources/scripts/DD_belatedPNG_0.0.7a.js"></script>
			<script type="text/javascript">
				DD_belatedPNG.fix('.png_bg, img, li');
			</script>
		<![endif]-->
		<script language="javascript">
<!-- chama a fun��o (nomeform) -->
function valida_dados (novoform1)
{
    if (novoform1.nome.value=="")
    {
        alert ("Por favor digite o nome.");
        return false;
    }
	
	if (novoform1.arquivo.value=="")
    {
        alert ("Por favor fa�a upload da imagem.");
        return false;
    }
	
	if (novoform1.urlcanal.value=="")
    {
        alert ("Por favor coloque a url, rtmp ou wmp.");
        return false;
    }
    
return true;
}
</script>
	</head>
  
	<body><div id="body-wrapper"> <!-- Wrapper for the radial gradient background -->
		
		<div id="sidebar"><div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
			
			<h1 id="sidebar-title"><a href="#">Simpla Admin</a></h1>
		  
			<!-- Logo (221px wide) -->
			<a href="#"><img id="logo" src="resources/images/logo.png" alt="Simpla Admin logo" /></a>
		  
			<!-- Sidebar Profile links -->
			<div id="profile-links">
				<?php require_once('top.php'); ?>
			</div>        
			
			<ul id="main-nav">  <!-- Accordion Menu -->
				
				<?php require_once('mnu.php'); ?>
				
			</ul> <!-- End #main-nav -->
			
			<div id="messages" style="display: none;"> <!-- Messages are shown when a link with these attributes are clicked: href="#messages" rel="modal"  -->
				<div id="reg-content">
<form  id="novoform1" name="novoform1" method="POST" enctype="multipart/form-data" onSubmit="return valida_dados(this)">
  <input type="hidden" name="hiddenField" id="hiddenField" />
					
						<label>Nome do canal*</label> 
						<input name="nome" type="text" id="nome" size="30" class="text-input" />
			
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Imagem* deve ter 70 x 50 px</label> 
						<input name="arquivo" type="file"  size="6" />
					
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
						<input type="radio" name="tipo" id="tipo" value="iframe" checked="checked">iframe (url)
						<input type="radio" name="tipo" id="tipo" value="rtmp">rtmp (streaming)
						<input type="radio" name="tipo" id="tipo" value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipo" id="tipo" value="livestream">Livestream.com
						<input type="radio" name="tipo" id="tipo" value="embed">Embed
						<input type="radio" name="tipo" id="tipo" value="m3u8">m3u8(playlist)
						<input type="radio" name="tipo" id="tipo" value="swf">swf
          
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label> 
						<input name="urlcanal" class="text-input" type="text" id="urlcanal" size="30" />
					
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">palavras chave</label> 
						 <input name="palavras" class="text-input" type="text" id="palavras" size="30" />
					
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Categoria</label> 
						<SELECT name="categoria" id="categoria">
	      <OPTION value="variedades" SELECTED>VARIEDADES / ABERTOS</OPTION>
	      <OPTION value="cinema">CINEMA / SERIES</OPTION>
		  <OPTION value="esportes">ESPORTES</OPTION>
		  <OPTION value="infantil">INFANTIL / DESENHOS</OPTION>
		  <OPTION value="clipes">CLIPES / MUSICAS</OPTION>
		  <OPTION value="religiosos">RELIGIOSOS</OPTION>
		  <OPTION value="documentarios">DOCUMENTARIOS</OPTION>
	      <OPTION value="noticias">NOTICIAS</OPTION>
	</SELECT>
					
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Canal vip ou aberto?</label> 
						<SELECT name="vip" id="vip">
	      <OPTION SELECTED value="na">Aberto e vip</OPTION>
	      <OPTION value="n">Aberto</OPTION>
		  <OPTION value="s">Vip</OPTION>
	</SELECT>
					
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Exibir propaganda?</label> 
						<SELECT name="propaganda" id="propaganda">
	      <OPTION SELECTED value="s">Sim</OPTION>
		  <OPTION value="n">N�o</OPTION>
	</SELECT>
	                    <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">link meuguia.tv programa��o</label> 
						<input name="urlprog" class="text-input" type="text" id="urlprog" size="30"/>
					
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Ativar canal?</label> 
						<SELECT name="ligar" id="ligar" style="margin-bottom:5px;">
	      <OPTION SELECTED value="s">Sim</OPTION>
	      <OPTION value="n">N�o</OPTION>
	</SELECT>
					<p/>
						<input type="submit" class="button" name="button" id="button" value="Add canal" />
    <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']; ?>" /> 
    <input type="hidden" name="MM_insert1" value="novoform1" /> 
</form>
</div>

			</div> <!-- End #messages -->
			
		</div></div> <!-- End #sidebar -->
		
		<div id="main-content"> <!-- Main Content Section with everything -->
			
			<noscript> <!-- Show a notification if the user has disabled javascript -->
				<div class="notification error png_bg">
					<div>
						Javascript is disabled or is not supported by your browser. Please <a href="http://browsehappy.com/" title="Upgrade to a better browser">upgrade</a> your browser or <a href="http://www.google.com/support/bin/answer.py?answer=23852" title="Enable Javascript in your browser">enable</a> Javascript to navigate the interface properly.</div>
				</div>
			</noscript>
			
			<!-- Page Head -->
			<ul class="shortcut-buttons-set">
				
				<li><a class="shortcut-button" href="#messages" rel="modal"><span>
					<img src="resources/images/icons/image_add_48.png" alt="icon" /><br />
					Add Canais
				</span></a></li>
				
			</ul><!-- End .shortcut-buttons-set -->
			
			<div class="clear"></div> <!-- End .clear -->
			
			<div class="content-box"><!-- Start Content Box -->
				
				<div class="content-box-header">
					
					<h3><? echo 'Resultados: '.$total; ?></h3>
					
					<ul class="content-box-tabs">
						<li><a href="#tab1" <? echo $tabdef1; ?>>Canais</a></li><!-- href must be unique and match the id of target div -->
						<li><a href="#tab2" <? echo $tabdef2; ?>>Canais desativados</a></li>
					</ul>
					
					<div class="clear"></div>
					
				</div> <!-- End .content-box-header -->
				
				<div class="content-box-content">
					
					<div <? echo $tabdefs1; ?> id="tab1" > <!-- This is the target div. id must match the href of this div's tab -->
						
						<table>
							

							<thead>
								<tr>
								   <th width="15%">Imagem</th>
								   <th width="15%">nome</th>
								   <th width="15%">Categoria</th>
								   <th width="15%">Tipo</th>
								   <th width="15%">Tecnologia</th>
								   <th width="13%">Ativo</th>
								   <th width="12%">Op�oes</th>
								</tr>
								
							</thead>
							<tbody>
	<?
           while($res = mysql_fetch_array($sql)){
		   
		   $checar1 = mysql_query("SELECT * from dados_beta WHERE categoria='".$res['nome_foto']."' AND ligar='s' AND lugar='canais' LIMIT 1");
    $result1 = mysql_num_rows($checar1);
	$checar1258 = mysql_query("SELECT * from dados_beta WHERE categoria='".$res['nome_foto']."' AND lugar='canais' LIMIT 1");
    $result1258 = mysql_num_rows($checar1258);
	if((($result1 == 1) && ($res['ligar'] == 'n')) or (($result1 <= 1) && ($res['ligar'] == 's'))){
    ?>
							                                                             <?php
		 $tipo6666 = $res['categoria'];
         $hr = $tipo6666;
         if($hr == variedades ) {  
              $resp = "variedades / abertos";  
         }
		 if ($hr == cinema ){  
              $resp = "cinema / series";  
         }
		 if ($hr == esportes ){  
              $resp = "esportes";  
         }
		 if ($hr == infantil ){  
              $resp = "infantil / desenhos";  
         }
		 if ($hr == clipes ){  
              $resp = "clipes / musicas";  
         }
		 if ($hr == religiosos ){  
              $resp = "religiosos";  
         }
		 if ($hr == documentarios ){  
              $resp = "documentarios";  
         }
		 if ($hr == noticias ){  
              $resp = "noticias";  
         }
    ?><?php
		 $tipo4444 = $res['vip'];
         $hr = $tipo4444;
         if($hr == s ) {  
              $resp2 = "vip";  
         }
		 if ($hr == n ){  
              $resp2 = "aberto";  
         }
		 if ($hr == na ){  
              $resp2 = "aberto e vip";  
         }
    ?>
	
	<tr>
									<td><img src="<?php linkico($res['vip'], $res['url_do_canal']); ?>" width="70" height="50" /></td>
									<td><?php echo $res['nome_do_canal']; ?></td>
									<td><?php echo $resp; ?></td>
									<td><?php echo $resp2; ?></td>
									<td><?php echo  $res['tipo']; ?></td>
									<td><?php echo  $res['ligar']; ?></td>
									<td>
										<a title='Editar' href='#<? echo $res['ID']; ?>' rel='modal'><img src='resources/images/icons/hammer_screwdriver.png' alt='Editar' /></a>
										<? if($result1258 == 0){ ?><a href='?deletar=<? echo $res['ID']; ?>&url=<? echo $res['url_do_canal']; ?>&retorna=<? echo base64_encode($_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']); ?>' title='Deletar' onclick="return confirm('Confirma exclus�o do canal <? echo $res['nome_do_canal']; ?>')"><img src='resources/images/icons/cross.png' alt='Deletar' /></a><? } ?>
						 <a title='Adicionar Op��es' href='#b<? echo $res['ID']; ?>' rel='modal'><img src='resources/images/icons/pencil.png' alt='Adicionar Op��es' /></a>
						 <a title='testar canal' target="_blank" href='ver.php?id=<? echo $res['ID']; ?>'><img src='resources/images/icons/lupa.png' alt='testar canal' /></a>
									</td>
									
							  </tr>
								<?
                                  $variav = $res['nome_foto'];
                                  $sql22 = mysql_query("SELECT * from dados_beta WHERE categoria='$variav'") or die("Erro ao consultar");
                                ?>
								 <?
                                     while($varios = mysql_fetch_array($sql22)){
                                 ?>
							  <tr style="display:none;">
                                    <td colspan="6"></td>
                              </tr>
	                          <tr>
							        <td></td>
									<td><?php echo $varios['nome_do_canal']; ?></td>
									<td><?php echo $resp; ?></td>
									<td><?php
		 $tipo4444 = $varios['vip'];
         $hr = $tipo4444;
         if($hr == s ) {  
              $resp2 = "vip";  
         }
		 if ($hr == n ){  
              $resp2 = "aberto";  

         }
		 if ($hr == na ){  
              $resp2 = "aberto e vip";  
         }
    ?><?php echo $resp2; ?></td>
									<td><?php echo $varios['tipo']; ?></td>
									<td><?php echo  $varios['ligar']; ?></td>
									<td><a title='Editar' href='#c<? echo $varios['ID']; ?>' rel='modal'><img src='resources/images/icons/hammer_screwdriver.png' alt='Editar' /></a>
									<a href='?deletar=<? echo $varios['ID']; ?>&retorna=<? echo base64_encode($_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']); ?>' title='Deletar' onclick="return confirm('Confirma exclus�o do canal <? echo $varios['nome_do_canal']; ?>')"><img src='resources/images/icons/cross.png' alt='Deletar' /></a>
									<a title='testar canal' target="_blank" href='ver.php?id=<? echo $varios['ID']; ?>'><img src='resources/images/icons/lupa.png' alt='testar canal' /></a>
									</td>
							  </tr><? } ?>
                                </tr>
	<? }} ?>

	
	
	
	
	
	
	

							</tbody>
						<tfoot>
								<tr>
									<td colspan="7">
										<div class="bulk-actions align-left" style="margin-right:20px;">
											<form method="get" accept-charset="UTF-8" action="admin.php">
      <input type="text" class="text-input" id="busca" name="busca" value="buscar canal..." onfocus="if (this.value == 'buscar canal...') this.value = '';" onblur="if (this.value == '') this.value = 'buscar canal...';" />
      <input type="submit" class="button" value="Buscar" title="Pesquisar" /></form>
										</div>
										
										<?php
	$menos = $pagina - 1;
    $mais  = $pagina + 1;
 
    $pgs = ceil($total / $limite);
 
    if($pgs > 1 ){
    echo '<div class="pagination">';
 
    if($menos > 0){ echo "<a href=".$_SERVER['PHP_SELF']."?busca=$get&pagina=$menos>&laquo; Anterior</a> ";}
 
	for($i=1;$i <= $pgs;$i++){
	  if($i != $pagina) {
		  echo " <a style=\"margin-bottom:15px;\" class=\"number\" href=".$_SERVER['PHP_SELF']."?busca=$get&pagina=".($i).">$i</a> ";
	  } else {
		  echo " <a style=\"margin-bottom:15px;\" class=\"number current\" href=".$_SERVER['PHP_SELF']."?busca=$get&pagina=".($i).">".$i."</a> ";
	  }
	}
 
	if($mais <= $pgs){
		echo " <a href=".$_SERVER['PHP_SELF']."?busca=$get&pagina=$mais>Pr�xima &raquo;</a>";
	}
	echo '<div>';
    }
    ?> 
								
										<div class="clear"></div>
									</td>
								</tr>
						  </tfoot>
						</table>
					</div> <!-- End #tab1 -->
					
					<?
     
// DEFINA AQUI O LIMITE DE RESULTADOS POR P�GINA             
$inicio1 = 0;
$limite1 = 4;

if($pagina1 != ''){ $inicio1 = ($pagina1 - 1) * $limite1;}

$checar12451 = mysql_query("SELECT * from dados_beta WHERE lugar='canais' AND form='cadastro' ORDER BY ID DESC");
while($res12451 = mysql_fetch_array($checar12451)){
if($res12451['ligar'] == 'n'){
$confere1 = mysql_query("SELECT * from dados_beta WHERE categoria='".$res12451['nome_foto']."' AND ligar='s' AND lugar='canais' LIMIT 1");
$result12451 = mysql_num_rows($confere1);
if($result12451 == 1){
if(!isset($naoconta1)){
$naoconta1 = 'AND ID !='.$res12451['ID'];
}else{
$naoconta1 = $naoconta1.' AND ID !='.$res12451['ID'];
}}}
if($res12451['ligar'] == 's'){
if(!isset($naoconta1)){
$naoconta1 = 'AND ID !='.$res12451['ID'];
}else{
$naoconta1 = $naoconta1.' AND ID !='.$res12451['ID'];
}
}
}
    
$sqlContar1 = mysql_query("SELECT * from dados_beta WHERE (nome_do_canal LIKE '%".$get1."%' OR categoria LIKE '%".$get1."%' OR palavras LIKE '%".$get1."%') AND ligar!='s' $naoconta1 AND form='cadastro'") or die("Erro ao consultar");
$total1 = mysql_num_rows($sqlContar1);
 
$sql1 = mysql_query("SELECT * from dados_beta WHERE (nome_do_canal LIKE '%".$get1."%' OR categoria LIKE '%".$get1."%' OR palavras LIKE '%".$get1."%') $naoconta1 AND lugar='canais' AND form='cadastro' ORDER BY ID DESC LIMIT $inicio1, $limite1") or die("Erro ao consultar");

$sql5 = mysql_query("SELECT * from dados_beta WHERE (nome_do_canal LIKE '%".$get1."%' OR categoria LIKE '%".$get1."%' OR palavras LIKE '%".$get1."%') $naoconta1 AND lugar='canais' AND form='cadastro' ORDER BY ID DESC LIMIT $inicio1, $limite1") or die("Erro ao consultar");
//fim pagina�ao e busca<<
					?>
					
					<div <? echo $tabdefs2; ?> id="tab2"> <!-- This is the target div. id must match the href of this div's tab -->
					<table>
							

							<thead>
								<tr>
								   <th>Imagem </th>
								   <th>nome</th>
								   <th>Categoria</th>
								   <th>Tipo</th>
								   <th>Tecnologia</th>
								   <th>Op�oes</th>
								</tr>
								
							</thead>
							<tbody>
	<?
           while($res1 = mysql_fetch_array($sql1)){
		     
		   $checar12 = mysql_query("SELECT * from dados_beta WHERE categoria='".$res1['nome_foto']."' AND ligar='n' AND lugar='canais' LIMIT 1");
    $result12 = mysql_num_rows($checar12);
	if(($result12 <= 1) && ($res1['ligar'] == 'n')){
    ?>
							                                                             <?php
		 $tipo66661 = $res1['categoria'];
         $hr1 = $tipo66661;
         if($hr1 == variedades ) {  
              $resp1 = "variedades / abertos";  
         }
		 if ($hr1 == cinema ){  
              $resp1 = "cinema / series";  
         }
		 if ($hr1 == esportes ){  
              $resp1 = "esportes";  
         }
		 if ($hr1 == infantil ){  
              $resp1 = "infantil / desenhos";  
         }
		 if ($hr1 == clipes ){  
              $resp1 = "clipes / musicas";  
         }
		 if ($hr1 == religiosos ){  
              $resp1 = "religiosos";  
         }
		 if ($hr1 == documentarios ){  
              $resp1 = "documentarios";  
         }
		 if ($hr1 == noticias ){  
              $resp1 = "noticias";  
         }
    ?><?php
		 $tipo44441 = $res1['vip'];
         $hr1 = $tipo44441;
         if($hr1 == s ) {  
              $resp21 = "vip";  
         }
		 if ($hr1 == n ){  
              $resp21 = "aberto";  
         }
		 if ($hr1 == na ){  
              $resp21 = "aberto e vip";  
         }
    ?>
	
	<tr>
									<td><img src="<?php linkico($res1['vip'], $res1['url_do_canal']); ?>" width="70" height="50" /></td>
									<td><?php echo $res1['nome_do_canal']; ?></td>
									<td><?php echo $resp1; ?></td>
									<td><?php echo $resp21; ?></td>
									<td><?php echo  $res1['tipo']; ?></td>
									<td>
										<a title='Editar' href='#<? echo $res1['ID']; ?>' rel='modal'><img src='resources/images/icons/hammer_screwdriver.png' alt='Editar' /></a>
										<? if($result12 == 0){ ?><a href='?deletar=<? echo $res1['ID']; ?>&url=<? echo $res1['url_do_canal']; ?>&retorna=<? echo base64_encode($_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']); ?>' title='Deletar' onclick="return confirm('Confirma exclus�o do canal <? echo $res1['nome_do_canal']; ?>')"><img src='resources/images/icons/cross.png' alt='Deletar' /></a><? } ?>
						 <a style="display:none;" title='Adicionar Op��es' href='#b<? echo $res1['ID']; ?>' rel='modal'><img src='resources/images/icons/pencil.png' alt='Adicionar Op��es' /></a>
						 <a title='testar canal' target="_blank" href='ver.php?id=<? echo $res1['ID']; ?>'><img src='resources/images/icons/lupa.png' alt='testar canal' /></a>
									</td>
									
							  </tr>
								<?
                                  $variav1 = $res1['nome_foto'];
                                  $sql221 = mysql_query("SELECT * from dados_beta WHERE categoria='$variav1'") or die("Erro ao consultar");
                                ?>
								 <?
                                     while($varios1 = mysql_fetch_array($sql221)){
                                 ?>
							  <tr style="display:none;">
                                    <td colspan="6"></td>
                              </tr>
	                          <tr>
							        <td></td>
									<td><?php echo $varios1['nome_do_canal']; ?></td>
									<td><?php echo $resp1; ?></td>
									<td><?php
		 $tipo44441 = $varios1['vip'];
         $hr1 = $tipo44441;
         if($hr1 == s ) {  
              $resp21 = "vip";  
         }
		 if ($hr1 == n ){  
              $resp21 = "aberto";  
         }
		 if ($hr1 == na ){  
              $resp21 = "aberto e vip";  
         }
    ?><?php echo $resp21; ?></td>
									<td><?php echo $varios1['tipo']; ?></td>
									<td><a title='Editar' href='#c<? echo $varios1['ID']; ?>' rel='modal'><img src='resources/images/icons/hammer_screwdriver.png' alt='Editar' /></a>
									<a href='?deletar=<? echo $varios1['ID']; ?>&retorna=<? echo base64_encode($_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']); ?>' title='Deletar' onclick="return confirm('Confirma exclus�o do canal <? echo $varios1['nome_do_canal']; ?>')"><img src='resources/images/icons/cross.png' alt='Deletar' /></a>
									<a title='testar canal' target="_blank" href='ver.php?id=<? echo $varios1['ID']; ?>'><img src='resources/images/icons/lupa.png' alt='testar canal' /></a>
									</td>
							  </tr><? } ?>
                                </tr>
	<? }} ?>

	
	
	
	
	
	
	

							</tbody>
						<tfoot>
								<tr>
									<td colspan="6">
										<div class="bulk-actions align-left" style="margin-right:20px;">
											<form method="get" accept-charset="UTF-8" action="admin.php">
      <input type="text" class="text-input" id="busca1" name="busca1" value="buscar canal..." onfocus="if (this.value == 'buscar canal...') this.value = '';" onblur="if (this.value == '') this.value = 'buscar canal...';" />
	  <input type="hidden" name="tabdef" id="tabdef" value="2" /> 
      <input type="submit" class="button" value="Buscar" title="Pesquisar" /></form>
										</div>
										
										<?php
	$menos1 = $pagina1 - 1;
    $mais1  = $pagina1 + 1;
 
    $pgs1 = ceil($total1 / $limite1);
 
    if($pgs1 > 1 ){
    echo '<div class="pagination">';
 
    if($menos1 > 0){ echo "<a href=".$_SERVER['PHP_SELF']."?busca1=$get1&tabdef=2&pagina1=$menos1>&laquo; Anterior</a> ";}
 
	for($i=1;$i <= $pgs1;$i++){
	  if($i != $pagina1) {
		  echo " <a class=\"number\" href=".$_SERVER['PHP_SELF']."?busca1=$get1&tabdef=2&pagina1=".($i).">$i</a> ";
	  } else {
		  echo " <a class=\"number current\" href=".$_SERVER['PHP_SELF']."?busca1=$get1&tabdef=2&pagina1=".($i).">".$i."</a> ";
	  }
	}
 
	if($mais1 <= $pgs1){
		echo " <a href=".$_SERVER['PHP_SELF']."?busca1=$get1&tabdef=2&pagina1=$mais1>Pr�xima &raquo;</a>";
	}
	echo '<div>';
    }
    ?> 
								
										<div class="clear"></div>
									</td>
								</tr>
					  </tfoot>
					  </table>
					</div> <!-- End #tab2 -->
				         	<?
                              while($res1 = mysql_fetch_array($sql2)){
                            ?>
							<div id="<?php echo $res1['ID']; ?>" style="display: none;">
							
				<form action="<?php echo $editFormAction; ?>" id="lolo" name="lolo" method="POST" enctype="multipart/form-data">
  <input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $res1['ID']; ?>" />
      <label>Nome do canal*</label>
      <input name="nomedocanal" type="text" id="nomedocanal" size="30" value="<?php echo $res1['nome_do_canal']; ?>" />
	  
	  <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Editar imagem, deve ter 70 x 50 px</label>
	  <input name="ulrdaimagem" type="hidden" id="ulrdaimagem" value="<?php echo $res1['url_do_canal']; ?>" />
	  <input name="editarimagemid" type="hidden" id="editarimagemid" value="<?php echo $res1['ID']; ?>" />
      <input name="arquivoeditar" type="file"  size="6" />
	  
      <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
	  <?php
         $hr = $res1['tipo'];
         if($hr == iframe ) {  
              $resp1 = "checked='checked'"; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == rtmp ) {
			  $resp1 = ""; 
			  $resp2 = "checked='checked'";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == wmp ) {
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "checked='checked'";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == livestream ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "checked='checked'";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == embed ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "checked='checked'";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == m3u8 ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "checked='checked'"; 
			  $resp7 = "";
         }
		 if ($hr == swf ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = ""; 
			  $resp7 = "checked='checked'";
         }
    ?>
	                    <input type="radio" name="tipodocanal" id="tipodocanal" value="iframe" <?php echo  "$resp1"; ?>>iframe (url)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp2"; ?> value="rtmp">rtmp (streaming)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp3"; ?> value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp4"; ?> value="livestream">Livestream.com
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp5"; ?> value="embed">Embed
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp6"; ?> value="m3u8">m3u8(playlist)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp7"; ?> value="swf">swf
						
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label>
	<textarea name="linkdocanal" cols="40" rows="2" id="linkdocanal"><?php echo $res1['linkdcanal']; ?></textarea>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">palavras chave</label>
    <input name="palavrased" value="<?php echo $res1['palavras']; ?>" type="text" id="palavrased" size="30" /></td> 
    
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Categoria</label>
	  <?php
         $hr = $res1['categoria'];
         if($hr == variedades ) {  
              $resp1 = "selected='selected'"; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if($hr == cinema ) {
			  $resp1 = ""; 
			  $resp2 = "selected='selected'";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if($hr == esportes ) {
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "selected='selected'";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if ($hr == infantil ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "selected='selected'";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if ($hr == clipes ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "selected='selected'";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if ($hr == religiosos ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "selected='selected'";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if ($hr == documentarios ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "selected='selected'";
			  $resp8 = ""; 
         }
		 if ($hr == noticias ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = "selected='selected'"; 
         }
    ?>
    <SELECT name="categoria" id="categoria">
	      <OPTION <?php echo  "$resp1"; ?> value="variedades">VARIEDADES / ABERTOS</OPTION>
	      <OPTION <?php echo  "$resp2"; ?> value="cinema">CINEMA / SERIES</OPTION>
		  <OPTION <?php echo  "$resp3"; ?> value="esportes">ESPORTES</OPTION>
		  <OPTION <?php echo  "$resp4"; ?> value="infantil">INFANTIL / DESENHOS</OPTION>
		  <OPTION <?php echo  "$resp5"; ?> value="clipes">CLIPES / MUSICAS</OPTION>
		  <OPTION <?php echo  "$resp6"; ?> value="religiosos">RELIGIOSOS</OPTION>
		  <OPTION <?php echo  "$resp7"; ?> value="documentarios">DOCUMENTARIOS</OPTION>
	      <OPTION <?php echo  "$resp8"; ?> value="noticias">NOTICIAS</OPTION>
	</SELECT>
	

	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Canal vip ou aberto?</label>
	  <?php
         $hrp = $res1['vip'];
         if($hrp == n ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
			  $respp3 = "";
         }
		 if($hrp == s ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
			  $respp3 = "";
         }
		 if($hrp == na ) {
			  $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "selected='selected'";
         }
    ?>
    <SELECT name="vipedit" id="vipedit">
	      <OPTION <?php echo  "$respp2"; ?> value="s">Vip</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="n">Aberto</OPTION>
		  <OPTION <?php echo  "$respp3"; ?> value="na">Aberto e vip</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Exibir propaganda?</label>
	  <?php
         $hrp = $res1['propaganda'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="propagandaedit" id="propagandaedit">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">link meuguia.tv programa��o</label>
        <input name="linkdaprog" value="<?php echo $res1['prog']; ?>" type="text" id="linkdaprog" size="30" />
		
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Ativar canal?</label>
	  <?php
         $hrp = $res1['ligar'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="ligared" id="ligared">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
	   <br>
        
        <div align="center">

		 <input name="tipoanteri" value="<?php echo $res1['vip']; ?>" type="hidden" id="tipoanteri"/>
		 <input name="catanteri" value="<?php echo $res1['categoria']; ?>" type="hidden" id="catanteri"/>
		  <input name="infolig" value="<?php echo $res1['ligar']; ?>" type="hidden" id="infolig"/>
          <input type="submit" class="button" name="button" id="button" value="Salvar" />
		  <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME']; if (strpos($_SERVER ['REQUEST_URI'], 'tabdef=2')){ echo str_replace('tabdef=2', "", $_SERVER ['REQUEST_URI']);} else{ echo $_SERVER ['REQUEST_URI'];} ?>" />
        </div>

  <p> 
    <input type="hidden" name="MM_update" value="lolo" />
</p> 
</form>
				
			</div>
			<div id="b<?php echo $res1['ID']; ?>" style="display:none;">
<form  id="novo" name="novo" method="POST" action="<?php echo $editFormAction; ?>" enctype="multipart/form-data" onSubmit="return valida_dados(this)">
  <input type="hidden" name="hiddenField" id="hiddenField" />
  <input type="hidden" name="nomefoto" id="nomefoto" value="<? echo $res1['nome_foto']; ?>" />
  <input type="hidden" name="categoria" id="categoria" value="<? echo $res1['categoria']; ?>" />
  <input type="hidden" name="principalvip" id="principalvip" value="<? echo $res1['vip']; ?>" />
  <input type="hidden" name="principalligar" id="principalligar" value="<? echo $res1['ligar']; ?>" /> 
  
  <label>Nome do canal*c</label>
  <input name="nome" type="text" id="nome" size="30" /></td>
    
  <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
                        <input type="radio" name="tipo" id="tipo" value="iframe" checked="checked">iframe (url)
						<input type="radio" name="tipo" id="tipo" value="rtmp">rtmp (streaming)
						<input type="radio" name="tipo" id="tipo" value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipo" id="tipo" value="livestream">Livestream.com
						<input type="radio" name="tipo" id="tipo" value="embed">Embed
						<input type="radio" name="tipo" id="tipo" value="m3u8">m3u8(playlist)
						<input type="radio" name="tipo" id="tipo" value="swf">swf
 
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label>
	<input name="urlcanal" type="text" id="urlcanal" size="30" /></td>
    
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">palavras chave</label>
	<input name="palavras" id="palavras" size="30" /></td>
   
    <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Canal vip ou aberto?</label>
    <SELECT name="vip" id="vip">
	      <OPTION SELECTED value="na">Aberto e vip</OPTION>
	      <OPTION value="n">Aberto</OPTION>
		  <OPTION value="s">Vip</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Exibir propaganda?</label> 
	<SELECT name="propaganda" id="propaganda">
	      <OPTION SELECTED value="s">Sim</OPTION>
		  <OPTION value="n">N�o</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Ativar canal?</label> 
	<SELECT name="ligar" id="ligar">
	      <OPTION SELECTED value="s">Sim</OPTION>
	      <OPTION value="n">N�o</OPTION>
	</SELECT>
	
	<div align="center"> 
        <input type="submit" class="button" name="button" id="button" value="Add canal" /> 
      </div>
	  
  <p>
    <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME']; if (strpos($_SERVER ['REQUEST_URI'], 'tabdef=2')){ echo str_replace('tabdef=2', "", $_SERVER ['REQUEST_URI']);} else{ echo $_SERVER ['REQUEST_URI'];} ?>" /> 
    <input type="hidden" name="addopt" value="novo" /> 
</p> 
</form>
			</div>
			<?
                                  $variav = $res1['nome_foto'];
                                  $sql22 = mysql_query("SELECT * from dados_beta WHERE categoria='$variav'") or die("Erro ao consultar");
                                ?>
								 <?
                                     while($varios = mysql_fetch_array($sql22)){
                                 ?>
							 <div id="c<? echo $varios['ID']; ?>" style="display:none;">
							 
							 <form action="<?php echo $editFormAction; ?>" id="editarnovo" name="editarnovo" method="POST" enctype="multipart/form-data">
  <input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $varios['ID']; ?>" />
  <input type="hidden" name="categoria" id="categoria" value="<? echo $res1['categoria']; ?>" />
  <input type="hidden" name="principalvip" id="principalvip" value="<? echo $res1['vip']; ?>" />
  <input type="hidden" name="principalligar" id="principalligar" value="<? echo $res1['ligar']; ?>" /> 
  
  <label>Nome do canal*e</label> 
  <input name="nomedocanal" type="text" id="nomedocanal" size="30" value="<?php echo $varios['nome_do_canal']; ?>" />
  
  <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
	  <?php
         $hr = $varios['tipo'];
         if($hr == iframe ) {  
              $resp1 = "checked='checked'"; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == rtmp ) {
			  $resp1 = ""; 
			  $resp2 = "checked='checked'";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == wmp ) {
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "checked='checked'";

			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == livestream ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "checked='checked'";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == embed ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "checked='checked'";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == m3u8 ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "checked='checked'";
			  $resp7 = "";
         }
		 if ($hr == swf ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "checked='checked'";
         }
    ?>
	                    <input type="radio" name="tipodocanal" id="tipodocanal" value="iframe" <?php echo  "$resp1"; ?>>iframe (url)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp2"; ?> value="rtmp">rtmp (streaming)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp3"; ?> value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp4"; ?> value="livestream">Livestream.com
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp5"; ?> value="embed">Embed
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp6"; ?> value="m3u8">m3u8(playlist)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp7"; ?> value="swf">swf
						
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label>
	<textarea name="linkdocanal" cols="30" rows="2" id="linkdocanal"><?php echo $varios['linkdcanal']; ?></textarea>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">palavras chave</label>
	<input name="palavrased" value="<?php echo $varios['palavras']; ?>" type="text" id="palavrased" size="30" /></td> 
    
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Canal vip ou aberto?</label> 
	  <?php
         $hrp = $varios['vip'];
         if($hrp == n ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
			  $respp3 = "";
         }
		 if($hrp == s ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
			  $respp3 = "";
         }
		 if($hrp == na ) {
			  $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "selected='selected'";
         }
    ?>
    <SELECT name="vipedit" id="vipedit">
	      <OPTION <?php echo  "$respp2"; ?> value="s">Vip</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="n">Aberto</OPTION>
		  <OPTION <?php echo  "$respp3"; ?> value="na">Aberto e vip</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Exibir propaganda?</label>
	  <?php
         $hrp = $varios['propaganda'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="propagandaedit" id="propagandaedit">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>

	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Ativar canal?</label>
	<?php
         $hrp = $varios['ligar'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="ligared" id="ligared">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
	
	   <br>
        
        <div align="center">

          <input type="submit" class="button" name="button" id="button" value="Salvar" />
        </div>

  <p>
    <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME']; if (strpos($_SERVER ['REQUEST_URI'], 'tabdef=2')){ echo str_replace('tabdef=2', "", $_SERVER ['REQUEST_URI']);} else{ echo $_SERVER ['REQUEST_URI'];} ?>" /> 
    <input type="hidden" name="editarform" value="editarnovo" />
</p> 
</form>
							 
							 </div>
							 <? } ?>
					     	<? } ?>
					<?
                              while($res5 = mysql_fetch_array($sql5)){
                            ?>
							<div id="<?php echo $res5['ID']; ?>" style="display: none;">
							
				<form action="<?php echo $editFormAction; ?>" id="lolo" name="lolo" method="POST" enctype="multipart/form-data">
  <input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $res5['ID']; ?>" />
      <label>Nome do canal</label>
      <input name="nomedocanal" type="text" id="nomedocanal" size="30" value="<?php echo $res5['nome_do_canal']; ?>" />
	  
	  <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Editar imagem, deve ter 70 x 50 px</label>
	  <input name="ulrdaimagem" type="hidden" id="ulrdaimagem" value="<?php echo $res5['url_do_canal']; ?>" />
	  <input name="editarimagemid" type="hidden" id="editarimagemid" value="<?php echo $res5['ID']; ?>" />
      <input name="arquivoeditar" type="file"  size="6" />
	  
      <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
	  <?php
	           $hr = $res5['tipo'];
         if($hr == iframe ) {  
              $resp1 = "checked='checked'"; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == rtmp ) {
			  $resp1 = ""; 
			  $resp2 = "checked='checked'";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == wmp ) {
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "checked='checked'";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == livestream ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "checked='checked'";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == embed ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "checked='checked'";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == m3u8 ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "checked='checked'"; 
			  $resp7 = "";
         }
		 if ($hr == swf ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = ""; 
			  $resp7 = "checked='checked'";
         }
    ?>
	                    <input type="radio" name="tipodocanal" id="tipodocanal" value="iframe" <?php echo  "$resp1"; ?>>iframe (url)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp2"; ?> value="rtmp">rtmp (streaming)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp3"; ?> value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp4"; ?> value="livestream">Livestream.com
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp5"; ?> value="embed">Embed
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp6"; ?> value="m3u8">m3u8(playlist)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp7"; ?> value="swf">swf
						
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label>
	<textarea name="linkdocanal" cols="40" rows="2" id="linkdocanal"><?php echo $res5['linkdcanal']; ?></textarea>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">palavras chave</label>
    <input name="palavrased" value="<?php echo $res5['palavras']; ?>" type="text" id="palavrased" size="30" /></td> 
    
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Categoria</label>
	  <?php
         $hr = $res5['categoria'];
         if($hr == variedades ) {  
              $resp1 = "selected='selected'"; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if($hr == cinema ) {
			  $resp1 = ""; 
			  $resp2 = "selected='selected'";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if($hr == esportes ) {
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "selected='selected'";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if ($hr == infantil ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "selected='selected'";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }

		 if ($hr == clipes ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "selected='selected'";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if ($hr == religiosos ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "selected='selected'";
			  $resp7 = "";
			  $resp8 = ""; 
         }
		 if ($hr == documentarios ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "selected='selected'";
			  $resp8 = ""; 
         }
		 if ($hr == noticias ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
			  $resp8 = "selected='selected'"; 
         }
    ?>
    <SELECT name="categoria" id="categoria">
	      <OPTION <?php echo  "$resp1"; ?> value="variedades">VARIEDADES / ABERTOS</OPTION>
	      <OPTION <?php echo  "$resp2"; ?> value="cinema">CINEMA / SERIES</OPTION>
		  <OPTION <?php echo  "$resp3"; ?> value="esportes">ESPORTES</OPTION>
		  <OPTION <?php echo  "$resp4"; ?> value="infantil">INFANTIL / DESENHOS</OPTION>
		  <OPTION <?php echo  "$resp5"; ?> value="clipes">CLIPES / MUSICAS</OPTION>
		  <OPTION <?php echo  "$resp6"; ?> value="religiosos">RELIGIOSOS</OPTION>
		  <OPTION <?php echo  "$resp7"; ?> value="documentarios">DOCUMENTARIOS</OPTION>
	      <OPTION <?php echo  "$resp8"; ?> value="noticias">NOTICIAS</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Canal vip ou aberto?</label>
	  <?php
         $hrp = $res5['vip'];
         if($hrp == n ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
			  $respp3 = "";
         }
		 if($hrp == s ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
			  $respp3 = "";
         }
		 if($hrp == na ) {
			  $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "selected='selected'";
         }
    ?>
    <SELECT name="vipedit" id="vipedit">
	      <OPTION <?php echo  "$respp2"; ?> value="s">Vip</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="n">Aberto</OPTION>
		  <OPTION <?php echo  "$respp3"; ?> value="na">Aberto e vip</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Exibir propaganda?</label>
	  <?php
         $hrp = $res5['propaganda'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="propagandaedit" id="propagandaedit">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">link meuguia.tv programa��o</label>
        <input name="linkdaprog" value="<?php echo $res5['prog']; ?>" type="text" id="linkdaprog" size="30" />
		
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Ativar canal?</label>
	  <?php
         $hrp = $res5['ligar'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="ligared" id="ligared">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
	   <br>
        
        <div align="center">

		 <input name="tipoanteri" value="<?php echo $res5['vip']; ?>" type="hidden" id="tipoanteri"/>
		 <input name="catanteri" value="<?php echo $res5['categoria']; ?>" type="hidden" id="catanteri"/>
		 <input name="infolig" value="<?php echo $res5['ligar']; ?>" type="hidden" id="infolig"/>
          <input type="submit" class="button" name="button" id="button" value="Salvar" />
		  <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME']; if (strpos($_SERVER ['REQUEST_URI'], 'tabdef=2')){ echo $_SERVER ['REQUEST_URI'];} else{ if (strpos($_SERVER ['REQUEST_URI'], '?')){ $ponts = '&';}else {$ponts = '?';} echo $_SERVER ['REQUEST_URI'].$ponts.'tabdef=2';} ?>" />
        </div>

  <p> 
    <input type="hidden" name="MM_update" value="lolo" />
</p> 
</form>
				
			</div>
			<div id="b<?php echo $res5['ID']; ?>" style="display:none;">
<form  id="novo" name="novo" method="POST" action="<?php echo $editFormAction; ?>" enctype="multipart/form-data" onSubmit="return valida_dados(this)">
  <input type="hidden" name="hiddenField" id="hiddenField" />
  <input type="hidden" name="nomefoto" id="nomefoto" value="<? echo $res5['nome_foto']; ?>" /> 
  
  <label>Nome do canal*</label>
  <input name="nome" type="text" id="nome" size="30" /></td>
    
  <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
                        <input type="radio" name="tipo" id="tipo" value="iframe" checked="checked">iframe (url)
						<input type="radio" name="tipo" id="tipo" value="rtmp">rtmp (streaming)
						<input type="radio" name="tipo" id="tipo" value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipo" id="tipo" value="livestream">Livestream.com
						<input type="radio" name="tipo" id="tipo" value="embed">Embed
						<input type="radio" name="tipo" id="tipo" value="m3u8">m3u8(playlist)
						<input type="radio" name="tipo" id="tipo" value="swf">swf
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label>
    <input name="urlcanal" type="text" id="urlcanal" size="30" /></td>
    
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">palavras chave</label>
	<input name="palavras" type="text" id="palavras" size="30" /></td>
    
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Canal vip ou aberto?</label>
	<SELECT name="vip" id="vip">
	      <OPTION SELECTED value="na">Aberto e vip</OPTION>
	      <OPTION value="n">Aberto</OPTION>
		  <OPTION value="s">Vip</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Exibir propaganda?</label>
	<SELECT name="propaganda" id="propaganda">
	      <OPTION SELECTED value="s">Sim</OPTION>
		  <OPTION value="n">N�o</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Ativar canal?</label>
	<SELECT name="ligar" id="ligar">
	      <OPTION SELECTED value="s">Sim</OPTION>
	      <OPTION value="n">N�o</OPTION>
	</SELECT>
	
	<div align="center"> 
        <input type="submit" class="button" name="button" id="button" value="Add canal" /> 
      </div>
	  
  <p>
    <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME']; if (strpos($_SERVER ['REQUEST_URI'], 'tabdef=2')){ echo $_SERVER ['REQUEST_URI'];} else{ if (strpos($_SERVER ['REQUEST_URI'], '?')){ $ponts = '&';}else {$ponts = '?';} echo $_SERVER ['REQUEST_URI'].$ponts.'tabdef=2';} ?>" />
    <input type="hidden" name="addopt" value="novo" /> 
</p> 
</form>
			</div>
<?
                                  $variav = $res5['nome_foto'];
                                  $sql22 = mysql_query("SELECT * from dados_beta WHERE categoria='$variav'") or die("Erro ao consultar");
                                ?>
								 <?
                                     while($varios = mysql_fetch_array($sql22)){
                                 ?>
							 <div id="c<? echo $varios['ID']; ?>" style="display:none;">
							 
							 <form action="<?php echo $editFormAction; ?>" id="lolo" name="lolo" method="POST" enctype="multipart/form-data">
  <input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $varios['ID']; ?>" />
      <label>Nome do canal*</label>
      <input name="nomedocanal" type="text" id="nomedocanal" size="30" value="<?php echo $varios['nome_do_canal']; ?>" />
	  
      <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
	  <?php
         $hr = $varios['tipo'];
         if($hr == iframe ) {  
              $resp1 = "checked='checked'"; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == rtmp ) {
			  $resp1 = ""; 
			  $resp2 = "checked='checked'";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == wmp ) {
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "checked='checked'";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == livestream ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "checked='checked'";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == embed ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "checked='checked'";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == m3u8 ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "checked='checked'";
			  $resp7 = "";
         }
		 if ($hr == swf ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "checked='checked'";
         }
    ?>
	                    <input type="radio" name="tipodocanal" id="tipodocanal" value="iframe" <?php echo  "$resp1"; ?>>iframe (url)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp2"; ?> value="rtmp">rtmp (streaming)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp3"; ?> value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp4"; ?> value="livestream">Livestream.com
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp5"; ?> value="embed">Embed
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp6"; ?> value="m3u8">m3u8(playlist)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp7"; ?> value="swf">swf
						
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label>
	<textarea name="linkdocanal" cols="40" rows="2" id="linkdocanal"><?php echo $varios['linkdcanal']; ?></textarea>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">palavras chave</label>
    <input name="palavrased" value="<?php echo $varios['palavras']; ?>" type="text" id="palavrased" size="30" /></td> 
    
	<?php
    $checarcat = mysql_query("SELECT * from dados_beta WHERE nome_foto='".$varios['categoria']."' LIMIT 1");
	$resultcat = mysql_num_rows($checarcat);
	$row_cat = mysql_fetch_assoc($checarcat);
	if($resultcat = 1){
	$catresult = $row_cat['categoria'];
	}
    ?>
	<input name="categoria" value="<?php echo $catresult; ?>" type="hidden" id="categoria"/>
   
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Canal vip ou aberto?</label>
	  <?php
         $hrp = $varios['vip'];
         if($hrp == n ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
			  $respp3 = "";
         }
		 if($hrp == s ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
			  $respp3 = "";
         }
		 if($hrp == na ) {
			  $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "selected='selected'";
         }
    ?>
    <SELECT name="vipedit" id="vipedit">
	      <OPTION <?php echo  "$respp2"; ?> value="s">Vip</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="n">Aberto</OPTION>
		  <OPTION <?php echo  "$respp3"; ?> value="na">Aberto e vip</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Exibir propaganda?</label>
	  <?php
         $hrp = $varios['propaganda'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="propagandaedit" id="propagandaedit">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
		
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Ativar canal?</label>
	  <?php
         $hrp = $varios['ligar'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="ligared" id="ligared">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
	   <br>
        
        <div align="center">

         <input name="tipoanteri" value="<?php echo $varios['vip']; ?>" type="hidden" id="tipoanteri"/>
		 <input name="catanteri" value="<?php echo $catresult; ?>" type="hidden" id="catanteri"/>
		  <input name="infolig" value="<?php echo $varios['ligar']; ?>" type="hidden" id="infolig"/>
		 <input name="libera" value="libera" type="hidden" id="libera"/>
          <input type="submit" class="button" name="button" id="button" value="Salvar" />
		  <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME']; if (strpos($_SERVER ['REQUEST_URI'], 'tabdef=2')){ echo $_SERVER ['REQUEST_URI'];} else{ if (strpos($_SERVER ['REQUEST_URI'], '?')){ $ponts = '&';}else {$ponts = '?';} echo $_SERVER ['REQUEST_URI'].$ponts.'tabdef=2';} ?>" />
        </div>

  <p> 
    <input type="hidden" name="MM_update" value="lolo" />
</p> 
</form>
							 
							 </div>
                             <? } ?>
                             <? } ?>
					<div class="tab-content" id="tab2">
						
					</div> <!-- End #tab2 -->        
					
				</div> <!-- End .content-box-content -->
				
			</div> <!-- End .content-box -->
			<div class="clear"></div>
			
		</div> <!-- End #main-content -->
		
	</div></body>
</html>