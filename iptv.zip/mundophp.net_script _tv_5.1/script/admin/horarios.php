<?php require_once('../painel/comfig.php');
      page_protect();
	  if(!checkAdmin()) {
header("Location: login.php");
exit();
} ?>
<?php

      function categoria($resp1548){
	     if($resp1548 == variedades ) {  
              return $resp456 = "1";  
         }
		 if ($resp1548 == cinema ){  
              return $resp456 = "2";  
         }
		 if ($resp1548 == esportes ){  
              return $resp456 = "3";  
         }
		 if ($resp1548 == infantil ){  
              return $resp456 = "4";  
         }
		 if ($resp1548 == clipes ){  
              return $resp456 = "5";  
         }
		 if ($resp1548 == religiosos ){  
              return $resp456 = "6";  
         }
		 if ($resp1548 == documentarios ){  
              return $resp456 = "7";  
         }
		 if ($resp1548 == noticias ){  
              return $resp456 = "9";  
         }
		 } 
		 
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "formularioeditar")) {

$catcvip = strip_tags(mysql_real_escape_string($_POST['cvip']));
$canais1223 = mysql_query("SELECT * FROM dados_beta WHERE (nome_foto = '$catcvip' or linkvip = '$catcvip')");
$row_canais1223 = mysql_fetch_assoc($canais1223);
if($row_canais1223['form'] == cadastro){
$catcvip = categoria($row_canais1223['categoria']);
}else{
$canais1223 = mysql_query("SELECT * FROM dados_beta WHERE nome_foto = '".$row_canais1223['categoria']."'");
$row_canais1223 = mysql_fetch_assoc($canais1223);
$catcvip = categoria($row_canais1223['categoria']);
}

$catcaberto = strip_tags(mysql_real_escape_string($_POST['caberto']));
$canais1223 = mysql_query("SELECT * FROM dados_beta WHERE (nome_foto = '$catcaberto' or linkvip = '$catcaberto')");
$row_canais1223 = mysql_fetch_assoc($canais1223);
if($row_canais1223['form'] == cadastro){
$catcaberto = categoria($row_canais1223['categoria']);
}else{
$canais1223 = mysql_query("SELECT * FROM dados_beta WHERE nome_foto = '".$row_canais1223['categoria']."'");
$row_canais1223 = mysql_fetch_assoc($canais1223);
$catcaberto = categoria($row_canais1223['categoria']);
}

  $updateSQL = sprintf("UPDATE horarios SET `0`=%s, `1`=%s, `2`=%s, `3`=%s, `4`=%s, `5`=%s, `6`=%s, `7`=%s, `8`=%s, `9`=%s, `10`=%s, `11`=%s, `12`=%s, `13`=%s, `14`=%s, `15`=%s, `16`=%s, `17`=%s, `18`=%s, `19`=%s, `20`=%s, `21`=%s, `22`=%s, `23`=%s , `cvip`=%s, `caberto`=%s, `tipo`=%s, `catcvip`=%s, `catcaberto`=%s WHERE id=%s",
                       GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['0'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['1'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['2'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['3'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['4'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['5'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['6'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['7'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['8'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['9'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['10'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['11'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['12'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['13'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['14'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['15'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['16'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['17'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['18'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['19'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['20'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['21'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['22'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['23'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['cvip'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['caberto'])), "text"),
					   GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['tipo'])), "text"),
					   GetSQLValueString($catcvip, "text"),
					   GetSQLValueString($catcaberto, "text"),
                       GetSQLValueString(strip_tags(mysql_real_escape_string($_POST['id'])), "int"));

  mysql_select_db($database_comfig, $link);
  $Result1 = mysql_query($updateSQL, $link) or die(mysql_error());

  $updateGoTo = "horarios.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_banners = "-1";
if (isset($_GET['id'])) {
  $colname_banners = strip_tags(mysql_real_escape_string($_GET['id']));
}

$query_banners = sprintf("SELECT * FROM horarios");
$banners = mysql_query($query_banners) or die(mysql_error());
$row_banners = mysql_fetch_assoc($banners);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
				
		<!--                       CSS                       -->
	  
		<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />
		
		<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
		<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />	
		
		<!-- Colour Schemes
	  
		Default colour scheme is green. Uncomment prefered stylesheet to use it.
		
		<link rel="stylesheet" href="resources/css/blue.css" type="text/css" media="screen" />
		
		<link rel="stylesheet" href="resources/css/red.css" type="text/css" media="screen" />  
	 
		-->
		
		<!-- Internet Explorer Fixes Stylesheet -->
		
		<!--[if lte IE 7]>
			<link rel="stylesheet" href="resources/css/ie.css" type="text/css" media="screen" />
		<![endif]-->
		
		<!--                       Javascripts                       -->
  
		<!-- jQuery -->
		<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>
		
		<!-- jQuery Configuration -->
		<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>
		
		<!-- Facebox jQuery Plugin -->
		<script type="text/javascript" src="resources/scripts/facebox.js"></script>
		
		<!-- jQuery WYSIWYG Plugin -->
		<script type="text/javascript" src="resources/scripts/jquery.wysiwyg.js"></script>
		
		<!-- jQuery Datepicker Plugin -->
		<script type="text/javascript" src="resources/scripts/jquery.datePicker.js"></script>
		<script type="text/javascript" src="resources/scripts/jquery.date.js"></script>
		<!--[if IE]><script type="text/javascript" src="resources/scripts/jquery.bgiframe.js"></script><![endif]-->

		
		<!-- Internet Explorer .png-fix -->
		
		<!--[if IE 6]>
			<script type="text/javascript" src="resources/scripts/DD_belatedPNG_0.0.7a.js"></script>
			<script type="text/javascript">
				DD_belatedPNG.fix('.png_bg, img, li');
			</script>
		<![endif]-->
		
	</head>
  
	<body><div id="body-wrapper"> <!-- Wrapper for the radial gradient background -->
		
		<div id="sidebar"><div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
			
			<h1 id="sidebar-title"><a href="#">Simpla Admin</a></h1>
		  
			<!-- Logo (221px wide) -->
			<a href="#"><img id="logo" src="resources/images/logo.png" alt="Simpla Admin logo" /></a>
		  
			<!-- Sidebar Profile links -->
			<div id="profile-links">
				<?php require_once('top.php'); ?></div>        
			
			<ul id="main-nav">  <!-- Accordion Menu -->
				
				<?php require_once('mnu.php'); ?>
				
			</ul> <!-- End #main-nav -->
			
		</div></div> 
		<!-- End #sidebar -->
		
		<div id="main-content"> <!-- Main Content Section with everything -->
			
			<noscript> <!-- Show a notification if the user has disabled javascript -->
				<div class="notification error png_bg">
					<div>
						Javascript is disabled or is not supported by your browser. Please <a href="http://browsehappy.com/" title="Upgrade to a better browser">upgrade</a> your browser or <a href="http://www.google.com/support/bin/answer.py?answer=23852" title="Enable Javascript in your browser">enable</a> Javascript to navigate the interface properly.
				    </div>
				</div>
			</noscript>
			
			<!-- Page Head -->
			
			<div class="clear"></div> <!-- End .clear -->
			
			<div class="content-box"><!-- Start Content Box -->
				
				<div class="content-box-header">
					
					<h3>Canal da index</h3>
					
					<ul class="content-box-tabs">
					</ul>
					
					<div class="clear"></div>
					
				</div> <!-- End .content-box-header -->
				
				<div class="content-box-content">
					
					<div class="tab-content default-tab" id="tab1"> <!-- This is the target div. id must match the href of this div's tab -->
					<? $hrp12 = $row_banners['tipo'];
         if($hrp12 == 1 ) {  
              $rep1 = "checked='checked'"; 
			  $rep2 = "";
         }
		 if($hrp12 == 2) {
			  $rep1 = ""; 
			  $rep2 = "checked='checked'";
         } ?>
					  <form action="<?php echo $editFormAction; ?>" method="POST" name="formularioeditar">
    <input name="id" type="hidden" id="id" value="<?php echo $row_banners['ID']; ?>" />
	              <h3><input type="radio" name="tipo" id="tipo" value="1" <?php echo  "$rep1"; ?>>Canal fixo</h3><br />
                  Area aberta: <select name='caberto' >
                  <?php
				  
                  $result = mysql_query("SELECT * FROM dados_beta WHERE lugar = 'canais' AND (vip = 'n' or vip = 'na') AND tipo!='swf' AND ligar = 's'  ORDER BY nome_do_canal");
                  while($row = mysql_fetch_array($result)) {
                   if($row_banners['caberto'] == $row['nome_foto']){
				  $check = " selected=\"selected\"";
				  }else{
				   $check = "";
				  }
                    echo '<option value="'.$row['nome_foto'].'"'.$check.'>'.$row['nome_do_canal'].'</option><br>';
                  }
                  ?>
                   </select>
				   Area vip: <select name='cvip' >
                  <?php
                  $result = mysql_query("SELECT * FROM dados_beta WHERE lugar = 'canais' AND (vip = 's' or vip = 'na') AND tipo!='swf' AND ligar = 's'  ORDER BY nome_do_canal");
                  while($row = mysql_fetch_array($result)) {
				  if($row_banners['cvip'] === $row['linkvip']){
				  $check2 = " selected=\"selected\"";
				  }else{
				   $check2 = "";
				  }
                    echo '<option value="'.$row['linkvip'].'"'.$check2.'>'.$row['nome_do_canal'].'</option><br>';
                  }
                  ?>
                   </select><br /><br />
				   <input type="submit" name="button" id="button" class="button" value="salvar altera�oes" />
				   <h3><input type="radio" name="tipo" id="tipo" value="2" <?php echo  "$rep2"; ?>>Sortear um canal de uma categoria de acordo com a hora</h3><br />
				   
<table width="100%" border="0">
<tr>
    <td><h3>Horario</h3></td>
    <td><h3>1</h3></td>
    <td><h3>2</h3></td>
    <td><h3>3</h3></td>
    <td><h3>4</h3></td>
    <td><h3>5</h3></td>
    <td><h3>6</h3></td>
    <td><h3>7</h3></td>
    <td><h3>8</h3></td>
  </tr>
  <tr>
    <td>00:00 as 1:00</td>
	<?php
         $hrp = $row_banners['0'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="0" id="0" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input name="0" type="radio" id="0" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="0" id="0" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="0" id="0" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="0" id="0" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="0" id="0" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="0" id="0" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="0" id="0" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>1:00 as 2:00</td>
	<?php
         $hrp = $row_banners['1'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="1" id="1" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="1" id="1" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="1" id="1" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="1" id="1" value="4" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="1" id="1" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="1" id="1" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="1" id="1" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="1" id="1" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>2:00 as 3:00</td>
	<?php
         $hrp = $row_banners['2'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="2" id="2" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="2" id="2" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="2" id="2" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="2" id="2" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="2" id="2" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="2" id="2" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="2" id="2" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="2" id="2" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>3:00 as 4:00</td>
	<?php
         $hrp = $row_banners['3'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="3" id="3" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="3" id="3" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="3" id="3" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="3" id="3" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="3" id="3" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="3" id="3" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="3" id="3" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="3" id="3" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>4:00 as 5:00</td>
	<?php
         $hrp = $row_banners['4'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="4" id="4" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="4" id="4" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="4" id="4" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="4" id="4" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="4" id="4" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="4" id="4" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="4" id="4" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="4" id="4" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>5:00 as 6:00</td>
	<?php
         $hrp = $row_banners['5'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="5" id="5" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="5" id="5" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="5" id="5" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="5" id="5" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="5" id="5" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="5" id="5" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="5" id="5" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="5" id="5" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>6:00 as 7:00</td>
	<?php
         $hrp = $row_banners['6'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="6" id="6" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="6" id="6" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="6" id="6" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="6" id="6" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="6" id="6" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="6" id="6" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="6" id="6" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="6" id="6" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>7:00 as 8:00</td>
	<?php
         $hrp = $row_banners['7'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="7" id="7" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="7" id="7" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="7" id="7" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="7" id="7" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="7" id="7" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="7" id="7" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="7" id="7" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="7" id="7" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>8:00 as 9:00</td>
	<?php
         $hrp = $row_banners['8'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="8" id="8" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="8" id="8" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="8" id="8" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="8" id="8" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="8" id="8" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="8" id="8" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="8" id="8" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="8" id="8" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>9:00 as 10:00</td>
	<?php
         $hrp = $row_banners['9'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="9" id="9" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="9" id="9" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="9" id="9" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="9" id="9" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="9" id="9" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="9" id="9" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="9" id="9" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="9" id="9" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>10:00 as 11:00</td>
	<?php
         $hrp = $row_banners['10'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="10" id="10" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="10" id="10" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="10" id="10" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="10" id="10" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="10" id="10" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="10" id="10" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="10" id="10" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="10" id="10" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>11:00 as 12:00</td>
	<?php
         $hrp = $row_banners['11'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="11" id="11" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="11" id="11" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="11" id="11" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="11" id="11" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="11" id="11" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="11" id="11" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="11" id="11" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="11" id="11" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>12:00 as 13:00</td>
	<?php
         $hrp = $row_banners['12'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="12" id="12" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="12" id="12" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="12" id="12" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="12" id="12" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="12" id="12" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="12" id="12" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="12" id="12" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="12" id="12" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>13:00 as 14:00</td>
	<?php
         $hrp = $row_banners['13'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="13" id="13" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="13" id="13" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="13" id="13" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="13" id="13" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="13" id="13" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="13" id="13" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="13" id="13" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="13" id="13" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>14:00 as 15:00</td>
	<?php
         $hrp = $row_banners['14'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="14" id="14" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="14" id="14" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="14" id="14" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="14" id="14" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="14" id="14" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="14" id="14" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="14" id="14" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="14" id="14" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>15:00 as 16:00</td>
	<?php
         $hrp = $row_banners['15'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="15" id="15" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="15" id="15" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="15" id="15" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="15" id="15" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="15" id="15" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="15" id="15" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="15" id="15" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="15" id="15" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>16:00 as 17:00</td>
	<?php
         $hrp = $row_banners['16'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="16" id="16" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="16" id="16" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="16" id="16" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="16" id="16" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="16" id="16" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="16" id="16" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="16" id="16" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="16" id="16" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>17:00 as 18:00</td>
	<?php
         $hrp = $row_banners['17'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="17" id="17" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="17" id="17" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="17" id="17" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="17" id="17" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="17" id="17" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="17" id="17" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="17" id="17" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="17" id="17" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>18:00 as 19:00</td>
	<?php
         $hrp = $row_banners['18'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="18" id="18" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="18" id="18" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="18" id="18" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="18" id="18" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="18" id="18" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="18" id="18" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="18" id="18" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="18" id="18" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>19:00 as 20:00</td>
	<?php
         $hrp = $row_banners['19'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="19" id="19" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="19" id="19" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="19" id="19" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="19" id="19" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="19" id="19" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="19" id="19" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="19" id="19" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="19" id="19" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>20:00 as 21:00</td>
	<?php
         $hrp = $row_banners['20'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="20" id="20" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="20" id="20" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="20" id="20" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="20" id="20" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="20" id="20" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="20" id="20" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="20" id="20" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="20" id="20" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>21:00 as 22:00</td>
	<?php
         $hrp = $row_banners['21'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="21" id="21" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="21" id="21" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="21" id="21" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="21" id="21" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="21" id="21" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="21" id="21" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="21" id="21" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="21" id="21" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>22:00 as 23:00</td>
	<?php
         $hrp = $row_banners['22'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="22" id="22" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="22" id="22" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="22" id="22" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="22" id="22" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="22" id="22" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="22" id="22" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="22" id="22" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="22" id="22" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
    <td>23:00 as 24:00</td>
	<?php
         $hrp = $row_banners['23'];
         if($hrp == 1 ) { 
              $respp1 = "checked='checked'"; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 2 ) {  
              $respp1 = ""; 
			  $respp2 = "checked='checked'";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 3 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "checked='checked'";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 4 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "checked='checked'";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 5 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "checked='checked'";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 6 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "checked='checked'";
			  $respp7 = "";
			  $respp8 = "";
         }
		 if($hrp == 7 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "checked='checked'";
			  $respp8 = "";
         }
		 if($hrp == 8 ) {  
              $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "";
			  $respp4 = "";
			  $respp5 = "";
			  $respp6 = "";
			  $respp7 = "";
			  $respp8 = "checked='checked'";
         }
    ?>
    <td><input type="radio" name="23" id="23" value="1" <?php echo  "$respp1"; ?>></td>
    <td><input type="radio" name="23" id="23" value="2" <?php echo  "$respp2"; ?>></td>
    <td><input type="radio" name="23" id="23" value="3" <?php echo  "$respp3"; ?>></td>
    <td><input type="radio" name="23" id="23" value="4" <?php echo  "$respp4"; ?>></td>
    <td><input type="radio" name="23" id="23" value="5" <?php echo  "$respp5"; ?>></td>
    <td><input type="radio" name="23" id="23" value="6" <?php echo  "$respp6"; ?>></td>
    <td><input type="radio" name="23" id="23" value="7" <?php echo  "$respp7"; ?>></td>
    <td><input type="radio" name="23" id="23" value="8" <?php echo  "$respp8"; ?>></td>
  </tr>
  <tr>
      <th scope="col"><div align="left">
        <input type="submit" name="button" id="button" class="button" value="salvar altera�oes" />
      </div></th>
    </tr>
</table>
<input type="hidden" name="MM_update" value="formularioeditar" />
  </form>
						
				  </div> <!-- End #tab1 -->
					
				  <div class="tab-content" id="tab2"></div> 
					<!-- End #tab2 -->        
					
				</div> <!-- End .content-box-content -->
				
			</div>
<div class="clear"></div>
			
			
			<!-- Start Notifications --><!-- End Notifications -->
			
		</div> <!-- End #main-content -->
		
	</div></body>
  

<!-- Download From www.exet.tk-->
</html>