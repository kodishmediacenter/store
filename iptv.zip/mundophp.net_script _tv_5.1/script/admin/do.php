<?php 
include '../painel/comfig.php';
session_start();
if(!checkAdmin()) {
header("Location: login.php");
exit();
}
$data = date('Y-m-d');
$ret = $_SERVER['HTTP_REFERER'];

foreach($_GET as $key => $value) {
	$get[$key] = filter($value);
}

if($get['cmd'] == 'Aprovar')
{
mysql_query("update users set approved='1' where id='$get[id]'") or die(mysql_error());
$rs_email = mysql_query("select user_email from users where id='$get[id]'") or die(mysql_error());
list($to_email) = mysql_fetch_row($rs_email);

$host  = $_SERVER['HTTP_HOST'];
$host_upper = strtoupper($host);
$login_path = @ereg_replace('admin','',dirname($_SERVER['PHP_SELF']));
$path   = rtrim($login_path, '/\\');

$message = 
"Obrigado por se registrar conosco. Sua conta foi ativada...

*****Link de Login*****\n
$siteurl/painel/login.php

Obrigado

Administrador
$host_upper
______________________________________________________
Esta � uma resposta autom�tica.
***N�o responda a este e-mail****
";

	@mail($to_email, "Ativa��o de Usu�rio", $message,
    "From: \"Tv online\" <auto-reply@$host>\r\n" .
     "X-Mailer: PHP/" . phpversion());


 echo "Ativo";


}

if($get['cmd'] == 'banir')
{
mysql_query("update users set banned='1' where id='$get[id]' and `user_name` <> 'admin'");

//header("Location: $ret");  
echo "Sim";
exit();

}
/* Editing users*/

if($get['cmd'] == 'edit')
{
/* Duplicate user name check */
$rs_usr_duplicate = mysql_query("select count(*) as total from `users` where `user_name`='$get[user_name]' and `id` != '$get[id]'") or die(mysql_error());
list($usr_total) = mysql_fetch_row($rs_usr_duplicate);
	if ($usr_total > 0)
	{
	echo "Desculpe! nome de usu&aacute;rio j&aacute; cadastrado.";
	exit;
	} 
/* Duplicate email check */	
$rs_eml_duplicate = mysql_query("select count(*) as total from `users` where `user_email`='$get[user_email]' and `id` != '$get[id]'") or die(mysql_error());
list($eml_total) = mysql_fetch_row($rs_eml_duplicate);
	if ($eml_total > 0)
	{
	echo "Desculpe! email usu&aacute;rio j&aacute; cadastrado.";
	exit;
	}
/* Now update user data*/	
mysql_query("
update users set  
`user_name`='$get[user_name]', 
`user_email`='$get[user_email]',
`vencimento`='$get[vencimento]',
`data`='$get[data]',
`user_level`='$get[user_level]'
where `id`='$get[id]'") or die(mysql_error());
//header("Location: $ret"); 

if(!empty($get['pass'])) {
$hash = PwdHash($get['pass']);
mysql_query("update users set `pwd` = '$hash' where `id`='$get[id]'") or die(mysql_error());
}

echo "altera&ccedil;&otilde;es feitas";
exit();
}

if($get['cmd'] == 'desbanir')
{
mysql_query("update users set banned='0' where id='$get[id]'");
echo "Nao";

//header("Location: $ret");  
// exit();

}


?>