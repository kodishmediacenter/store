<?php require_once('../painel/comfig.php');
      page_protect();
	  if(!checkAdmin()) {
header("Location: login.php");
exit();
} ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$editFormAction = $_SERVER['PHP_SELF']; 
if (isset($_SERVER['QUERY_STRING'])) { 
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']); 
} 


 if ((isset($_POST["MM_insert1"])) && ($_POST["MM_insert1"] == "novoform1")) {
$valor = strip_tags(mysql_real_escape_string(substr( $_POST['example2'], 3 )));
$result = mysql_num_rows(mysql_query("SELECT * FROM formaspag WHERE valor = '$valor'"));
$tempo = strip_tags(mysql_real_escape_string($_POST['tempo']));
if ($result < 1){
  $insertSQL = sprintf("INSERT INTO formaspag (`valor`, `tempo`, `moeda`) VALUES (%s, %s, %s)",
                       GetSQLValueString($valor, "text"),
					   GetSQLValueString($tempo, "text"),
					   GetSQLValueString('BRL', "text"));
					    
  mysql_select_db($database_comfig, $link); 
  $Result1 = mysql_query($insertSQL, $link) or die(mysql_error()); 
 
  $insertGoTo = "valor.php"; 
  if (isset($_SERVER['QUERY_STRING'])) { 
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?"; 
    $insertGoTo .= $_SERVER['QUERY_STRING']; 
  } 
  header(sprintf("Location: %s", $insertGoTo));
  }else{
  echo "<script type='text/javascript'>
alert('N�o pode cadastrar um pre�o ja existente');
</script>"; 
  }
}

$maxRows_menudecanais = 1000;
$pageNum_menudecanais = 0;
if (isset($_GET['pageNum_menudecanais'])) {
  $pageNum_menudecanais = $_GET['pageNum_menudecanais'];
}
$startRow_menudecanais = $pageNum_menudecanais * $maxRows_menudecanais;

mysql_select_db($database_comfig, $link);
$query_menudecanais = "SELECT * FROM formaspag ORDER BY tempo ASC";
$query_limit_menudecanais = sprintf("%s LIMIT %d, %d", $query_menudecanais, $startRow_menudecanais, $maxRows_menudecanais);
$menudecanais = mysql_query($query_limit_menudecanais, $link) or die(mysql_error());
$row_menudecanais = mysql_fetch_assoc($menudecanais);

if (isset($_GET['totalRows_menudecanais'])) {
  $totalRows_menudecanais = $_GET['totalRows_menudecanais'];
} else {
  $all_menudecanais = mysql_query($query_menudecanais);
  $totalRows_menudecanais = mysql_num_rows($all_menudecanais);
}
$totalPages_menudecanais = ceil($totalRows_menudecanais/$maxRows_menudecanais)-1;

$maxRows_editarvariedades = 1000;
$pageNum_editarvariedades = 0;
if (isset($_GET['pageNum_editarvariedades'])) {
  $pageNum_editarvariedades = $_GET['pageNum_editarvariedades'];
}
$startRow_editarvariedades = $pageNum_editarvariedades * $maxRows_editarvariedades;

mysql_select_db($database_comfig, $link);
$query_editarvariedades = "SELECT * FROM formaspag ORDER BY tempo ASC";
$query_limit_editarvariedades = sprintf("%s LIMIT %d, %d", $query_editarvariedades, $startRow_editarvariedades, $maxRows_editarvariedades);
$editarvariedades = mysql_query($query_limit_editarvariedades, $link) or die(mysql_error());
$row_editarvariedades = mysql_fetch_assoc($editarvariedades);

if (isset($_GET['totalRows_editarvariedades'])) {
  $totalRows_editarvariedades = $_GET['totalRows_editarvariedades'];
} else {
  $all_editarvariedades = mysql_query($query_editarvariedades);
  $totalRows_editarvariedades = mysql_num_rows($all_editarvariedades);
}
$totalPages_editarvariedades = ceil($totalRows_editarvariedades/$maxRows_editarvariedades)-1;

mysql_select_db($database_comfig, $link);
$query_editarnoticias = "SELECT * FROM formaspag ORDER BY tempo ASC";
$query_limit_editarnoticias = sprintf("%s LIMIT %d, %d", $query_editarnoticias, $startRow_editarnoticias, $maxRows_editarnoticias);
$editarnoticias = mysql_query($query_limit_editarnoticias, $link) or die(mysql_error());
$row_editarnoticias = mysql_fetch_assoc($editarnoticias);

if (isset($_GET['totalRows_editarnoticias'])) {
  $totalRows_editarnoticias = $_GET['totalRows_editarnoticias'];
} else {
  $all_editarnoticias = mysql_query($query_editarnoticias);
  $totalRows_editarnoticias = mysql_num_rows($all_editarnoticias);
}
//deletar registro sem foto >>
if ((isset($_GET['deletar'])) && ($_GET['deletar'] != "")) {

$iddelete = strip_tags(mysql_real_escape_string($_GET['deletar']));
$retorno = 'http://'.base64_decode(strip_tags(mysql_real_escape_string($_GET['retorna'])));

mysql_query("DELETE FROM formaspag WHERE ID=$iddelete");

header(sprintf("Location: %s", $retorno));
exit();
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
				
		<!--                       CSS                       -->
	  
		<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />
		
		<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
		<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />	
		
		<!-- Colour Schemes
	  
		Default colour scheme is green. Uncomment prefered stylesheet to use it.
		
		<link rel="stylesheet" href="resources/css/blue.css" type="text/css" media="screen" />
		
		<link rel="stylesheet" href="resources/css/red.css" type="text/css" media="screen" />  
	 
		-->
		
		<!-- Internet Explorer Fixes Stylesheet -->
		
		<!--[if lte IE 7]>
			<link rel="stylesheet" href="resources/css/ie.css" type="text/css" media="screen" />
		<![endif]-->
		
		<!--                       Javascripts                       -->
  
		<!-- jQuery -->
		<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>
		
		<!-- jQuery Configuration -->
		<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>
		
		<!-- Facebox jQuery Plugin -->
		<script type="text/javascript" src="resources/scripts/facebox.js"></script>
		
		<!-- jQuery WYSIWYG Plugin -->
		<script type="text/javascript" src="resources/scripts/jquery.wysiwyg.js"></script>
		
		<!-- jQuery Datepicker Plugin -->
		<script type="text/javascript" src="resources/scripts/jquery.datePicker.js"></script>
		<script type="text/javascript" src="resources/scripts/jquery.date.js"></script>
		<!--[if IE]><script type="text/javascript" src="resources/scripts/jquery.bgiframe.js"></script><![endif]-->
		
		<script type="text/javascript" src="resources/jquery.price_format.2.0.js"></script>
		<script type="text/javascript">
		$(function(){
	
	$('#example2').priceFormat({
		prefix: 'R$ ',
		centsSeparator: '.',
		thousandsSeparator: ''
	});

});
		</script>

		<script type="text/javascript">
			$(document).ready(function() {
    $("#tempo").keydown(function(event) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ( $.inArray(event.keyCode,[46,8,9,27,13,190]) !== -1 ||
             // Allow: Ctrl+A
            (event.keyCode == 65 && event.ctrlKey === true) || 
             // Allow: home, end, left, right
            (event.keyCode >= 35 && event.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        else {
            // Ensure that it is a number and stop the keypress
            if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
                event.preventDefault(); 
            }   
        }
    });
});
			</script>
		<!-- Internet Explorer .png-fix -->
		
		<!--[if IE 6]>
			<script type="text/javascript" src="resources/scripts/DD_belatedPNG_0.0.7a.js"></script>
			<script type="text/javascript">
				DD_belatedPNG.fix('.png_bg, img, li');
			</script>
		<![endif]-->
		<script language="javascript">
<!-- chama a fun��o (nomeform) -->
function valida_dados (novoform1)
{
    if (novoform1.tempo.value=="")
    {
        alert ("Por favor digite o Tempo.");
        return false;
    }
	
	if (novoform1.example2.value=="")
    {
        alert ("Por favor digite um pre�o.");
        return false;
    }
    
return true;
}
</script>
	</head>
  
	<body><div id="body-wrapper"> <!-- Wrapper for the radial gradient background -->
		
		<div id="sidebar"><div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
			
			<h1 id="sidebar-title"><a href="#">Simpla Admin</a></h1>
		  
			<!-- Logo (221px wide) -->
			<a href="#"><img id="logo" src="resources/images/logo.png" alt="Simpla Admin logo" /></a>
		  
			<!-- Sidebar Profile links -->
		  <div id="profile-links">
		  
			  <?php require_once('top.php'); ?>			</div>        
			
			<ul id="main-nav">  <!-- Accordion Menu -->
				
				<?php require_once('mnu.php'); ?>
				
			</ul> <!-- End #main-nav -->
			
			
			
		</div></div> <!-- End #sidebar -->
		
		<div id="main-content"> <!-- Main Content Section with everything -->
			
			<noscript> <!-- Show a notification if the user has disabled javascript -->
				<div class="notification error png_bg">
					<div>
						Javascript is disabled or is not supported by your browser. Please <a href="http://browsehappy.com/" title="Upgrade to a better browser">upgrade</a> your browser or <a href="http://www.google.com/support/bin/answer.py?answer=23852" title="Enable Javascript in your browser">enable</a> Javascript to navigate the interface properly.
					</div>
				</div>
			</noscript>
			
			<!-- Page Head -->
			
			<div class="clear"></div> <!-- End .clear -->
			
			<div class="content-box"><!-- Start Content Box -->
				
				<div class="content-box-header">
					
					<h3><?
$consulta = mysql_query("SELECT * FROM formaspag");
$qtd = mysql_num_rows($consulta);
echo "<font face=Verdana, Arial, Helvetica, sans-serif><font size=1>$qtd</a></font>";
?> Planos
</h3>
					
					<ul class="content-box-tabs">
						<li><a href="#tab1" class="default-tab">Pre�os</a></li> <!-- href must be unique and match the id of target div -->
					</ul>
					
					<div class="clear"></div>
					
				</div> <!-- End .content-box-header -->
				
				<div class="content-box-content">
				
				  <div class="tab-content default-tab" id="tab1"> <!-- This is the target div. id must match the href of this div's tab -->
						
						<table>
							
							<thead>
								<tr>
								   <th>Pre�o</th>
								   <th>Tempo (em meses)</th>
								   <th>Op�&otilde;es</th>
								</tr>
								
							</thead>
						 
							<tbody>
							<?php do { ?>
								<tr>
									<td>R$<?php echo $row_editarvariedades['valor']; ?></td>
									<td><?php echo $row_editarvariedades['tempo']; ?></td>
									<td>
										<!-- Icons -->
										
										 <a href='?deletar=<? echo $row_editarvariedades['id']; ?>&retorna=<? echo base64_encode($_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']); ?>' title='Deletar' onclick="return confirm('Confirma exclus�o do valor?')"><img src='resources/images/icons/cross.png' alt='Deletar' /></a> 
									</td>
								</tr>
							</tbody>
							<?php } while ($row_editarvariedades = mysql_fetch_assoc($editarvariedades)); ?>
						</table>
						<br />
						<form  id="novoform1" name="novoform1" method="POST" enctype="multipart/form-data" onSubmit="return valida_dados(this)">
  <input type="hidden" name="hiddenField" id="hiddenField" />
					
						<label>Valor*</label> 
						<input id="example2" type="text" class="text-input" value=" " name="example2"></input>
						<label>Tempo (em meses)*</label> 
						<input name="tempo" type="text" id="tempo" class="text-input" onKeyPress="return sem_acento(event);" />
						
					<p/>
						<input type="submit" class="button" name="button" id="button" value="Add pre�o" />
    <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']; ?>" /> 
    <input type="hidden" name="MM_insert1" value="novoform1" /> 
</form>
					    <div>
					      <div>N&atilde;o &eacute;&nbsp;aconselh&aacute;vel&nbsp;ficar apagando os valores, crie e deixe! Porque caso um&nbsp;usu&aacute;rio online&nbsp;clicar em um valor antes de voc&ecirc; apagar e logo ap&oacute;s voc&ecirc; apagar ele finalizar a compra com um valor que&nbsp;n&atilde;o&nbsp;existe o pagamento dele&nbsp;n&atilde;o&nbsp;vai ser confirmado automaticamente</div>
			        </div>
					</div> <!-- End #tab1 -->
					
				</div> <!-- End .content-box-content -->
				
			</div> <!-- End .content-box -->
			
			<div class="clear"></div>

			
		</div> <!-- End #main-content -->
		
	</div></body>
  

<!-- Download From www.exet.tk-->
</html>
