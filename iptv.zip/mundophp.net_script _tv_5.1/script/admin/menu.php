<?php require_once('../painel/comfig.php');
      page_protect();
	  if(!checkAdmin()) {
header("Location: login.php");
exit();
} ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$editFormAction = $_SERVER['PHP_SELF']; 
if (isset($_SERVER['QUERY_STRING'])) { 
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']); 
} 

$unid = uniqid();
function friendlyUrl($string) {

    $table = array(
            '�'=>'S', '�'=>'s', '�'=>'D', 'd'=>'d', '�'=>'Z', '�'=>'z', 'C'=>'C', 'c'=>'c', 'C'=>'C', 'c'=>'c',
            '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'A', '�'=>'C', '�'=>'E', '�'=>'E',
            '�'=>'E', '�'=>'E', '�'=>'I', '�'=>'I', '�'=>'I', '�'=>'I', '�'=>'N', '�'=>'O', '�'=>'O', '�'=>'O',
            '�'=>'O', '�'=>'O', '�'=>'O', '�'=>'U', '�'=>'U', '�'=>'U', '�'=>'U', '�'=>'Y', '�'=>'B', '�'=>'Ss',
            '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'a', '�'=>'c', '�'=>'e', '�'=>'e',
            '�'=>'e', '�'=>'e', '�'=>'i', '�'=>'i', '�'=>'i', '�'=>'i', '�'=>'o', '�'=>'n', '�'=>'o', '�'=>'o',
            '�'=>'o', '�'=>'o', '�'=>'o', '�'=>'o', '�'=>'u', '�'=>'u', '�'=>'u', '�'=>'y', '�'=>'y', '�'=>'b',
            '�'=>'y', 'R'=>'R', 'r'=>'r', '/' => '-', ' ' => '-', '&'=>'e'
    );

    // -- Remove duplicated spaces
    $stripped = preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $string);

    // -- Returns the slug
    return strtolower(strtr($string, $table));


}
$variavel_limpa = friendlyUrl(strip_tags(mysql_real_escape_string($_POST['nome'])));
$nome_final = $variavel_limpa.'-'."menu-".$unid; 
$nome_finalvip = $variavel_limpa.'-'."vip-".$unid;
 
 if ((isset($_POST["MM_insert1"])) && ($_POST["MM_insert1"] == "novoform1")) {
 $tipo = strip_tags(mysql_real_escape_string($_POST['tipo']));
 $propaganda = strip_tags(mysql_real_escape_string($_POST['propaganda']));
 $nome = strip_tags(mysql_real_escape_string($_POST['nome']));
 $vip = strip_tags(mysql_real_escape_string($_POST['vip']));
 $urlcanal = $_POST['urlcanal'];
 $ligar = strip_tags(mysql_real_escape_string($_POST['ligar']));
 
  $insertSQL = sprintf("INSERT INTO dados_beta (`nome_do_canal`, `vip`, `ligar`, linkdcanal, `nome_foto`, `tipo`, `categoria`, lugar, `linkvip`, propaganda) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($nome, "text"),
					   GetSQLValueString($vip, "text"),
					   GetSQLValueString($ligar, "text"),
                       GetSQLValueString($urlcanal, "text"),
					   GetSQLValueString($nome_final, "text"),
					   GetSQLValueString($tipo, "text"),
					   GetSQLValueString('variedades', "text"),
					   GetSQLValueString('menu', "text"),
					   GetSQLValueString($nome_finalvip, "text"),
					   GetSQLValueString($propaganda, "text"));
					    
  mysql_select_db($database_comfig, $link); 
  $Result1 = mysql_query($insertSQL, $link) or die(mysql_error()); 
 
  $insertGoTo = "menu.php"; 
  if (isset($_SERVER['QUERY_STRING'])) { 
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?"; 
    $insertGoTo .= $_SERVER['QUERY_STRING']; 
  } 
  header(sprintf("Location: %s", $insertGoTo)); 
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "lolo")) {
   mysql_query("UPDATE dados_beta SET `nome_do_canal`='".strip_tags(mysql_real_escape_string($_POST['nomedocanal']))."', tipo='".strip_tags(mysql_real_escape_string($_POST['tipodocanal']))."', linkdcanal='".$_POST['linkdocanal']."', categoria='variedades', vip='".strip_tags(mysql_real_escape_string($_POST['vipedit']))."', propaganda='".strip_tags(mysql_real_escape_string($_POST['propagandaedit']))."', palavras='".strip_tags(mysql_real_escape_string($_POST['palavrased']))."', ligar='".strip_tags(mysql_real_escape_string($_POST['ligared']))."' WHERE ID='".strip_tags(mysql_real_escape_string($_POST['hiddenField']))."'");

  $updateGoTo = "menu.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$maxRows_menudecanais = 1000;
$pageNum_menudecanais = 0;
if (isset($_GET['pageNum_menudecanais'])) {
  $pageNum_menudecanais = strip_tags(mysql_real_escape_string($_GET['pageNum_menudecanais']));
}
$startRow_menudecanais = $pageNum_menudecanais * $maxRows_menudecanais;

mysql_select_db($database_comfig, $link);
$query_menudecanais = "SELECT * FROM dados_beta ORDER BY ID ASC";
$query_limit_menudecanais = sprintf("%s LIMIT %d, %d", $query_menudecanais, $startRow_menudecanais, $maxRows_menudecanais);
$menudecanais = mysql_query($query_limit_menudecanais, $link) or die(mysql_error());
$row_menudecanais = mysql_fetch_assoc($menudecanais);

if (isset($_GET['totalRows_menudecanais'])) {
  $totalRows_menudecanais = strip_tags(mysql_real_escape_string($_GET['totalRows_menudecanais']));
} else {
  $all_menudecanais = mysql_query($query_menudecanais);
  $totalRows_menudecanais = mysql_num_rows($all_menudecanais);
}
$totalPages_menudecanais = ceil($totalRows_menudecanais/$maxRows_menudecanais)-1;

$maxRows_editarvariedades = 1000;
$pageNum_editarvariedades = 0;
if (isset($_GET['pageNum_editarvariedades'])) {
  $pageNum_editarvariedades = strip_tags(mysql_real_escape_string($_GET['pageNum_editarvariedades']));
}
$startRow_editarvariedades = $pageNum_editarvariedades * $maxRows_editarvariedades;

mysql_select_db($database_comfig, $link);
$query_editarvariedades = "SELECT * FROM dados_beta WHERE lugar LIKE 'menu' ORDER BY ID ASC";
$query_limit_editarvariedades = sprintf("%s LIMIT %d, %d", $query_editarvariedades, $startRow_editarvariedades, $maxRows_editarvariedades);
$editarvariedades = mysql_query($query_limit_editarvariedades, $link) or die(mysql_error());
$row_editarvariedades = mysql_fetch_assoc($editarvariedades);

if (isset($_GET['totalRows_editarvariedades'])) {
  $totalRows_editarvariedades = strip_tags(mysql_real_escape_string($_GET['totalRows_editarvariedades']));
} else {
  $all_editarvariedades = mysql_query($query_editarvariedades);
  $totalRows_editarvariedades = mysql_num_rows($all_editarvariedades);
}
$totalPages_editarvariedades = ceil($totalRows_editarvariedades/$maxRows_editarvariedades)-1;

mysql_select_db($database_comfig, $link);
$query_editarnoticias = "SELECT * FROM dados_beta WHERE categoria LIKE  'noticias' ORDER BY ID ASC";
$query_limit_editarnoticias = sprintf("%s LIMIT %d, %d", $query_editarnoticias, $startRow_editarnoticias, $maxRows_editarnoticias);
$editarnoticias = mysql_query($query_limit_editarnoticias, $link) or die(mysql_error());
$row_editarnoticias = mysql_fetch_assoc($editarnoticias);

if (isset($_GET['totalRows_editarnoticias'])) {
  $totalRows_editarnoticias = strip_tags(mysql_real_escape_string($_GET['totalRows_editarnoticias']));
} else {
  $all_editarnoticias = mysql_query($query_editarnoticias);
  $totalRows_editarnoticias = mysql_num_rows($all_editarnoticias);
}
//deletar registro sem foto >>
if ((isset($_GET['deletar'])) && ($_GET['deletar'] != "")) {

$iddelete = strip_tags(mysql_real_escape_string($_GET['deletar']));
$retorno = 'http://'.base64_decode($_GET['retorna']);

mysql_query("DELETE FROM dados_beta WHERE ID=$iddelete");

header(sprintf("Location: %s", $retorno));
exit();
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
			
		<!--                       CSS                       -->
	  
		<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />
		
		<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
		<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />	
		
		<!-- Colour Schemes
	  
		Default colour scheme is green. Uncomment prefered stylesheet to use it.
		
		<link rel="stylesheet" href="resources/css/blue.css" type="text/css" media="screen" />
		
		<link rel="stylesheet" href="resources/css/red.css" type="text/css" media="screen" />  
	 
		-->
		
		<!-- Internet Explorer Fixes Stylesheet -->
		
		<!--[if lte IE 7]>
			<link rel="stylesheet" href="resources/css/ie.css" type="text/css" media="screen" />
		<![endif]-->
		
		<!--                       Javascripts                       -->
  
		<!-- jQuery -->
		<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>
		
		<!-- jQuery Configuration -->
		<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>
		
		<!-- Facebox jQuery Plugin -->
		<script type="text/javascript" src="resources/scripts/facebox.js"></script>
		
		<!-- jQuery WYSIWYG Plugin -->
		<script type="text/javascript" src="resources/scripts/jquery.wysiwyg.js"></script>
		
		<!-- jQuery Datepicker Plugin -->
		<script type="text/javascript" src="resources/scripts/jquery.datePicker.js"></script>
		<script type="text/javascript" src="resources/scripts/jquery.date.js"></script>
		<!--[if IE]><script type="text/javascript" src="resources/scripts/jquery.bgiframe.js"></script><![endif]-->

			<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
		<!-- Internet Explorer .png-fix -->
		
		<!--[if IE 6]>
			<script type="text/javascript" src="resources/scripts/DD_belatedPNG_0.0.7a.js"></script>
			<script type="text/javascript">
				DD_belatedPNG.fix('.png_bg, img, li');
			</script>
		<![endif]-->
		<script language="javascript">
<!-- chama a fun��o (nomeform) -->
function valida_dados (novoform1)
{
    if (novoform1.nome.value=="")
    {
        alert ("Por favor digite o nome.");
        return false;
    }
	
	if (novoform1.urlcanal.value=="")
    {
        alert ("Por favor coloque a url, rtmp ou wmp.");
        return false;
    }
    
return true;
}
</script>
	</head>
  
	<body><div id="body-wrapper"> <!-- Wrapper for the radial gradient background -->
		
		<div id="sidebar"><div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
			
			<h1 id="sidebar-title"><a href="#">Simpla Admin</a></h1>
		  
			<!-- Logo (221px wide) -->
			<a href="#"><img id="logo" src="resources/images/logo.png" alt="Simpla Admin logo" /></a>
		  
			<!-- Sidebar Profile links -->
		  <div id="profile-links">
		  
			  <?php require_once('top.php'); ?>			</div>        
			
			<ul id="main-nav">  <!-- Accordion Menu -->
				
				<?php require_once('mnu.php'); ?>
				
			</ul> <!-- End #main-nav -->
			
			<div id="messages" style="display: none;"> <!-- Messages are shown when a link with these attributes are clicked: href="#messages" rel="modal"  -->
				<form  id="novoform1" name="novoform1" method="POST" enctype="multipart/form-data" onSubmit="return valida_dados(this)">
  <input type="hidden" name="hiddenField" id="hiddenField" />
					
						<label>Nome do menu*</label> 
						<input name="nome" type="text" id="nome" size="30" value="" class="text-input" />
			
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
						<input type="radio" name="tipo" id="tipo" value="iframe" checked="checked">iframe (url)
						<input type="radio" name="tipo" id="tipo" value="rtmp">rtmp (streaming)
						<input type="radio" name="tipo" id="tipo" value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipo" id="tipo" value="livestream">Livestream.com
						<input type="radio" name="tipo" id="tipo" value="embed">Embed
						<input type="radio" name="tipo" id="tipo" value="m3u8">m3u8(playlist)
						<input type="radio" name="tipo" id="tipo" value="swf">swf
          
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label> 
						<input name="urlcanal" class="text-input" value="" type="text" id="urlcanal" size="30" />
					
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Menu vip ou aberto?</label> 
						<SELECT name="vip" id="vip">
	      <OPTION SELECTED value="na">Aberto e vip</OPTION>
	      <OPTION value="n">Aberto</OPTION>
		  <OPTION value="s">Vip</OPTION>
	</SELECT>
					
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Exibir propaganda?</label> 
						<SELECT name="propaganda" id="propaganda">
	      <OPTION SELECTED value="s">Sim</OPTION>
		  <OPTION value="n">N�o</OPTION>
	</SELECT>
	
						<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Ativar menu?</label> 
						<SELECT name="ligar" id="ligar" style="margin-bottom:5px;">
	      <OPTION SELECTED value="s">Sim</OPTION>
	      <OPTION value="n">N�o</OPTION>
	</SELECT>
					<p/>
						<input type="submit" class="button" name="button" id="button" value="Add menu" />
    <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']; ?>" /> 
    <input type="hidden" name="MM_insert1" value="novoform1" /> 
</form>
				
			</div> <!-- End #messages -->
			
			<?php
$menudecanais_endRow = 0;
$menudecanais_columns = 16; // number of columns
$menudecanais_hloopRow1 = 0; // first row flag
do {
    if($menudecanais_endRow == 0  && $menudecanais_hloopRow1++ != 0) echo "<tr>";
   ?>
      <?php
$menudecanais_endRow = 0;
$menudecanais_columns = 16; // number of columns
$menudecanais_hloopRow1 = 0; // first row flag
do {
    if($menudecanais_endRow == 0  && $menudecanais_hloopRow1++ != 0) echo "<tr>";
   ?><div id="<?php echo $row_menudecanais['ID']; ?>" style="display: none;"> <!-- Messages are shown when a link with these attributes are clicked: href="#messages" rel="modal"  -->
				

<form action="<?php echo $editFormAction; ?>" id="lolo" name="lolo" method="POST" enctype="multipart/form-data">
  <input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $row_menudecanais['ID']; ?>" />
      <label>Nome do Menu*</label>
      <input name="nomedocanal" type="text" id="nomedocanal" size="30" value="<?php echo $row_menudecanais['nome_do_canal']; ?>" />
	  
      <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px;">Tecnologia</label>
	  <?php
         $hr = $row_menudecanais['tipo'];
         if($hr == iframe ) {  
              $resp1 = "checked='checked'"; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == rtmp ) {
			  $resp1 = ""; 
			  $resp2 = "checked='checked'";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if($hr == wmp ) {
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "checked='checked'";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == livestream ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "checked='checked'";
			  $resp5 = "";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == embed ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "checked='checked'";
			  $resp6 = "";
			  $resp7 = "";
         }
		 if ($hr == m3u8 ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = "checked='checked'"; 
			  $resp7 = "";
         }
		 if ($hr == swf ){
			  $resp1 = ""; 
			  $resp2 = "";
			  $resp3 = "";
			  $resp4 = "";
			  $resp5 = "";
			  $resp6 = ""; 
			  $resp7 = "checked='checked'";
         }
    ?>
	                    <input type="radio" name="tipodocanal" id="tipodocanal" value="iframe" <?php echo  "$resp1"; ?>>iframe (url)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp2"; ?> value="rtmp">rtmp (streaming)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp3"; ?> value="wmp">wmp (rtsp/mms)<br />
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp4"; ?> value="livestream">Livestream.com
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp5"; ?> value="embed">Embed
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp6"; ?> value="m3u8">m3u8(playlist)
						<input type="radio" name="tipodocanal" id="tipodocanal" <?php echo  "$resp7"; ?> value="swf">swf
						
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Coloque o link, rtmp, wmp, nome livestream ou codigo embed*</label>
	<textarea name="linkdocanal" cols="40" rows="2" id="linkdocanal"><?php echo $row_menudecanais['linkdcanal']; ?></textarea>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Menu vip ou aberto?</label>
	  <?php
         $hrp = $row_menudecanais['vip'];
         if($hrp == n ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
			  $respp3 = "";
         }
		 if($hrp == s ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
			  $respp3 = "";
         }
		 if($hrp == na ) {
			  $respp1 = ""; 
			  $respp2 = "";
			  $respp3 = "selected='selected'";
         }
    ?>
    <SELECT name="vipedit" id="vipedit">
	      <OPTION <?php echo  "$respp2"; ?> value="s">Vip</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="n">Aberto</OPTION>
		  <OPTION <?php echo  "$respp3"; ?> value="na">Aberto e vip</OPTION>
	</SELECT>
	
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Exibir propaganda?</label>
	  <?php
         $hrp = $row_menudecanais['propaganda'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="propagandaedit" id="propagandaedit">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
		
	<label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">Ativar Menu?</label>
	  <?php
         $hrp = $row_menudecanais['ligar'];
         if($hrp == s ) {  
              $respp1 = "selected='selected'"; 
			  $respp2 = "";
         }
		 if($hrp == n ) {
			  $respp1 = ""; 
			  $respp2 = "selected='selected'";
         }
    ?>
    <SELECT name="ligared" id="ligared">
	      <OPTION <?php echo  "$respp2"; ?> value="n">N�o</OPTION>
	      <OPTION <?php echo  "$respp1"; ?> value="s">Sim</OPTION>
	</SELECT>
	   <br>
        
        <div align="center">

		 <input name="tipoanteri" value="<?php echo $row_menudecanais['vip']; ?>" type="hidden" id="tipoanteri"/>
		 <input name="catanteri" value="<?php echo $row_menudecanais['categoria']; ?>" type="hidden" id="catanteri"/>
          <input type="submit" class="button" name="button" id="button" value="Salvar" />
		  <input type="hidden" name="retorno" value="http://<? echo $_SERVER['SERVER_NAME']; if (strpos($_SERVER ['REQUEST_URI'], 'tabdef=2')){ echo str_replace('tabdef=2', "", $_SERVER ['REQUEST_URI']);} else{ echo $_SERVER ['REQUEST_URI'];} ?>" />
        </div>

  <p> 
    <input type="hidden" name="MM_update" value="lolo" />
</p> 
</form>
				
			</div><?php  $menudecanais_endRow++;
if($menudecanais_endRow >= $menudecanais_columns) {
  ?>
      <?php
 $menudecanais_endRow = 0;
  }
} while ($row_menudecanais = mysql_fetch_assoc($menudecanais));
if($menudecanais_endRow != 0) {
while ($menudecanais_endRow < $menudecanais_columns) {
    $menudecanais_endRow++;
}
}?>
      <?php  $menudecanais_endRow++;
if($menudecanais_endRow >= $menudecanais_columns) {
  ?>
      <?php
 $menudecanais_endRow = 0;
  }
} while ($row_menudecanais = mysql_fetch_assoc($menudecanais));
if($menudecanais_endRow != 0) {
while ($menudecanais_endRow < $menudecanais_columns) {
    $menudecanais_endRow++;
}
}?>
			
		</div></div> <!-- End #sidebar -->
		
		<div id="main-content"> <!-- Main Content Section with everything -->
			
			<noscript> <!-- Show a notification if the user has disabled javascript -->
				<div class="notification error png_bg">
					<div>
						Javascript is disabled or is not supported by your browser. Please <a href="http://browsehappy.com/" title="Upgrade to a better browser">upgrade</a> your browser or <a href="http://www.google.com/support/bin/answer.py?answer=23852" title="Enable Javascript in your browser">enable</a> Javascript to navigate the interface properly.
					</div>
				</div>
			</noscript>
			
			<!-- Page Head -->
			
			<ul class="shortcut-buttons-set">
				<li><a class="shortcut-button" href="#messages" rel="modal"><span>
					<img src="resources/images/icons/image_add_48.png" alt="icon" /><br />
					Add menu
				</span></a></li>
				
			</ul><!-- End .shortcut-buttons-set -->
			
			<div class="clear"></div> <!-- End .clear -->
			
			<div class="content-box"><!-- Start Content Box -->
				
				<div class="content-box-header">
					
					<h3><?
$consulta = mysql_query("SELECT * FROM dados_beta WHERE lugar LIKE 'menu'");
$qtd = mysql_num_rows($consulta);
echo "<font face=Verdana, Arial, Helvetica, sans-serif><font size=1>$qtd</a></font>";
?> menus
</h3>
					
					<ul class="content-box-tabs">
						<li><a href="#tab1" class="default-tab">Menus</a></li> <!-- href must be unique and match the id of target div -->
					</ul>
					
					<div class="clear"></div>
					
				</div> <!-- End .content-box-header -->
				
				<div class="content-box-content">
				
					<div class="tab-content default-tab" id="tab1"> <!-- This is the target div. id must match the href of this div's tab -->
						
						<table>
							
							<thead>
								<tr>
								   <th>nome</th>
								   <th>Ativo</th>
								   <th>Tecnologia</th>
								   <th>Tipo</th>
								   <th>Op�&otilde;es</th>
								</tr>
								
							</thead>
						 
							<tfoot>
								<tr>
									<td colspan="6">
										 <!-- End .pagination -->
									</td>
								</tr>
							</tfoot>
						 
							<tbody>
							<?php do { ?>
								<tr>
									<td><?php echo $row_editarvariedades['nome_do_canal']; ?></td>
									<td><?php echo $row_editarvariedades['ligar']; ?></td>
									<td><?php echo $row_editarvariedades['tipo']; ?></td>
									<td><?php
		 $tipo4444 = $row_editarvariedades['vip'];
         $hr = $tipo4444;
         if($hr == s ) {  
              $resp2 = "vip";  
         }
		 if ($hr == n ){  
              $resp2 = "aberto";  
         }
		 if ($hr == na ){  
              $resp2 = "aberto e vip";  
         }
    ?><?php echo $resp2; ?></td>
									<td>
										<!-- Icons -->
										 <a title="Editar" href="#<?php echo $row_editarvariedades['ID']; ?>" rel="modal"><img src="resources/images/icons/pencil.png" alt="Editar" /></a>
										 <a href='?deletar=<? echo $row_editarvariedades['ID']; ?>&url=<? echo $row_editarvariedades['url_do_canal']; ?>&retorna=<? echo base64_encode($_SERVER['SERVER_NAME'].$_SERVER ['REQUEST_URI']); ?>' title='Deletar' onclick="return confirm('Confirma exclus�o do menu <? echo $row_editarvariedades['nome_do_canal']; ?>')"><img src='resources/images/icons/cross.png' alt='Deletar' /></a> 
									</td>
								</tr>
							</tbody>
							<?php } while ($row_editarvariedades = mysql_fetch_assoc($editarvariedades)); ?>
						</table>
						
					</div> <!-- End #tab1 -->
					
				</div> <!-- End .content-box-content -->
				
			</div> <!-- End .content-box -->
			
			<div class="clear"></div>

			
		</div> <!-- End #main-content -->
		
	</div></body>
  

<!-- Download From www.exet.tk-->
</html>
