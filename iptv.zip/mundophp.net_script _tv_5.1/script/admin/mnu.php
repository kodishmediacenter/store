<?php require_once('../painel/comfig.php');
      page_protect();
	  if(!checkAdmin()) {
header("Location: login.php");
exit();
} ?>                <? $base =  parse_url ($siteurlb);
				$base =  $base['path'];
				$base =  strrchr($base,"/");
				$base = str_replace("/", "", $base); ?>
				<li>
					<a href="#" class="nav-top-item <? if(($base == 'admin.php') or ($base == 'foradoar.php')) echo 'current'; ?>">
						Canais
					</a>
					<ul>
						<li><a href="admin.php">Canais</a></li>
						<li><a href="foradoar.php">Canais fora do ar</a></li>
					</ul>
				</li>
				
				<li>
					<a href="us.php" class="nav-top-item no-submenu <? if($base == 'us.php') echo 'current'; ?>"> <!-- Add the class "no-submenu" to menu items with no sub menu -->
						Usu�rios
					</a>       
				</li>
				
				<li>
					<a href="menu.php" class="nav-top-item no-submenu <? if($base == 'menu.php') echo 'current'; ?>"> <!-- Add the class "no-submenu" to menu items with no sub menu -->
						Menu
					</a>       
				</li>
				
				<li>
					<a href="banners.php" class="nav-top-item no-submenu <? if($base == 'banners.php') echo 'current'; ?>"> <!-- Add the class "no-submenu" to menu items with no sub menu -->
						Banners
					</a>       
				</li>
				
				<li>
					<a href="#" class="nav-top-item <? if(($base == 'conf.php') or ($base == 'confchat.php')  or ($base == 'confplayer.php') or ($base == 'conflogo.php') or ($base == 'conftitulo.php') or ($base == 'confgratis.php') or ($base == 'horarios.php')  or ($base == 'confsocial.php')  or ($base == 'conftermos.php') or ($base == 'confanalytics.php') or ($base == 'conflink.php')) echo 'current'; ?>">
						Configura��es
					</a>
					<ul>
						<li><a href="conf.php">Gerais</a></li>
						<li><a href="horarios.php">Canal da index</a></li>
						<li><a href="conftitulo.php">Titulo e descri��o dos canais</a></li>
						<li><a href="conflink.php">Link dos canais</a></li>
						<li><a href="confplayer.php">Livestream.com</a></li>
						<li><a href="confchat.php">Chat</a></li>
						<li><a href="conflogo.php">logo</a></li>
						<li><a href="confgratis.php">Dias gr�tis �rea vip</a></li>
						<li><a href="conftermos.php">Termos de uso �rea vip</a></li>
						<li><a href="confsocial.php">Widgets redes sociais</a></li>
						<li><a href="confanalytics.php">Analytics google</a></li>
					</ul>
				</li>
				<li>
					<a href="#" class="nav-top-item <? if(($base == 'confpagseguro.php') or ($base == 'confpaypal.php') or ($base == 'valor.php')) echo 'current'; ?>">
						Financeiro
					</a>
					<ul>
					    <li><a href="valor.php">Planos</a></li>
						<li><a href="confpagseguro.php">Pagseguro</a></li>
						<li><a href="confpaypal.php">Paypal</a></li>
					</ul>
				</li>
				<li>
					<a href="atualizar.php" class="nav-top-item no-submenu <? if($base == 'atualizar.php') echo 'current'; ?>"> <!-- Add the class "no-submenu" to menu items with no sub menu -->
						Atualizar script
					</a>       
				</li>