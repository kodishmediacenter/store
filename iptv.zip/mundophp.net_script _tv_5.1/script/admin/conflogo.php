<?php
require_once('../painel/comfig.php');
      page_protect();
	  if(!checkAdmin()) {
header("Location: ../painel/login.php");
exit();
}
//editar imagem>>>
if((!empty($_FILES['arquivoeditar']['name']))){
/// altera��o de imagem 

$nome = $_POST['nomedocanal']; 
// Pasta onde o arquivo vai ser salvo 
$_UP['pasta'] = '../images/'; 
 
// Tamanho m�ximo do arquivo (em Bytes) 
$_UP['tamanho'] = 1024 * 1024 * 1; // 2Mb 
 
// Array com as extens�es permitidas 
$_UP['extensoes'] = array('png', 'astalavista'); ; 
 
// Renomeia o arquivo? (Se true, o arquivo ser� salvo como .jpg e um nome �nico) 
$_UP['renomeia'] = true; 
 
// Array com os tipos de erros de upload do PHP 
$_UP['erros'][0] = 'N�o houve erro'; 
$_UP['erros'][1] = 'O arquivo no upload � maior do que o limite do PHP'; 
$_UP['erros'][2] = 'O arquivo ultrapassa o limite de tamanho especifiado no HTML'; 
$_UP['erros'][3] = 'O upload do arquivo foi feito parcialmente'; 
$_UP['erros'][4] = 'N�o foi feito o upload do arquivo'; 
 
// Verifica se houve algum erro com o upload. Se sim, exibe a mensagem do erro 
if ($_FILES['arquivoeditar']['error'] != 0) { 
die("N�o foi poss�vel fazer o upload, erro:<br />" . $_UP['erros'][$_FILES['arquivoeditar']['error']]); 
exit; // Para a execu��o do script 
} 
 
// Caso script chegue a esse ponto, n�o houve erro com o upload e o PHP pode continuar 

// Faz a verifica��o da extens�o do arquivo 
$extensao = strtolower(end(explode('.', $_FILES['arquivoeditar']['name']))); 
if (array_search($extensao, $_UP['extensoes']) === false) { 
echo "<script type='text/javascript'>
alert('erro: extens�o permitida: png');
</script>"; 
} 
 
// Faz a verifica��o do tamanho do arquivo 
else if ($_UP['tamanho'] < $_FILES['arquivoeditar']['size']) { 
echo "<script type='text/javascript'>
alert('O arquivo enviado � muito grande, envie arquivos de at� 1Mb.');
</script>"; 
} 
// O arquivo passou em todas as verifica��es, hora de tentar mov�-lo para a pasta 
else { 

// Cria um nome baseado no UNIX TIMESTAMP atual e com extens�o .jpg 
$nome_final = 'logo.png'; 

$url = '../images/logo.png';
unlink($url);

// Depois verifica se � poss�vel mover o arquivo para a pasta escolhida 
if (move_uploaded_file($_FILES['arquivoeditar']['tmp_name'], $_UP['pasta'] . $nome_final)) { 
// Upload efetuado com sucesso, exibe uma mensagem e um link para o arquivo 
 
} else { 
// N�o foi poss�vel fazer o upload, provavelmente a pasta est� incorreta 
echo "<script type='text/javascript'>
alert('N�o foi poss�vel enviar o arquivo, tente novamente');
</script>"; 
} 
 
} 
}
//fim editar imagem<<<
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		
		<!--                       CSS                       -->
	  
		<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />
		
		<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
		<link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />	
		
		<!-- Colour Schemes
	  
		Default colour scheme is green. Uncomment prefered stylesheet to use it.
		
		<link rel="stylesheet" href="resources/css/blue.css" type="text/css" media="screen" />
		
		<link rel="stylesheet" href="resources/css/red.css" type="text/css" media="screen" />  
	 
		-->
		
		<!-- Internet Explorer Fixes Stylesheet -->
		
		<!--[if lte IE 7]>
			<link rel="stylesheet" href="resources/css/ie.css" type="text/css" media="screen" />
		<![endif]-->
		
		<!--                       Javascripts                       -->
  
		<!-- jQuery -->
		<script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>
		
		<!-- jQuery Configuration -->
		<script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>
		
		<!-- Facebox jQuery Plugin -->
		<script type="text/javascript" src="resources/scripts/facebox.js"></script>
		
		<!-- jQuery WYSIWYG Plugin -->
		<script type="text/javascript" src="resources/scripts/jquery.wysiwyg.js"></script>
		
		<!-- jQuery Datepicker Plugin -->
		<script type="text/javascript" src="resources/scripts/jquery.datePicker.js"></script>
		<script type="text/javascript" src="resources/scripts/jquery.date.js"></script>
		<!--[if IE]><script type="text/javascript" src="resources/scripts/jquery.bgiframe.js"></script><![endif]-->

		
		<!-- Internet Explorer .png-fix -->
		
		<!--[if IE 6]>
			<script type="text/javascript" src="resources/scripts/DD_belatedPNG_0.0.7a.js"></script>
			<script type="text/javascript">
				DD_belatedPNG.fix('.png_bg, img, li');
			</script>
		<![endif]-->
		
	    <style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style2 {color: #0000FF}
-->
        </style>
</head>
  
	<body><div id="body-wrapper"> <!-- Wrapper for the radial gradient background -->
		
		<div id="sidebar"><div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
			
			<h1 id="sidebar-title"><a href="#">Simpla Admin</a></h1>
		  
			<!-- Logo (221px wide) -->
			<a href="#"><img id="logo" src="resources/images/logo.png" alt="Simpla Admin logo" /></a>
		  
			<!-- Sidebar Profile links -->
			<div id="profile-links">
				
				<?php require_once('top.php'); ?>
			</div>        
			
			<ul id="main-nav">  <!-- Accordion Menu -->
				
				<?php require_once('mnu.php'); ?>
				
			</ul> <!-- End #main-nav -->
			
		</div></div> <!-- End #sidebar -->
		
		<div id="main-content"> <!-- Main Content Section with everything -->
			
			<noscript> <!-- Show a notification if the user has disabled javascript -->
				<div class="notification error png_bg">
					<div>
						Javascript is disabled or is not supported by your browser. Please <a href="http://browsehappy.com/" title="Upgrade to a better browser">upgrade</a> your browser or <a href="http://www.google.com/support/bin/answer.py?answer=23852" title="Enable Javascript in your browser">enable</a> Javascript to navigate the interface properly.
				    </div>
				</div>
			</noscript>
			
			<!-- Page Head -->
			
			<div class="clear"></div> <!-- End .clear -->
			
			<div class="content-box"><!-- Start Content Box -->
				
				<div class="content-box-header">
					
					<h3>Logo</h3>
					
					<ul class="content-box-tabs">
					</ul>
					
					<div class="clear"></div>
					
			  </div> <!-- End .content-box-header -->
				
				<div class="content-box-content">
					
				  <div class="tab-content default-tab" id="tab1"> <!-- This is the target div. id must match the href of this div's tab -->
					  <form action="<?php echo $editFormAction; ?>" id="lolo" name="lolo" method="POST" enctype="multipart/form-data">
  <input name="hiddenField" type="hidden" id="hiddenField" value="<?php echo $res1['ID']; ?>" />
  
	  <label style="border-top-style:solid;border-top-width:1px;border-top-color:#CCCCCC; margin-top:5px; padding-top:4px;">O logo deve ter 179x61 pixel e ser png</label>
      <input name="arquivoeditar" type="file"  size="6" />

	   <br>

          <div align="left">
		  <br />
            <input type="submit" class="button" name="button" id="button" value="Alterar logo" />
            </div>
          <p> 
    <input type="hidden" name="MM_update" value="lolo" />
</p> 
</form>
                      </div> <!-- End #tab1 -->
					
				     <div class="tab-content" id="tab2">
				    
				  </div> 
					<!-- End #tab2 -->        
					
				</div> <!-- End .content-box-content -->
				
			</div>
<div class="clear"></div>
			
			
			<!-- Start Notifications --><!-- End Notifications -->

			
		</div> <!-- End #main-content -->
		
	</div></body>
  

<!-- Download From www.exet.tk-->
</html>