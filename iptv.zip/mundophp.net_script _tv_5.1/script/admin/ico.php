<?
require_once('../painel/comfig.php');
page_protect();
if(!checkAdmin()) {
header("Location: login.php");
exit();
}
function criaicone($id){
$new_width = 70;
$new_height = 50;

$new_width2 = 350;
$new_height2 = 350;

$confere = mysql_query("SELECT * from dados_beta WHERE ID='".$id."' AND lugar='canais' LIMIT 1");
$result = mysql_num_rows($confere);
$canais = mysql_fetch_assoc($confere);

if($canais['form'] == opt) {
$checar2 = mysql_query("SELECT * FROM dados_beta WHERE lugar='canais' AND nome_foto='".$canais['categoria']."' LIMIT 1");
$canais = mysql_fetch_assoc($checar2);
}

if($result=='1') {

 if($canais['vip'] == s){
 $checar = mysql_query("SELECT * FROM dados_beta WHERE lugar='canais' AND (vip='n' or vip='na') AND categoria='".$canais['nome_foto']."' LIMIT 1");
$result = mysql_num_rows($checar);
if($result==1) {
$canais['vip'] = "na";
}
 }
 if($canais['vip'] == n){
 $checar = mysql_query("SELECT * FROM dados_beta WHERE lugar='canais' AND (vip='s' or vip='na') AND categoria='".$canais['nome_foto']."' LIMIT 1");
$result = mysql_num_rows($checar);
if($result==1) {
$canais['vip'] = "na";
}
 }

 $srcImagePath = '../'.$canais['url_do_canal'];
 $Image = basename($srcImagePath);
 
 $arquivo1111 = pathinfo($Image, PATHINFO_EXTENSION);
 if($arquivo1111 == 'jpg'){
 $tileImg = imagecreatefromjpeg($srcImagePath);
 $file = basename($srcImagePath, ".jpg");
 }
 if($arquivo1111 == 'png'){
 $tileImg = imagecreatefrompng($srcImagePath);
 $file = basename($srcImagePath, ".png");
 }
 if($arquivo1111 == 'gif'){
 $tileImg = imagecreatefromgif($srcImagePath);
 $file = basename($srcImagePath, ".gif");
 }
 
 list($width,$height)=getimagesize($srcImagePath);
 $tmp=imagecreatetruecolor($new_width,$new_height);
 imagecopyresampled($tmp,$tileImg,0,0,0,0,$new_width,$new_height,$width,$height);
 
 $tmp2=imagecreatetruecolor($new_width2,$new_height2);
 $white = imagecolorallocate($tmp2, 255, 255, 255);
 imagefill($tmp2, 0, 0, $white);
 imagecopyresampled($tmp2,$tileImg,0,50,0,0,$new_width2,250,$width,$height);
 imagedestroy($tileImg);

$link = $_SERVER['DOCUMENT_ROOT'].'/icones/pequeno/aberto/'.$file.'.jpeg';
$link2 = $_SERVER['DOCUMENT_ROOT'].'/icones/grande/aberto/'.$file.'.jpeg';
$link3 = $_SERVER['DOCUMENT_ROOT'].'/icones/pequeno/vip/'.$file.'.jpeg';
$link4 = $_SERVER['DOCUMENT_ROOT'].'/icones/grande/vip/'.$file.'.jpeg';

if (file_exists($link)) {   
unlink($link);                    
}
if (file_exists($link2)) {   
unlink($link2);                    
}
if (file_exists($link3)) {   
unlink($link3);                    
}
if (file_exists($link4)) {   
unlink($link4);                    
}

if($canais['vip'] == s){
imagejpeg($tmp, $link3, 90);
imagejpeg($tmp2, $link4, 90);
}
if($canais['vip'] == n){
imagejpeg($tmp, $link, 90);
imagejpeg($tmp2, $link2, 90);
}
if($canais['vip'] == na){
imagejpeg($tmp, $link, 90);
imagejpeg($tmp2, $link2, 90);
imagejpeg($tmp, $link3, 90);
imagejpeg($tmp2, $link4, 90);
}
imagedestroy($tmp);
imagedestroy($tmp2);
}
}
?>