<?
header("Location: ../painel/login.php");
exit();
?>