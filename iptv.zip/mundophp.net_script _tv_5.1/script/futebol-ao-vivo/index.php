<?php
require_once('../painel/comfig.php'); ?>
<? 
$url = 'http://www.vertvonline.biz/futebolaovivo/';
$dadosSite = file_get_contents($url);
preg_match_all("/<div class=\"categoria\">(.+?)<\/div>/is", $dadosSite, $categoria, PREG_SET_ORDER);
preg_match_all("/<div class=\"tempo\">(.+?)<\/div>/is", $dadosSite, $tempo, PREG_SET_ORDER);
preg_match_all("/<div class=\"f_jogo_jogo\">(.+?)<\/div>/is", $dadosSite, $jogo, PREG_SET_ORDER);
preg_match_all("/<div class=\"f_jogo_tv\">(.+?)<\/div>/is", $dadosSite, $jogotv, PREG_SET_ORDER);

$i = 0;
$i2 = 0;
$i3 = 0;
$i4 = 0;
foreach ($categoria as  $e){
    ${"categoria" . $i} = utf8_decode(strip_tags($e[0]));
	${"categoria" . $i} = str_replace("\n", "", trim(${"categoria" . $i}));
	$i++; 
}
foreach ($tempo as  $e){
    ${"tempo" . $i2} = utf8_decode(strip_tags($e[0]));
	${"tempo" . $i2} =  str_replace("\n", "", trim(${"tempo" . $i2}));
	$i2++; 
}
foreach ($jogo as  $e){
    ${"jogo" . $i3} = utf8_decode(strip_tags($e[0]));
	${"jogo" . $i3} =  str_replace("\n", "", trim(${"jogo" . $i3}));
	$i3++; 
}
foreach ($jogotv as  $e){
    ${"jogotv" . $i4} = utf8_decode($e[0]);
	$i4++; 
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="refresh" content="60">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="content-language" content="pt-br" />
<meta name="description" content="futebol online ao vivo gr�tis aqui � o lugar com cobertura completa do Brasileir�o, Copa do Brasil, Libertadores, Sul-Americana, Estaduais e muito mais para voc�!" />
<meta name="distribution" content="Global" />
<meta name="rating" content="General" />
<meta name="robots" content="index, follow" />
<title>Futebol Online Ao Vivo - Futebol Gr�tis</title><link href="style.css" rel="stylesheet" type="text/css" /></head>
<body>
<div class="header">
<div class="logo"></div><div class="box_titulo">
<div class="titulo">Futebol <? echo $configuracoes['nomedosite']; ?></div>
<div class="time"><?php
$dia = (date(w));
$diasDasemana = array (1 => "Segunda-Feira",2 => "Ter�a-Feira",3 => "Quarta-Feira",4 => "Quinta-Feira",5 => "Sexta-Feira",6 => "S�bado",0 => "Domingo");
echo $diasDasemana["$dia"].' '.date("d/m/Y");
?> | HOR�RIO DE BRAS�LIA</div>
</div><div class="atualizar">
<a href="javascript:location.reload(true)" title="ATUALIZAR PROGRAMA��O">ATUALIZAR PROGRAMA��O</a>
</div>
</div>
<div class="jogos">
<?php
$io = 0;
while ($io <= 10)
{
if(!empty(${'tempo' . $io})){
?>
<div class="box_jogo">
			  <div class="jogo_hora"><?php echo ${'tempo' . $io}; ?> | <?php echo ${'categoria' . $io}; ?></div><div class="jogo_times"><?php echo ${'jogo' . $io}; ?></div><div class="jogo_canais"><?php echo ${'jogotv' . $io}; ?></div></div>
<?
} 
$io ++;
}
?> 
</div>
<div class="rodape">
</div></body>
</html>