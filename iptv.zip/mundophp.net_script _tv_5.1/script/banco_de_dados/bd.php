<?
define ("DB_HOST", "localhost"); // set database host
define ("DB_USER", "user"); // set database user
define ("DB_PASS","pass"); // set database password
define ("DB_NAME","database"); // set database name
?>