<?php
ob_start();
session_start();
$agora = time();
$agora2 = $agora-60;
require_once('painel/comfig.php'); ?>
<?php
if($_POST){
$id = trim(strip_tags(mysql_real_escape_string($_POST['id'])));
if(!empty($id) && is_numeric($id)){
$checar = mysql_query("SELECT * from dados_beta WHERE ID=$id AND lugar = 'canais' AND ligar = 's' LIMIT 1");
$canal = mysql_fetch_object($checar);
$result = mysql_num_rows($checar);
if($result==1) {

$checar1 = mysql_query("SELECT * from foradoar WHERE id=$id LIMIT 1");
$result1 = mysql_num_rows($checar1);

if($result1==0) {

if(isset($_SESSION['user_id'])){
$user = isset($_SESSION['user_id']);
}else{
$user = $_SERVER['REMOTE_ADDR'];
}
$checar2 = mysql_query("SELECT * from foradoar WHERE user='$user' AND tempo > $agora2");
$result2 = mysql_num_rows($checar2);
if($result2==0) {
   mysql_query("INSERT INTO foradoar (id, cliques, user, tempo) VALUES ('$id', '1', '$user', '$agora') ON DUPLICATE KEY UPDATE cliques=cliques+1");
   $mens = utf8_encode("Obrigado por nos informar que o canal \"".$canal->nome_do_canal."\" esta fora do ar, em breve iremos revisar ele!");
   $array = array("mens"=>$mens ,"status"=>"success", "title"=>utf8_encode('Aviso'));
   echo json_encode($array);
}else{
$mens = utf8_encode("Acalme se, voc� esta indo r�pido demais, voc� fez outro aviso a pouco tempo!");
$array = array("mens"=>$mens ,"status"=>"error", "title"=>utf8_encode('Aviso'));
echo json_encode($array);
}
}else{
$mens = utf8_encode("J� fomos informados que o canal \"".$canal->nome_do_canal."\" esta fora do ar, em breve iremos revisar ele!");
$array = array("mens"=>$mens ,"status"=>"notice", "title"=>utf8_encode('Aviso'));
echo json_encode($array);
}

}else{
$mens = utf8_encode('Voc� s� deve nos avisar sobre um canal fora do ar, no momento voc� n�o tem nenhum canal aberto!');
$array = array("mens"=>"0", "mens2"=>$mens, "title"=>utf8_encode('Aviso'));
echo json_encode($array);
}
}elseif(!empty($_SESSION['canal_aberto_nome'])){
$mens = utf8_encode('Voc� tem certeza que o canal "' . $_SESSION['canal_aberto_nome'] . '" esta fora do ar?');
$array = array("mens"=>$mens, "id"=>$_SESSION['canal_aberto'], "title"=>utf8_encode('Confirma��o'));
echo json_encode($array);
}else{
$mens = utf8_encode('Voc� s� deve nos avisar sobre um canal fora do ar, no momento voc� n�o tem nenhum canal aberto!');
$array = array("mens"=>"0", "mens2"=>$mens, "title"=>utf8_encode('Aviso'));
echo json_encode($array);
}
}
?>