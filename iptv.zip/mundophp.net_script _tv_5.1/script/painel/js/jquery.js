$(document).ready(function() {
//********************************
//you can set coutdown as you want 
//*********************************

		var austDay = new Date("February 28, 2013 00:00:00");
			$('#countdown').countdown({until: austDay, layout: '<div class="counter"><p>{dn}</p> <span>{dl}</span></div> <div class="counter counter-two"><p>{hn}</p> <span>{hl}</span></div> <div class="counter counter-three"><p>{mn}</p> <span>{ml}</span></div> <div class="counter counter-four"><p>{sn}</p> <span>{sl}</span></div>'});
			$('#year').text(austDay.getFullYear());

//function for the social hover effect - tooltips		
	$('.tooltip').tipsy
	({
		fade: true,
		gravity: 's'
	});
    $('#contact').click(function(){
        $('#cform').slideDown('slow');
        $('#home').slideUp('slow');
        $('.about-us').slideUp('slow');
    });
    
    $('#about').click(function(){
        $('.about-us').slideDown('slow');
        $('#home').slideUp('slow');
        $('#cform').slideUp('slow');
    });
    
    $('#home-link').click(function(){
        $('.about-us').slideUp('slow');
        $('#cform').slideUp('slow');
        $('#home').slideDown('slow');
    });
});	