<?php

include 'comfig.php';

foreach($_GET as $key => $value) {
	$get[$key] = filter($value);
}

$user = mysql_real_escape_string($get['user']);

if(isset($get['cmd']) && $get['cmd'] == 'check') {

if(!isUserID($user)) {
echo "Nome de usuario invalido";
exit();
}

if(empty($user) && strlen($user) <=3) {
echo "Digite 5 caracteres ou mais";
exit();
}



$rs_duplicate = mysql_query("select count(*) as total from users where user_name='$user' ") or die(mysql_error());
list($total) = mysql_fetch_row($rs_duplicate);

	if ($total > 0)
	{
	echo "Indisponivel, escolha outro!";
	} else {
	echo "Disponivel";
	}
}

?>