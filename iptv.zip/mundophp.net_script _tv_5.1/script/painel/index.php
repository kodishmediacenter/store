<?php 
require_once('comfig.php');
page_protect();
?>
<?php 
/********************** MYSETTINGS.PHP**************************
This updates user settings and password
************************************************************/

$user_id = strip_tags(mysql_real_escape_string($_SESSION['user_id'])); // Parametro passado pelo sistema de login!

$err = array();
$msg = array();

if($_POST['doUpdate'] == 'Alterar')  
{


$rs_pwd = mysql_query("select pwd from users where id='$user_id'");
list($old) = mysql_fetch_row($rs_pwd);
$old_salt = substr($old,0,9);

//check for old password in md5 format
	if($old === PwdHash($_POST['pwd_old'],$old_salt))
	{
	$newsha1 = PwdHash($_POST['pwd_new']);
	mysql_query("update users set pwd='$newsha1' where id='$user_id'");
	$msg[] = "<Script Language='JavaScript'>
	alert('Sua senha foi atualizada');
	</Script>";
	//header("Location: mysettings.php?msg=Your new password is updated");
	} else
	{
	 $err[] = "<Script Language='JavaScript'>
	alert('Sua senha antiga � inv�lida');
	</Script>";
	 //header("Location: mysettings.php?msg=Your old password is invalid"); 
	}

}
 
$rs_settings = mysql_query("select * from users where id='$user_id'"); 
?>
<?php
$boas_vindas = mysql_query("SELECT id, vencimento, data FROM users WHERE id = '$user_id'")
or die(mysql_error());
if(@mysql_num_rows($boas_vindas) <= '0') 
echo "Erro ao selecionar o usuário";
else{
while($res_boas_vindas=mysql_fetch_array($boas_vindas)){
$vencimento = $res_boas_vindas[1];
$data = $res_boas_vindas[2];


$dataI= date('Y/m/d');
$I= strtotime($dataI);
$dataII= $vencimento;
$II= strtotime($dataII);
$dataIII= $data;
$III= strtotime($dataIII);


// Define os valores a serem usados
$data_inicial = $data;
$data_final = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial = strtotime($data_inicial);
$time_final = strtotime($data_final);

// Calcula a diferença de segundos entre as duas datas:
$diferenca = $time_final - $time_inicial; // 19522800 segundos

// Calcula a diferença de dias
$dias = (int)floor( $diferenca / (60 * 60 * 24)); // 225 dias


// Define os valores a serem usados
$data_inicial1 = $dataI;
$data_final1 = $dataII;

// Usa a função strtotime() e pega o timestamp das duas datas:
$time_inicial1 = strtotime($data_inicial1);
$time_final1 = strtotime($data_final1);

// Calcula a diferença de segundos entre as duas datas:
$diferenca1 = $time_final1 - $time_inicial1; // 19522800 segundos

// Calcula a diferença de dias
$dias1 = (int)floor( $diferenca1 / (60 * 60 * 24)); // 225 dias
?>
<?php
$porc = $dias+0.000001;
$valor = $dias1;
$resul = $valor/$porc;
$fim = $resul*100;

if ($dias1 <= 1){ 
$plural1 = "dia";
}if ($dias1 >= 2){ 
$plural1 = "dias";
}

if ($I >= $II){ 
$datavencimento = '<strong><font style="color:red">' . date('d/m/Y', strtotime($vencimento)) . '</font></strong>';
$marcador = "0";
$menssage = "Conta aguardando pagamento...";
$falta = '0';
$vencido = '1';
}else{
$datavencimento = '<font style="color:green">' . date('d/m/Y', strtotime($vencimento)) . '</font>';
$marcador = $fim;
$falta = $dias1;
$menssage = "voc&ecirc; pode usar o sistema por";
$plural = $plural1;
$vencido = '0';
$ip = $_SERVER["REMOTE_ADDR"];
$agora = time(); //pega o tempo real
mysql_query("INSERT INTO users_sessions (id, ultima, ip) VALUES ('$user_id', '$agora', '$ip') ON DUPLICATE KEY UPDATE ultima='$agora', ip='$ip'");
}
}
}

// adiciona o tempo para o cliente
//selecionando dados da tabela para pegar o tempo para o cliente
                    $checarpag = mysql_query("SELECT * FROM BuyerTable WHERE userid=$user_id AND creditado='n' AND (status='Completed' or status='Aprovado')");
                    $resultpag = mysql_num_rows($checarpag);
					if($resultpag >= 1){
                    $sql458 = "SELECT * FROM BuyerTable WHERE userid=$user_id AND creditado='n' AND (status='Completed' or status='Aprovado')";
                    $query458 = mysql_query($sql458);
                    while($sql458 = mysql_fetch_array($query458)){
                    $tempo = $sql458["tempo"];
					$idcredito = $sql458["ID"];
                    //onde $tempo é a variavel que rerpresenta a coluna "tempo" nessa
                    //mesma tabela.
                    }
					if($I >= $II){
					$tempsoma = 0;
					}else{
					$tempsoma = $diferenca1;
					}
					$tempcompra = ($tempo * 30) + 1;
					$tempadd = $falta + $tempcompra;
					$tempadd = date('Y-m-d', strtotime(' +'.$tempadd.' day'));
					mysql_query("update users set data='$dataI', vencimento='$tempadd' where id='$user_id'");
					mysql_query("update BuyerTable set creditado='s' where ID='$idcredito'");
					header("HTTP/1.1 301 Moved Permanently");
					header("Location: index.php");
                    exit();
					}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>Painel usuario</title> 

<link rel="stylesheet" href="style.css" type="text/css" media="screen">
<script language="JavaScript" type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
<script language="JavaScript" type="text/javascript" src="js/jquery.validate.js"></script>
<script type="text/javascript" src="js/jquery.countdown.js"></script>
<script type="text/javascript" src="js/jquery.tipsy.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/ntip.js" type="text/javascript"></script>
<script>
  $(document).ready(function(){
    $("#myform").validate();
	 $("#pform").validate();
  });
  </script>
  <script>
    function submitOnClick(formName){
        document.forms[formName].submit();
    }
</script>
<style type="text/css">
<!--
.style2 {font-size: 16px}
-->
.style1 {font-size: 36px; line-height:50px;}
-->
.block{
  background: #58B85C;
  color: #fcfcfc;
  width: 250px;
  padding: 5px;
  margin:5px 0px 0px 0px;
  border: 2px dotted #fff;
  cursor:pointer;
  }
.block1{
  background: #58B85C;
  color: #fcfcfc;
  width: 250px;
  padding: 5px;
  margin:5px 0px 0px 0px;
  border: 2px dotted #fff;
  cursor:pointer;
  }
 .smalll{
 font-size:12px;
  }
</style>
<script>
		$(function() {
			$(".meter > span").each(function() {
				$(this)
					.data("origWidth", $(this).width())
					.width(0)
					.animate({
						width: $(this).data("origWidth")
					}, 1200);
			});
		});
	</script>
</head>

<body> 
    
	<div id="wrapper">
        <header>
            <div class="logo" style="text-align:center;"><img src="images/logo.png"></div>
            <!--logo-->
        </header><div class="button-box">
					<button class="button" id="home-link">Canais</button>
                    <button class="button" id="about">Seu perfil</button>
					<button class="button" id="contact">Contato</button>
					<?php 
if (checkAdmin()) {
?>
<a target="_top" href="../admin/admin.php" class="button">Admin</a>
	  <?php } ?>
                </div>
        <hr></hr><?php	
	if(!empty($err))  {
	  foreach ($err as $e) {
	    echo "$e";
	    }
	   }
	   if(!empty($msg))  {
	    echo "$msg[0]";

	   }
	  ?>
			<div class="content-page">
				<div id="cform">
				<?
// aqui come�a o script
//pega as variaveis por POST
$nome      = strip_tags(mysql_real_escape_string($_POST["nome"]));
$email   = strip_tags(mysql_real_escape_string($_POST["email"]));
$assunto   = strip_tags(mysql_real_escape_string($_POST["assunto"]));
$mensagem  = strip_tags(mysql_real_escape_string($_POST["mensagem"]));

global $email; //fun��o para validar a vari�vel $email no script todo

if(!empty($mensagem) && $_POST){
$data      = date("d/m/y");                     //fun��o para pegar a data de envio do e-mail
$ip        = $_SERVER['REMOTE_ADDR'];           //fun��o para pegar o ip do usu�rio
$navegador = $_SERVER['HTTP_USER_AGENT'];       //fun��o para pegar o navegador do visitante
$hora      = date("H:i");                       //para pegar a hora com a fun��o date
$mais      = $configuracoes['email'];
$host  = $_SERVER['HTTP_HOST'];
//aqui envia o e-mail para voc�
mail ("$mais",                       //email aonde o php vai enviar os dados do form
      "$assunto",
      "Nome: $nome\nData: $data\nIp: $ip\nNavegador: $navegador\nHora: $hora\nE-mail: $email\n\nMensagem: $mensagem",
      "From: $email"
     );

//aqui s�o as configura��es para enviar o e-mail para o visitante
$site   = "auto-reply@".$host;                    //o e-mail que aparecer� na caixa postal do visitante
$titulo = "CONTATO TV";                  //titulo da mensagem enviada para o visitante
$msg    = "$nome, obrigado por entrar em contato conosco, em breve entraremos em contato";

//aqui envia o e-mail de auto-resposta para o visitante
mail("$email",
     "$titulo",
     "$msg",
     "From: $site"
    );
echo "<script type='text/javascript'>
alert('sua mensagem foi enviada');
</script>"; 
}if(empty($mensagem) && $_POST){
echo "<script type='text/javascript'>
alert('sua mensagem n�o foi enviada, a mensagem esta em branco!');
</script>"; 
} ?>
					<div class="form-wrapper in-touch">
						<div id="message"></div>
						<div align="center"><form method="post" action="" name="contactform" id="contactform">
							<div align="left">
							  <input type="text" name="nome" placeholder="Seu nome" id="name" />
							  </br>
							    <input type="text" name="email" placeholder="Seu email" id="email" />
							  </br>
							    <input type="text" name="assunto" placeholder="Assunto" id="subject" />
							  </br>
							    <textarea placeholder="Mensagem" name="mensagem" id="comments"></textarea>
							  </br>
							  
							    <input type="submit" name="send" value="Enviar" id="submit" class="orange" /> 
		        </div>
</form></div>
					</div>
				</div>
                    <div class="about-us">
                        <?php while ($row_settings = mysql_fetch_array($rs_settings)) {?>
      <div align="center"><form name="myform" id="myform">
        <table width="400" border="0" align="center" cellpadding="3" cellspacing="3" class="forms">
          <tr>
            <td >Nome de usuario:<br>
			<input name="user_name" type="text" disabled id="name" value="<? echo $row_settings['user_name']; ?>" size="50"></td>
          </tr>
          <tr> 
            <td colspan="2">Email:<br>
			<input name="user_email" type="text" disabled  id="name"  value="<? echo $row_settings['user_email']; ?>" size="50"></td>
          </tr>
  </table>
      </form>
	  <?php } ?>
	  <form name="pform" id="pform" method="post" action="">
        <table width="400" border="0" align="center" cellpadding="3" cellspacing="3" class="forms">
		  <tr>
              <td colspan="2">Se voc� quiser alterar sua senha, por favor digite sua senha antiga e nova para fazer a altera��es.</td>
          </tr>
		  <tr> 
            <td width="20%">Senha antiga:</td>
            <td width="80%"><input name="pwd_old" type="password" class="required password"  id="pwd_old"></td>
          </tr>
          <tr> 
            <td>Nova senha:</td>
            <td><input name="pwd_new" type="password" id="pwd_new" class="required password"  ></td>
          </tr>
        </table>
        <p align="center"> 
          <input name="doUpdate" type="submit" id="doUpdate" value="Alterar">
        </p>
        <p>&nbsp; </p>
      </form></div>
                    </div>
				<div id="home">
                <h3 style="color:#fff;"><?php echo $menssage; ?> <?php if (isset($falta) && $falta != 0){echo $falta;} ?> <?php echo $plural; ?> <?php echo $vteste; ?></h3>
                <div class="meter red">
                    <span style="width: <?php echo $marcador; ?>%"></span></div>
					<table width="100%" align="left" cellspacing="0" class="canais">
    <tr>
	<? if($vencido == '0'){ ?>
	<?
    $i = 1;
    $colunas = 7;

    $q_canais_variedades = mysql_query("SELECT * FROM dados_beta WHERE lugar = 'canais' AND (vip = 's' or vip = 'na') AND ligar = 's'  ORDER BY nome_do_canal");
    while($canais_variedades = mysql_fetch_object($q_canais_variedades)){
	$resto = $i % $colunas;
	?>
	<td><a style="color:#FFFFFF; font-weight:bold;" href="<? echo $siteurl.'/mover/'.$canais_variedades->linkvip; ?>" title="<? echo $sql458['nome_do_canal']; ?>" target="_top"><span><? if (strlen($canais_variedades->nome_do_canal) > 15) { echo substr($canais_variedades->nome_do_canal, 0, 15) . '...'; } else {
echo $canais_variedades->nome_do_canal; }?></span></a></td>
	<?
    if(($resto == 0)){
    print "</tr>
	<tr>
	";
    }
    
    $i++;
    
    }
    if($resto != 0){ ?></tr>
<? } ?>
<? } ?>
    </table>
				<? if(true){ ?><div align="center" style=" padding-right:40px;">
  <? if(!empty($configuracoes['PayPalApiUsername']) && !empty($configuracoes['PayPalApiPassword']) && !empty($configuracoes['PayPalApiSignature'])){ ?><div style="width:268px; display:inline-block; height:113px; color:#5D7D2C; margin:10px 10px 0 0; background-color:#E8F0DC; border:  4px solid #76A331; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; font-size:18px;"><span class="formInfo2"><form action="../pagamentos/paypal/process.php" id="myForm" target="_blank" method="post">
<input type="hidden" name="lc" value="BR">
<table width="268">
<tr><td>Op��es de pagamento PayPal</td></tr><tr><td>
	<select id="itemprice" name="itemprice">
	<? $preco = "select * from formaspag ORDER BY tempo ASC";
       $querypreco = mysql_query($preco);
       while ($linhapreco = mysql_fetch_array($querypreco)) {
	   $tempoemmes = $linhapreco['tempo'];
	   if($tempoemmes >= '2'){
	   $mes = 'Meses';
	   }else{
	   $mes = 'M�s';
	   }
       echo $linhapreco['id'] . "<br />"; //id é o nome do campo. Substitua pelo nome do campo da sua tabela
	   echo '<option value="'.$linhapreco['valor'].'">Op��o : '.$linhapreco['tempo'].' '.$mes.' conta vip - R$'.$linhapreco['valor'].'</option>';
    } ?>
	</select></td></tr>
</table>
       <?
	   $preco = "select * from formaspag ORDER BY tempo ASC";
       $querypreco = mysql_query($preco);
	   $ia = 1;
       while ($linhapreco = mysql_fetch_array($querypreco)) {
	   if($ia == 1){
	   ?>
	   <script type='text/javascript'>//<![CDATA[ 
$(window).load(function(){
$(document).ready(function () {
    $('.block').hide();
    $('#<? echo str_replace(".", "", $linhapreco['valor']); ?>').show();
    $('#itemprice').change(function () {
	    $('.block').hide();
		someVariable = $(this).val().replace('.', '');
        $('#'+someVariable).fadeIn();
    });
});

});//]]>  

</script>
	   <? } $ia++;?>
	   <div id="<? echo str_replace(".", "", $linhapreco['valor']); ?>" style="display:none;" onClick="submitOnClick('myForm')" class="block">CLIQUE AQUI PARA PAGAR<br/> <span class="smalll">R$ <? echo $linhapreco['valor']; ?> | Cart�o ou Saldo Paypal</span></div>
	   <?
    } ?>
<img alt="" border="0" src="https://www.paypalobjects.com/pt_BR/i/scr/pixel.gif" width="1" height="1">
</form>
<span style="display: none;" class="mycontent2"><div style="width:565px; height:100px; background-color:#FFFFFF; border-style:solid; border-width:4px; border-color:#76A331; border-radius: 5px;"><img src="images/paypal.png"></div></span>
</span>
</div><? } ?>
  <? if(!empty($configuracoes['tokenpagseguro']) && !empty($configuracoes['emailpagseguro'])){ ?><div style="width:268px; display:inline-block; height:113px; color:#5D7D2C; margin:10px 0 0 10px; background-color:#E8F0DC; border:  4px solid #76A331; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; font-size:18px;"><span class="formInfo"><form target="PagSeguro" action="../pagamentos/pagseguro/PagSeguroRetornoEnvia.php" method="post" id="myForm1" name="contavip" />
<table width="268">
<tr><td>Op��es de pagamento Pagseguro</td></tr><tr><td>
	<select id="itemprice1" name="item_valor_1">
	<? $preco = "select * from formaspag ORDER BY tempo ASC";
       $querypreco = mysql_query($preco);
       while ($linhapreco = mysql_fetch_array($querypreco)) {
	   $tempoemmes = $linhapreco['tempo'];
	   if($tempoemmes >= '2'){
	   $mes = 'Meses';
	   }else{
	   $mes = 'M�s';
	   }
       echo $linhapreco['id'] . "<br />"; //id é o nome do campo. Substitua pelo nome do campo da sua tabela
	   echo '<option value="'.$linhapreco['valor'].'">Op��o : '.$linhapreco['tempo'].' '.$mes.' conta vip - R$'.$linhapreco['valor'].'</option>';
    } ?>
	</select></td></tr>
</table>
 <?
	   $preco = "select * from formaspag ORDER BY tempo ASC";
       $querypreco = mysql_query($preco);
	   $ia = 1;
       while ($linhapreco = mysql_fetch_array($querypreco)) {
	   if($ia == 1){
	   ?>
	   <script type='text/javascript'>//<![CDATA[ 
$(window).load(function(){
$(document).ready(function () {
    $('.block1').hide();
    $('#b<? echo str_replace(".", "", $linhapreco['valor']); ?>').show();
    $('#itemprice1').change(function () {
	    $('.block1').hide();
		someVariable = $(this).val().replace('.', '');
        $('#b'+someVariable).fadeIn();
    });
});

});//]]>  

</script>
	   <? } $ia++;?>
	   <div id="b<? echo str_replace(".", "", $linhapreco['valor']); ?>" style="display:none;" onClick="submitOnClick('myForm1')" class="block1">CLIQUE AQUI PARA PAGAR<br/> <span class="smalll">R$ <? echo $linhapreco['valor']; ?> | Boleto, Cart�o ou Transfer�ncia</span></div>
	   <?
    } ?>
  <img alt="" border="0" src="https://www.paypalobjects.com/pt_BR/i/scr/pixel.gif" width="1" height="1">
</form>
<span style="display: none;" class="mycontent"><div style="width:565px; height:100px; background-color:#FFFFFF; border-style:solid; border-width:4px; border-color:#76A331; border-radius: 5px;"><img src="images/pagseguro.png"></div></span>
</span>

</div><? } ?>
<div id="conteudo" style="display:none; width:580px;" align="left"><img src="https://p.simg.uol.com.br/out/pagseguro/i/banners/pagamento/todos_estatico_550_100.gif"></div>
<? if(!empty($configuracoes['PayPalApiUsername']) && !empty($configuracoes['PayPalApiPassword']) && !empty($configuracoes['PayPalApiSignature']) or (!empty($configuracoes['tokenpagseguro']) && !empty($configuracoes['emailpagseguro']))){ ?><div id="sa" class="style1" style="font-size: 18px; line-height:25px; width:625px; display:inline-block;">O pagamento � confirmado automaticamente, 24 horas por dia, 7 dias por semana.</div><? } ?>
					 </div>

				<? } ?>
				</div>
			</div>
				
    <footer>
        <p class="copyright"></p>
    </footer>
<script type="text/javascript" src="js/jquery.placeholder.js"></script>	<!-- placeholder html5 tag support for IE and Old Browsers -->
<script type="text/javascript">
			$(document).ready(function(){
		$(".formInfo").tooltip({tooltipcontentclass:"mycontent"})
});;
		</script>
<script type="text/javascript">
			$(document).ready(function(){
		$(".formInfo2").tooltip({tooltipcontentclass:"mycontent2"})
});;
		</script>
</body> 
</html>
