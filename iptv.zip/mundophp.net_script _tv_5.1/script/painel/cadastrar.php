<?php 
ob_start();

include 'comfig.php';

$hoje = date('Y-m-d');
$diasgratis = $configuracoes['diasgratis'];
$vencimento = date('Y-m-d', strtotime(' +'.$diasgratis.' day'));

$err = array();
					 
if($_POST['doRegister'] == 'Cadastrar') 
{ 
/******************* Filtering/Sanitizing Input *****************************
This code filters harmful script code and escapes data of all POST data
from the user submitted form.
*****************************************************************/
foreach($_POST as $key => $value) {
	$data[$key] = filter($value);
}

/************************ SERVER SIDE VALIDATION **************************************/
/********** This validation is useful if javascript is disabled in the browswer ***/


// Validate User Name
if (!isUserID($data['user_name'])) {
$err[] = "ERRO - nome de usu�rio inv�lido. Ele pode conter alfabeto, n�meros e sublinhado.";
//header("Location: cadastrar.php?msg=$err");
//exit();
}

// Validate Email
if(!isEmail($data['usr_email'])) {
$err[] = "ERRO - endere�o de e-mail inv�lido.";
//header("Location: cadastrar.php?msg=$err");
//exit();
}
// Check User Passwords
if (!checkPwd($data['pwd'],$data['pwd2'])) {
$err[] = "ERRO - Senha ou incompatibilidade inv�lido. Digite 5 caracteres ou mais";
//header("Location: cadastrar.php?msg=$err");
//exit();
}
	  
$user_ip = $_SERVER['REMOTE_ADDR'];

// stores sha1 of password
$sha1pass = PwdHash($data['pwd']);

// Automatically collects the hostname or domain  like example.com) 
$host  = $_SERVER['HTTP_HOST'];
$host_upper = strtoupper($host);
$path   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');

// Generates activation code simple 4 digit number
$activ_code = rand(1000,9999);

$usr_email = $data['usr_email'];
$user_name = $data['user_name'];

/************ USER EMAIL CHECK ************************************
This code does a second check on the server side if the email already exists. It 
queries the database and if it has any existing email it throws user email already exists
*******************************************************************/

$rs_duplicate = mysql_query("select count(*) as total from users where user_email='$usr_email' OR user_name='$user_name'") or die(mysql_error());
list($total) = mysql_fetch_row($rs_duplicate);

if ($total > 0)
{
$err[] = "ERRO - O nome de usu�rio / e-mail j� existe. Por favor, tente novamente com outro nome de usu�rio e e-mail.";
//header("Location: cadastrar.php?msg=$err");
//exit();
}
/***************************************************************************/

if(empty($err)) {

$sql_insert = "INSERT into `users`
  			(`user_email`,`pwd`,`date`,`users_ip`,`activation_code`,`user_name`,`full_name`,`data`,`vencimento`)
		    VALUES
		    ('$usr_email','$sha1pass',now(),'$user_ip','$activ_code','$user_name','$user_name','$hoje','$vencimento')
			";
			
mysql_query($sql_insert,$link) or die("Insertion Failed:" . mysql_error());
$user_id = mysql_insert_id($link);
$md5_id = md5($user_id);
mysql_query("update users set md5_id='$md5_id' where id='$user_id'");

if($user_registration)  {
$a_link = utf8_encode("
*****LINK DE ATIVA&Ccedil;�O*****\n
http://$host$path/ativar.php?user=$md5_id&activ_code=$activ_code
"); 
} else {
$a_link = 
utf8_encode("Sua conta esta *Aguardando aprova��o* embreve sera ativada por um dministrador.
");
}

$message = 
utf8_encode("Ola \n
Obrigado por se cadastrar conosco. Aqui est�o os detalhes de login...\n

Usu�rio: $user_name
Email: $usr_email \n 
Senha: $data[pwd] \n

$a_link

Obrigado

Administrador
$host_upper
______________________________________________________
ESTA � UMA RESPOSTA AUTOM�TICA. 
***N�O RESPONDA A ESTE E-MAIL****
");

	mail($usr_email, "Dados de Acesso", $message,
    "From: \"Inscri��o de membro\" <auto-reply@$host>\r\n" .
     "X-Mailer: PHP/" . phpversion());
	 
	header("Location: sucesso.html");
    exit();
	 } 
 }					 

$banners = mysql_query("SELECT * FROM termos");
$row_banners = mysql_fetch_assoc($banners);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
		
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		
		<title>Cadastro tv online</title>
		
		<!--                       CSS                       -->
	  
		<!-- Reset Stylesheet -->
		<link rel="stylesheet" href="../admin/resources/css/reset.css" type="text/css" media="screen" />
	  
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="../admin/resources/css/style.css" type="text/css" media="screen" />
		
		<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
		<link rel="stylesheet" href="../admin/resources/css/invalid.css" type="text/css" media="screen" />	
		
		<script type="text/javascript" src="../admin/resources/scripts/jquery-1.3.2.min.js"></script>
		
		<!-- jQuery Configuration -->
		<script type="text/javascript" src="../admin/resources/scripts/simpla.jquery.configuration.js"></script>
		
		<!-- Facebox jQuery Plugin -->
		<script type="text/javascript" src="../admin/resources/scripts/facebox.js"></script>
		
		<!-- jQuery WYSIWYG Plugin -->
		<script type="text/javascript" src="../admin/resources/scripts/jquery.wysiwyg.js"></script>
		
		<!-- Internet Explorer .png-fix -->
		
        <script language="JavaScript" type="text/javascript" src="../painel/js/jquery.validate.js"></script>

  <script>
  $(document).ready(function(){
    $.validator.addMethod("username", function(value, element) {
        return this.optional(element) || /^[a-z0-9\_]+$/i.test(value);
    }, "Usu�rio deve conter apenas letras, n�meros ou sublinhado.");

    $("#regForm").validate();
  });
  </script>
<script type='text/javascript'>//<![CDATA[ 
$(window).load(function(){
function onSubmit() 
{ 
  var fields = $("input[name='termos']").serializeArray(); 
  if (fields.length == 0) 
  { 
    alert('Voc� n�o concordou com os termos de uso!'); 
    // cancel submit
    return false;
  } 
}

// register event on form, not submit button
$('#regForm').submit(onSubmit)
});//]]>  

</script>
	
	</head>
  
	<body id="login">
		
		<div id="login-wrapper1" class="png_bg" style="color:#FFFFFF;">
			<div id="reg-content" style="color:#FFFFFF;">
	  </p>
      <h2 class="titlehdr" style="color:#FFFFFF;">Cadastro Area Vip</h2>
	  <?php
	  /******************** ERROR MESSAGES*************************************************
	  This code is to show error messages 
	  **************************************************************************/
	  if(!empty($err))  {
	   echo "<div class='notification information png_bg'><div>";
	  foreach ($err as $e) {
	    echo "$e <br>";
	    }
	  echo "</div></div>";	
	   }
	  if(!empty($msg))  {
	    echo "<div class='notification information png_bg'><div>";
		echo $msg[0] . " <br>";
		 echo "</div></div>";	
		}
	  /******************************* END ********************************/	  
	  ?>
	  <br>
       <form action="cadastrar.php" method="post" name="regForm" id="regForm" >
					<p>
						<label>Usuario</label>
						<input name="user_name" type="text" id="user_name" class="required text-input" minlength="5" > 
              <input name="btnAvailable" type="button" class="button" id="btnAvailable" 
			  onclick='$("#checkid").html("Aguarde..."); $.get("checkuser.php",{ cmd: "check", user: $("#user_name").val() } ,function(data){  $("#checkid").html(data); });'
			  value="Testar "> 
			    <span style="color:#61A700; font: bold 12px verdana; " id="checkid" ></span> 
					</p>
					<div class="clear"></div>
					<p>
						<label>Senha</label>
						<input name="pwd" type="password" class="required text-input" minlength="5" id="pwd"> 
              <span class="example">* M�nimo de 5 caracteres.</span>
					</p>
					<div class="clear"></div>
					<p>
						<label>Repita a senha</label>
						<input name="pwd2"  id="pwd2" class="required text-input" type="password" minlength="5" equalto="#pwd">
					</p>
					<div class="clear"></div>
					<p>
						<label>Seu E-mail</label>
						<input name="usr_email" type="text" id="usr_email3" class="required text-input"> 
              <span class="example">* E-mail v�lido, por favor.</span>
					</p>
					<p>
						<label>Termos de uso, Por Favor Leia At� o Fim:</label>
						<div id="FreeTextBox1" style="overflow: auto; width: 320px; height:200px; border: 1px solid black;"><?php echo $row_banners['termos']; ?></div>
						<br />
		 <h5 style="color:#FFFFFF"> <input name="termos" id="termos0" type="checkbox" >Li os Termos de Uso e Aceito!</h5><br />
					<p>
					<div class="clear"></div>

						<input name="doRegister" type="submit" id="doRegister" value="Cadastrar" class="button" >
					</p>
					
			  </form>

			</div> <!-- End #login-content -->
			
		</div> <!-- End #login-wrapper -->
		
  </body>
  </html>
