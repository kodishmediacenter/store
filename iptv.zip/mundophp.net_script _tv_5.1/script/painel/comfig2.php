<?
date_default_timezone_set('America/Sao_Paulo');
$configuracoes = mysql_query("SELECT * from configuracoes WHERE id='1' LIMIT 1");
$configuracoes = mysql_fetch_array($configuracoes);
?>