<?php
require_once('comfig.php');
logout();
?> 