<?php
require_once('painel/comfig.php'); ?>
<?php
header("Content-type: text/xml");
echo '<?xml version="1.0" encoding="UTF-8"?>';

$hoje = date('Y-m-d');
?>
  <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  <url>
 <loc><?php echo $siteurl;?>/</loc>
 <lastmod><?php echo $hoje;?></lastmod>
 <priority>1.00</priority>
 <changefreq>daily</changefreq>
</url><?php
 function nomeico($extensao){
 $arquivo1111 = pathinfo($extensao, PATHINFO_EXTENSION);
 if($arquivo1111 == 'jpg'){
 return $file = basename($extensao, ".jpg");
 }
 if($arquivo1111 == 'png'){
 return $file = basename($extensao, ".png");
 }
 if($arquivo1111 == 'gif'){
 return $file = basename($extensao, ".gif");
 }
}
function linkico($vip, $link){
global $siteurl;
if($vip==s){ return $siteurl.'/icones/grande/vip/'.nomeico($link).'.jpeg';}
if($vip==n){ return $siteurl.'/icones/grande/aberto/'.nomeico($link).'.jpeg';}
if($vip==na){ return $siteurl.'/icones/grande/aberto/'.nomeico($link).'.jpeg';}
}

/*
Conecta ao banco de dados... essa parte voc� acha f�cil na internet.
*/
$sql_tabela = mysql_query("SELECT * FROM dados_beta WHERE lugar LIKE 'canais' AND ligar LIKE 's' AND (vip LIKE 'n' or vip LIKE 'na') ORDER BY nome_do_canal ASC");

 while($tabela = mysql_fetch_assoc($sql_tabela)){
if($tabela['form'] == 'cadastro'){
	$imagem = '<image:image>
 <image:loc>
    '.linkico($tabela['vip'], $tabela['url_do_canal']).'
 </image:loc>
</image:image>
';			
	}else{
	$imagem = '';
	}

echo "
<url>
 <loc>".$siteurl."/tv/".$tabela['nome_foto']."</loc>
".$imagem."<lastmod>".$hoje."</lastmod>
 <changefreq>daily</changefreq>
 <priority>0.80</priority>
</url>";
}
 ?>
</urlset>