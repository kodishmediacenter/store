import xbmc
import xbmcgui
import webbrowser
import plugintools

#def busca_assistirme():

def browser_player(os,link):

    if os =='android':
        links = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+link+'' ) )
    else:
        links = webbrowser . open ( ''+link+'' )



def sites(os):
    dialog = xbmcgui.Dialog()
    ret3 = dialog.select('[COLOR yellow]Bem Vindo ao Site[/COLOR]', ['Lancamentos', 'Filmes','Series','Animes','Desenhos','','Calendario'])

    if ret3 == 0:
        link0 = "https://assistir.me/lancamentos"
        browser_player(os,link0)
    
    if ret3 == 1:
        link1 = "https://assistir.me/filmes"
        browser_player(os,link1)

    if ret3 == 2:
        link2 = "https://assistir.me/series"
        browser_player(os,link2)
        
    if ret3 == 3:
        link3 = "https://assistir.me/animes"
        browser_player(os,link3)

    if ret3 == 4:
        link4 = "https://assistir.me/desenhos"
        browser_player(os,link4)
    
    if ret3 == 5:
        link5 = ""
        browser_player(os,link5)

    if ret3 == 6:
        link6 = "https://www.vejoseries.com/Calendario/GoogleCalendar"
        browser_player(os,link6)
        







if xbmc . getCondVisibility ('system.platform.android'):
    os = 'android'
    sites(os)
else:
    os = 'null'
    sites(os)



