import xbmc
import xbmcgui
import webbrowser
import plugintools

def browser_player(os,link):

    if os =='android':
        links = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+link+'' ) )
    else:
        links = webbrowser . open ( ''+link+'' )



    
def canais():
    dialog = xbmcgui.Dialog()
    ret5 = dialog.select('[COLOR yellow]Canais do Ruivo[/COLOR]', ['Ruivo TM', 'Ruivo Old School'])
    if ret5 == 0:
        xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.youtube/channel/UCenM8DcC2UXzF97FWCC4Zdw/)")
    if ret5 == 1:
        xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.youtube/channel/UCw2jDAZL_EmfzI0sOvor5Sw/)")

def loja(os):
    loja = "https://www.lojakissfm.com.br/"
    browser_player(os,loja)

def redessociais2(os):
    ret2 = dialog.select('[COLOR yellow]Redes Sociais[/COLOR]', ['Facebook', 'Instagram','Youtube'])

    if ret2 == 0:
        link10 = "https://www.facebook.com/RuivoGameplays"
        browser_player(os,link10)
        

    if ret2 == 1:
        link11 = "https://www.instagram.com/ruivoplay"
        browser_player(os,link11)

    if ret2 == 2:
        canais()



def placas(os):
    dialog = xbmcgui.Dialog()
    ret4 = dialog.select('[COLOR yellow]Boards e Mini PC[/COLOR]', ['Raspberry Pi', 'UP Board','Orange Pi','Banana Pi','Nano PC'])

    if ret4 == 0:
        link21 = "http://jogoretro.blogspot.com.br/search/label/Raspberry%20Pi"
        browser_player(os,link21)

    if ret4 == 1:
        link22 = "http://jogoretro.blogspot.com.br/search/label/UP%20Board"
        browser_player(os,link22)

    if ret4 == 2:
        link23 = "http://jogoretro.blogspot.com.br/search/label/Orange%20PI"
        browser_player(os,link23)

    if ret4 == 3:
        link24 = "http://jogoretro.blogspot.com.br/search/label/Banana%20Pi"
        browser_player(os,link24)

    if ret4 == 4:
        link25 = "http://jogoretro.blogspot.com.br/search/label/NanoPC"
        browser_player(os,link25)

def sites(os):
    dialog = xbmcgui.Dialog()
    ret3 = dialog.select('[COLOR yellow]Bem Vindo ao Site[/COLOR]', ['Boards / Mini-PC', 'Raspberry Pi Downloads','Android','Mugen','Open Bor','Patchs / Hack','Redes Sociais'])

    if ret3 == 0:
        placas(os)
    
    if ret3 == 1:
        link1 = "http://jogoretro.blogspot.com.br/2017/06/raspberry-pi-downloads.html"
        browser_player(os,link1)

    if ret3 == 2:
        link2 = "http://jogoretro.blogspot.com.br/search/label/ANDROID"
        browser_player(os,link2)
        
    if ret3 == 3:
        link3 = "http://jogoretro.blogspot.com.br/search/label/MUGEN"
        browser_player(os,link3)

    if ret3 == 4:
        link4 = "http://jogoretro.blogspot.com.br/search/label/OpenBOR"
        browser_player(os,link4)
    
    if ret3 == 5:
        link5 = ""
        browser_player(os,link5)

    if ret3 == 6:
        link6 = "https://www.facebook.com/RuivoGameplays"
        browser_player(os,link6)
        




    
dialog = xbmcgui.Dialog()
ret2 = dialog.select('[COLOR yellow]Bem Vindo Ruivo[/COLOR]', ['Site', 'Redes Sociais'])


if ret2 == 0: 
    if xbmc . getCondVisibility ('system.platform.android'):
        os = 'android'
        sites(os)
    else:
        os = 'null'
        sites(os)

if ret2 == 1:
    if xbmc . getCondVisibility ('system.platform.android'):
        os = 'android'
        redessociais2(os)
    else:
        os = 'null'
        redessociais2(os)
    
