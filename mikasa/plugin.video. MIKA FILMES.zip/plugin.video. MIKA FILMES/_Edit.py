import xbmcaddon

MainBase = 'https://pastebin.com/raw/dsS678iF'
addon = xbmcaddon.Addon('plugin.video.MIKA FILMES')