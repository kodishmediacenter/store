sudo cp -r /home/kodish/.kodi  /opt/kodish/kodish-crio/
sudo cp -r /home/kodi/.kodi  /opt/kodish/kodish-crio/
