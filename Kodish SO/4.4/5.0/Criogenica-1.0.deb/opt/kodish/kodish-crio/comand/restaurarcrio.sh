rm -r /home/kodish/.kodi
cp -r /opt/kodish/kodish-crio/.kodi /home/kodish/.kodi
rm -r /home/kodi/.kodi
cp -r /opt/kodish/kodish-crio/.kodi /home/kodi/.kodi
