# -*- coding: utf-8 -*- 
import sys 
import xbmc,xbmcgui 

dialog = xbmcgui.Dialog()
link = dialog.select('Web Tv', ['Anime Tv','Canal 29','Tv Cine Trianon','Genial Tv','Tv Nova Barreiros','Tv Nova Manchete','Radio Play Pixel','Retro Cartoon Tv','TV Aracati','TV Futuro','Tv Japi','Tv Manchete BH','Tv Mega Cine','Tv Montanha','Tv na Ilha','Tv Nova Onda','Tv Star Trek','Tv vale das Artes','Tv Unitvburitama','Via Morena Tv','Vintage Tv','YeaahTV','Paga 2'])

if link == 0:
    url = "https://stmv1.srvif.com/animetv/animetv/chunklist_w1327383665.m3u8"
    xbmc.Player().play(url)

if link == 1:
    url = "https://59f1cbe63db89.streamlock.net:1443/canal/_definst_/canal/chunklist_w196292492.m3u8"
    xbmc.Player().play(url)


if link == 2:
    url = "https://srv2.zcast.com.br/cleto2085/cleto2085/chunklist_w347555181.m3u8"
    xbmc.Player().play(url)

if link == 3:
    url = "https://studio.genialltv.com/live/Stream1_360p/chunklist_w883469436.m3u8"
    xbmc.Player().play(url)

if link == 4:
    url = "https://5d82644094cc0.streamlock.net/8026/8026/chunklist_w1879209005.m3u8"
    xbmc.Player().play(url)

if link == 5:
    url = "https://srv5.zcast.com.br/tvmanchete/tvmanchete/chunklist_w967550760.m3u8"
    xbmc.Player().play(url)


if link == 6:
    url = "http://stream.zeno.fm/8g81y3e51k8uv.m3u"
    xbmc.Player().play(url)

if link == 7:
    url = "https://stmv1.srvstm.com/cartoonr2/cartoonr2/chunklist_w887705203.m3u8"
    xbmc.Player().play(url)

if link == 8:
    url = "https://livefocamundo.com:8081/8148/tracks-v1a1/mono.m3u8"
    xbmc.Player().play(url)

if link == 9:
    url = "https://streaming03.zas.media/tvfuturo/tvfuturo/chunklist_w605692760.m3u8"
    xbmc.Player().play(url)

if link == 10:
    url = "https://srv2.zcast.com.br/tvjapi/tvjapi/chunklist_w955737550.m3u8"
    xbmc.Player().play(url)

if link == 11:
    url = "https://stmv1.srvif.com/manchetebahia/manchetebahia/chunklist_w1967542387.m3u8"
    xbmc.Player().play(url)

if link == 12:
    url = "https://stmv1.srvif.com/reconsatcine/reconsatcine/chunklist_w1246757685.m3u8"
    xbmc.Player().play(url)

if link == 13:
    url = "https://srv2.zcast.com.br/oney7654/oney7654/chunklist_w117317781.m3u8"
    xbmc.Player().play(url)

if link == 14:
    url = "http://video01.kshost.com.br/clodoaldo6562/clodoaldo6562/chunklist_w1007254778.m3u8"
    xbmc.Player().play(url)

if link == 15:
    url = "https://5c483b9d1019c.streamlock.net/8078/8078/chunklist_w1660411812.m3u8"
    xbmc.Player().play(url)

if link == 16:
    url = "https://stmv1.srvstm.com/tvserie3/tvserie3/chunklist_w1062191621.m3u8"
    xbmc.Player().play(url)

if link == 17:
    url = "https://59f1cbe63db89.streamlock.net:1443/tvvaledasartes/_definst_/tvvaledasartes/chunklist_w725792145.m3u8"
    xbmc.Player().play(url)

if link == 18:
    url = "https://stmv3.samcast.com.br/marcosroberto5912/marcosroberto5912/chunklist_w749717003.m3u8"
    xbmc.Player().play(url)

if link == 19:
    url = "https://59f1cbe63db89.streamlock.net:1443/cleuzaviamorena/_definst_/cleuzaviamorena/chunklist_w1790442423.m3u8"
    xbmc.Player().play(url)

if link == 20:
    url = "https://stmv1.srvstm.com/rogerio4248/rogerio4248/chunklist_w465794776.m3u8"
    xbmc.Player().play(url)

if link == 21:
    url = "https://srv3.zcast.com.br/yeeaah/yeeaah/chunklist.m3u8"
    xbmc.Player().play(url)

if link == 22:
    url = ""
    xbmc.Player().play(url)

if link == 24:
    url = ""
    xbmc.Player().play(url)
