# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvstm.com/cartoonr2/cartoonr2/chunklist_w367195532.m3u8"


xbmc.Player().play(url)