# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv3.zcast.com.br/yeeaah/yeeaah/chunklist_w1895141637.m3u8"


xbmc.Player().play(url)