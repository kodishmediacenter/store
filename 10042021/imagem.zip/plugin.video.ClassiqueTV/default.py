# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvstm.com/classique2/classique2/chunklist.m3u8"


xbmc.Player().play(url)