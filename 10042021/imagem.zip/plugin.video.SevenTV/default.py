# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://videodj.fm5.com.br:19360/seventv/seventv.m3u8"


xbmc.Player().play(url)