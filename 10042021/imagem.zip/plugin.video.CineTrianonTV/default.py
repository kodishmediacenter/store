# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv2.zcast.com.br/cleto2085/cleto2085/chunklist_w347555181.m3u8"


xbmc.Player().play(url)