# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.samcast.com.br/joaomatheus5156/joaomatheus5156/chunklist_w1427669147.m3u8"


xbmc.Player().play(url)