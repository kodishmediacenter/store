# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.vhcast.com/tvcine/tvcine/chunklist_w1578077607.m3u8"


xbmc.Player().play(url)