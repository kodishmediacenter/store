# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "http://video01.kshost.com.br/jorge7437/jorge7437/chunklist_w1521183830.m3u8"


xbmc.Player().play(url)