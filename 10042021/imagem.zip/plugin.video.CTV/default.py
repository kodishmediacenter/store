# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://5d2c98775bafe.streamlock.net/8020/8020/chunklist_w177077210.m3u8"


xbmc.Player().play(url)