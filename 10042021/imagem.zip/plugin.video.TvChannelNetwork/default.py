# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://serv3.videovox.pw/alexandre4108/alexandre4108/chunklist_w2046138234.m3u8"


xbmc.Player().play(url)