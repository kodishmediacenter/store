# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv4.zcast.com.br/andre2183/andre2183/chunklist_w1445108989.m3u8"


xbmc.Player().play(url)