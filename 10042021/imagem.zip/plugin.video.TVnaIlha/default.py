# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "http://video01.kshost.com.br/clodoaldo6562/clodoaldo6562/chunklist_w1007254778.m3u8"


xbmc.Player().play(url)