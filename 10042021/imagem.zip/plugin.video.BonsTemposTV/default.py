# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://tv01.livemustv.com.br/rivaldo6209/rivaldo6209/chunklist_w1428672052.m3u8"


xbmc.Player().play(url)