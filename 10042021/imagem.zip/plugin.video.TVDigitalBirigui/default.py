# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "http://wse01.logicahost.com.br:1935/tvdigitalbirigui/_definst_/tvdigitalbirigui/chunklist_w1110438788.m3u8"


xbmc.Player().play(url)