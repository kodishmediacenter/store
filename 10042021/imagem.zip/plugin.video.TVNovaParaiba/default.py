# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://srv4.zcast.com.br/tvnovaparaiba/tvnovaparaiba/chunklist_w127143760.m3u8"


xbmc.Player().play(url)