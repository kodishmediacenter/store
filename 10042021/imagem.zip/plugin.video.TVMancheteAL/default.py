# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/tvmanchete1/tvmanchete1/chunklist_w345517326.m3u8"


xbmc.Player().play(url)