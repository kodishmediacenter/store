# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://video01.kshost.com.br/natanael3635/natanael3635/chunklist_w1675901198.m3u8"


xbmc.Player().play(url)