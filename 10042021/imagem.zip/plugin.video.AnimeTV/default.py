# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvif.com/animetv/animetv/chunklist_w39016581.m3u8"


xbmc.Player().play(url)