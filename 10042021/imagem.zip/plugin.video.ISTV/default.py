# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.voxtvhd.com.br/istv/istv/chunklist_w1853797597.m3u8"


xbmc.Player().play(url)