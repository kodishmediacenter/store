# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://verizon.gcp.br.cdn.booyah.live/hls/151073/34850987_1080.m3u8"


xbmc.Player().play(url)