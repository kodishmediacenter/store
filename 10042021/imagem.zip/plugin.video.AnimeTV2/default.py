# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.srvstm.com/animetv2/animetv2/chunklist_w1792327554.m3u8"


xbmc.Player().play(url)