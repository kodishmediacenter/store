# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv3.samcast.com.br/rosanaa9913/rosanaa9913/chunklist_w1832872038.m3u8"


xbmc.Player().play(url)