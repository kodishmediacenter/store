# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.voxtvhd.com.br/webtvxtreme/webtvxtreme/chunklist_w839757191.m3u8"


xbmc.Player().play(url)