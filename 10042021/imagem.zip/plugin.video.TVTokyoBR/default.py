# -*- coding: utf-8 -*- 
import sys 
import xbmc 

url = "https://stmv1.voxtvhd.com.br/tvtokio/tvtokio/chunklist_w381196228.m3u8"


xbmc.Player().play(url)