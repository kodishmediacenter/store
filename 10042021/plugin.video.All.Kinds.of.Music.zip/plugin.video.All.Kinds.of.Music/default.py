# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.All.Kinds.of.Music'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1 = "PLD7SPvDoEddZ4awWJjYEQdI10UP-9sGkO"
YOUTUBE_CHANNEL_ID2 = "PL9HJJedWjAmNILSM93NSf0-5-VoLXs_6Q"
YOUTUBE_CHANNEL_ID3 = "PLJhKEt4Hct7X5ox53HIqxCHRdhghj581o"
YOUTUBE_CHANNEL_ID4 = "PLsGK3aH9-P9nqEH-M-TKEnAcBNxhq1ljq"
YOUTUBE_CHANNEL_ID5 = "PLGXbBW1RbSb4UPshkqvYOO43L5_p5A5j4"
YOUTUBE_CHANNEL_ID6 = "PLsGK3aH9-P9krMatVVQwTuraacMknlAeB"
YOUTUBE_CHANNEL_ID7 = "PLq3UZa7STrbqdoap8wrwWryndN6rmm_Qc"
YOUTUBE_CHANNEL_ID8 = "PL3oW2tjiIxvRIO95Du4117quZ42amYmIC"
YOUTUBE_CHANNEL_ID9 = "PLUMJYOoO2JQ8UVF6Pv2x0UcN0T3i9qPBw"
YOUTUBE_CHANNEL_ID10 = "PLMC9KNkIncKtsacKpgMb0CVq43W80FKvo"
YOUTUBE_CHANNEL_ID11 = "PLI_7Mg2Z_-4KU0S6_qMAojurEZ2C__j8w"
YOUTUBE_CHANNEL_ID12 = "PLhYloEd6Z5nWzry65UghGYAnXH-j5NOGy"
YOUTUBE_CHANNEL_ID13 = "PLxvodScTx2RsV2VIDIBksBmuLFngu3mgU"
YOUTUBE_CHANNEL_ID14 = "PLgwLwE95SwXPiOEPk8HXTrYy95yDKsUNV"
YOUTUBE_CHANNEL_ID15 = "PLpuDUpB0osJmZQ0a3n6imXirSu0QAZIqF"
YOUTUBE_CHANNEL_ID16 = "PL05E1623111A9A860"
YOUTUBE_CHANNEL_ID17 = "PLE19ADDE73A2A9499"
YOUTUBE_CHANNEL_ID18 = "PL09eGQfW13QjtcB0nITNYP56g8OMKe0uc"
YOUTUBE_CHANNEL_ID19 = "PLCD0445C57F2B7F41"
YOUTUBE_CHANNEL_ID20 = "PL7DA3D097D6FDBC02"
YOUTUBE_CHANNEL_ID21 = "PLK9Sc5q_4K6aNajVLKtkaAB1JGmKyccf2"
YOUTUBE_CHANNEL_ID22 = "PLMOnUdcodDmS7Ji3CWZReR6mFWtNBkO8l"
YOUTUBE_CHANNEL_ID23 = "PLs-kfwmk-th7qSMbgpg3Fq6XQQsgFA02b"
YOUTUBE_CHANNEL_ID24 = "PL09eGQfW13QgGH50QDnsE01bf9n3eJJz0"
YOUTUBE_CHANNEL_ID25 = "PL5219C5FC3806FEA9"
YOUTUBE_CHANNEL_ID26 = "PLd5xnond3B5Q8RQpGlrlvZv0n4_hpvxNv"
YOUTUBE_CHANNEL_ID27 = "PL61EE4ED086789D1C"
YOUTUBE_CHANNEL_ID28 = "PL09eGQfW13QhaQTz8guvp0x03_3OoOCdP"
YOUTUBE_CHANNEL_ID29 = "PLw-VjHDlEOgtwFlySm1JHphU3j8wUtSlu"
YOUTUBE_CHANNEL_ID30 = ""
YOUTUBE_CHANNEL_ID31 = ""
YOUTUBE_CHANNEL_ID32 = ""
YOUTUBE_CHANNEL_ID33 = ""
YOUTUBE_CHANNEL_ID34 = ""
YOUTUBE_CHANNEL_ID35 = ""

def addDir(title, url, thumbnail,fanart,folder):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   #addDir(title = "[COLOR lime][B]All Kinds of Music[/B][/COLOR]",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)

   addDir(title=" [COLOR lightskyblue]German TOP 100 Single Charts [/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail="https://i.ytimg.com/vi/8HSvsModtVg/maxresdefault.jpg",fanart="",folder=True)
   addDir(title=" [COLOR lightskyblue]Top 100 Schlager Charts[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4WfpttBJIgdpdtGCBOgETWez_7Ydh7Ekm5phS75SZIgzRJmcN",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]iTunes Top 100 US [/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail="https://img.freepik.com/freie-ikonen/itunes_318-133846.jpg?size=338&ext=jpg",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Musik Mix HD [/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail="https://cdn3.iconfinder.com/data/icons/multimedia-13/63/high-def-512.png",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Sounds of Summer [/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID5+"/",thumbnail="https://www.dropbox.com/s/d8lu4hp5ls039kv/Dance2.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Tomorrowland,Parokaville,Defcon,Qlimax,Goa und Psytrance Festival[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID6+"/",thumbnail="https://www.dropbox.com/s/s2m12goh16786fi/a079c6502ef0e4996b2987a433320824.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Best Pop Songs [/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID7+"/",thumbnail="https://www.dropbox.com/s/01gl6txjcil0u1n/Pop%20Hits.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Top Chart Music[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID8+"/",thumbnail="https://www.dropbox.com/s/ljlh49pdwqvc148/Top%20Chart%20Musik.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Top Billboard Charts [/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID9+"/",thumbnail="https://www.dropbox.com/s/699atmpi5hk8ikk/Billboard_Hot_100_logo.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Summer Hits  (Best Summer Songs)[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID10+"/",thumbnail="https://www.dropbox.com/s/pjqqrnssta5yroa/Dance5.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Best Old Summer Music[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID11+"/",thumbnail="https://www.dropbox.com/s/wo0vkhrcskixm2w/Dance4.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Kuschelrock[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID12+"/",thumbnail="https://www.dropbox.com/s/5ihu4acewhfro52/Kuschelrock.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Best New Reggae 2019[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID13+"/",thumbnail="https://www.dropbox.com/s/0uqicooja8id4oi/This%20is%20reggea%20musik.png?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Best songs of Hiphop from 2000-2019[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID14+"/",thumbnail="https://www.dropbox.com/s/l3ca0en2tq9vp6i/1A%202000er%20Hits.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]2000's Hits [/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID15+"/",thumbnail="https://www.dropbox.com/s/l3ca0en2tq9vp6i/1A%202000er%20Hits.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Top Hits of the 2000's[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID16+"/",thumbnail="https://www.dropbox.com/s/5mwdv1er81bgjr0/i%20love.png?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]100 Best Rock Songs of 2000's[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID17+"/",thumbnail="https://www.dropbox.com/s/kns3fss5krbbtsf/1A%20Rock%20Songs.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Best of 70s Music[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID18+"/",thumbnail="https://www.dropbox.com/s/bt90uj33mp6vtnp/images.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Greatest Hits (Best 80s Songs)[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID19+"/",thumbnail="https://www.dropbox.com/s/nej18b4fhdtm0ex/80er.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Greatest 90's Music Hits[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID20+"/",thumbnail="https://www.dropbox.com/s/vipki2z661lgdd9/90s.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]ROCK / Pop HITS 70's/80's/90's/00's[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID21+"/",thumbnail="https://www.dropbox.com/s/td2qklwc3vmixle/Rock%20Musik.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Deutschrock - Bester Rock für Dich Volume1[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID22+"/",thumbnail="https://www.dropbox.com/s/tlsa1ux87rxkr0b/Deutschrock.png?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Deutschrock - Bester Rock für Dich Volume2[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID23+"/",thumbnail="https://www.dropbox.com/s/tlsa1ux87rxkr0b/Deutschrock.png?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Deutsch - Pop / Rock[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID24+"/",thumbnail="https://www.dropbox.com/s/5tc9acfj1p5rtba/Rock%20Pop%202.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Deutsche Lieder - Gemischt [/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID25+"/",thumbnail="https://www.dropbox.com/s/23f3mm5tsribn8j/German-wallpaper74.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Neue Deutsche Welle 80s[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID26+"/",thumbnail="https://www.dropbox.com/s/sbvo422jwyqyqq6/Neue%20deutsche%20Welle.jpg?dl=1",fanart="",folder=True )
   addDir(title=" [COLOR lightskyblue]Schlager Marathon[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID27+"/",thumbnail="https://www.dropbox.com/s/0klb6c3s4vzpgic/1A%20Party%20Schlager.jpg?dl=1",fanart="",folder=True )
   addDir(title="[COLOR lightskyblue]Party & Schlager - Hits[/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID26+"/",thumbnail="https://www.dropbox.com/s/h8lkbsnhy1m7kjr/1A%20Party%20Hits.jpg?dl=1",fanart="",folder=True )
   addDir(title="[COLOR lightskyblue]Die besten Deutsche Lieder aller Zeiten [/COLOR]",url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID26+"/",thumbnail="https://www.dropbox.com/s/dh0uf6b24d8ehrx/1A%20Deutsche%20Hits.jpg?dl=1",fanart="",folder=True )					   
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
