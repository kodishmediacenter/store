import os,sys
import httplib
from urllib import urlencode
import urllib,urllib2,re,sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from httplib import HTTP
from urlparse import urlparse
import StringIO
import requests
from bs4 import BeautifulSoup



settings = xbmcaddon.Addon(id='plugin.video.Lexdan_Filmes')
addon_dir = xbmc.translatePath(settings.getAddonInfo('path'))
sys.path.append(os.path.join( addon_dir, 'resources', 'lib' ))
icon = settings.getAddonInfo('icon')
fanart = settings.getAddonInfo('fanart')
lexdan_handle = int(sys.argv[1])
ulr_principal = 'http://www.lexdan.co/Lexdan_Filmes/'
_pluginName = (sys.argv[0])
dialog = xbmcgui.Dialog()
username = settings.getSetting('username')
password = settings.getSetting('password')
url = 'http://www.lexdan.co/login-2/'
values = {'log':username, 'pwd':password, 'wp-submit':'Fazer login'}
data = urllib.urlencode(values)
data = data.encode('utf-8')
req = urllib2.Request(url, data)
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
resp = opener.open(req)
respData = resp.read()
x = resp.geturl()
if x== 'http://www.lexdan.co/login-2/': 
	dialog.ok('LEXDAN LOGGIN', '[COLOR=green][COLOR=red]VC NAO ESTA LOGADO!!!!!!![/COLOR][COLOR=blue]"CLIQUE OK"[/COLOR] E VC SERA DIRECIONADO PARA [COLOR=blue]"CONFIGURACOES"[/COLOR] COLOQUE SEU [COLOR=blue]"USUARIO"[/COLOR] E SUA [COLOR=blue]"SENHA"[/COLOR] O REGISTRO NO SITE LEXDAN E GRATUITO VISITE[/COLOR]  [COLOR=red]WWW.LEXDAN.CO[/COLOR]')
	xbmcaddon.Addon('plugin.video.Lexdan_Filmes').openSettings()
	exit()
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

def lexdan_open(url):
	headers = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36'}
	lexdan1 = requests.get(url,headers=headers)
	lexdan2 = lexdan1.text
	lexdan1.close
	return lexdan2
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

def get_params(): 
	param=[] 
	paramstring=sys.argv[2] 
	if len(paramstring)>=2: 
			params=sys.argv[2] 
			cleanedparams=params.replace('?','') 
			if (params[len(params)-1]=='/'): 
					params=params[0:len(params)-2] 
			pairsofparams=cleanedparams.split('&') 
			param={} 
			for i in range(len(pairsofparams)): 
					splitparams={} 
					splitparams=pairsofparams[i].split('=') 
					if (len(splitparams))==2: 
							param[splitparams[0]]=splitparams[1] 
							 
	print "input,output",paramstring,param 
	return param 
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def addDir(name,url,mode,iconimage,page=0):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&page="+str(page) 
	ok=True 
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage) 
	liz.setInfo( type="Video", infoLabels={ "Title": name } ) 
	ok=xbmcplugin.addDirectoryItem(handle=lexdan_handle,url=u,listitem=liz,isFolder=True) 
	return ok 
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
def addLink(name,url,mode,iconimage): 
	u=_pluginName+"?url="+urllib.quote_plus(url)+"&mode="+str(mode) 
	ok=True 
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage) 
	liz.setInfo( type="Video", infoLabels={ "Title": name } ) 
	liz.setProperty("IsPlayable","true"); 
	ok=xbmcplugin.addDirectoryItem(handle=lexdan_handle,url=u,listitem=liz,isFolder=False) 
	return ok

#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def Menu():
	addDir('[COLOR aqua][I][B]COLECOES[/B][/I][/COLOR]','http://www.lexdan.co/Lexdan_Filmes/category/colecoes/',9,'http://www.lexdan.co/Lexdan_Filmes/wp-content/uploads/2017/01/robot-21.jpg',1)
	addDir('[COLOR yellow][I][B]CATEGORIAS[/B][/I][/COLOR]','http://www.lexdan.co/Lexdan_Filmes/',2,'http://www.lexdan.co/Lexdan_Filmes/wp-content/uploads/2016/12/robot11.jpg',1)
	addDir('[COLOR blue][I][B]LANCAMENTOS[/B][/I][/COLOR]','http://www.lexdan.co/Lexdan_Filmes/category/lancamentos/',4,'http://www.lexdan.co/Lexdan_Filmes/wp-content/uploads/2016/12/robot31.jpg',1)
	addDir('[COLOR green][I][B]SERIES[/B][/I][/COLOR]','http://www.lexdan.co/Lexdan_Filmes/series/',11,'http://www.lexdan.co/Lexdan_Filmes/wp-content/uploads/2017/01/robot-img1.jpg',1)
	addDir('[COLOR lime][I][B]ANIMES E DESENHOS[/B][/I][/COLOR]','http://www.lexdan.co/Lexdan_Filmes/animes-e-desenhos/',14,'http://www.lexdan.co/Lexdan_Filmes/wp-content/uploads/2017/01/2e9dab4bbf0696103e6b807cd709477f.jpg',1)
	addDir('[COLOR chocolate][I][B]BUSCA[/B][/I][/COLOR]','http://www.lexdan.co/Lexdan_Filmes',5,'http://www.lexdan.co/Lexdan_Filmes/wp-content/uploads/2016/12/robotbusca.jpg',1)
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def series():
	joao = lexdan_open('http://www.lexdan.co/Lexdan_Filmes/series/')
	alex = re.compile('<a href="(.+?)"><img class=".+?" src="(.+?)" alt="" width=".+?" height=".+?" /></a>').findall(joao)
	for dan in alex:
		name = dan[0].replace('http://www.lexdan.co/Lexdan_Filmes/uncategorized/','').replace('/','')
		url = dan[0]
		imagem = dan[1]
		addDir('[COLOR green]%s[/COLOR]'%name.upper().replace('-',' '),url,12,imagem,1)
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def animes():
	joao = lexdan_open('http://www.lexdan.co/Lexdan_Filmes/animes-e-desenhos/')
	alex = re.compile('<a href="(.+?)"><img class=".+?" src="(.+?)" alt="" width=".+?" height=".+?" /></a>').findall(joao)
	for dan in alex:
		name = dan[0].replace('http://www.lexdan.co/Lexdan_Filmes/uncategorized/','').replace('/','')
		url = dan[0]
		imagem = dan[1]
		addDir('[COLOR lime]%s[/COLOR]'%name.upper().replace('-',' '),url,15,imagem,1)
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

def colecoes():
	conteudo = lexdan_open(ulr_principal)
	resultado = re.compile('<a href="(.+?)"><span class="screen-reader-text">(.+?)</span></a></li>').findall(conteudo)
	r = resultado[1:-14]
	for url, name in r:
		addDir('[COLOR aqua]%s[/COLOR]'%name.encode('utf8'),url,3,'',1)
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def Categorias():
	conteudo = lexdan_open(ulr_principal)
	resultado = re.compile('<a href="(.+?)"><span class="screen-reader-text">(.+?)</span></a></li>').findall(conteudo)
	r = resultado[25:-2]
	for url, name in r:
		addDir('[COLOR yellow]%s[/COLOR]'%name.encode('utf8'),url,3,'',1)
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def busca():
	dialog = xbmcgui.Dialog()
	d = dialog.input('Nome do Filme:', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.PASSWORD_VERIFY)
	url1='http://www.lexdan.co/Lexdan_Filmes/?s='+ d
	conteudo = lexdan_open(url1)
	match = re.compile('<a href="(.+?)" title="(.+?)"><img width=".+?" height=".+?" src="(.+?)"').findall(conteudo)
	for url,name,image in match:
		if 'uncategorized' in url:
			addDir('[COLOR chocolate]%s[/COLOR]'%name.encode('utf8'),url,15,image.encode('utf8'))
		else:
			addDir('[COLOR chocolate]%s[/COLOR]'%name.encode('utf8'),url,6,image.encode('utf8'))
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def pegar_series(name,url):
	joao = lexdan_open(url)
	if '<h1 style=' in joao:
		alex = re.compile('<h1 style="text-align: center;"><a href="(.+?)">').findall(joao)
		dan = re.compile('<p><a href="(.+?)">(.+?)</a></p>').findall(joao)
	else:
		alex = re.compile('<p style="text-align: center;"><a href="(.+?)">').findall(joao)
		dan = re.compile('<p><a href="(.+?)">(.+?)</a></p>').findall(joao)

	for item in dan:
		url = item[0]
		name = item[1]
		for imagem in alex:
			addDir('[COLOR blue]%s[/COLOR]'%name.encode('utf8'),url,13,imagem)
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def pegar_animes(name,url):
	joao = lexdan_open(url)
	if '<h1 style=' in joao:
		alex = re.compile('<h1 style="text-align: center;"><a href="(.+?)">').findall(joao)
		dan = re.compile('<p><a href="(.+?)">(.+?)</a></p>').findall(joao)
	else:
		alex = re.compile('<p style="text-align: center;"><a href="(.+?)">').findall(joao)
		dan = re.compile('<p><a href="(.+?)">(.+?)</a></p>').findall(joao)

	for item in dan:
		url = item[0]
		name = item[1]
		for imagem in alex:
			addDir('[COLOR blue]%s[/COLOR]'%name.encode('utf8'),url,16,imagem)
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def pegar_filmes(name,mainurl,page):
	if page == 1:
		url_lexdan = mainurl
	else:
		url_lexdan = mainurl+'page/%s/'%page
	conteudo = lexdan_open(url_lexdan)
	resultado = re.compile('<a href="(.+?)" title="(.+?)"><img width=".+?" height=".+?" src="(.+?)"').findall(conteudo)
	if resultado:
		for url,name,imagem in resultado:
			addDir('[COLOR blue]%s[/COLOR]'%name.encode('utf8'),url,6,imagem.encode('utf8'))
		addDir('[COLOR green]Seguinte[/COLOR]',mainurl,3,'http://www.lexdan.co/Lexdan_Filmes/wp-content/uploads/2016/12/Seguinte-botao-1.png',page+1)
	else:
		if name == '[COLOR green]Seguinte[/COLOR]':
			addDir('ACABOU OS FILMES',mainurl,'','')
		else:
			addDir('SEM LINK',mainurl,'','')
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def Lancamentos():
	url1 = 'http://www.lexdan.co/Lexdan_Filmes/category/lancamentos/'
	if page==1:
		url_page=url1
	else:
		url_page=url1+'page/%s/'%page
	conteudo = lexdan_open(url_page)
	match = re.compile('<a href="(.+?)" title="(.+?)"><img width=".+?" height=".+?" src="(.+?)"').findall(conteudo)
	if match:
		for url, name, image in match:
			addDir('[COLOR blue]%s[/COLOR]'%name.encode('utf8'),url,6,image.encode('utf8'))
		addDir('[COLOR green]Seguinte[/COLOR]',url1,3,'http://www.lexdan.co/Lexdan_Filmes/wp-content/uploads/2016/12/Seguinte-botao-1.png',page+1)
	else:
		if name == '[COLOR green][B]Seguinte[/B][/COLOR]':
			addDir('ACABOU OS FILMES ',url1,'','')
		else:
			addDir('sem link',url1,'','')
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def play_series(name,url):
	addLink('[COLOR green]%s[/COLOR]'%name,url,10,'')
	# if 'blogger'in url:
	#   addLink('[COLOR blue][B]%s[/B][/COLOR]'%name,url,8,'')


	xbmcplugin.endOfDirectory(lexdan_handle) 
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def play_animes(name,url):
	addLink('[COLOR blue]%s[/COLOR]'%name,url,8,'')
	addLink('[COLOR green]%s[/COLOR]'%name,url,10,'')
	
	xbmcplugin.endOfDirectory(lexdan_handle) 


	
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

def lexdan_page(name,url):
	conteudo = lexdan_open(url)
	
	lexdan = re.compile('<p style="text-align: left;"><a href="(.+?)">(.+?)</a></p>').findall(conteudo)
	alex = re.compile('<img class=".+?" src="(.+?)" alt=".+?"').findall(conteudo)

	for item in lexdan:
		dan = item[0]
		joao = item[1]
		for image in alex:
			addLink('[COLOR yellow]%s[/COLOR]'%joao,dan,10,image) 

#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def player(url):
	import urlresolver 
	 
	stream_link = urlresolver.resolve(url) 
	print "stream_link",stream_link 
	if stream_link is None: 
			return 
	listItem = xbmcgui.ListItem(path=str(stream_link)) 
	xbmcplugin.setResolvedUrl(lexdan_handle, True, listItem)     

#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
def playLink(url):
	listItem = xbmcgui.ListItem(path=str(url)) 
	xbmcplugin.setResolvedUrl(lexdan_handle, True, listItem) 
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX




params=get_params() 
url=None 
name=None 
mode=None 
page=1 

	 
try: 
		url=urllib.unquote_plus(params["url"]) 
except: 
		pass 
try: 
		name=urllib.unquote_plus(params["name"]) 
except: 
		pass 
try: 
		mode=int(params["mode"]) 
except: 
		pass 
try: 
		page=int(params["page"]) 
except: 
		pass 
# print "Mode: "+str(mode) 
# print "URL: "+str(url) 
# print "Name: "+str(name) 
# print "page: "+str(page) 

#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

if mode==None or url==None or len(url)<1:
	Menu()
		
elif mode==2:
	Categorias()
	 
elif mode==3:
	pegar_filmes(name,url,page)
		 
elif mode==4:
	Lancamentos()

elif mode==5:
	busca()
elif mode==6:
	lexdan_page(name,url)  
elif mode==8:
	playLink(url)
elif mode==9:
	colecoes()  
elif mode==10:
	player(url)
elif mode==11:
	series()
elif mode==12:
	pegar_series(name,url)
elif mode==13:
	play_series(name,url)
elif mode==14:
	animes()
elif mode==15:
	pegar_animes(name,url)
elif mode==16:
	play_animes(name,url)
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
xbmcplugin.endOfDirectory(lexdan_handle)    