# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/MarcioCandido06 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

from addon.common.addon import Addon

addonID = 'plugin.video.Mr.Wil info Kodi Center'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
base    = 'plugin://plugin.video.youtube/'

icon1 = 'https://yt3.ggpht.com/-RpCxMtYziHc/AAAAAAAAAAI/AAAAAAAAAAA/Vg2Jm6qdxdw/s100-c-k-no-rj-c0xffffff/photo.jpg'
icon2 ='https://yt3.ggpht.com/-FnYm5rtbMrg/AAAAAAAAAAI/AAAAAAAAAAA/t1MH477brhM/s100-c-k-no-rj-c0xffffff/photo.jpg'


def run():
    plugintools.log("CineTube.run")
    
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def main_list(params):
		plugintools.log("Cene Tube===> " + repr(params))

		plugintools.add_item(title = "Mr. Wil Info Kodi Center"                  , url = base + "channel/UCy-4KL5pfEYena_FDWPHmxA/"          , thumbnail = icon1, folder = True)
		plugintools.add_item(title = "Mister Wil Informática"                    , url = base + "channel/UCWRmHse3qh_i-1rz8JaY6_A/"          , thumbnail = icon2, folder = True)
		
		
		
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmc.executebuiltin('Container.SetViewMode(500)')
		
run()