# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/MarcioCandido06 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

from addon.common.addon import Addon

addonID = 'plugin.video.CineTube'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
base    = 'plugin://plugin.video.youtube/'

icon1 = 'http://www.somdaharpa.com.br/wp-content/uploads/2015/05/Gospel.png'
icon2 ='http://4.bp.blogspot.com/-_ujclrJBpSw/VdfX3dia3jI/AAAAAAAAAAg/cJDIjrdY1qw/s1600/TPFILMES.png'
icon3 = 'https://i.ytimg.com/vi/UKe-64QGp9E/maxresdefault.jpg'
icon4 = 'http://filmeshd.info/wp-content/uploads/2016/02/filmesHD.png'
icon5 = 'https://scontent-gru2-1.xx.fbcdn.net/v/t1.0-9/563664_531098736968107_606629043_n.png?oh=3640e102fd68b31b580db52ce0b30a30&oe=57E53A4D'
icon6 = 'https://yt3.ggpht.com/-QoEoA5ZncnY/AAAAAAAAAAI/AAAAAAAAAAA/1HJigho4loA/s100-c-k-no-rj-c0xffffff/photo.jpg'
icon7 = 'https://yt3.ggpht.com/--wrAytLXknk/AAAAAAAAAAI/AAAAAAAAAAA/m_EwEA0DyUs/s100-c-k-no-rj-c0xffffff/photo.jpg'
icon8 = 'http://www.tpai.tv/img/programas/CINE_TV.png'
icon9 = 'http://www.cinematv.in/usr/local/csp/staticContent/cinema_tv/scheduleImages/logo.png'
icon0 = 'http://icons.iconarchive.com/icons/trayse101/basic-filetypes-2/128/playlist-icon.png'
icon  = 'https://image.freepik.com/free-vector/retro-neon-sign_23-2147501855.jpg'
icon = 'https://image.freepik.com/free-vector/retro-neon-sign_23-2147501855.jpg'


def run():
    plugintools.log("CineTube.run")
    
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def main_list(params):
		plugintools.log("Cene Tube===> " + repr(params))

		plugintools.add_item(title = "Filmes Gospel"           , url = base + "playlist/PLi4rqAfRMrrNoSEKrD5XQMInRa7hXthkS/"          , thumbnail = icon1, folder = True)
		plugintools.add_item(title = "Top Filmes"                    , url = base + "playlist/PLi4rqAfRMrrNlNLTYxSmqH7LWsDP-CYIM/", thumbnail = icon2, folder = True)
		plugintools.add_item(title = "Filmes adolescentes"           , url = base + "channel/UCBcS3YNmFnuvferr6-bwlJg/", thumbnail = icon3, folder = True)
		plugintools.add_item(title = "Filmes HD"               , url = base + "channel/UCbO3S9VLQmq6TvBkvred3kA/", thumbnail = icon4, folder = True)
		plugintools.add_item(title = "Cine pix"                      , url = base + "playlist/PL32D7B0774051D748/"     , thumbnail = icon5, folder = True)
		plugintools.add_item(title = "Trash Filmes"                  , url = base + "channel/UCJNetjL6Zi9cI42lL1yGDAw/", thumbnail = icon6, folder = True)
		plugintools.add_item(title = "Ten Filmes"                    , url = base + "playlist/PLWyD8c16D1CPcPkmuoZHB0N5k6YjBDfzt/", thumbnail = icon7, folder = True)
		plugintools.add_item(title = "CINE TV"                       , url = base + "channel/UCkQs99O6tiDkp0w17-gcdZQ/", thumbnail = icon8, folder = True)
		plugintools.add_item(title = "Cinema Tv"                   , url = base + "channel/UCP0mEwFuXfKGDnlDiNPmFVA/", thumbnail = icon9, folder = True)
		plugintools.add_item(title = "Varios Generos"                , url = base + "playlist/PLsbNlAbfmD-F5az31iYL_h0mHnqR0_0As/", thumbnail = icon0, folder = True)
		plugintools.add_item(title = "Retro"                         ,url = base + "user/vladuarte/", thumbnail = icon, folder = True)
		
		
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmc.executebuiltin('Container.SetViewMode(500)')
		
run()