#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# @file record_live_streams.py
# @author cleiton.leonel@gmail.com
# @recording video in Python.

'''
    MasterSoftware
    Copyright (C) 2017 MasterSoftware

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib,urllib2,time,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys,base64,requests
from datetime import datetime,date,timedelta

addon_id = 'Cineplay.tv Premium'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
folder = selfAddon.getSetting('record_live')
icon = addonfolder + '/icon.png'
msg = 'Gravando agora'
seconds = 10000

def recording(url,tempo):
    print "Recording video..."
    print url	
    xbmcgui.Dialog().notification(addon_id, msg, time=seconds, icon=icon)
    response = urllib2.urlopen(url)
    filename = time.strftime("%Y%m%d%H%M%S", time.localtime())
    path = folder#addonfolder
    lib = os.path.join(path, filename+'.mp4')
    f = open(lib, 'wb')

    block_size = 1024
    duration = int(tempo) * 60
    print duration	

    start = datetime.now()
    end = start + timedelta(seconds=duration)

    while datetime.now() < end:
        try:
            buffer = response.read(block_size)
            if not buffer:
                xbmcgui.Dialog().notification(addon_id, 'Gravação finalisada!!!', time=10000, icon=icon)			
                break

            f.write(buffer)

        except:
            pass 

    f.close()