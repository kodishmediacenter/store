﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
############################################################################################################
#                                     BIBLIOTECAS A IMPORTAR E DEFINIÇÕES                                  #
############################################################################################################

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,HTMLParser,os,sys,base64,time,json,simplejson,requests
import xml.etree.ElementTree as ElementTree
import json as simplejson
from datetime import datetime,date,timedelta
from time import localtime,strftime
from record_live_streams import recording

versao = '0.0.3'
addon_id = 'Cineplay.tv Premium'
selfAddon = xbmcaddon.Addon(id=addon_id)
setting = xbmcaddon.Addon().getSetting
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
fanart = addonfolder + '/fanart.jpg'
icon = addonfolder + '/icon.png'
username = selfAddon.getSetting('username')
password = selfAddon.getSetting('password')
parental = selfAddon.getSetting('control-parental')
folder = selfAddon.getSetting('record_live')
server = 'http://painel.tvdigitalsbl.net:8081/'	
m3u_regex = '^#EXTINF:-1 tvg-ID=".*?" tvg-name=".*?" tvg-logo="(.*?)" group-title=".*?",(.*?)\n(.*?)$'#EXTINF:-1 tvg-ID=".*?" tvg-name=".*?" tvg-logo="(.*?)" group-title=".*?",(.*?)\n(.*?)$'^#EXTINF:.*?tvg-logo="(.*?)",(.*?)\n(.*?)$'
tv_sbl = '%senigma2.php?username=%s&password=%s&type=get_live_categories'%(server,username,password)
ondemand_sbl = '%senigma2.php?username=%s&password=%s&type=get_vod_categories'%(server,username,password)
get_tv = '%splayer_api.php?username=%s&password=%s'%(server,username,password)
get_link = '%sget.php?username=%s&password=%s&type=m3u_plus&output=ts'%(server,username,password)
menu_principal = '%spanel_api.php?mode=live&username=%s&password=%s'%(server,username,password)
rec_epg = '%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id='%(server,username,password)
cat_regex = "<title>(.*?)</title><description>(.*?)</description><category_id>(.*?)</category_id><playlist_url>(.*?)</playlist_url>"
txt_regex = '(.*?),(.*?),\s*'
#m3u_regex = '#(.+?),(.+)\s*(.+)\s*'
#m3u_regex2 = '#(.+?),(.+)\s*#.+\s*(.+)\s*'
#m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
#m3u_group_regex = 'group-title=[\'"](.*?)[\'"]'

msg = 'Gravando agora'
seconds = 100000

if username == '' or password == '':
	xbmcgui.Dialog().ok(addon_id,'Se possui conta conosco insira os dados nas configurações...')
	selfAddon.openSettings()
	sys.exit(0)
else:
	pass
	try:
		req = urllib2.Request(get_link)
		req.add_header('User-Agent', 'Googlebot/2.1 (+http://www.googlebot.com/bot.html)')
		response = urllib2.urlopen(req)	  
		get_link = response.read()
		response.close()
	except urllib2.URLError, e:	
	    xbmcgui.Dialog().ok(addon_id,'Usuário ou senha inválido,tente novamente com um login diferente...')
	    selfAddon.openSettings()
	    sys.exit(0)
	
############################################################################################################
#                                                  MENUS                                                   #
############################################################################################################

def listar_menu(url,description):
	print 'SOU DESC '+str(description)
	link = abrir_url(url)
	match = re.compile(cat_regex ).findall(link)
	for title,desc,cat,url in match:
		title = dec_64(title)
		print title		
		desc = dec_64(desc)
		url = url.replace("<![CDATA[","").replace("]","").replace(">","")
		if description == 'Canais Brasileiros':
		    if 'TV ABERTA' == title or 'NOTICIAS' == title or 'VARIEDADES' == title or 'INFANTIL' == title or 'DOCUMENTARIOS' == title or 'ESPORTES' == title or 'FILMES' == title or 'SERIES' == title:
		        iconimage = list_img(title)			
		        addDir('[COLOR white]'+title+'[/COLOR]',url,4,iconimage,fanart,'','','','')
		elif description == 'Canais Internacionais':
		    if 'CANAIS PORTUGAL' == title or 'CANAIS USA' == title or 'CANAIS CANADA' == title or 'CANAIS ITALIA' == title:
		        print 'SOU DESC '+str(title)			    
		        iconimage = list_img(title)
		        addDir('[COLOR white]'+title+'[/COLOR]',url,4,iconimage,fanart,'','','','')				
		elif description == 'Filmes HD':
		    print title	
		    if 'All' == title:
		        print 'SOU DESC '+str(url)			
		        listar_canais(url)				
		elif description == 'Rádios':
		    if 'RADIOS' == title:		
		        listar_canais(url)				
		elif description == 'Adultos':
		    if 'ADULTOS' == title:		
		        listar_canais(url)		

def listar_canais(url):
    request = urllib2.Request(url, headers={"Accept" : "application/xml"})
    u = urllib2.urlopen(request)
    print str(u)	
    tree = ElementTree.parse(u)
    print str(tree)	
    rootElem = tree.getroot()
    for channel in tree.findall("channel"):
        title = channel.find("title").text		
        title = dec_64(title)		
        title = title.partition("[")		
        link = channel.find("stream_url").text		
        img = channel.find("desc_image").text		
        titulo = title[1]+title[2]		
        titulo = titulo.partition("]")		
        titulo = titulo[2]		
        titulo = titulo.partition("   ")		
        titulo = titulo[2]		
        title = ("[COLOR white]%s [/COLOR]")%(title[0])+ '[COLOR green]' + str(titulo) + '[/COLOR]'
        description = channel.find("description").text
        if description:
            description = dec_64(description)
            description = description.partition("(")
            description = ("NOW:") + description[0]
            desc = description.partition(")\n")
            desc = desc[2].partition("(")
            desc = ("NEXT:") + description[0]
            description = description+desc
        else:
            description = ""
        if img:
            addDir2(title,link,3,img,fanart,description,'','','',False)
            setViewFilmes()		   
        else:
            addDir2(title,link,3,'img',fanart,description,'','','',False)		
            setViewFilmes()
		   
def dec_64(enc):
	dec = base64.b64decode(enc)
	return dec

def list_img(title):
    if 'TV ABERTA' == title:
        img = artfolder + 'tv.png'
        return img
    elif 'NOTICIAS' == title:
        img = artfolder + 'noticias.png'
        return img
    elif 'VARIEDADES' == title:
        img = artfolder + 'variedades.png'
        return img
    elif 'INFANTIL' == title:
        img = artfolder + 'desenhos.png'
        return img
    elif 'DOCUMENTARIOS' == title:
        img = artfolder + 'documentarios.png'
        return img
    elif 'ESPORTES' == title:
        img = artfolder + 'esportes.png'
        return img
    elif 'FILMES' == title:
        img = artfolder + 'filmes.png'
        return img
    elif 'SERIES' == title:
        img = artfolder + 'series.png'
        return img
    elif 'CANAIS PORTUGAL' == title:
        img = artfolder + 'portugal.jpg'
        return img
    elif 'CANAIS ITALIA' == title:
        img = artfolder + 'italia.jpg'
        return img
    elif 'CANAIS CANADA' == title:
        img = artfolder + 'canada.jpg'
        return img
    elif 'CANAIS USA' == title:
        img = artfolder + 'usa.jpg'
        return img		

############################################################################################################
#                                                  SUBMENU                                                 #
############################################################################################################

def menu():
    addDir('[B]Canais Brasileiros[/B]',tv_sbl,2,artfolder + 'brasil.jpg',fanart,'Canais Brasileiros','','','')	
    addDir('[B]Canais Internacionais[/B]',tv_sbl,2,artfolder + 'internacional.jpg',fanart,'Canais Internacionais','','','')
    addDir('[B]Filmes HD[/B]',ondemand_sbl,2,artfolder + 'movie.jpg',fanart,'Filmes HD','','','')
    addDir('[B]Adultos[/B]',tv_sbl,5,artfolder + 'xxx.png',fanart,'Adultos','','','')	
    addDir('[B]Rádios[/B]',tv_sbl,2,artfolder + 'radios.jpg',fanart,'Rádios','','','')
    addDir('[B]Playback[/B]','-',7,artfolder + 'playback.jpg',fanart,'Playback','','','')
    addDir('[B]Gravação Agendada[/B]',menu_principal,10,artfolder + 'record.jpg',fanart,'Gravação Agendada','','','')	
    addDir('[B]Minha Conta[/B]',get_tv,6,artfolder + 'account.jpg',fanart,'Minha Conta','','','')	
    setViewFilmes()	
	
def player(name,url,iconimage):
	print name	
	if 'RADIO' in name or 'Radio' in name or 'radio' in name or 'FM' in name or 'AM' in name:
		print url		
		xbmcPlayer = xbmc.Player()
		xbmcPlayer.play(url)		
	else:
	    pass	
	    print url
	    stype = ''
	    if '.ts' in url:
	        stype = 'TSDOWNLOADER'
	    elif '.m3u' in url:
	        stype = 'HLS'
	    if stype:
		    from F4mProxy import F4mProxy
		    f4mp = F4mProxy.f4mProxyHelper()
		    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
		    f4mp.playF4mLink(url,name,proxy=None,use_proxy_for_chunks=False, maxbitrate=0, simpleDownloader=False, auth=None, streamtype=stype,setResolved=False,swf=None , callbackpath="",callbackparam="", iconImage=iconimage)
		    return	
        #url = 'plugin://plugin.video.f4mTester/?url='+url+'&amp;streamtype=TSDOWNLOADER&amp;name='+name+'&amp;iconImage='+iconimage
	    playlist = xbmc.PlayList(1)
	    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	    playlist.clear()
	    len = playlist.size()
	    posn = playlist.getposition()
	    next = posn+1	
	    try:
		    listitem = xbmcgui.ListItem(name,thumbnailImage=iconimage)
		    listitem.setInfo("Video", {"Title":name.replace('Assistir o Filme: ','')})
		    listitem.setProperty('mimetype', 'video/mp4')
		    playlist.add(url,listitem)
		    xbmcPlayer = xbmc.Player()
		    xbmcPlayer.play(playlist)		
	    except:
	        pass	

def listar_dados(url,iconimage):
	print 'URL : ' + url
	r = requests.get(url)
	#data = json.loads(r.content)
	data = simplejson.loads(r.content)
	#data = r.json()	
	print data
 	data = data['user_info']
	user = data['username']
	print user
	status = data['status']
	print status
	timestamp = data['exp_date']	
	value = datetime.fromtimestamp(float(timestamp))
	expire = value.strftime('%Y-%m-%d %H:%M:%S')	
	print expire
	max_conection = data['max_connections']
	print max_conection
	signature = data['is_trial']
	print signature
	if signature == '1':
	    addLink('Lista Teste','',artfolder + 'teste.png')
	else:
	    addLink('Lista Premium','',artfolder + 'premium.png')
	addLink('Usuário: ' + str(user),'',artfolder + 'usuario.png')
	addLink('Status: ' + status,'',artfolder + 'status.png')
	addLink('Expira em: ' + expire,'',artfolder + 'expira.png')
	addLink('Conexões Permitidas: ' + str(max_conection),'',artfolder + 'conexoes.png')

def playback_tv():
    url = menu_principal
    #print 'URL : ' + url
    json_ = abrir_url(url)
    data = re.compile(r'name":"(.*?)",.*?"stream_id":"(.*?)","stream_icon":"(.*?)".*?,"live":"1".*?,"tv_archive":(.*?),').findall(json_)	
    #print data
    for name,stream_id,stream_icon,tv_archive in data:
        title = name.encode('utf-8')		
        id = stream_id
        iconimage = stream_icon.replace('\/','/')
        rec = tv_archive
        if rec == '1':
            #print title
            addDir(title,rec_epg,8,iconimage,fanart,title,'','',id)			

def resolve_rec_tv(name,url,iconimage,nota):
    id_stream = nota
    now = datetime.now()
    print 'SOU NOW : ' + str(now)	
    day = str(now).split(".")
    today = day[0]
    print today
    now_day = now - timedelta(hours=2)
    delta = str(now_day).split(".")
    day_now = delta[0]
    print 'SOU DAY_NOW : ' + str(day_now)	
    temp = now - timedelta(hours=24)
    print 'SOU TEMPO : ' + str(temp)
    delta = str(temp).split(".")
    start_day = delta[0]
    print 'SOU START_DAY : ' + str(start_day)
    url = url + str(id_stream)
    print url
    r = requests.get(url)
    #data = json.loads(r.content)
    data = simplejson.loads(r.content)
    #data = r.json()	
    #print data
    data = data['epg_listings']
    print data		
    for s in data:
        title = s['title']
        title = dec_64(title)			
        print title
        start = s['start']
        print start
        day_start = start.replace(':','-').replace(' ',':')
        print day_start			
        if start <= str(day_now) and start >= str(start_day):
            print 'SOU START : ' + start
            print 'SOU TITLE : ' + title
            rec_tv = '%sstreaming/timeshift.php?username=%s&password=%s&stream=%s&start=%s&duration=120'%(server,username,password,id_stream,day_start)
            print 'SOU REC_TV : ' + rec_tv
            addDir(title+' '+start.encode('utf-8'),rec_tv,3,iconimage,fanart,title+' '+start.encode('utf-8'),'','','',False)	
            setViewFilmes()
    	
def controle_dos_pais(url,description):
    chave = parental
    senha = xbmcgui.Dialog().numeric(0, 'Digite a senha')
    if senha == chave:
        listar_menu(url,description)	
    else:
        dialog = xbmcgui.Dialog()
        dialog.notification('ERROR', 'Conteúdo bloqueado', xbmcgui.NOTIFICATION_ERROR, 5000)
        return menu()	

def gravando(name,url,iconimage):
    tempo = xbmcgui.Dialog().numeric(0, ' Quantos minutos deseja capturar ? ')		
    recording(url,str(tempo))   

def prog_all(url):
    url = menu_principal
    json_ = abrir_url(url)
    data = re.compile(r'name":"(.*?)",.*?,"type_name":"Live Streams","stream_id":"(.*?)","stream_icon":"(.*?)".*?,"live":"1".*?,"tv_archive":.*?,').findall(json_)	
    for name,stream_id,stream_icon in data:
        title = name.encode('utf-8')		
        id = stream_id
        iconimage = stream_icon.replace('\/','/')
        if '#' not in title and title not in username:		
            addDir(title,rec_epg,11,iconimage,fanart,title,'','',id)
	
def prog_channel(name,url,iconimage,nota):
    id_stream = nota
    now = datetime.now()	
    day = str(now).split(".")
    today = day[0]
    _day = now + timedelta(hours=12)
    delta = str(_day).split(".")
    day_tomorrow = delta[0]
    url = url + str(id_stream)	
    r = requests.get(url)
    data = simplejson.loads(r.content)
    data = data['epg_listings']		
    for s in data:
        title = s['title']
        title = dec_64(title)
        start = s['start']
        end = s['end']		
        if start >= str(today) and start <= str(day_tomorrow):		
            url_tv = '%slive/%s/%s/%s.ts'%(server,username,password,id_stream)
            addDir2(title+' - [COLOR lime]Start[/COLOR] '+str(start)+' - [COLOR red]End[/COLOR] '+str(end),url_tv,12,iconimage,fanart,title,'','',start+','+end,False)

def rec_prog_channel(name,url,iconimage,nota):
    now = datetime.now()	
    day = str(now).split(".")
    today = day[0]	
    titulo = name.split('-')
    titulo = titulo[0]
    hora_data = nota.split(',')
    start = hora_data[0]
    end = hora_data[1]
    f = '%Y-%m-%d %H:%M:%S'
    #dif = (datetime.strptime(end, f) - datetime.strptime(start, f)).total_seconds()
    path = folder + '/shedule.rec'
    f = open(path,'w')
    f.write(str(url)+','+str(start)+','+str(end))
    f.close
    xbmcgui.Dialog().notification(addon_id, 'Gravação agendada com sucesso!!!', time=0, icon=icon)
    sys.exit(0)	
    return

def lembrete(nota):
    print nota
    hora_data = nota.split(',')
    start = hora_data[0]
    f = '%Y-%m-%d %H:%M:%S'
    #dif = (datetime.strptime(end, f) - datetime.strptime(start, f)).total_seconds()
    path = folder + '/opa.clc'
    f = open(path,'w')
    f.write(str(start))
    f.close
    xbmcgui.Dialog().notification(addon_id, 'Lembrarei quando começar!!!', time=10000, icon=icon)
    #sys.exit(0)	
    return    	
	
############################################################################################################
#                                                  FUNÇÕES                                                 #
############################################################################################################
	
def abrir_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Googlebot/2.1 (+http://www.googlebot.com/bot.html)')#'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link	
	
def gethtml(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    soup = BeautifulSoup(link)
    return soup
	
def addDir(name,url,mode,iconimage,art,description,year,genre,nota,pasta=True,total=1):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&art="+urllib.quote_plus(art)+ '&description=' + urllib.quote_plus(description)+ '&nota=' + urllib.quote_plus(nota)
	sysaddon = sys.argv[0]
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="iconimage", thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Rating": nota, "Genre": genre, "Year": year})
	liz.setProperty("fanart_image", art)	
	contextMenuItems = []
	contextMenuItems.append(("Movie Information", "XBMC.Action(Info)","RunPlugin(%s?action=addView&content=movies)" % sysaddon))	
	liz.addContextMenuItems(contextMenuItems, replaceItems=False)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok	

def addDir1(name,url,mode,iconimage,pasta=True,total=1,plot=''):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="iconimage", thumbnailImage=iconimage)
    liz.setProperty('fanart_image', fanart)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": plot})
    contextMenuItems = []
    contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
    return ok	

def addDir2(name, url, mode, iconimage, art, description, year, genre, nota, pasta = True, total = 1):
    u = sys.argv[0] + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&iconimage=' + urllib.quote_plus(iconimage) + '&art=' + urllib.quote_plus(art)+ '&nota=' + urllib.quote_plus(nota)
    sysaddon = sys.argv[0]
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='iconimage', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name,'Plot': description,'Rating': nota,'Genre': genre,'Year': year})
    liz.setProperty('fanart_image', art)
    contextMenuItems = []
    contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)', 'RunPlugin(%s?action=addView&content=movies)' % sysaddon))
    if str(mode) == '3':	
        contextMenuItems.append(("[COLOR lime]Gravar[/COLOR]",'XBMC.RunPlugin(%s?name=name%s&url=%s&mode=9&iconimage=iconimage%s)'%(sys.argv[0], urllib.quote(name), url, urllib.quote(iconimage))))
    if str(mode) == '12':
        contextMenuItems.append(("[COLOR lime]Agendar gravação[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=12&iconimage=%s&nota=%s)'%(sys.argv[0], urllib.quote(name), url, urllib.quote(iconimage), urllib.quote(nota))))		
    if str(mode) == '12':
        contextMenuItems.append(("[COLOR lime]Avisar quando começar[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=13&iconimage=%s&nota=%s)'%(sys.argv[0], urllib.quote(name), url, urllib.quote(iconimage), urllib.quote(nota))))	
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=pasta, totalItems=total)
    return ok	
	
def addLink(name,url,iconimage):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok

def ReadFile(fileName):
	f = open(fileName,'r')
	content = f.read().replace("\n\n", "\n")
	f.close()
	return content
	
def config():
		selfAddon.openSettings()
		setViewMenu()
		sys.exit(0)
		xbmcplugin.endOfDirectory(int(sys.argv[1]))

def setViewMenu():
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
		opcao = selfAddon.getSetting('menuVisu')
		if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
		elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
		elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")

def setViewFilmes():
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		opcao = selfAddon.getSetting('filmesVisu')
		if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
		elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
		elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")
		elif opcao == '3': xbmc.executebuiltin("Container.SetViewMode(501)")
		elif opcao == '4': xbmc.executebuiltin("Container.SetViewMode(508)")
		elif opcao == '5': xbmc.executebuiltin("Container.SetViewMode(504)")
		elif opcao == '6': xbmc.executebuiltin("Container.SetViewMode(503)")
		elif opcao == '7': xbmc.executebuiltin("Container.SetViewMode(515)")
		
def make_request(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Googlebot/2.1 (+http://www.googlebot.com/bot.html)')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason		
	
############################################################################################################
#                                             MAIS PARÂMETROS                                              #
############################################################################################################
              
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]                                
        return param
      
params = get_params()
url = None
name = None
mode = None
iconimage = None
art = None
description = None
year = None
nota = None
genre = None

try:
    url = urllib.unquote_plus(params['url'])
except:
    pass

try:
    name = urllib.unquote_plus(params['name'])
except:
    pass

try:
    mode = int(params['mode'])
except:
    pass

try:
    iconimage = urllib.unquote_plus(params['iconimage'])
except:
    pass

try:
    art = urllib.unquote_plus(params['art'])
except:
    pass

try:
    description = urllib.unquote_plus(params['description'])
except:
    pass

try:
    year = urllib.unquote_plus(params['year'])
except:
    pass

try:
    nota = urllib.unquote_plus(params['nota'])
except:
    pass

try:
    genre = urllib.unquote_plus(params['genre'])
except:
    pass

print 'Mode: ' + str(mode)
print 'URL: ' + str(url)
print 'Name: ' + str(name)
print 'Iconimage: ' + str(iconimage)
print 'Art: ' + str(art)
print 'Description: ' + str(description)
print 'Year: ' + str(year)
print 'Genre: ' + str(genre)
print 'Nota: ' + str(nota)

###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################

if mode==None or url==None or len(url)<1:
    print ""	
    menu()

elif mode==2:
    print ""	
    listar_menu(url,description)	
	
elif mode==3:
    print ""	
    player(name,url,iconimage)
	
elif mode==4:
    print ""
    listar_canais(url)	

elif mode==5:
    print ""
    controle_dos_pais(url,description)

elif mode ==6:
    print"" 
    listar_dados(url,iconimage)

elif mode ==7:
    print"" 
    playback_tv()

elif mode ==8:
    print"" 
    resolve_rec_tv(name,url,iconimage,nota)

elif mode ==9:
    print"" 
    gravando(name,url,iconimage)

elif mode ==10:
    print"" 
    prog_all(url)

elif mode ==11:
    print"" 
    prog_channel(name,url,iconimage,nota)

elif mode ==12:
    print"" 
    rec_prog_channel(name,url,iconimage,nota)

elif mode ==13:
    print"" 
    lembrete(nota)	

xbmcplugin.endOfDirectory(int(sys.argv[1]))	