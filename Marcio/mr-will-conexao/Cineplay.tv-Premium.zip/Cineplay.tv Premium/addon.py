﻿#!/usr/bin/env python
# coding: utf-8
#
############################################################################################################
#                                     BIBLIOTECAS A IMPORTAR E DEFINIÇÕES                                  #
############################################################################################################

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,HTMLParser,os,sys,base64,codecs,md5,hashlib
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP

version = '0.0.3'
addon_id = 'Cineplay.tv Premium'
selfAddon = xbmcaddon.Addon(id=addon_id)
setting = xbmcaddon.Addon().getSetting
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
fanart = addonfolder + '/fanart.jpg'
addon_xml = addonfolder + '/addon.xml'
#user = selfAddon.getSetting('username')
#password = selfAddon.getSetting('password')
upgrade = selfAddon.getSetting('upgrade')
txt_regex = '(.*?),(.*?),\s*'
server = ''
#msgm = '              Acesso negado,tente novamente mais tarde!!!'

def getSoup():
    data = open(addon_xml)
    return BeautifulSOAP(data, convertEntities=BeautifulStoneSoup.XML_ENTITIES)

def addon_verify():
    soup = getSoup()
    print soup	
    versao = re.compile(r'<addon id=".*?" name=".*?" version="(.*?)" provider-name=".*?">').findall(str(soup))
    print versao
    for ver in versao:
        versao = str(ver)
        return versao		

version_addon = addon_verify()
print 'VERSAO : ' + version_addon	

ADDON_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="Cineplay.tv Premium" name="Cineplay.tv Premium" version="%(version)s" provider-name="MasterSoftware">
    <requires>
        <import addon="xbmc.python" version="2.1.0"/>
    </requires>
    <extension point="xbmc.python.pluginsource" library="main.py">
        <provides>video</provides>
    </extension>
        <extension point="xbmc.addon.metadata">
        <language>en</language>
        <platform>all</platform>
        <summary lang="en">Cineplay.tv Premium</summary>
	    <description lang="en">SEUS CANAIS BRASILEIROS EM HD TUDO EM UM SÓ LUGAR ([COLOR blue]Cineplay.tv Premium[/COLOR])</description>
        <disclaimer lang="en">SEUS CANAIS BRASILEIROS EM HD TUDO EM UM SÓ LUGAR ([COLOR blue]Cineplay.tv Premium[/COLOR])</disclaimer>
	    <website>Cineplay.tv Premium</website>
		<source>Cineplay.tv Premium</source>
		<assets>
			<icon>icon.png</icon>
			<fanart>fanart.jpg</fanart>
			<screenshot>resources/img/screenshot001.png</screenshot>
			<screenshot>resources/img/screenshot003.png</screenshot>
			<screenshot>resources/img/screenshot004.png</screenshot>
		</assets>
		<news>- VERSÃO INICIAL</news>	
    </extension>
</addon>"""

#if user == '' or password == '':
	#xbmcgui.Dialog().ok(addon_id,'Se possui conta conosco insira os dados nas configurações...')
	#selfAddon.openSettings()
	#sys.exit(0)
#else:
    #pass

up = upgrade
print 'UPGRADE:'+ up
#password = md5.new(password).hexdigest()
#print 'Senha hash ' + md5.new(password).hexdigest()
	
############################################################################################################
#                                                  MENUS                                                   #
############################################################################################################

def login():
    for line in urllib2.urlopen('https://docs.google.com/uc?export=download&id=0B4KWNSgTIdibdDNKc0hpMVl3TkU').readlines():
        #print line
        params = line.split(',')
        url_base = params[0]
        home(url_base)		
        version_check(url_base)
	
def home(url_base):
    if setting("upgrade") == '0':
        logado(url_base)
    else:
        try:
            import main
        except:
            pass
            logado()

def logado(url_base):
	req = urllib2.Request(url_base)
	req.add_header('User-Agent', 'Googlebot/2.1 (+http://www.googlebot.com/bot.html)')
	response = urllib2.urlopen(req)
	link = response.read()
	path = addonfolder
	lib = os.path.join(path,'default.py')
	arquivo = open(lib,'wb')
	arquivo.write(link)
	arquivo.close()
	response.close()
	
def version_check(url_base):
    for line in urllib2.urlopen('https://docs.google.com/uc?export=download&id=0B4KWNSgTIdibUm15OEdzSFBZZjA').readlines():
        print line
        match = re.compile(r'version = (.*?),\s*').findall(line)
        print match
        for version_up in match:
            version_up = version_up
            print version_up
            if version_up > version_addon:			
                i = xbmcgui.Dialog().yesno(addon_id,'Nova versão disponível... ( versão ' + version_up + ' ) ' + '\n' + 'Deseja atualizar agora ???')
                print i				
                if i == 1:
                    up_version(version_up)				
                    logado(url_base)
                else:
                    try:
                        import main
                    except:
                        pass
                        logado(url_base)
            else:
                print 'EOFError'			
	
def up_version(version_up):
    addon = ADDON_XML % {
    'version': version_up,}
    path = addonfolder
    lib = os.path.join(path,'addon.xml')
    arquivo = open(lib,'wb')
    arquivo.write(addon)
    arquivo.close()    

############################################################################################################
#                                                  FUNÇÕES                                                 #
############################################################################################################
	
def abrir_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Googlebot/2.1 (+http://www.googlebot.com/bot.html)')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link	
	
############################################################################################################
#                                             MAIS PARÂMETROS                                              #
############################################################################################################
              
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

      
params=get_params()
url=None
name=None
mode=None
iconimage=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass		

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Iconimage: "+str(iconimage)

###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################

if mode==None or url==None or len(url)<1:
    print ""
    login()

try:
    import default
except:
    pass	

xbmcplugin.endOfDirectory(int(sys.argv[1]))