#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# @file Autoexec.py
# @author cleiton.leonel@gmail.com
# @recording video in Python.

'''
    MasterSoftware
    Copyright (C) 2017 MasterSoftware

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os,sys,xbmcplugin,xbmcgui,xbmc,xbmcaddon,glob,time,urllib,urllib2,random
from datetime import datetime,date,timedelta

addon_id = 'Cineplay.tv Premium'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
folder = selfAddon.getSetting('record_live')

icon = addonfolder + '/icon.png'
msg = 'Gravando...'
dir = folder

print 'Loading',

i=0

def verify():
    while (i<1):
        time.sleep(1)
        sys.stdout.write('.')
        sys.stdout.flush()
        now = datetime.now()	
        day = str(now).split(".")
        today = day[0]
        print 'AGORA : ' + str(today)
        now_hour = now + timedelta(minutes=1)
        delta = str(now_hour).split(".")
        prog_ = delta[0]
        print 'AGORA + 1 MIN : ' + str(prog_)
        try:		
            arq = random.choice(glob.glob(dir + '/*.clc'))
            print arq
            file = dir + '/opa.clc'
            for line in open(arq,'r').readlines():
                print line
                line = str(line)
                print line 				
            if line == prog_:
                print 'PROGRAMA COMEÇA : ' + line
                xbmcgui.Dialog().notification(addon_id, 'Seu programa vai começar jájá !!!', time=10000, icon=icon)
        except:
            pass				
        try:	
            arq = random.choice(glob.glob(dir + '/*.rec'))
            file = dir+'/shedule.rec'
            for line in open(arq,'r').readlines():
                a = line.split(',')				
            if line:				
                url_stream = a[0]				
                start = a[1]				
                end = a[2]
            recording(url_stream,start,end)
            if line == '':
                break			
            if not line:				
                break
        except:
            pass		

def recording(url_stream,start,end):
    now = datetime.now()	
    day = str(now).split(".")
    today = day[0]
    if today == start:	
        print "Recording video"
        xbmcgui.Dialog().notification(addon_id, msg, time=10000, icon=icon)		
        response = urllib2.urlopen(url_stream)
        filename = time.strftime("%Y%m%d%H%M%S",time.localtime())+".mp4"
        f = open(dir+filename, 'wb')
        block_size = 1024
        while str(datetime.now()).split('.')[0] < end:
            #print str(datetime.now()).split('.')[0]+' < '+str(end)
            #sys.stdout.write(str(datetime.now()).split('.')[0])+' < '+str(end))
            tempo = str(datetime.now()).split('.')[0]
            sys.stdout.write("\r%s"%tempo)			
            sys.stdout.flush()
            try:
                buffer = response.read(block_size)
                if not buffer:
                    xbmcgui.Dialog().notification(addon_id, 'Gravação finalisada!!!', time=10000, icon=icon)					
                    break
                f.write(buffer)
            except:
                pass
                xbmcgui.Dialog().notification(addon_id, 'Gravação finalisada!!!', time=10000, icon=icon)				
        f.close()				

if __name__ == "__main__":
        verify()