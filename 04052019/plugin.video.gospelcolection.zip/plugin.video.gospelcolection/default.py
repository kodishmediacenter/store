# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------
import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

icon    = "https://yt3.ggpht.com/a-/ACSszfGytKnwmNfEGexgHwk44SaxESMtQ2f1pBaTYw=s900-mo-c-c0xffffffff-rj-k-no"
base    = 'plugin://plugin.video.youtube/'


def run():
    plugintools.log("gospelcolection.run")
    
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def main_list(params):

    
                
    


                
		plugintools.log("gospelcolection ===> " + repr(params))
                plugintools.add_item(title = "Gospel Colection Mix 1"         , url = base + "playlist/PL_Q15fKxrBb4pxTp2zQm6zZU3-h4dlm05/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "Gospel Colection Mix 2"         , url = base + "playlist/PLjwDi_dm6srlAU54JHsDwaMWb9jmTvysq/",       thumbnail = icon, folder = True)

                plugintools.add_item(title = "As Melhores Musicas Gospel e Mais Tocadas"         , url = base + "playlist/PL2296dlVp4DPuI0B053-nQU9D30GWONW5/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "Louvores Para Acalmar A Alma em 2019"         , url = base + "playlist/PLKy-MuzQusGDK1VWdImCMEw7J6S4fQgCB/",       thumbnail = icon, folder = True)                
                plugintools.add_item(title = "As melhores mÃºsicas gospel mais tocadas"         , url = base + "playlist/PLqb5MhlswtopztyMGjsMfceIm6Phzyi5j/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "As Melhores MÃºsicas Gospel Mais Tocadas 2"         , url = base + "playlist/PLGu_O2_84gnVbUlsqrbSGQYHjvRSNcJo-/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "As Melhores Musicas Gospel Mais Tocadas 2019 - Anderson Freire, Aline Barros"         , url = base + "playlist/PLoZREtoAvBufg-_a7NHYBRkyKyTXfxxxb/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "top 10 musicas gospel - Melhores mÃºsicas gospel mais tocadas - musicas gospel"         , url = base + "playlist/PLHRfvZ6qvZfjhyajTKyV5VZcVnSyn9kFS/",       thumbnail = icon, folder = True)

		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmc.executebuiltin('Container.SetViewMode(500)')

run()

