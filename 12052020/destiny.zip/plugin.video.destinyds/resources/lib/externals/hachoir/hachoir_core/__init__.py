from resources.lib.externals.hachoir.hachoir_core.version import VERSION as __version__, PACKAGE, WEBSITE, LICENSE

