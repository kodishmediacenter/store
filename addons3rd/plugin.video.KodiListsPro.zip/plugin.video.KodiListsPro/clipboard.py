'''
A croos platform clipboard read/write library.

...well, as I were trying to implement this.
I realize that everything is already in the pyperclip module.

'''
from pyperclip import copy, paste
