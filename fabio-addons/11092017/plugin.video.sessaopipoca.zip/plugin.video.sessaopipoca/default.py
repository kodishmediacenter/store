import os
import sys
import time
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.sessaopipoca'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'
entryurl=resfolder+"entrada.mp4"

YOUTUBE_CHANNEL_ID1 = "PLlorHglRgLcRiv7FrX5Ifeal-esYAzggr"
YOUTUBE_CHANNEL_ID2 = "PLlorHglRgLcSx1mjJJhiJYWVZrc7j2TBi"
YOUTUBE_CHANNEL_ID3 = "PLlorHglRgLcTpsmVyvnHGShYsEus-xZQ9"
YOUTUBE_CHANNEL_ID4 = "PLlorHglRgLcSx1mjJJhiJYWVZrc7j2TBi"
YOUTUBE_CHANNEL_ID5 = "PLlorHglRgLcSRlJCid5jCXlQuulfU9aYp"


def run():
	
	params = plugintools.get_params()
	
	if params.get("action") is None:
		xbmc.Player().play(entryurl)
		
		while xbmc.Player().isPlaying():
			time.sleep(1)

		main_list(params)
	else:
		action = params.get("action")
		exec action+"(params)"

	plugintools.close_item_list()


def main_list(params):
	plugintools.log("sessaopipoca.main_list "+repr(params))
	
	plugintools.log("sessaopipoca.run")
	
	#plugintools.direct_play(str(entryurl))

	plugintools.add_item(
		title = "[COLOR blue][B]Sessao Pipoca Light[/B][/COLOR]",
		url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID1+"/",
		thumbnail = icon,
		folder = True )

	plugintools.add_item(
		title = "[B][COLOR yellow]Sessao Pipoca Prime[/B][/COLOR]",
		url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",
		thumbnail = icon,
		folder = True )

	plugintools.add_item(
		title = "[COLOR red][B]Sessao Pipoca Essentials[/B][/COLOR]",
		url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",
		thumbnail = icon,
		folder = True )

	plugintools.add_item(
		title = "[COLOR orange][B]Sessao Pipoca Premier[/B][/COLOR]",
		url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID4+"/",
		thumbnail = icon,
		folder = True )
	
	plugintools.add_item(
		title = "[COLOR green][B]Sessao Pipoca Plus[/B][/COLOR]",
		url = "plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID5+"/",
		thumbnail = icon,
		folder = True )
		

run()
