import xbmcaddon

MainBase = 'https://pastebin.com/raw/F3TQXZ71'
addon = xbmcaddon.Addon('plugin.video.dosapo')
