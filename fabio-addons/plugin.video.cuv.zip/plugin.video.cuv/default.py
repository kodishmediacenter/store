
import os
import sys
import time
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.cuv'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
#icon = ""

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'
entryurl=resfolder+"entrada.mp4"

YOUTUBE_USER_ID = "channel/UCWtVeQY2QVUo6WxygAcvQqw"

# Ponto de Entrada
def run():
	
	params = plugintools.get_params()
	
	if params.get("action") is None:
		xbmc.Player().play(entryurl)
		
		while xbmc.Player().isPlaying():
			time.sleep(1)

		main_list(params)
	else:
		action = params.get("action")
		exec action+"(params)"

	plugintools.close_item_list()

# Menu Principal
def main_list(params):
	plugintools.log("cuv.main_list "+repr(params))
	
	plugintools.log("cuv.run")
	
	#plugintools.direct_play(str(entryurl))

	plugintools.add_item(
		title = "Canal Universo Virtual",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_USER_ID+"/",
		thumbnail = icon,
		folder = True )

run()