

import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools
import regex

from addon.common.addon import Addon



addonID = 'plugin.video.xgenerator'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')

userDataFolder = xbmc.translatePath("special://home/addons/"+addonID+"/lista.xml")

keynlista = xbmc.Keyboard('', 'Nome da Lista:')
keynlista.doModal()
nlista = keynlista.getText()

keyicone = xbmc.Keyboard('', 'Coloque o link do icone:')
keyicone.doModal()
icone = keyicone.getText()

keylista = xbmc.Keyboard('', 'Coloque o link da lista:')
keylista.doModal()
lista = keylista.getText()

keyfanart = xbmc.Keyboard('', 'Coloque o link da fanart:')
keyfanart.doModal()
fanart = keyfanart.getText()

keyopcao = xbmc.Keyboard('', 'Digite 1 nova lista 2 Para anexar novo iten a lista:')
keyopcao.doModal()
opcao = keyopcao.getText()


regex.regex(opcao,userDataFolder,nlista,icone,lista,fanart)




