# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/OMundo2osBrasileiros
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

from addon.common.addon import Addon

addonID = 'plugin.video.goosehouse'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
base    = 'plugin://plugin.video.youtube/'


def run():
    plugintools.log("caillou.run")
    
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def main_list(params):
		plugintools.log("goosehouse ===> " + repr(params))

		
                plugintools.add_item(title = "Goosehouse Original"         , url = base + "playlist/PLBD68F5F4CEEC308D/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "Goose house of the year 2016" , url = base + "playlist/PLO9K4AusEfOhY6iDk7fCFpqxqT91JpORr/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "HOY2016"             , url = base + "playlist/PLO9K4AusEfOjy_ZizB6UFbvUEGPurKDh_/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "Goosehouse Message"             , url = base + "playlist/PL003E8638A0161404/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "Goose house SOLO"            ,url = base + "playlist/PLO9K4AusEfOiYuDzlGlvy-0vk0of3m2BY/",       thumbnail = icon, folder = True)

                plugintools.add_item(title = "KEI'S TV"         , url = base + "playlist/PLO9K4AusEfOibBPpGUjcrdTXItRQh6t0W/",       thumbnail = icon, folder = True)
                
                plugintools.add_item(title = "Goose house of the year 2015 Best10" , url = base + "playlist/PLO9K4AusEfOjuiaHC-NO-nHjxXyTwMBjK/",       thumbnail = icon, folder = True)
    
                plugintools.add_item(title = "Goosehouse plus"             , url = base + "playlist/PLO9K4AusEfOiIAaczRmDqvKS_KTY72kr7/",       thumbnail = icon, folder = True)

                plugintools.add_item(title = "HOY2013"             , url = base + "playlist/PLO9K4AusEfOipzJRcuenpfMLkesGFOMCf/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "Goosehouse ニューシングル 2013.3.13リリース"            ,url = base + "playlist/PLO9K4AusEfOiqExXBMgZkYzRpA00SuFMr/",       thumbnail = icon, folder = True)

		plugintools.add_item(title = "Phrase #03 Wandering"             , url = base + "playlist/PLE19D99B54578DE1A/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "#04 Beautiful Life 情報！"            ,url = base + "playlist/PLO9K4AusEfOgFMb5vT1oKGg9nHBgsvoXH/",       thumbnail = icon, folder = True)

		
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmc.executebuiltin('Container.SetViewMode(500)')

run()
