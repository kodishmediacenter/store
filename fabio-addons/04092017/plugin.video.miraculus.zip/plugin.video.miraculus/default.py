# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint

addonID = 'plugin.video.miraculus'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://home/addons/plugin.video.miraculus/data/" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close

eng2sp = {1:"https://docs.google.com/file/d/0B95y69kndqqGMk1UM1ZaOGRlcUE",
2:"https://docs.google.com/file/d/0B95y69kndqqGNzJTU0tRakowSEU",
3:"https://docs.google.com/file/d/0B95y69kndqqGSFIyeGRfMEcwQVk",
4:"https://docs.google.com/file/d/0B95y69kndqqGNk5zYmdQaDMxLW8",
5:"https://docs.google.com/file/d/0B95y69kndqqGckJKUVFPN2lRWEk",
6:"https://docs.google.com/file/d/0B95y69kndqqGSVV0ZEdJRVpHNEk",
7:"https://docs.google.com/file/d/0B95y69kndqqGVFRObUg4NF9lVzA",
8:"https://docs.google.com/file/d/0B95y69kndqqGYW1jdjhGMkRUN0E",
9:"https://docs.google.com/file/d/0B95y69kndqqGaHVKNWpvMWNVblE",
10:"https://docs.google.com/file/d/0B95y69kndqqGUU1jdlRZbDM3a3c",
11:"https://docs.google.com/file/d/0B95y69kndqqGX1ZMTFNldzVDTWc",
12:"https://docs.google.com/file/d/0B95y69kndqqGdzhWX0hIUzQ2VmM",
13:"https://docs.google.com/file/d/0B95y69kndqqGTGlIN0llTm1sVUE",
14:"https://docs.google.com/file/d/0B95y69kndqqGX0FDSlFaV25RbG8",
15:"https://docs.google.com/file/d/0B95y69kndqqGa2VvM3RMMkFjQ1E",
16:"https://docs.google.com/file/d/0B95y69kndqqGTWJWSDFRSXgxZ2s",
17:"https://docs.google.com/file/d/0B95y69kndqqGMkdoU3FHajhTX3c",
18:"https://docs.google.com/file/d/0B95y69kndqqGU2QwYmlfcEhUaW8",
19:"https://docs.google.com/file/d/0B95y69kndqqGQ2FYREYtUmRLcFk",
20:"https://docs.google.com/file/d/0B95y69kndqqGQUNGNFZDOVRTYXM",
21:"https://docs.google.com/file/d/0B95y69kndqqGSmc4NDRLZDZpSlE",
22:"https://docs.google.com/file/d/0B95y69kndqqGQVI3bjdkY3Y5clE",
23:"https://docs.google.com/file/d/0B95y69kndqqGS1JHRGgtZXZ5Slk",
24:"https://docs.google.com/file/d/0B95y69kndqqGaHFLQ0taN0djdlk",
25:"https://docs.google.com/file/d/0B95y69kndqqGWkZRcUFnUVI2Q0U",
26:"https://docs.google.com/file/d/0B95y69kndqqGWmNhYW9yR0UyZ2c",
27:"https://docs.google.com/file/d/0B95y69kndqqGNEtjVEVZeVhDSzQ",
}

        
for j in range(1,28):
	    
        file = open(""+m3u+"","a")
        file.write("plugin://plugin.video.gdrive?mode=streamURL&amp;url="+eng2sp[j]+"")
        file.write("\n")
        file.close

        


xbmc.Player().play(""+m3u+"")