# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint

addonID = 'plugin.video.bb24horas'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,62)
ieps = 62 - eps

eng2sp = {1:"http://v5.ec.cx/RedeCanais/RCServer05/ondemand/BBT01EP01.mp4",
2:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT01EP02.mp4",
3:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT01EP03.mp4",
4:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT01EP04.mp4",
5:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT01EP05.mp4",
6:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT01EP06.mp4",
7:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT01EP07.mp4",
8:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP01.mp4",
9:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP02.mp4",
10:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP03.mp4",
11:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP04.mp4",
12:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP05.mp4",
13:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP06.mp4",
14:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP07.mp4",
15:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP08.mp4",
16:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP09.mp4",
17:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP10.mp4",
18:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP11.mp4",
19:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP12.mp4",
20:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT02EP13.mp4",
21:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP01.mp4",
22:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP02.mp4",
23:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP03.mp4",
24:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP04.mp4",
25:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP05.mp4",
26:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP06.mp4",
27:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP07.mp4",
28:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP08.mp4",
29:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP09.mp4",
30:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP10.mp4",
31:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP11.mp4",
32:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP12.mp4",
33:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT03EP13.mp4",
34:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP01.mp4",
35:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP02.mp4",
36:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP03.mp4",
37:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP04.mp4",
38:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP05.mp4",
39:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP06.mp4",
40:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP07.mp4",
41:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP08.mp4",
42:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP09.mp4",
43:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP10.mp4",
44:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP11.mp4",
45:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP12.mp4",
46:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT04EP13.mp4",
47:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT05EP01.mp4",
48:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT05EP02.mp4",
49:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT05EP03.mp4",
50:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT05EP04.mp4",
51:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT05EP05.mp4",
52:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT05EP06.mp4",
53:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT05EP07.mp4",
54:"http://cdnv14.ec.cx/RedeCanais/RCServer05/ondemand/BBT05EP08.mp4",
55:"http://cdnv10.ec.cx/RedeCanais/RedeCanais/RCServer07/ondemand/BBT05EP09.mp4",
56:"http://cdnv10.ec.cx/RedeCanais/RedeCanais/RCServer07/ondemand/BBT05EP10.mp4",
57:"http://cdnv10.ec.cx/RedeCanais/RedeCanais/RCServer07/ondemand/BBT05EP11.mp4",
58:"http://cdnv10.ec.cx/RedeCanais/RedeCanais/RCServer07/ondemand/BBT05EP12.mp4",
59:"http://cdnv10.ec.cx/RedeCanais/RedeCanais/RCServer07/ondemand/BBT05EP13.mp4",
60:"http://cdnv10.ec.cx/RedeCanais/RedeCanais/RCServer07/ondemand/BBT05EP14.mp4",
61:"http://cdnv10.ec.cx/RedeCanais/RedeCanais/RCServer07/ondemand/BBT05EP15.mp4",
62:"http://cdnv10.ec.cx/RedeCanais/RedeCanais/RCServer07/ondemand/BBT05EP16.mp4",
}

        
for j in range(ieps,(ieps+15)):
        
        file = open(""+m3u+"","a")
        file.write(eng2sp[j])
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

