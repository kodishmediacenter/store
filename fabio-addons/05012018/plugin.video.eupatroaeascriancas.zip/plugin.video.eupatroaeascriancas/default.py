# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint

addonID = 'plugin.video.eupatroaeascriancas'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,123)
ieps = 123 - eps

eng2sp = {1:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP01.mp4",
2:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP02.mp4",
3:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP03.mp4",
4:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP04.mp4",
5:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP05.mp4",
6:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP06.mp4",
7:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP07.mp4",
8:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP08.mp4",
9:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP09.mp4",
10:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP10.mp4",
11:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT01EP11.mp4",
12:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP01.mp4",
13:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP02.mp4",
14:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP03.mp4",
15:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP04.mp4",
16:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP05.mp4",
17:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP06.mp4",
18:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP07.mp4",
19:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP08.mp4",
20:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP09.mp4",
21:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP10.mp4",
22:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP11.mp4",
23:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP12.mp4",
24:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP13.mp4",
25:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP14.mp4",
26:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP15.mp4",
27:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP16.mp4",
28:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP17.mp4",
29:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP18.mp4",
30:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP19.mp4",
31:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP20.mp4",
32:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP21.mp4",
33:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP22.mp4",
34:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP23.mp4",
35:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP24.mp4",
36:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP25.mp4",
37:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP26.mp4",
38:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP27.mp4",
39:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP28.mp4",
40:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT02EP29.mp4",
41:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP01.mp4",
42:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP02.mp4",
43:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP03.mp4",
44:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP04.mp4",
45:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP05.mp4",
46:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP06.mp4",
47:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP07.mp4",
48:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP08.mp4",
49:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP09.mp4",
50:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP10.mp4",
51:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP11.mp4",
52:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP12.mp4",
53:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP13.mp4",
54:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP14.mp4",
55:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP15.mp4",
56:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP16.mp4",
57:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP17.mp4",
58:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP18.mp4",
59:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP19.mp4",
60:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP20.mp4",
61:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP21.mp4",
62:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP22.mp4",
63:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP23.mp4",
64:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP24.mp4",
65:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP25.mp4",
66:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP26.mp4",
67:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT03EP27.mp4",
68:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP01.mp4",
69:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP02.mp4",
70:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP03.mp4",
71:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP04.mp4",
72:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP05.mp4",
73:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP06.mp4",
74:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP07.mp4",
75:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP08.mp4",
76:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP09.mp4",
77:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP10.mp4",
78:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP11.mp4",
79:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP12.mp4",
80:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP13.mp4",
81:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP14.mp4",
82:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP15.mp4",
83:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP16.mp4",
84:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP17.mp4",
85:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP18.mp4",
86:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP19.mp4",
87:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP20.mp4",
88:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP21.mp4",
89:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP22.mp4",
90:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP23.mp4",
91:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP24.mp4",
92:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP25.mp4",
93:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP26.mp4",
94:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP27.mp4",
95:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP28.mp4",
96:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP29.mp4",
97:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT04EP30.mp4",
98:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP01.mp4",
99:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP02.mp4",
100:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP03.mp4",
101:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP04.mp4",
102:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP05.mp4",
103:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP06.mp4",
104:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP07.mp4",
105:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP08.mp4",
106:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP09.mp4",
107:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP10.mp4",
108:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP11.mp4",
109:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP12.mp4",
110:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP13.mp4",
111:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP14.mp4",
112:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP15.mp4",
113:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP16.mp4",
114:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP17.mp4",
115:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP18.mp4",
116:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP19.mp4",
117:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP20.mp4",
118:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP21.mp4",
119:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP22.mp4",
120:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP23.mp4",
121:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP24.mp4",
122:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP25.mp4",
123:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/EUAPTEACT05EP26.mp4",
}

        
for j in range(ieps,(ieps+30)):
        
        file = open(""+m3u+"","a")
        file.write(eng2sp[j])
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

