# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint

addonID = 'plugin.video.todomundoodeiacris24horas'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,88)


eng2sp = {1:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP01.mp4",
2:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP02.mp4",
3:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP03.mp4",
4:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP04.mp4",
5:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP05.mp4",
6:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP06.mp4",
7:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP07.mp4",
8:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP08.mp4",
9:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP09.mp4",
10:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP10.mp4",
11:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP11.mp4",
12:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP12.mp4",
13:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP13.mp4",
14:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP14.mp4",
15:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP15.mp4",
16:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP16.mp4",
17:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP17.mp4",
18:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP18.mp4",
19:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP19.mp4",
20:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP20.mp4",
21:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP21.mp4",
22:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT01EP22.mp4",
23:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP01.mp4",
24:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP02.mp4",
25:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP03.mp4",
26:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP04.mp4",
27:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP05.mp4",
28:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP06.mp4",
29:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP07.mp4",
30:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP08.mp4",
31:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP09.mp4",
32:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP10.mp4",
33:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP11.mp4",
34:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP12.mp4",
35:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP13.mp4",
36:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP14.mp4",
37:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP15.mp4",
38:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP16.mp4",
39:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP17.mp4",
40:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP18.mp4",
41:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP19.mp4",
42:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP20.mp4",
43:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP21.mp4",
44:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT02EP22.mp4",
45:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP01.mp4",
46:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP02.mp4",
47:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP03.mp4",
48:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP04.mp4",
49:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP05.mp4",
50:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP06.mp4",
51:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP07.mp4",
52:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP08.mp4",
53:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP09.mp4",
54:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP10.mp4",
55:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP11.mp4",
56:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP12.mp4",
57:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP13.mp4",
58:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP14.mp4",
59:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP15.mp4",
60:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP16.mp4",
61:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP17.mp4",
62:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP18.mp4",
63:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP19.mp4",
64:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP20.mp4",
65:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP21.mp4",
66:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT03EP22.mp4",
67:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP01.mp4",
68:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP02.mp4",
69:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP03.mp4",
70:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP04.mp4",
71:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP05.mp4",
72:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP06.mp4",
73:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP07.mp4",
74:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP08.mp4",
75:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP09.mp4",
76:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP10.mp4",
77:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP11.mp4",
78:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP12.mp4",
79:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP13.mp4",
80:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP14.mp4",
81:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP15.mp4",
82:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP16.mp4",
83:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP17.mp4",
84:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP18.mp4",
85:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP19.mp4",
86:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP20.mp4",
87:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP21.mp4",
88:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/TDMNDOCT04EP22.mp4",
}

        
for j in range(eps,(eps+30)):
        
        file = open(""+m3u+"","a")
        file.write(eng2sp[j])
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

