# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint

addonID = 'plugin.video.maluconopedaco'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,148)
ieps = 148 - eps

eng2sp = {1:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/067e7df0",
2:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ea8e3c25",
3:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8f159bb3",
4:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/571909a8",
5:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e7157065",
6:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ef072301",
7:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ed365644",
8:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a4f68b8c",
9:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c22feb33",
10:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5a628ad8",
11:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3472604d",
12:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/38b9349f",
13:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a419d409",
14:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a9478120",
15:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a8cdb319",
16:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0b992f65",
17:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/cbd9f6b0",
18:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/614e68cb",
19:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4bd7a48e",
20:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/251595b6",
21:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c733d5c6",
22:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4985c4f0",
23:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ee4111cc",
24:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/224fb666",
25:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c973d5e0",
26:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8edce6d9",
27:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/15af0157",
28:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/79731fc5",
29:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c5c6818d",
30:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7ec8842a",
31:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/bf49b7cb",
32:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a774fd3d",
33:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/cd09e570",
34:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f2445848",
35:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7f910fc3",
36:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4510d4f7",
37:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f8456e47",
38:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/fdd4d909",
39:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9cf7c795",
40:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a2d9cb9f",
41:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/695fb092",
42:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d18b79c5",
43:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/71de3148",
44:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/67f24cdb",
45:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f8aa6b48",
46:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ed77ae49",
47:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d82f9df9",
48:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/de6409e1",
49:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1ce8a8b3",
50:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/58d1a31b",
51:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e9883572",
52:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b9d23c42",
53:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/75ddffaf",
54:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/482f33ac",
55:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0b1158ba",
56:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/814092ee",
57:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c8cebaa5",
58:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3130fc38",
59:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9be63ee0",
60:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a4db8f45",
61:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/79ef9fb0",
62:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/eafa8f43",
63:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4bfc3053",
64:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b2887f39",
65:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d280859a",
66:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/47def499",
67:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/dad0ce63",
68:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3597ff7c",
69:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1e0fd5ab",
70:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/358ab74d",
71:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0c09dcf8",
72:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/09982795",
73:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e924cd72",
74:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b0c19498",
75:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/7481c1c0",
76:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f3b8dfe1",
77:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/246e9ac5",
78:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/46afb3c8",
79:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d91a9ab1",
80:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e805cdb5",
81:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/28b22592",
82:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/329518ca",
83:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/11dedc24",
84:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6d50672a",
85:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/180a8635",
86:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5ffa2b09",
87:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/11052d92",
88:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8fa86ada",
89:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/cd66d430",
90:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6be6328a",
91:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5cb04a1e",
92:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5ee995d6",
93:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/cfe51e85",
94:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4d684389",
95:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/78cd88c8",
96:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c6d4ae2a",
97:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/4ab7d982",
98:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8f8a68b7",
99:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1326dd77",
100:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a3a4d180",
101:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/a90c5112",
102:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/07152f28",
103:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f4e4a8df",
104:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6f2f4654",
105:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/852d7d7f",
106:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ef10d566",
107:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/53474290",
108:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/31db1493",
109:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1e47ac0e",
110:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/0b32811c",
111:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/09296f53",
112:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/81f6164e",
113:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/38bc22a3",
114:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ef671f3d",
115:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8872d262",
116:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d7b2d706",
117:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/91edb17e",
118:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1a087ff5",
119:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/bb5499e5",
120:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/07f21f33",
121:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5370a462",
122:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/86828bed",
123:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/2749aa39",
124:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/5e0200e7",
125:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f76a093d",
126:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/22187a4e",
127:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d28a73c6",
128:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/ac760a7d",
129:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/71115c23",
130:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/f9c556e6",
131:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/d92ba149",
132:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/e35eda63",
133:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/8cb69d4f",
134:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6280f255",
135:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/10fdee17",
136:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/1c6297b1",
137:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/82b3cb80",
138:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9d17ae78",
139:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/64366dba",
140:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/3a8f0be6",
141:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/08e1de15",
142:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/73a49bf3",
143:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/c0b53b91",
144:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/db70c37e",
145:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/6d9e9343",
146:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/b0648f26",
147:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/31616bc5",
148:"http://cdnv11.ec.cx/RedeCanais/RedeCanais/RCServer01/videos/9e823cbf",}

        
for j in range(ieps,(ieps+30)):
        
        file = open(""+m3u+"","a")
        file.write(eng2sp[j])
	file.write(".mp4")
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

