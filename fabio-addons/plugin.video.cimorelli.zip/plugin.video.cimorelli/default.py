# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.cimorelli'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'
entryurl=resfolder+"entrada.mp4"

YOUTUBE_CHANNEL_ID= "playlist/PLxvNPv0hzSDD7Ir_jDjjiQicf6JOWqi4K"
YOUTUBE_CHANNEL_ID2="playlist/PLxvNPv0hzSDCcMCAQNF7XZNlfXWgYt4II"
YOUTUBE_CHANNEL_ID3="playlist/PL7B71B644B0166239"
YOUTUBE_CHANNEL_ID4="playlist/PLF21BB70C750A7A7C"
YOUTUBE_CHANNEL_ID5="playlist/PLxvNPv0hzSDCXJxjA0El1qvWKmJmoprNv"
YOUTUBE_CHANNEL_ID6="playlist/PL75703FBFD564AE41"
YOUTUBE_CHANNEL_ID7="playlist/PLxvNPv0hzSDACUI5lBghLzIUmL85ztcWd"
YOUTUBE_CHANNEL_ID8="playlist/PLxvNPv0hzSDDqQjfRrevgiZoSmNrOsVCP"
YOUTUBE_CHANNEL_ID9="playlist/PLxvNPv0hzSDDYR1cqDSqx-tAL3uawuMOY"

# Ponto de Entrada
def run():
	# Pega Parâmetros
	params = plugintools.get_params()
	
	if params.get("action") is None:
		xbmc.Player().play(entryurl)
		
		while xbmc.Player().isPlaying():
			time.sleep(1)

		main_list(params)
	else:
		action = params.get("action")
		exec action+"(params)"

	plugintools.close_item_list()

# Menu Principal
def main_list(params):
	plugintools.log("cimorelli.main_list "+repr(params))
	
	plugintools.log("cimorelli.run")
	
	#plugintools.direct_play(str(entryurl))

	plugintools.add_item(
		title = "Cimorelli Original Songs",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID+"/",
		thumbnail = icon,
		folder = True )
		
	plugintools.add_item(
		title = "Cimorelli Style",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",
		thumbnail = icon,
		folder = True )
		
	plugintools.add_item(
		title = "Other Stuff",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",
		thumbnail = icon,
		folder = True )
		
	plugintools.add_item(
		title = "Cimorelli Music Videos Covers",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",
		thumbnail = icon,
		folder = True )
		
	plugintools.add_item(
		title = "Summer With Cimorelli - Our Comedy Series",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",
		thumbnail = icon,
		folder = True )
		
	plugintools.add_item(
		title = "Christmas Songs",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",
		thumbnail = icon,
		folder = True )
		
	plugintools.add_item(
		title = "Our East Coast Tour",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID7+"/",
		thumbnail = icon,
		folder = True )
		
	plugintools.add_item(
		title = "Cimorelli Takes Europe",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID8+"/",
		thumbnail = icon,
		folder = True )
		
	plugintools.add_item(
		title = "YT Holiday Extravagannza",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID9+"/",
		thumbnail = icon,
		folder = True )

run()
