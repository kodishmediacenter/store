# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.TheMasterInvencoes'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
#icon = local.getAddonInfo('icon')

icon  = "http://i.ytimg.com/vi/rTQnM9f5dns/maxresdefault.jpg"
icon2 = "http://i.ytimg.com/vi/ApPiNMYyCMc/maxresdefault.jpg"
icon3 = "http://i.ytimg.com/vi/bQIVKi2CNvM/maxresdefault.jpg"
icon4 = "http://i.ytimg.com/vi/QLQijEza6xE/maxresdefault.jpg"
icon5 = "http://i.ytimg.com/vi/hClCTiUzawM/maxresdefault.jpg"
icon6 = "http://i.ytimg.com/vi/dzAcl7qHQUo/maxresdefault.jpg"
icon7 = "http://i.ytimg.com/vi/CA5IBQis8GY/maxresdefault.jpg"
icon8 = "http://i.ytimg.com/vi/dzAcl7qHQUo/maxresdefault.jpg"
icon9 = "http://i.ytimg.com/vi/ZdP08JoDtbw/maxresdefault.jpg"
icon10 = "http://i.ytimg.com/vi/buMZjSLEXms/maxresdefault.jpg"
icon11 = "http://i.ytimg.com/vi/kAMkd-U6eTA/maxresdefault.jpg"
icon12 = "http://i.ytimg.com/vi/C3a1uCWpmWw/maxresdefault.jpg"
icon13 = "http://i.ytimg.com/vi/clmcmdEDXBs/maxresdefault.jpg"
icon14 = "http://i.ytimg.com/vi/dXL4Cpin260/maxresdefault.jpg"
icon15 = "http://i.ytimg.com/vi/WQTfgAH9lbk/maxresdefault.jpg"

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'
entryurl=resfolder+"entrada.mp4"

YOUTUBE_CHANNEL_ID= "playlist/PLxp7beIqfdnz7gqFnKDJQQsBFIEGK5xYK"
YOUTUBE_CHANNEL_ID2="playlist/PLxp7beIqfdnxNDkVsZ_7hYMmK8W9OQVqR"
YOUTUBE_CHANNEL_ID3="playlist/PLxp7beIqfdnxQ2x2QpKXLcoL0nmRxf_kj"
YOUTUBE_CHANNEL_ID4="playlist/PLxp7beIqfdnxwNUJX66SVz3rIPNn5d-WR"
YOUTUBE_CHANNEL_ID5="playlist/PLxp7beIqfdny2NGlPQf2Si1mnesEiI4Jj"
YOUTUBE_CHANNEL_ID6="playlist/PLxp7beIqfdnxHyubajXuQFjkiZVk1wf0O"
YOUTUBE_CHANNEL_ID7="playlist/PLxp7beIqfdnwHVwwMBY-sqZqBqlLfcXzP"
YOUTUBE_CHANNEL_ID8="playlist/PLxp7beIqfdnyaJ-z9-HQG1sMktsKCZOux"
YOUTUBE_CHANNEL_ID9="playlist/PLxp7beIqfdny6mi9OyBTfUUtsuNXTQoaZ"
YOUTUBE_CHANNEL_ID10="playlist/PLxp7beIqfdnz83LXBaHG7j2Wdm3L73C9M"
YOUTUBE_CHANNEL_ID11="playlist/PLxp7beIqfdnwIo9sria_r9wH0RlGSL3IS"
YOUTUBE_CHANNEL_ID12="playlist/PLxp7beIqfdnx0gcJo802UAA9TIYn6HVqY"
YOUTUBE_CHANNEL_ID13="playlist/PLxp7beIqfdnzXUddXkQYMAQENAucFjap2"
YOUTUBE_CHANNEL_ID14="playlist/PLxp7beIqfdnw1FGnTXTEOibgMJMvHyJ8C"
YOUTUBE_CHANNEL_ID15="playlist/PL945E64231D0E2735"

# Ponto de Entrada
def run():
	# Pega Parâmetros
	params = plugintools.get_params()
	
	if params.get("action") is None:
		xbmc.Player().play(entryurl)
		
		while xbmc.Player().isPlaying():
			time.sleep(1)

		main_list(params)
	else:
		action = params.get("action")
		exec action+"(params)"

	plugintools.close_item_list()

# Menu Principal
def main_list(params):
	plugintools.log("TheMasterInvencoes.main_list "+repr(params))
	
	plugintools.log("TheMasterInvencoes.run")
	
	#plugintools.direct_play(str(entryurl))

plugintools.add_item(
		title = "Armas Caseiras",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID+"/",
		thumbnail = icon,
		folder = True )

plugintools.add_item(
		title = "Dicas - Life Hacks",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",
		thumbnail = icon2,
		folder = True )

plugintools.add_item(
		title = "Invenções Divertidas",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",
		thumbnail = icon3,
		folder = True )

plugintools.add_item(
		title = "English Videos",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",
		thumbnail = icon4,
		folder = True )
		
		
plugintools.add_item(
		title = "Coisas para Celular",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",
		thumbnail = icon5,
		folder = True )

plugintools.add_item(
		title = "Inveções e Tecnologia",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",
		thumbnail = icon6,
		folder = True )
		
		
plugintools.add_item(
		title = "Equipamento de HERÓIS (Adereços)",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID7+"/",
		thumbnail = icon7,
		folder = True )
		
plugintools.add_item(
		title = "Filmes, Jogos e Séries ",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID8+"/",
		thumbnail = icon8,
		folder = True )

plugintools.add_item(
		title = "Ferramentas",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID9+"/",
		thumbnail = icon9,
		folder = True )
		
		
plugintools.add_item(
		title = "Sobrevivência",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID10+"/",
		thumbnail = icon10,
		folder = True )
		
plugintools.add_item(
		title = "Foguetes",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID11+"/",
		thumbnail = icon11,
		folder = True )
		
plugintools.add_item(
		title = "Avião, Carro e Barco",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID12+"/",
		thumbnail = icon12,
		folder = True )
		
plugintools.add_item(
		title = "Fogo",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID13+"/",
		thumbnail = icon13,
		folder = True )
		
plugintools.add_item(
		title = "Origami",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID14+"/",
		thumbnail = icon14,
		folder = True )

plugintools.add_item(
		title = "Airgun",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID15+"/",
		thumbnail = icon15,
		folder = True )		
run()
