# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint

addonID = 'plugin.video.miraculus'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'



addon_data_dir = os.path.join(xbmc.translatePath("special://home/addons/plugin.video.miraculus/data/" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close

eng2sp = {1:"http://198.50.137.183/24str/fabiolmg/MLB%20S01E01%20-%20Tormenta%20[720p][Dublado].mkv-0B95y69kndqqGMk1UM1ZaOGRlcUE.mkv",
2:"http://198.50.137.183/24str/fabiolmg/MLB%20S01E02%20-%20Ilustrador%20Do%20Mal%20[720p][Dublado].mkv-0B95y69kndqqGNzJTU0tRakowSEU.mkv",
3:"http://198.50.137.183/24str/fabiolmg/MLB%20S01E03%20-%20Lady%20Wifi%20[720p][Dublado].mkv-0B95y69kndqqGSFIyeGRfMEcwQVk.mkv",
4:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E04%20-%20Cupido%20Negro%20[720p][Dublado].mkv-0B95y69kndqqGNk5zYmdQaDMxLW8.mkv",
5:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E05%20-%20Sr.%20Pombo%20[720p][Dublado].mkv-0B95y69kndqqGckJKUVFPN2lRWEk.mkv",
6:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E06%20-%20Homem-Bolha%20[720p][Dublado]%20.mkv-0B95y69kndqqGSVV0ZEdJRVpHNEk.mkv",
7:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E07%20-%20Rogercop%20[720p][Dublado].mkv-0B95y69kndqqGVFRObUg4NF9lVzA.mkv",
8:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E08%20-%20Jogador%20[720p][Dublado].mkv-0B95y69kndqqGYW1jdjhGMkRUN0E.mkv",
9:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E09%20–%20Animan%20[720p][Dublado].mkv-0B95y69kndqqGaHVKNWpvMWNVblE.mkv",
10:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E10%20-%20Lâmina%20Negra%20[720p][Dublado].mkv-0B95y69kndqqGUU1jdlRZbDM3a3c.mkv",
11:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E11%20-%20O%20Faraó%20[720p][Dublado].mkv-0B95y69kndqqGX1ZMTFNldzVDTWc.mkv",
12:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E12%20-%20Horrificador%20[720p][Dublado].mkv-0B95y69kndqqGdzhWX0hIUzQ2VmM.mkv",
13:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E13%20-%20A%20Marionestista%20[720p][Dublado].mkv-0B95y69kndqqGTGlIN0llTm1sVUE.mkv",
14:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E14%20-%20Copycat%20[720p][Dublado].mkv-0B95y69kndqqGX0FDSlFaV25RbG8.mkv",
15:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E15%20-%20Temporizadora%20[720p][Dublado].mkv-0B95y69kndqqGa2VvM3RMMkFjQ1E.mkv",
16:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E16%20-%20O%20Mímico%20[720p][Dublado].mkv-0B95y69kndqqGTWJWSDFRSXgxZ2s.mkv",
17:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E17%20-%20Antibug%20[720p][Dublado].mkv-0B95y69kndqqGMkdoU3FHajhTX3c.mkv",
18:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E18%20-%20Kung%20Food%20[720p][Dublado].mkv-0B95y69kndqqGU2QwYmlfcEhUaW8.mkv",
19:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E19%20-%20Pixelador%20[720p][Dublado].mkv-0B95y69kndqqGQ2FYREYtUmRLcFk.mkv",
20:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E20%20-%20Guitarrista%20Malvado%20[720p][Dublado].mkv-0B95y69kndqqGQUNGNFZDOVRTYXM.mkv",
21:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E21%20-%20Reflecta%20[720p][Dublado].mkv-0B95y69kndqqGSmc4NDRLZDZpSlE.mkv",
22:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E22%20-%20Simon%20Mandou%20[720p][Dublado].mkv-0B95y69kndqqGQVI3bjdkY3Y5clE.mkv",
23:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E23%20-%20Princesa%20Perfume%20[720p][Dublado].mkv-0B95y69kndqqGS1JHRGgtZXZ5Slk.mkv",
24:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E24%20-%20Ladybug%20_u0026%20Cat%20Noir%20(Origem%20-%20Parte%201)%20[720p][Dublado].mkv-0B95y69kndqqGaHFLQ0taN0djdlk.mkv",
25:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E25%20-%20Coração%20De%20Pedra%20(Origem%20-%20Parte%202)%20[720p][Dublado].mkv-0B95y69kndqqGWkZRcUFnUVI2Q0U.mkv",
26:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S01E26%20-%20Volpina%20[720p][Dublado].mkv-0B95y69kndqqGWmNhYW9yR0UyZ2c.mkv",
27:"http://198.50.137.183/24str/fabiolmg/MLB%20%20S02E00%20-%20O%20Natal%20de%20Ladybug%20[720p][Dublado].mkv-0B95y69kndqqGNEtjVEVZeVhDSzQ.mkv",}




for j in range(1,28):
	    
        file = open(""+m3u+"","a")
        file.write(eng2sp[j])
        file.write("\n")
        file.close

        


xbmc.Player().play(""+m3u+"")