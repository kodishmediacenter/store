# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/ncs
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.kodishcolection'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)

sys = xbmc.translatePath("special://home/addons/plugin.video.kodishcolection")
icon = local.getAddonInfo('icon')
icon2 = ''+sys+'/nekotenshi.png'
icon3 = ''+sys+'/icon-nerdologia.png'
icon4 = ''+sys+'/icon-manualdomundo.png'
icon5 = ''+sys+'/icon-FatosDesconhecidos.png'
icon6 = ''+sys+'/icon-diolinux.png'
icon7 = ''+sys+'/icon-colecaonintendo.png'


addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'
entryurl=resfolder+"entrada.mp4"

YOUTUBE_CHANNEL_ID2 = "user/GiovanAnileMisachan"
YOUTUBE_CHANNEL_ID3 = "nerdologia"
YOUTUBE_CHANNEL_ID4 = "iberethenorio"
YOUTUBE_CHANNEL_ID5 ="fatosdesconhecidos"
YOUTUBE_CHANNEL_ID6 ="Diolinux" 
YOUTUBE_CHANNEL_ID7 = "UCADV2FgLb4URxDYBwEllOSQ"
# Ponto de Entrada
def run():
	# Pega Parâmetros
	params = plugintools.get_params()
	
	if params.get("action") is None:
		xbmc.Player().play(entryurl)
		
		while xbmc.Player().isPlaying():
			time.sleep(1)

		main_list(params)
	else:
		action = params.get("action")
		exec action+"(params)"

	plugintools.close_item_list()

# Menu Principal
def main_list(params):
	plugintools.log("kodishcolection.main_list "+repr(params))
	
	plugintools.log("kodishcolection.run")
	
	#plugintools.direct_play(str(entryurl))


	plugintools.add_item(
		title = "Neko Tenshi",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",
		thumbnail = icon2,
		folder = True )

	plugintools.add_item(
		title = "Nerdologia",
		url = "plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID3+"/",
		thumbnail = icon3,
		folder = True )

	plugintools.add_item(
		title = "Manual do Mundo",
		url = "plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID4+"/",
		thumbnail = icon4,
		folder = True )
	
	plugintools.add_item(
		title = "Fatos de Desconhecidos",
		url = "plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID5+"/",
		thumbnail = icon5,
		folder = True )

	plugintools.add_item(
		title = "Diolinux",
		url = "plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID6+"/",
		thumbnail = icon6,
		folder = True )

	plugintools.add_item(
		title = "Coleção Nintendo",
		url = "plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID7+"/",
		thumbnail = icon7,
		folder = True )
	
run()
