import xbmc
import xbmcgui
import webbrowser

def browser_player(os,link):

    if os =='android':
        links = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+link+'' ) )
    else:
        links = webbrowser . open ( ''+link+'' )


def loja(os):
    loja = "https://www.lojakissfm.com.br/"
    browser_player(os,loja)


def redessociais(os):
    dialog = xbmcgui.Dialog()
    ret3 = dialog.select('[COLOR yellow]Kiss FM 102.1 Radio Rock[/COLOR]', ['Whatsapp', 'Youtube','Facebook','Instagram'])
    if ret3 == 0:
        whats = "https://api.whatsapp.com/send?phone=5511998874343"
        browser_player(os,whats)
    if ret3 == 1:
        xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.youtube/user/RadioKissFMoficial/)")
    if ret3 == 2:
        face = "https://www.facebook.com/radiokissfm/"
        browser_player(os,face)
    if ret3 == 3:
        insta = "https://www.instagram.com/kissfm1021/"
        browser_player(os,insta)




    
dialog = xbmcgui.Dialog()
ret2 = dialog.select('[COLOR yellow]Kiss FM 102.1 Radio Rock[/COLOR]', ['Ao Vivo', 'Redes Sociais','Loja Virtual'])

if ret2 == 0:
    link = "http://stm50.sateg.com.br:26840/"
    xbmc.Player().play(""+link+"")

if ret2 == 1: 
    if xbmc . getCondVisibility ('system.platform.android'):
        os = 'android'
        redessociais(os)
    else:
        os = 'null'
        redessociais(os)

if ret2 == 2:
    if xbmc . getCondVisibility ('system.platform.android'):
        os = 'android'
        loja(os)
    else:
        os = 'null'
        loja(os)
    
