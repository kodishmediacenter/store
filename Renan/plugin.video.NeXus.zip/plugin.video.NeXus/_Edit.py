import xbmcaddon

MainBase = 'http://pastebin.com/raw/z9SwypZy'
addon = xbmcaddon.Addon('plugin.video.NeXus')