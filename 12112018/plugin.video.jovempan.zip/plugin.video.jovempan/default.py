# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.jovempan'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
icon2 = "https://yt3.ggpht.com/a-/AN66SAxTMfDCB_8xbp1WStv6d4Ov4g7zP7CMKUaMUg=s288-mo-c-c0xffffffff-rj-k-no"
icon3 = "https://yt3.ggpht.com/a-/AN66SAy6GaIn9_mOCqTmKSk4-FA7uLSwDBO-4YEM6Q=s288-mo-c-c0xffffffff-rj-k-no"
addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'
entryurl=resfolder+"entrada.mp4"

YOUTUBE_CHANNEL_ID1=  "user/portaljovempan"
YOUTUBE_CHANNEL_ID2=  "channel/UCv-Nx8pSfG_LxbViMz14RWQ"
YOUTUBE_CHANNEL_ID3=  "channel/UCsahCqRiZarflb9vXpAOVtQ"




# Ponto de Entrada
def run():
	# Pega Parâmetros
	params = plugintools.get_params()
	
	if params.get("action") is None:
		xbmc.Player().play(entryurl)
		
		while xbmc.Player().isPlaying():
			time.sleep(1)

		main_list(params)
	else:
		action = params.get("action")
		exec action+"(params)"

	plugintools.close_item_list()

# Menu Principal
def main_list(params):
	plugintools.log("jovempan.main_list "+repr(params))
	
	plugintools.log("jovempan.run")
	
	#plugintools.direct_play(str(entryurl))

	plugintools.add_item(
		title = "Jovem Pan News",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",
		thumbnail = icon,
		folder = True )

	plugintools.add_item(
		title = "Jovem Pan Sports",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",
		thumbnail = icon2,
		folder = True )

	plugintools.add_item(
		title = "Jovem Pan FM - Fun & Music",
		url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",
		thumbnail = icon3,
		folder = True )



run()
