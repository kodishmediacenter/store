# Criogenic App
# Cria um Link Simbolico para Facilitar acesso 

sudo ln -s /opt/kodish/crio /home/criogenic