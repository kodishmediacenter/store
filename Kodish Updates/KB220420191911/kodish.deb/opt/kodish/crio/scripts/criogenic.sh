# Criogenic App
# Criar o Backup do Kodi Instalado 
 
echo "Qual usuario que ta logado"
read user
mkdir /opt/kodish/crio
cp -r /home/$user/.kodi /opt/kodish/crio