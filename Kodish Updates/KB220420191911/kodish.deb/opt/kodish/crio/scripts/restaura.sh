# Criogenic App
# Restaura o Backup do Kodi em caso Catastrofe
 
echo "Qual usuario que ta logado"
read user
sudo rm /home/$user/.kodi 
cp -r /opt/kodish/crio/.kodi /home/$user/.kodi