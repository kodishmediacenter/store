# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint
import base64
import naomi

addonID = 'plugin.video.jiraia'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'

tunel = "UmVmZXJlcj1odHRwOi8vd3d3LnJlZGVjYW5haXMuY29tLmJyLw=="
ftunel = base64.b64decode(tunel)

addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,50)
ieps = 50 - eps

eng2sp = {1:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP01.mp4|"+ftunel+"",
2:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP02.mp4|"+ftunel+"",
3:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP03.mp4|"+ftunel+"",
4:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP04.mp4|"+ftunel+"",
5:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP05.mp4|"+ftunel+"",
6:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP06.mp4|"+ftunel+"",
7:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP07.mp4|"+ftunel+"",
8:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP08.mp4|"+ftunel+"",
9:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP09.mp4|"+ftunel+"",
10:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP10.mp4|"+ftunel+"",
11:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP11.mp4|"+ftunel+"",
12:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP12.mp4|"+ftunel+"",
13:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP13.mp4|"+ftunel+"",
14:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP14.mp4|"+ftunel+"",
15:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP15.mp4|"+ftunel+"",
16:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP16.mp4|"+ftunel+"",
17:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP17.mp4|"+ftunel+"",
18:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP18.mp4|"+ftunel+"",
19:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP19.mp4|"+ftunel+"",
20:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP20.mp4|"+ftunel+"",
21:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP21.mp4|"+ftunel+"",
22:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP22.mp4|"+ftunel+"",
23:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP23.mp4|"+ftunel+"",
24:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP24.mp4|"+ftunel+"",
25:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP25.mp4|"+ftunel+"",
26:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP26.mp4|"+ftunel+"",
27:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP27.mp4|"+ftunel+"",
28:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP28.mp4|"+ftunel+"",
29:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP29.mp4|"+ftunel+"",
30:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP30.mp4|"+ftunel+"",
31:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP31.mp4|"+ftunel+"",
32:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP32.mp4|"+ftunel+"",
33:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP33.mp4|"+ftunel+"",
34:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP34.mp4|"+ftunel+"",
35:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP35.mp4|"+ftunel+"",
36:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP36.mp4|"+ftunel+"",
37:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP37.mp4|"+ftunel+"",
38:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP38.mp4|"+ftunel+"",
39:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP39.mp4|"+ftunel+"",
40:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP40.mp4|"+ftunel+"",
41:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP41.mp4|"+ftunel+"",
42:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP42.mp4|"+ftunel+"",
43:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP43.mp4|"+ftunel+"",
44:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP44.mp4|"+ftunel+"",
45:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP45.mp4|"+ftunel+"",
46:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP46.mp4|"+ftunel+"",
47:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP47.mp4|"+ftunel+"",
48:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP48.mp4|"+ftunel+"",
49:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP49.mp4|"+ftunel+"",
50:"http://fabiolmg.local/RCServer02/ondemand/JOINJEP50.mp4|"+ftunel+"",
}

        
for j in range(eps,(eps+15)):
        
        file = open(""+m3u+"","a")
        eps = naomi.getserver(eng2sp[j])
        file.write(eps)
        file.write("\n")
        file.close

        
xbmc.Player().play(""+m3u+"")

