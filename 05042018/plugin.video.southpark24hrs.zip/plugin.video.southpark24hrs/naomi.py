# Biblioteca converte links emulado para real

def getserver(link):

    if link[0:32] == "http://fabiolmg.local/RCServer01":
        naomi = "http://d2ffn9f9wdgeuu.redecanais.video/RedeCanais/RedeCanais/RCServer01"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer02":
        naomi = "http://d3w5d78471030.redecanais.video/RedeCanais/RedeCanais/RCServer02"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer05":
        naomi = "http://d2ffn9f9wdgeuu.redecanais.video/RedeCanais/RedeCanais/RCServer05"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer07":
        naomi = "http://d3w5d78471030.redecanais.video/RedeCanais/RedeCanais/RCServer07"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer08":
        naomi = "http://d1sbqx70xmng1t.redecanais.video/RedeCanais/RCServer08"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer10":
        naomi = "http://d234fl6nc0tzg6.redecanais.video/RedeCanais/RedeCanais/RCServer10"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer11":
        naomi = "http://d2i9nsbhos9zv.redecanais.download/RedeCanais/RCServer11"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    
