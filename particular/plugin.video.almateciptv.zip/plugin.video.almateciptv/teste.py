def login(url):

    login = "teste"
    password = "teste"

    tam = len(url)
    print (tam)
    base = "http://almateciptv.ddns.net:8000/live"
    logos = ""+login+"/"+password+""
   
    baseurl = ""+base+"/"+logos+"/"+url[57:tam]+""
    print(baseurl)	




login("http://almateciptv.ddns.net:8000/live/+login+/+password+/1485.ts")
