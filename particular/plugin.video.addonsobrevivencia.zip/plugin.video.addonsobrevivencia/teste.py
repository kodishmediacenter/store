
def teste():
		url =channel/UCXZf964iFfaIBjegUhMJ-1A
		icone = https://yt3.ggpht.com/-A_cuKDfT3ek/AAAAAAAAAAI/AAAAAAAAAAA/25_CmJmQmIM/s100-c-k-no-mo-rj-c0xffffff/photo.jpg
		bloco =Filmáticas Espírita
		YOUTUBE_CHANNEL_ID = url
		icon = icone