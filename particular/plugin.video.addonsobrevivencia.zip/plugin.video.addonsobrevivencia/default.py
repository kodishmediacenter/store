# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/OMundo2osBrasileiros
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

from addon.common.addon import Addon

addonID = 'plugin.video.addonsobrevivencia'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
base    = ''

icon1 = "https://yt3.ggpht.com/-ltZggK6cUTw/AAAAAAAAAAI/AAAAAAAAAAA/BqTxvylOH1o/s176-c-k-no-mo-rj-c0xffffff/photo.jpg"
icon2 = "https://yt3.ggpht.com/-WpF4lZbxLdI/AAAAAAAAAAI/AAAAAAAAAAA/LzqrIPoOWm0/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
icon3 = "https://yt3.ggpht.com/-Ocd7fw5BC1U/AAAAAAAAAAI/AAAAAAAAAAA/iyh9xwFbTiw/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
icon4 = "https://yt3.ggpht.com/-LEHgv6dRQM8/AAAAAAAAAAI/AAAAAAAAAAA/8FVK_JqMcH8/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
icon5 = "https://yt3.ggpht.com/-wBaLDtb7QaM/AAAAAAAAAAI/AAAAAAAAAAA/jd2I8OC85Rg/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
icon6 = "https://yt3.ggpht.com/-n1k_GG9VN58/AAAAAAAAAAI/AAAAAAAAAAA/nquhQmNx13k/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
icon7 = "https://yt3.ggpht.com/-a8e4OKk4uOw/AAAAAAAAAAI/AAAAAAAAAAA/QXZU6zXwiQ0/s100-c-k-no-mo-rj-c0xffffff/photo.jpg" 
icon8 = "https://yt3.ggpht.com/-qavheHvTXU4/AAAAAAAAAAI/AAAAAAAAAAA/4bTYPTJPk1g/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
icon9 = "https://yt3.ggpht.com/-CprYIzjnAbg/AAAAAAAAAAI/AAAAAAAAAAA/XN2PkpjDoYU/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
icon10 ="https://yt3.ggpht.com/-2bDvdO5mQYw/AAAAAAAAAAI/AAAAAAAAAAA/pOAZ17n54M4/s100-c-k-no-mo-rj-c0xffffff/photo.jpg" 
icon11 ="https://yt3.ggpht.com/-4wHpi-9VXD4/AAAAAAAAAAI/AAAAAAAAAAA/kVi894f9o8I/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"
icon12 ="https://yt3.ggpht.com/-G25ekd1g864/AAAAAAAAAAI/AAAAAAAAAAA/k4wSoDBe80o/s100-c-k-no-mo-rj-c0xffffff/photo.jpg"

id001 = "channel/UC_zcJcSmGbuu3K_KFknYzfw/"
id002 = "channel/UCqIybq9X4xs3taXQB6nik3Q/"
id003 = "channel/UCAdrvZwaKlAB13u3lxlZ1hQ/" 
id004 = "user/Sobrevivencialismo/"
id005 = "user/giutoniolo/"
id006 = "user/PescaVideos/"
id007 = "channel/UCo0Xub6B1Z3as-hrfuxsbTQ/"
id008 = "channel/UC48K5h2t2hTDAkfRcJkNbYA/"
id009 = "user/WildWayTube/"
id010 = "user/paulocinti1/"
id011 = "user/campdoarmamento/"
id012 = "user/blogtocandira/"

def run():
    plugintools.log("plugin.video.addonsobrevivencia.run")
    
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def main_list(params):
		plugintools.log("addonsobrevivencia ===> " + repr(params))


                plugintools.add_item(title = "Guia do Sobrevivente"              , url = "plugin://plugin.video.youtube/"+id001+"", thumbnail = icon1, folder = True)
                plugintools.add_item(title = "Sobrevivente Urbano"              , url = "plugin://plugin.video.youtube/"+id002+"", thumbnail = icon2, folder = True)
                plugintools.add_item(title = "O Collector"              , url = "plugin://plugin.video.youtube/"+id003+"", thumbnail = icon3, folder = True)
                plugintools.add_item(title = "Sobrevivencialismo"              , url = "plugin://plugin.video.youtube/"+id004+"", thumbnail = icon4, folder = True)
                plugintools.add_item(title = "Giuliano Toniolo"              , url = "plugin://plugin.video.youtube/"+id005+"", thumbnail = icon5, folder = True)
                plugintools.add_item(title = "Pesca Vídeos"              , url = "plugin://plugin.video.youtube/"+id006+"", thumbnail = icon6, folder = True)
                plugintools.add_item(title = "Pesca Dicas"              , url = "plugin://plugin.video.youtube/"+id007+"", thumbnail = icon7, folder = True)
                plugintools.add_item(title = "Pesca, Atividades Mateiras e Sobrevivencia"       , url = "plugin://plugin.video.youtube/"+id008+"", thumbnail = icon8, folder = True)
                plugintools.add_item(title = "Celso Cavallini"              , url = "plugin://plugin.video.youtube/"+id009+"", thumbnail = icon9, folder = True)
                plugintools.add_item(title = "Paulo cinti"              , url = "plugin://plugin.video.youtube/"+id010+"", thumbnail = icon10, folder = True)
                plugintools.add_item(title = "Instituto DEFESA Brasil"              , url = "plugin://plugin.video.youtube/"+id011+"", thumbnail = icon11, folder = True)
                plugintools.add_item(title = "Tocandira Atividades Mateiras"       , url = "plugin://plugin.video.youtube/"+id012+"", thumbnail = icon12, folder = True)
      
      
      
       
		
		
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmc.executebuiltin('Container.SetViewMode(500)')
		
run()
