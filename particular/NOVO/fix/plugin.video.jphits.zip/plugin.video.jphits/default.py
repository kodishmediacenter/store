import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

from addon.common.addon import Addon

addonID = 'plugin.video.jphits'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
base    = ''

disco1 = "https://archive.org/download/14AlyUsFollowMe/14AlyUsFollowMe_vbr.m3u"
disco2 = "https://archive.org/download/01NewtonSkyHigh/01NewtonSkyHigh_vbr.m3u"

keyplay = xbmc.Keyboard('', 'Digite 1 a 7: ')
keyplay.doModal()
op = keyplay.getText()	  
	  
if op == "1": 
	xbmc.Player().play(""+disco1+"")

if op == "2": 
	xbmc.Player().play(""+disco2+"")
