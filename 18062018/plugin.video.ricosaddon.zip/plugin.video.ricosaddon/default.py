import plugintools
import xbmcgui
import xbmc
import xbmcplugin
import webbrowser
import os

dialog = xbmcgui.Dialog()
link = dialog.select('Bem Vindo Addon Ricos TV', ['Ao Vivo', 'Canal No Youtube','Whatsapp'])

def run():
    plugintools.log("ricos.run")
    params = plugintools.get_params()
    if params.get("action") is None: main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    plugintools.close_item_list()

if link == 0:
    url = "plugin://plugin.video.f4mTester/?url=http://painel.tvdigitalhd.org:1935/canalricos548/canalricos548/playlist.m3u8&amp;streamtype=HLS"
    xbmc.Player().play(url)

if link == 1:
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.youtube/channel/UCsx3z9zMWDEDZrveqZ4vPbA/)")

if link == 2:
     if xbmc . getCondVisibility ( 'system.platform.android' ) :
         xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://api.whatsapp.com/send?phone=5511988700735' ) )
     else:
        webbrowser . open ( 'https://api.whatsapp.com/send?phone=5511988700735' )
    
    
