# encoding=utf8
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import xbmcgui
import xbmcplugin
import xbmc
import urllib
import urllib2
import urlparse
import json
import xbmcaddon
import os
import re
 
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')
 
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:

    request = urllib2.Request('http://hirayasoftware.com/onair_scrap/countries.php')
    json_data = json.loads(urllib2.urlopen(request).read())

    for data in json_data:
        url = build_url({'mode': 'radios_by_country', 'country': data})
        li = xbmcgui.ListItem(data, iconImage = PATH + '/icon.png')
        li.setInfo(type="Video", infoLabels={"plot": data})
        li.setArt({'fanart': PATH + '/fanart.jpg'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

elif mode[0] == 'radios_by_country':

    request = urllib2.Request('http://hirayasoftware.com/onair_scrap/radios_by_country.php?country=' + args['country'][0].replace(' ','%20'))
    json_data = json.loads(urllib2.urlopen(request).read())

    for data in json_data:
        li = xbmcgui.ListItem('[B]' + data['name'] + '[/B]', iconImage=PATH + '/icon.png')
        li.setInfo(type="Video", infoLabels={ "plot": data['name'], "Title" : '[B]' + data['name'] + '[/B]'})
        li.setArt({ 'poster': PATH + '/icon.png', 'fanart': PATH + '/fanart.jpg' })
        li.setProperty("IsPlayable","true")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='http://radio.garden/api/content/listen/' + data['link'] + '/channel.mp3', listitem=li, isFolder=False)
 
xbmcplugin.endOfDirectory(addon_handle)