import base64
import xbmc
import xbmcgui
import os

api = "ewogICAgImtleXMiOiB7CiAgICAgICAgImRldmVsb3BlciI6IHt9LCAKICAgICAgICAicGVyc29uYWwiOiB7CiAgICAgICAgICAgICJhcGlfa2V5IjogIkFJemFTeUFBVzg0QnpTLVRXVTNIazVLNVBrOVZ1N2p1N2pDVUE2cyIsIAogICAgICAgICAgICAiY2xpZW50X2lkIjogIjEwMDY3NzczNTYxOTktZGF1cG4xbWlpbHBrdTlzNHVhMWliaTU5ZDU3NnJxczMiLCAKICAgICAgICAgICAgImNsaWVudF9zZWNyZXQiOiAiVTlfYndzR2pKcVpWZFdJSTJUNnA2SnA2IgogICAgICAgIH0KICAgIH0KfQ=="
json_file = "special://home/userdata/addon_data/plugin.video.youtube/api_keys.json"
api_wr = base64.b64decode(api) 
api_file  = os.path.join(xbmc.translatePath(json_file).decode("utf-8"))
youutube_file = open(api_file, 'w')
youutube_file.write(api_wr)

dialog = xbmcgui.Dialog()
dialog.textviewer('[B]Api aplicado com Sucesso[/B]', 'Renicie o Kodi caso n�o funcione aplica denovo. Caso Daily Limit gere vc mesmo a chaves seguindo o video https://bit.ly/geradordeapi')

