import base64
import xbmc
import os

api = "ewogICAgImtleXMiOiB7CiAgICAgICAgImRldmVsb3BlciI6IHt9LCAKICAgICAgICAicGVyc29uYWwiOiB7CiAgICAgICAgICAgICJhcGlfa2V5IjogIkFJemFTeUF6dTA3Zk5kZkx4WE4wY2M3V0Iyb0Z0cEI3dmtNS3pYbyIsIAogICAgICAgICAgICAiY2xpZW50X2lkIjogIjI5NDIzOTMzNTUxMy10ZjBmNnVxYWU2aXBrOW4yZzk2bnBrcmJsZW4wazY3ZyIsIAogICAgICAgICAgICAiY2xpZW50X3NlY3JldCI6ICJ2R3JUZjZZT3VFYXA3SWtPNno5QzJVZ3giCiAgICAgICAgfQogICAgfQp9"
json_file = "special://home/userdata/addon_data/plugin.video.youtube/api_keys.json"
api_wr = base64.b64decode(api) 
api_file  = os.path.join(xbmc.translatePath(json_file).decode("utf-8"))
youutube_file = open(api_file, 'w')
youutube_file.write(api_wr)


