import xbmcaddon

MainBase = 'http://bit.ly/igorlistaN'
addon = xbmcaddon.Addon('plugin.video.igorlista')