# Biblioteca converte links emulado para real

def getserver(link):


    if link[0:32] == "http://fabiolmg.local/RCServer01":
        naomi = "http://dtm07lg7h1lzn.cloudfront.net/RedeCanais/RedeCanais/RCServer01"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:33] == "http://fabiolmg.local/RCFServer01":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCFServer1"
        tam = len(link)
        linkf = ""+naomi+""+link[33:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer02":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCServer02"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    

    if link[0:33] == "http://fabiolmg.local/RCFServer02":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCFServer2"
        tam = len(link)
        linkf = ""+naomi+""+link[33:tam]+""
        return linkf

    if link[0:33] == "http://fabiolmg.local/RCFServer03":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCFServer3"
        tam = len(link)
        linkf = ""+naomi+""+link[33:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer03":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCServer03"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:33] == "http://fabiolmg.local/RCFServer04":
        naomi = "http://dtm07lg7h1lzn.cloudfront.net/RedeCanais/RedeCanais/RCFServer4"
        tam = len(link)
        linkf = ""+naomi+""+link[33:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer04":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCServer04"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
 
    
    if link[0:32] == "http://fabiolmg.local/RCServer05":
        naomi = "http://dtm07lg7h1lzn.cloudfront.net/RedeCanais/RedeCanais/RCServer05"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf


    if link[0:32] == "http://fabiolmg.local/RCServer06":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCServer06"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer07":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCServer07"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer08":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCServer08"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer09":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCServer09"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer10":
        naomi = "http://d1253j4wvfqwc4.cloudfront.net/RedeCanais/RedeCanais/RCServer10"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer11":
        naomi = "http://d3gzc7tmh6x71j.cloudfront.net/RedeCanais/RCServer11"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    if link[0:32] == "http://fabiolmg.local/RCServer12":
        naomi = "http://dtm07lg7h1lzn.cloudfront.net/RedeCanais/RedeCanais/RCServer12"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf
    
    if link[0:32] == "http://fabiolmg.local/RCServer13":
        naomi = "http://dtm07lg7h1lzn.cloudfront.net/RedeCanais/RedeCanais/RCServer13"
        tam = len(link)
        linkf = ""+naomi+""+link[32:tam]+""
        return linkf

    
