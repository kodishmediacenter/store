# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import os
import sys
import time
#import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
from random import randint
import base64
import naomi
import re
import urllib2

addonID = 'plugin.video.southpark24hrs'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

addonfolder = local.getAddonInfo('path')
resfolder = addonfolder + '/resources/'

def Update(): #creditos ao cube play pela biblioteca
	Path = xbmc.translatePath("special://home/addons/"+addonID+"/naomi.py").decode("utf-8")
        fonte = urllib2.urlopen( "https://raw.githubusercontent.com/kodishmediacenter/store/master/naomi.py" ).read().replace('\n','')
	py = Path
	file = open(py, "w")
	file.write(fonte)
	file.close()
	
tunel = "UmVmZXJlcj1odHRwOi8vd3d3LnJlZGVjYW5haXMuY29tLmJyLw=="
ftunel = base64.b64decode(tunel)

addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), addonID)

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

m3u =  os.path.join(addon_data_dir, "files.m3u")

file = open(""+m3u+"","w")
file.close


eps = randint(1,277)
ieps = 145 - eps

eng2sp = {1:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP01.mp4|"+ftunel+"",
2:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP02.mp4|"+ftunel+"",
3:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP03.mp4|"+ftunel+"",
4:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP04.mp4|"+ftunel+"",
5:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP05.mp4|"+ftunel+"",
6:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP06.mp4|"+ftunel+"",
7:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP07.mp4|"+ftunel+"",
8:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP08.mp4|"+ftunel+"",
9:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP09.mp4|"+ftunel+"",
10:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP10.mp4|"+ftunel+"",
11:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP11.mp4|"+ftunel+"",
12:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP12.mp4|"+ftunel+"",
13:"http://fabiolmg.local/RCServer01/videos/STHPRKT01EP13.mp4|"+ftunel+"",
14:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP01.mp4|"+ftunel+"",
15:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP02.mp4|"+ftunel+"",
16:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP03.mp4|"+ftunel+"",
17:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP04.mp4|"+ftunel+"",
18:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP05.mp4|"+ftunel+"",
19:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP06.mp4|"+ftunel+"",
20:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP07.mp4|"+ftunel+"",
21:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP08.mp4|"+ftunel+"",
22:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP09.mp4|"+ftunel+"",
23:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP10.mp4|"+ftunel+"",
24:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP11.mp4|"+ftunel+"",
25:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP12.mp4|"+ftunel+"",
26:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP13.mp4|"+ftunel+"",
27:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP14.mp4|"+ftunel+"",
28:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP15.mp4|"+ftunel+"",
29:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP16.mp4|"+ftunel+"",
30:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP17.mp4|"+ftunel+"",
31:"http://fabiolmg.local/RCServer01/videos/STHPRKT02EP18.mp4|"+ftunel+"",
32:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP01.mp4|"+ftunel+"",
33:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP02.mp4|"+ftunel+"",
34:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP03.mp4|"+ftunel+"",
35:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP04.mp4|"+ftunel+"",
36:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP05.mp4|"+ftunel+"",
37:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP06.mp4|"+ftunel+"",
38:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP07.mp4|"+ftunel+"",
39:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP08.mp4|"+ftunel+"",
40:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP09.mp4|"+ftunel+"",
41:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP10.mp4|"+ftunel+"",
42:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP11.mp4|"+ftunel+"",
43:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP12.mp4|"+ftunel+"",
44:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP13.mp4|"+ftunel+"",
45:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP14.mp4|"+ftunel+"",
46:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP15.mp4|"+ftunel+"",
47:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP16.mp4|"+ftunel+"",
48:"http://fabiolmg.local/RCServer01/videos/STHPRKT03EP17.mp4|"+ftunel+"",
49:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP01.mp4|"+ftunel+"",
50:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP02.mp4|"+ftunel+"",
51:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP03.mp4|"+ftunel+"",
52:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP04.mp4|"+ftunel+"",
53:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP05.mp4|"+ftunel+"",
54:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP06.mp4|"+ftunel+"",
55:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP07.mp4|"+ftunel+"",
56:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP08.mp4|"+ftunel+"",
57:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP09.mp4|"+ftunel+"",
58:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP10.mp4|"+ftunel+"",
59:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP11.mp4|"+ftunel+"",
60:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP12.mp4|"+ftunel+"",
61:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP13.mp4|"+ftunel+"",
62:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP14.mp4|"+ftunel+"",
63:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP15.mp4|"+ftunel+"",
64:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP16.mp4|"+ftunel+"",
65:"http://fabiolmg.local/RCServer01/videos/STHPRKT04EP17.mp4|"+ftunel+"",
66:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP01.mp4|"+ftunel+"",
67:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP02.mp4|"+ftunel+"",
68:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP03.mp4|"+ftunel+"",
69:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP04.mp4|"+ftunel+"",
70:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP05.mp4|"+ftunel+"",
71:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP06.mp4|"+ftunel+"",
72:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP07.mp4|"+ftunel+"",
73:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP08.mp4|"+ftunel+"",
74:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP09.mp4|"+ftunel+"",
75:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP10.mp4|"+ftunel+"",
76:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP11.mp4|"+ftunel+"",
77:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP12.mp4|"+ftunel+"",
78:"http://fabiolmg.local/RCServer01/videos/STHPRKT05EP13.mp4|"+ftunel+"",
79:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP01.mp4|"+ftunel+"",
80:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP02.mp4|"+ftunel+"",
81:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP03.mp4|"+ftunel+"",
82:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP04.mp4|"+ftunel+"",
83:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP05.mp4|"+ftunel+"",
84:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP06.mp4|"+ftunel+"",
85:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP07.mp4|"+ftunel+"",
86:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP08.mp4|"+ftunel+"",
87:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP09.mp4|"+ftunel+"",
88:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP09.mp4|"+ftunel+"",
89:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP11.mp4|"+ftunel+"",
90:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP12.mp4|"+ftunel+"",
91:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP13.mp4|"+ftunel+"",
92:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP14.mp4|"+ftunel+"",
93:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP15.mp4|"+ftunel+"",
94:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP16.mp4|"+ftunel+"",
95:"http://fabiolmg.local/RCServer01/videos/STHPRKT06EP17.mp4|"+ftunel+"",
96:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP01.mp4|"+ftunel+"",
97:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP02.mp4|"+ftunel+"",
98:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP03.mp4|"+ftunel+"",
99:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP03.mp4|"+ftunel+"",
100:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP04.mp4|"+ftunel+"",
101:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP05.mp4|"+ftunel+"",
102:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP06.mp4|"+ftunel+"",
103:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP07.mp4|"+ftunel+"",
104:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP08.mp4|"+ftunel+"",
105:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP09.mp4|"+ftunel+"",
106:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP10.mp4|"+ftunel+"",
107:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP11.mp4|"+ftunel+"",
108:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP12.mp4|"+ftunel+"",
109:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP13.mp4|"+ftunel+"",
110:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP14.mp4|"+ftunel+"",
111:"http://fabiolmg.local/RCServer01/videos/STHPRKT07EP15.mp4|"+ftunel+"",
112:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP01.mp4|"+ftunel+"",
113:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP02.mp4|"+ftunel+"",
114:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP03.mp4|"+ftunel+"",
115:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP04.mp4|"+ftunel+"",
116:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP05.mp4|"+ftunel+"",
117:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP06.mp4|"+ftunel+"",
118:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP07.mp4|"+ftunel+"",
119:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP08.mp4|"+ftunel+"",
120:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP09.mp4|"+ftunel+"",
121:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP10.mp4|"+ftunel+"",
122:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP11.mp4|"+ftunel+"",
123:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP12.mp4|"+ftunel+"",
124:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP13.mp4|"+ftunel+"",
125:"http://fabiolmg.local/RCServer01/videos/STHPRKT08EP14.mp4|"+ftunel+"",
126:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP01.mp4|"+ftunel+"",
127:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP02.mp4|"+ftunel+"",
128:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP03.mp4|"+ftunel+"",
129:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP04.mp4|"+ftunel+"",
130:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP05.mp4|"+ftunel+"",
131:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP06.mp4|"+ftunel+"",
132:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP07.mp4|"+ftunel+"",
133:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP08.mp4|"+ftunel+"",
134:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP09.mp4|"+ftunel+"",
135:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP10.mp4|"+ftunel+"",
136:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP11.mp4|"+ftunel+"",
137:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP12.mp4|"+ftunel+"",
138:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP13.mp4|"+ftunel+"",
139:"http://fabiolmg.local/RCServer01/videos/STHPRKT09EP14.mp4|"+ftunel+"",
140:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP01.mp4|"+ftunel+"",
141:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP02.mp4|"+ftunel+"",
142:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP03.mp4|"+ftunel+"",
143:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP04.mp4|"+ftunel+"",
144:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP05.mp4|"+ftunel+"",
145:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP06.mp4|"+ftunel+"",
146:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP07.mp4|"+ftunel+"",
147:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP08.mp4|"+ftunel+"",
148:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP09.mp4|"+ftunel+"",
149:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP10.mp4|"+ftunel+"",
150:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP11.mp4|"+ftunel+"",
151:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP12.mp4|"+ftunel+"",
152:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP13.mp4|"+ftunel+"",
153:"http://fabiolmg.local/RCServer01/videos/STHPRKT10EP14.mp4|"+ftunel+"",
154:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP01.mp4|"+ftunel+"",
155:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP02.mp4|"+ftunel+"",
156:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP03.mp4|"+ftunel+"",
157:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP04.mp4|"+ftunel+"",
158:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP05.mp4|"+ftunel+"",
159:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP06.mp4|"+ftunel+"",
160:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP07.mp4|"+ftunel+"",
161:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP08.mp4|"+ftunel+"",
162:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP09.mp4|"+ftunel+"",
163:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP10.mp4|"+ftunel+"",
164:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP11.mp4|"+ftunel+"",
165:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP12.mp4|"+ftunel+"",
166:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP13.mp4|"+ftunel+"",
167:"http://fabiolmg.local/RCServer01/videos/STHPRKT11EP14.mp4|"+ftunel+"",
168:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP01.mp4|"+ftunel+"",
169:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP02.mp4|"+ftunel+"",
170:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP03.mp4|"+ftunel+"",
171:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP04.mp4|"+ftunel+"",
172:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP05.mp4|"+ftunel+"",
173:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP06.mp4|"+ftunel+"",
174:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP07.mp4|"+ftunel+"",
175:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP08.mp4|"+ftunel+"",
176:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP09.mp4|"+ftunel+"",
177:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP10.mp4|"+ftunel+"",
178:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP11.mp4|"+ftunel+"",
179:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP12.mp4|"+ftunel+"",
180:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP13.mp4|"+ftunel+"",
181:"http://fabiolmg.local/RCServer01/videos/STHPRKT12EP14.mp4|"+ftunel+"",
182:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP01.mp4|"+ftunel+"",
183:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP02.mp4|"+ftunel+"",
184:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP03.mp4|"+ftunel+"",
185:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP04.mp4|"+ftunel+"",
186:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP05.mp4|"+ftunel+"",
187:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP06.mp4|"+ftunel+"",
188:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP07.mp4|"+ftunel+"",
189:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP08.mp4|"+ftunel+"",
190:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP09.mp4|"+ftunel+"",
191:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP10.mp4|"+ftunel+"",
192:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP11.mp4|"+ftunel+"",
193:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP12.mp4|"+ftunel+"",
194:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP13.mp4|"+ftunel+"",
195:"http://fabiolmg.local/RCServer01/videos/STHPRKT13EP14.mp4|"+ftunel+"",
196:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP01.mp4|"+ftunel+"",
197:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP02.mp4|"+ftunel+"",
198:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP03.mp4|"+ftunel+"",
199:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP04.mp4|"+ftunel+"",
200:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP05.mp4|"+ftunel+"",
201:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP06.mp4|"+ftunel+"",
202:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP07.mp4|"+ftunel+"",
203:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP08.mp4|"+ftunel+"",
204:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP09.mp4|"+ftunel+"",
205:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP10.mp4|"+ftunel+"",
206:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP11.mp4|"+ftunel+"",
207:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP12.mp4|"+ftunel+"",
208:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP13.mp4|"+ftunel+"",
209:"http://fabiolmg.local/RCServer01/videos/STHPRKT14EP14.mp4|"+ftunel+"",
210:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP01.mp4|"+ftunel+"",
211:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP02.mp4|"+ftunel+"",
212:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP03.mp4|"+ftunel+"",
213:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP04.mp4|"+ftunel+"",
214:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP05.mp4|"+ftunel+"",
215:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP06.mp4|"+ftunel+"",
216:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP07.mp4|"+ftunel+"",
217:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP08.mp4|"+ftunel+"",
218:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP09.mp4|"+ftunel+"",
219:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP10.mp4|"+ftunel+"",
220:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP11.mp4|"+ftunel+"",
221:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP12.mp4|"+ftunel+"",
222:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP13.mp4|"+ftunel+"",
223:"http://fabiolmg.local/RCServer01/videos/STHPRKT15EP14.mp4|"+ftunel+"",
224:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP01.mp4|"+ftunel+"",
225:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP02.mp4|"+ftunel+"",
226:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP03.mp4|"+ftunel+"",
227:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP04.mp4|"+ftunel+"",
228:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP05.mp4|"+ftunel+"",
229:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP06.mp4|"+ftunel+"",
230:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP07.mp4|"+ftunel+"",
231:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP08.mp4|"+ftunel+"",
232:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP09.mp4|"+ftunel+"",
233:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP10.mp4|"+ftunel+"",
234:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP11.mp4|"+ftunel+"",
235:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP12.mp4|"+ftunel+"",
236:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP13.mp4|"+ftunel+"",
237:"http://fabiolmg.local/RCServer02/ondemand/STHPRKT16EP14.mp4|"+ftunel+"",
238:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP01.mp4|"+ftunel+"",
239:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP02.mp4|"+ftunel+"",
240:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP03.mp4|"+ftunel+"",
241:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP04.mp4|"+ftunel+"",
242:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP05.mp4|"+ftunel+"",
243:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP06.mp4|"+ftunel+"",
244:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP07.mp4|"+ftunel+"",
245:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP08.mp4|"+ftunel+"",
246:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP09.mp4|"+ftunel+"",
247:"http://fabiolmg.local/RCServer08/ondemand/STHPRKT17EP10.mp4|"+ftunel+"",
248:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP01.mp4|"+ftunel+"",
249:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP02.mp4|"+ftunel+"",
250:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP03.mp4|"+ftunel+"",
251:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP04.mp4|"+ftunel+"",
252:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP05.mp4|"+ftunel+"",
253:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP06.mp4|"+ftunel+"",
254:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP07.mp4|"+ftunel+"",
255:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP08.mp4|"+ftunel+"",
256:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP09.mp4|"+ftunel+"",
257:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT18EP10.mp4|"+ftunel+"",
258:"http://fabiolmg.local/RCServer09/ondemand/STHPRKT19EP01.mp4|"+ftunel+"",
259:"http://fabiolmg.local/RCServer10/ondemand/STHPRKT19EP02.mp4|"+ftunel+"",
260:"http://fabiolmg.local/RCServer10/ondemand/STHPRKT19EP03.mp4|"+ftunel+"",
261:"http://fabiolmg.local/RCServer10/ondemand/STHPRKT19EP04.mp4|"+ftunel+"",
262:"http://fabiolmg.local/RCServer10/ondemand/STHPRKT19EP05.mp4|"+ftunel+"",
263:"http://fabiolmg.local/RCServer10/ondemand/STHPRKT19EP06.mp4|"+ftunel+"",
264:"http://fabiolmg.local/RCServer10/ondemand/STHPRKT19EP07.mp4|"+ftunel+"",
265:"http://fabiolmg.local/RCServer10/ondemand/STHPRKT19EP08.mp4|"+ftunel+"",
266:"http://fabiolmg.local/RCServer10/ondemand/STHPRKT19EP09.mp4|"+ftunel+"",
267:"http://fabiolmg.local/RCServer10/ondemand/STHPRKT19EP10.mp4|"+ftunel+"",
268:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP01.mp4|"+ftunel+"",
269:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP02.mp4|"+ftunel+"",
270:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP03.mp4|"+ftunel+"",
271:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP04.mp4|"+ftunel+"",
272:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP05.mp4|"+ftunel+"",
273:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP06.mp4|"+ftunel+"",
274:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP07.mp4|"+ftunel+"",
275:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP08.mp4|"+ftunel+"",
276:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP09.mp4|"+ftunel+"",
277:"http://fabiolmg.local/RCServer11/ondemand/STHPRKT20EP10.mp4|"+ftunel+"",
}

        
def rodar24horas(eps):
        for j in range(eps,(eps+25)):
                file = open(""+m3u+"","a")
                eps = naomi.getserver(eng2sp[j])
                file.write(eps)
                file.write("\n")
                file.close
        
        xbmc.Player().play(""+m3u+"")


Update()
rodar24horas(eps)


