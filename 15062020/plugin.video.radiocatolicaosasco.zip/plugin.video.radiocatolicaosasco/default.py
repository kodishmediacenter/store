import xbmc



link = "http://74.63.192.157:8306/live?1591707703718"
xbmc.Player().play(""+link+"")

