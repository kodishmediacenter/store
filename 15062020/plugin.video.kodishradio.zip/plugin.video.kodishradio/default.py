import xbmc



link = "http://193.46.199.65:8000/listen.m3u?sid=1"
xbmc.Player().play(""+link+"")

